<?php
$name='DejaVuSansCondensed-Bold';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 262148,
  'FontBBox' => '[-962 -415 1778 1174]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='/data/home/pdcisinl/public_html/azullserver/wp-content/plugins/azull/mpdf/ttfonts/DejaVuSansCondensed-Bold.ttf';
$TTCfontID='0';
$originalsize=653336;
$sip=false;
$smp=true;
$BMPselected=true;
$fontkey='dejavusanscondensedB';
$panose=' 0 0 2 b 8 6 3 6 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>