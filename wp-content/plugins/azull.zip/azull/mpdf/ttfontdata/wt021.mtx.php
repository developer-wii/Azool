<?php
$name='HanWangLiSuMedium';
$type='TTF';
$desc=array (
  'Ascent' => 811,
  'Descent' => -207,
  'CapHeight' => 811,
  'Flags' => 4,
  'FontBBox' => '[-44 -219 1043 838]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$up=-107;
$ut=49;
$ttffile='/data/home/pdcisinl/public_html/azullserver/wp-content/plugins/azull/mpdf/ttfonts/wt021.ttf';
$TTCfontID='0';
$originalsize=8456040;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='wt021';
$panose=' 0 0 2 0 5 0 0 0 0 0 0 0';
$haskerninfo=false;
$unAGlyphs=false;
?>