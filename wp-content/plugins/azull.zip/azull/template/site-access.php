<div class="webgroup zindex" id="access">
        <table class='form-table access'>
	    <tr>
                <th><label for=site_url>URL</label></th>
		<td>
                    <input type="text" name="access[url]" size="80" value="<?php echo(isset($access['url'])) ? esc_html( $access['url'] ) : ''; ?>" />
                    <br>
                    <span class='description'>Enter a valid client website URL eg.(http://www.azull.info)</span>
		 </td>
	    </tr>
	    <tr>
                 <th><label>Key</label></th>
		<td>
                    <input type="text" name="access[key]"  size="80"  autocomplete="off" value="<?php echo ( isset($access['key']) && esc_html( $access['key'])!='') ? esc_html( $access['key'] ) : wp_generate_password( 71, false ) ?>" />
                    <br>		  
                    <span class='description'>Enter/Change api key(system generates a 71 character long api key will be saved on client website to provide access server api.)</span>
		</td>
	    </tr>

	    <tr>
                <th></th>
		<td style="background: none repeat scroll 0 0 hsl(0, 0%, 95%);padding: 10px 0 0 150px;">
                    <label for="site_username">Username</label>
                    <input type="text" name="access[name]"  size="30" value="<?php echo (isset($access['name'])) ? esc_html( $access['name'] ) : ''; ?>" />
                    </td>
	    </tr>
	    <tr>
                <th></th>
		<td style="background: none repeat scroll 0 0 hsl(0, 0%, 95%);padding: 0 0 10px 150px;">
                    <label>Password</label>
                    <input type="password" name="access[pass]"  size="30"  autocomplete="off" value="<?php echo (isset($access['pass'])) ? esc_html( $access['pass'] ) :''; ?>" />

		</td>
	    </tr>
	    <tr>
                <th><label for=site_url>Milchimp API key</label></th>
		<td>
                    <input type="text" name="access[mailChipKey]" size="80" value="<?php echo(isset($access['mailChipKey'])) ? esc_html( $access['mailChipKey'] ) : ''; ?>" />
                    <br>
                    <span class='description'><?php _e('Enter a valid client Milchimp API key','azull'); ?></span>
		 </td>
	    </tr>
	    <tr>
                <th><label for=site_url>Milchimp List ID</label></th>
		<td>
                    <input type="text" name="access[mailListID]" size="40" value="<?php echo(isset($access['mailListID'])) ? esc_html( $access['mailListID'] ) : ''; ?>" />
                    <br>
                    <span class='description'><?php _e('Enter a valid milchimp list ID. All the subscriber will be added to this list.','azull'); ?></span>
		 </td>
	    </tr>
	</table>
    </div>