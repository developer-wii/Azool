<script src="<?php echo WP_PLUGIN_URL ?>/azull/js/tinymce/tinymce.min.js"></script>
<script>
jQuery(document).ready(function($) {
	
	/* get added page order
	   Date:- 16-july-2016
	*/
	
	var  blockval = jQuery('#block').val();
	var  siteid = jQuery('#siteId').val();  
	jQuery("#block").show();
	var layout= jQuery('input[name=layout]:checked', '#post').val();
    if(blockval && siteid){
		 var data = {
		      'action': 'loadPageDropDown',     
		      'ID' : blockval,
		      'site_id':siteid,
		      'layout':layout
		   };
		   jQuery.post(ajaxurl, data, function(response) {                
		      jQuery("#display_id").html(response);
		  }); 
    }
    jQuery('#post input').on('change', function() {
    	var layout= jQuery('input[name=layout]:checked', '#post').val();
    	if(layout == 'mobile'){
           jQuery("#block").hide();
    	}else{
    		jQuery("#block").show();
    	}
    	
    	var  blockval = jQuery('#block').val();
	    var  siteid = jQuery('#siteId').val();  
         var data = {
		      'action': 'loadPageDropDown',     
		      'ID' : blockval,
		      'site_id':siteid,
		      'layout':layout
		   };
		   jQuery.post(ajaxurl, data, function(response) {                
		      jQuery("#display_id").html(response);
		  }); 
    });



    jQuery( "#post-body" ).removeClass( "columns-2" );
    jQuery("#upload_logo").click(function(){
       
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
	    window.send_to_editor = function(html) {

        imgurl = jQuery('img',html).attr('src');
        
        jQuery("input[name = 'general[logo]']").val(imgurl);
        jQuery("#logo").attr('src',imgurl);
        tb_remove();
        return false; 
    }
    });
    
   
    tinymce.init({
    selector: "textarea.textareaEditor",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });

    jQuery("#upload_favicon").click(function(){
       
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
	
            window.send_to_editor = function(html) {

                imgurl = jQuery('img',html).attr('src');
                jQuery("input[name = 'general[favicon]']").val(imgurl);
                jQuery("#favicon").attr('src',imgurl) ;
                tb_remove();
                return false; 
        }
    });

     
    
 }); 

</script>
<style>#side-sortables{display:none!important;}</style>
<?php  global $aj_config, $post;  $languages = qtranxf_getSortedLanguages();
$general = get_post_meta($post->ID,'general',true);
$lng = get_post_meta($post->ID,'language',true);


?>
 <script type="text/javascript">//<![CDATA[
			function header_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#header_language_{$lang}').hide();"; endforeach; ?>
				jQuery('#header_language_'+lang).show();
			}
		//]]>
</script>
 <script type="text/javascript">//<![CDATA[
			function epc_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#epc_language_{$lang}').hide();"; endforeach; ?>
				jQuery('#epc_language_'+lang).show();
			}
		//]]>
</script>
<script type="text/javascript">//<![CDATA[
			function footer_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#footer_language_{$lang}').hide();"; endforeach; ?>
				jQuery('#footer_language_'+lang).show();
			}
		//]]>
</script>

<script type="text/javascript">//<![CDATA[
			function mail_signature_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#email_signature_{$lang}').hide();"; endforeach; ?>
				jQuery('#email_signature_'+lang).show();
			}
		//]]>
</script>

<script type="text/javascript">//<![CDATA[
			function club_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#club_{$lang}').hide();"; endforeach; ?>
				jQuery('#club_'+lang).show();
			}
		//]]>
</script>
<script type="text/javascript">//<![CDATA[
			function info_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#info_{$lang}').hide();"; endforeach; ?>
				jQuery('#info_'+lang).show();
			}
		//]]>
</script>

<script type="text/javascript">//<![CDATA[
			function website_msg(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#website_msg_{$lang}').hide();"; endforeach; ?>
				jQuery('#website_msg_'+lang).show();
			}
		//]]>
</script>

<script type="text/javascript">//<![CDATA[
			function emailContent_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#emailContent_{$lang}').hide();"; endforeach; ?>
				jQuery('#emailContent_'+lang).show();
			}
		//]]>
</script>



<div  id="general" class="webgroup">
	<table>

	    <tr>
                <th><label>Currency </label></th>
		<td>
		    <label style="text-align: right;line-height: 39px; padding: 5px;"><?php _e("Symbols","azull");?>:</label><input type="text" size="3" name="general[csymbols]"class=""  value="<?php echo (isset($general['csymbols']) && $general['csymbols']) ? $general['csymbols'] :'';?>" />
		    <label style="text-align: right;ine-height: 39px; padding: 5px;"><?php _e("Exchange rate:","azull");?></label><input style="text-align: right;" type="text" name="general[cxchange]"  class=""  value="<?php echo (isset($general['cxchange']) && $general['cxchange']) ? $general['cxchange'] :'';?>" />
		    <!--select style="width: 20%; ">
			    <option  value="fa fa-btc" class="fa fa-btc"></option>
			    <option  value="fa fa-jpy" class="fa fa-jpy"></option>
			    <option  value="fa fa-usd" class="fa fa-usd"></option>
			    <option  value="fa fa-eur" class="fa fa-eur"></option>
			    <option  value="fa fa-gbp" class="fa fa-gbp"></option>
			    <option  value="fa fa-ils" class="fa fa-ils"></option>
			    <option  value="fa fa-rub" class="fa fa-rub"></option>
			    <option  value="fa fa-try" class="fa fa-try"></option>
                            <option  value="fa fa-inr" class="fa fa-inr"></option>
                           
                        </select-->
	       </td>                
	    </tr>
	    <tr>
                <th><label><?php _e("Website header","azull");?></label></th>
		<td class="website-header">
                  
                <div style="margin: 5px;     text-align: right;" class="epc_language-switcher">
		<?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:header_switch_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div>
                </div>
                    <div class="website-header-bottom">
                        <div  class="logo">
                            <img style="width: 115px;height: 100px; display: block;" id="logo" src="<?php echo (isset($general['logo'])) ? $general['logo'] :'';?>" />
                            <input type="hidden" name="general[logo]"  value="<?php echo (isset($general['logo'])) ? $general['logo'] :'';?>">
                            <input class="button" id="upload_logo" value="<?php (isset($general['logo'])) ?_e("Change logo","azull"):_e("Add logo","azull") ;?>" />
                            
                        </div>
                        <div  class="social">
                            <ul>
                                <li><input type="text" name="general[f]"  value="<?php echo (isset($general['f'])) ? $general['f'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/f.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[t]" value="<?php echo (isset($general['t'])) ? $general['t'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/t.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[g]" value="<?php echo (isset($general['g'])) ? $general['g'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/g.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[in]" value="<?php echo (isset($general['in'])) ? $general['in'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/in.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[yt]" value="<?php echo (isset($general['yt'])) ? $general['yt'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/yt.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[em]" value="<?php echo (isset($general['em'])) ? $general['em'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/em.jpeg') no-repeat scroll 1px 3px #fff;"></li>
                            </ul>
                        </div>
                        <div  class="menue">
			    <?php $menus = get_terms( 'nav_menu', array( 'hide_empty' => false )); ?>
                            <select name="general[mheader]"  style="width: 206px;">
                                <option value=''>select menue</option>
                                 <?php foreach ($menus as $menu ):?>                               
				    <option value="<?php echo $menu->term_id; ?>" <?php echo (isset($general['mheader']) && $general['mheader']==$menu->term_id)?'selected':'';?>><?php echo $menu->name; ?></option>                           
			        <?php endforeach;?>                         
                            </select>
                            <?php foreach($languages as $lang): ?>
                            <div id="header_language_<?php echo $lang ?>"  <?php echo (($lang!='en') ? 'style="display:none"' :'');?>>
                                <input name="general[wptitle][<?php echo $lang;?>]" type="text" placeholder="<?php _e('Website title','azull')?>" value="<?php echo (isset($general['wptitle'][$lang])) ? $general['wptitle'][$lang] :'';?>">
                                <input name="general[wptagline][<?php echo $lang;?>]" type="text" placeholder="<?php _e('Website tag line','azull')?>" value="<?php echo (isset($general['wptagline'][$lang])) ? $general['wptagline'][$lang] :'';?>">
                            </div>        
                            <?php endforeach; ?>
                            <div class="favicon">
                            <img width="32" height="32"  id="favicon" src="<?php echo (isset($general['favicon'])) ? $general['favicon'] :'';?>" />    
                            <input type="hidden"name="general[favicon]" value="<?php echo (isset($general['favicon'])) ? $general['favicon'] :'';?>">
                            <input class="button"  id="upload_favicon" value="<?php (isset($general['favicon'])) ?_e("Change favicon","azull"): _e("Add favicon","azull");?>" />
                            </div>
                            
                        </div>
                    </div> 
		</td>
                
	    </tr>
            <tr>
                
                <th><label>Website country</label></th>
		<td>
		    <?php			    
			    $countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
			   
			    if ( !empty( $countries) && !is_wp_error( $countries) ){
					$html .="<select  title='Select country'  style=' margin: 0 0 0 50px;width:225px;'   name='general[remoteCountry]'>";                                       
					$html .= "<option  selected>Select country</option>";
					foreach ($countries as $country):
					        $html .= "<option value='".$country->term_id."' ".((isset($general['remoteCountry']) && $country->term_id==$general['remoteCountry'])? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$country->name)."</option>";
					endforeach;
					
					     $html .="</select>";
					}else{
					     $html .="<select style=' margin: 0 0 0 50px;width:225px;'    name='general[remoteCountry]'  multiple>";
					     $html .= "<option value='' disabled selected>Select Country</option>";
					     $html .="</select>";
				}
				 echo $html;
				$html ='';
				?>
		</td>
                
	    </tr>

	    
            <tr>
                <th><label>Defatul language</label></th>
		<td><ul class="lang">
                    <?php global $q_config; foreach($languages as $lang): ?>
                     <li><img  src="<?php echo WP_PLUGIN_URL ?>/azull/flags/<?php echo $q_config['flag'][$lang] ?>"><input type="radio" name="language[d]" value="<?php echo $lang; ?>" <?php echo (isset($lng['d']) && ($lng['d']==$lang)  ? "checked" : ""); ?> /><?php echo  $q_config['language_name'][$lang] ?></li>
                    <?php endforeach; ?>
                    </ul>
		</td>
                
	    </tr>
            <tr>
                <th><label>Active language</label></th>
		<td><ul class="lang">
		    <?php foreach($languages as $lang): ?>
                     <li><img  src="<?php echo WP_PLUGIN_URL ?>/azull/flags/<?php echo $q_config['flag'][$lang] ?>"><input type="checkbox" name="language[a][<?php echo  $lang; ?>]" value="<?php echo $lang ?>" <?php echo (isset($lng['a'][$lang]) && ($lng['a'][ $lang]==$lang) ? "checked" :""); ?> /><?php echo  $q_config['language_name'][$lang] ?></li>
                    <?php endforeach; ?>
                    </ul>
		</td>                
	    </tr>
	    <tr>
            <th><label>Phone Number</label></th>
			<td>
			    <input type="text"  name="general[phoneNumber]" value="<?php echo (isset($general['phoneNumber']))? $general['phoneNumber']:'';?>" />
			</td>
	    </tr>
        <tr>
                <th><label>Home Page Layout</label></th>
		<td><ul class="lang">
                     <li>
                     <input type="radio" name="general[homeLayout]" value="1" <?php echo (isset($general['homeLayout']) && ($general['homeLayout']==1)  ? "checked" : ""); ?> />Left</li>
                     <li>
                     <input type="radio" name="general[homeLayout]" value="2" <?php echo (isset($general['homeLayout']) && ($general['homeLayout']==2)  ? "checked" : ""); ?> />Center</li>
                     <li>
                     <input type="radio" name="general[homeLayout]" value="3" <?php echo (isset($general['homeLayout']) && ($general['homeLayout']==3)  ? "checked" : ""); ?> />Right</li>
                    </ul>
		</td>
                
	    </tr>

     
    <tr>
            <th><label>Interest Rate</label></th>
			<td>
			    <input type="text"  name="general[interestRate]" value="<?php echo (isset($general['interestRate']))? $general['interestRate']:'';?>" />&nbsp;%
			</td>
	    </tr>
	    <tr>
                <th><label><?php _e('Carasole block','azull');?></label></th>
		<td>
		    <div style="width:100%; ">
			<div style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);margin: 0 ;padding:0;width: 100%;">			
			<?php			    
			    $countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
			  
			   if ( !empty($countries) && !is_wp_error( $countries ) ){
				    	$html .="<select title='Select country' style='width:225px;' taxonomy='country' id='property_meta_country' >";                                       
					$html .= "<option value='' selected='selected'>--</option>";
					
					$assigned_terms = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
					
					foreach ($countries as $countrie):
					$html .= "<option value='".$countrie->term_id."'>".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";
					endforeach;
					
					$html .="</select>";
				 }else{
					$html .="<select title='Select country' style='width:225px;' taxonomy='country' id='property_meta_country'>";
                                        $html .= "<option value='' selected='selected'>--</option>";
					$html .="</select>";
				}
				$html .="<select title='Select region' style='width:225px;' taxonomy='region' id='property_meta_region' name='property_meta_essential[provinces]'>";
                                $html .= "<option  selected='selected'>--</option>";
				$html .="</select><a title='Add selected region' class='add-button' href='JavaScript:void(0);' id='region-add'>+</a>";
				
				$html .="<select title='Select province' style='width:225px;' taxonomy='provinces' id='property_meta_province' name='property_meta_essential[provinces]'>";
                                $html .= "<option  selected='selected'>--</option>";
				$html .="</select><a title='Add selected provinces' class='add-button' href='JavaScript:void(0);' id='province-add'>+</a>";
				
				$html .="<select title='Select place' style='width:225px;' taxonomy='place' id='property_meta_place' name='property_meta_essential[provinces]'>";
                                $html .= "<option  selected='selected'>--</option>";
				$html .="</select><a title='Add selected place' class='add-button' href='JavaScript:void(0);' id='place-add'>+</a>"; 
				$html  .="<div style='width:100%;' id='carasoleBlock'><ul data-id='".$post->ID."'>";
				
				$carasoleBlocks = json_decode(get_post_meta($post->ID,'_carasoleBlock',true),true);
				
				if(isset($carasoleBlocks)){
				    foreach($carasoleBlocks as $carasoleBlock){
					$text ="";
					if($carasoleBlock['taxonomy']='region'){
					    $term = get_term_by('id', (int)$carasoleBlock['term'], 'region');
					    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
					     
					    $country = get_term_by('id', (int)$taxonomy_meta['country'], 'country');
					    $text .="Country : ".qtranxf_use(qtranxf_getLanguage(),$country->name)."<br>";
					     
					    $text .="Region : ". qtranxf_use(qtranxf_getLanguage(),$term->name)."<br>";
					}elseif($carasoleBlock['provinces']='provinces'){
					    $term = get_term_by('id', (int)$carasoleBlock['term'], 'provinces');
					    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
					     
					    $country = get_term_by('id', (int)$taxonomy_meta['country'], 'country');
					    $text .="Country : ".qtranxf_use(qtranxf_getLanguage(),$country->name)."<br>";
					     
					    $region = get_term_by('id', (int)$taxonomy_meta['Region'], 'region');
					    $text .="Region : ".qtranxf_use(qtranxf_getLanguage(),$region->name)."<br>";
					     
					    $text .="Provinces : ". qtranxf_use(qtranxf_getLanguage(),$term->name)."<br>";
					    
					}elseif($carasoleBlock['provinces']='place'){
					    $term = get_term_by('id', (int)$carasoleBlock['term'], 'place');
					    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
					     
					    $country = get_term_by('id', (int)$taxonomy_meta['country'], 'country');
					    $text .="Country : ".qtranxf_use(qtranxf_getLanguage(),$country->name)."<br>";
					     
					    $region = get_term_by('id', (int)$taxonomy_meta['Region'], 'region');
					    $text .="Region : ".qtranxf_use(qtranxf_getLanguage(),$region->name)."<br>";
					    
					    $provinces = get_term_by('id', (int)$taxonomy_meta['province'], 'provinces');
					    $text .=" Provinces : ".qtranxf_use(qtranxf_getLanguage(),$provinces->name)."<br>";					     
					    
					    $text .="Place : ". qtranxf_use(qtranxf_getLanguage(),$term->name)."<br>";
					}else{}
					$html  .="<li   taxonomy='".$carasoleBlock['taxonomy']."' term='".$carasoleBlock['term']."'>".$text."<span >-</span></li>";
				    }
				}
				$html  .="</ul></div>";
				echo $html;
				?>
			</div>

			    
		    <br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
		    <span class="description"> Note: Depending region/provinces/place assignment home page property carasole block will be shown. Block should be multiple of 3.
		    </span>
		    </div>		 

		    
		</td>                
	    </tr>
	    <tr>
                <th><label>Access</label></th>
		<td>
                    <input type="checkbox" name="general[backend]"   value="1" />&nbsp; Enable backend access.
                    <br>		  
                    <span class='description'>Allow wordpress backend access on client website.</span>
		</td>
                
	    </tr>
	    

            <tr>
                <th><label>Website Footer</label></th>
		<td class="website-footer">
		    
		<div class="website-footer-bottom">
		<input style="float: right;" type="text" name="general[greenlink]" placeholder="<?php _e('Green certificate link','azull'); ?>" value="<?php echo(isset($general[greenlink])) ?$general[greenlink]:''; ?>"/>
		<?php $menus = get_terms( 'nav_menu', array( 'hide_empty' => false )); ?>
                            <select style="float:right; width: 206px;" name="general[mfooter]" >
                                <option value=''>select menue</option>
                                 <?php foreach ($menus as $menu ):?>                               
				    <option value="<?php echo $menu->term_id; ?>" <?php echo (isset($general['mfooter']) && $general['mfooter']==$menu->term_id)?'selected':'';?>><?php echo $menu->name; ?></option>                           
			        <?php endforeach;?>                         
                            </select>
	        </div>		    
		</td>
                
	    </tr>
	    <tr>
                <th><img src="<?php echo WP_PLUGIN_URL ?>/azull/images/salesforce.png"/></th>
		<td class="website-footer">
		        <div style="width: 230px; float: left;">
		        <input style="width: 230px" type="text"  name="general[oid]" value="<?php echo (isset($general['oid']))? $general['oid']:'';?>" /><br/>
			<span class="description" style="display: inline-block;width: 230px;clear: both;"> Set <strong>Salesforce web-to-lead form</strong>  oid.
			</span>
			</div>
			<div style="width: 725px;float: right;font-style: italic;font-size: 12px;line-height: 16px;">
			    Check "How to create web-to-lead form? <a target="_blank" href="https://help.salesforce.com/apex/HTViewHelpDoc?id=setting_up_web-to-lead.htm&language=en">here</a>. Paste the oid from the form you have created. The form should contain following fields <strong>title, url,first name, last-name, email, phone,zip and description</strong>. Azull form will be mapped with it and data will be sent on your salesforce account. You don't need to set return url.
			</div>
		</td>
                
	    </tr>
	    <tr>
                <th><img title="Analytic script" src="<?php echo WP_PLUGIN_URL ?>/azull/images/js.png"/></label></th>
		<td class="website-footer">		    
			<textarea style="width:100%;background: hsl(0, 0%, 95%);" rows="10" name="general[formjs]"><?php echo (isset($general['formjs']))? $general['formjs']:'';?></textarea>	    
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			<span class="description"> Note: Don't forget to incude script tags and replace shorthand "$" with "jQuery". JS will be included on all azull thanks page.
			</span>
		</td>
                
	    </tr>
	    
	    
	    <tr>
                <th><label><?php _e('Email signature','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:mail_signature_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="email_signature_<?php echo $lang ?>"  <?php echo (($lang!='en') ? 'style="display:none"' :'');?>>
			<textarea  class="textareaEditor" id="textareaeditor_<?php echo $lang ?>" style="width:100%;background: hsl(0, 0%, 95%);" rows="10" name="general[emailSignature][<?php echo $lang;?>]"><?php echo (isset($general['emailSignature'][$lang]))? $general['emailSignature'][$lang]:'';?></textarea>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>
	    <tr>
                <th><label><?php _e('Azull club','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="epc_language-switcher">
		 
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:club_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="club_<?php echo $lang ?>"  <?php echo (($lang!='en') ? 'style="display:none"' :'');?>>
		    
			<textarea class="textareaEditor"  style="width:100%;background: hsl(0, 0%, 95%);" rows="6" name="general[azullClub][<?php echo $lang;?>]"><?php echo (isset($general['azullClub'][$lang]))? $general['azullClub'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed AULL CLUB','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>
	    <tr>
                <th><label><?php _e('Property info request','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;text-align: right;" class="epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:info_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="info_<?php echo $lang ?>"  <?php echo (($lang!='en') ? 'style="display:none"' :'');?>>
		    
		    
			<?php /*<textarea clsss="textareaEditor" id="general[infoContent][<?php echo $lang;?>];" style="width:100%;background: hsl(0, 0%, 95%);" rows="6" name="general[infoContent][<?php echo $lang;?>]"><?php echo (isset($general['infoContent'][$lang]))? $general['infoContent'][$lang]:'';?></textarea> */
		      wp_editor( "test", 23); ?> 
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed request info popup box.','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>	    
	    
	    <tr>
                <th><label><?php _e('Property send email','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:emailContent_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="emailContent_<?php echo $lang ?>"  <?php echo (($lang!='en') ? 'style="display:none"' :'');?>>
			<textarea style="width:100%;background: hsl(0, 0%, 95%);" rows="3" name="general[emailContentTop][<?php echo $lang;?>]"><?php echo (isset($general['emailContentTop'][$lang]))? $general['emailContentTop'][$lang]:'';?></textarea>
			<textarea style="width:100%;background: hsl(0, 0%, 95%);" rows="3" name="general[emailContentBottom][<?php echo $lang;?>]"><?php echo (isset($general['emailContentBottom'][$lang]))? $general['emailContentBottom'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed send email popup box.','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>

        <tr>
                <th><label><?php _e('Welcome message','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:website_msg('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="website_msg_<?php echo $lang ?>"  <?php echo (($lang!='en') ? 'style="display:none"' :'');?>>
		    
		    
			<textarea clsss="textareaEditor" style="width:100%;background: hsl(0, 0%, 95%);" rows="6" name="general[welcome_message][<?php echo $lang;?>]"><?php echo (isset($general['welcome_message'][$lang]))? $general['welcome_message'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed website popup box.','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>


         <tr>
                <th><label>Website layout</label></th>
         
         <td>
<input type="hidden" name="siteID" id="siteId" value="<?php echo $_GET['post'];?>">
  <input type="radio" id="mob"checked="checked" value="desktop" name="layout">Desktop&nbsp;<input type="radio" id="desktop"  name="layout" value="mobile">	Mobile &nbsp; &nbsp;&nbsp;&nbsp;<select name="block" id="block" onchange="return loadpages(this.value,<?php echo $_GET['post']?>);">
                   <option value="main_block">Main Block</option>
                   <option value="side_block">Side Block</option>
                </select> 

         </td>
         
	    </tr>
        <tr>
         <td></td>
         <td id="display_id"></td>
        </tr>

	   
	</table>  
    </div>
    <style>
  
	#normal-sortables .postbox .submit {
	    background: 0 0;
	    border: 0;
	    float: left;
	    padding: 5px 2%;
	    margin: 0;
	    width: 95.6%;
	    text-align: right;
	    background: #000;
	    margin: 2px;
	    }
    </style>
    