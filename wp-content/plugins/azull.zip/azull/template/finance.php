<?php
defined('ABSPATH') or die("No script kiddies please!");
$default= get_option('azullsettings', false);
if (isset($default)) $default= $default['financial'];
global $post;
?>

<div class="finance-right">        
    <script>
        jQuery(document).ready(function($) {            
            jQuery(".meta_sale_price").change(function() {   
                    if ((jQuery(this).val() == '')) {                        
                        jQuery(this).trigger('keyup');
                    }               
            });	    
	    loadaFinincialData('<?php echo $post->ID; ?>'); //method is def.. in azull.js
        });
    </script>
    <table id="finance_override" class='form-table financial_data'> </table>
    <p class="info">.....</p>        
</div>

<div class="finance-left">
    <h4> <?php echo __('Additional Details','azull'); ?> </h4>
    <table class='form-table financial_data'>
        <tr>
            <td><label> <?php echo __('Agent','azull'); ?> </label>
                <select id="activate_agent" name='property_meta_finance[agent]'>
                    <option value=''>&nbsp;</option>
                    <?php
                    $terms = get_terms('agent', array('parent' => 0, 'orderby' => 'slug', 'hide_empty' => false));
		            $assigned_agent = wp_get_post_terms($post->ID, 'agent', array("fields" => "ids"));

                     foreach ($terms as $term):
                        $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
                        $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';
                        $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : '';
                        ?>
                        <option value='<?php echo $term->term_id; ?>' data-subtitle="<?php echo 'Phone :' . $phone . '<br/>Email:' . $email; ?>"  data-left="<img src='<?php echo z_taxonomy_image_url($term->term_id); ?>'>" data-right="<?php echo $term->term_id; ?>" <?php echo ((isset($assigned_agent[0]) && $term->term_id == $assigned_agent[0]) ? 'selected' : '') ?>><?php echo $term->name; ?></option>
                    <?php endforeach; ?>
                </select>
                <br><span  class='description'> <?php echo __('Select Property agent','azull'); ?> </span>
                <input value="activate selectator" id="activate_agent_click" type="hidden">        
            </td>
        </tr>
        <tr>
            <td><label> <?php echo __('Comission','azull'); ?> </label>
                <input  style='width: 10%;' id="commissionPer" onkeydown="calculateCommission(this);" onkeyup="calculateCommission(this);" size="4" name='property_meta_finance[commissionPer]' vaue="<?php echo (get_post_meta($post->ID,"_commissionPer",true)) ? get_post_meta($post->ID,"_commissionPer",true):""; ?>" type="text"/> <input  style='width: 48%;' id="commissionAmount" name='property_meta_finance[commissionAmount]'size="10"  readonly value="" type="text"/> 
                <br><span  class='description'> <?php echo __('Agent Commission','azull'); ?> </span>
                
            </td>
        </tr>

        <tr>
            <td><label> <?php echo __('*Status','azull'); ?> </label>
                
                <?php $terms = get_terms('status', array('parent' => 0, 'orderby' => 'name', 'hide_empty' => false));
		                $assigned_status = get_post_meta ($post->ID, "_status",true);
                //$assigned_status = wp_get_post_terms($post->ID, 'status', array("fields" => "ids"));
                //  $assigned_status =
                //echo $assigned_status[0] ." ==". $term->term_id
               //print_r($assigned_status);
		?>
                <select name='property_meta_finance[fstatus]'>
                    <option value='0'>--</option>
                    <?php  foreach ($terms as $term): ?>
                    <option value='<?php echo $term->term_id; ?>' <?php echo ((isset($assigned_status) && $assigned_status== $term->term_id) ? 'selected' : '');?>><?php echo $term->name; ?></option>
                    <?php  endforeach; ?>
                </select>
   
                <br><span  class='description'> <?php echo __('Select Financial status','azull'); ?> </span>
            </td>
        </tr>
        <tr>
	   
            <td><label> <?php echo __('*Old price','azull'); ?> </label><input autocomplete='off' class="decimal"  maxlength="12" type='text' name='property_meta_finance[oldPrice]'  value='<?php echo (get_post_meta($post->ID,"_oldPrice",true)) ? get_post_meta($post->ID,"_oldPrice",true):""; ?>' /><br><span class='description'> <?php echo __('Enter old price.','azull'); ?> </span></td>
        </tr>
        <tr>
            <td><label> <?php echo __('Reservation amount','azull'); ?> </label><input autocomplete='off' class="decimal"  maxlength="12" type='text' name='property_meta_finance[reservationAmount]'  value='<?php echo (get_post_meta($post->ID,"_reservationAmount",true)) ? get_post_meta($post->ID,"_reservationAmount",true):""; ?>' /><br><span class='description'> <?php echo __('Enter reservation amount.','azull'); ?> </span></td>
        </tr>
        <tr>
            <td><label> <?php echo __('Monthly charges','azull'); ?> </label><input autocomplete='off' class="decimal"  maxlength="12" type='text' name='property_meta_finance[monthlyCharges]'  value='<?php echo (get_post_meta($post->ID,"_monthlyCharges",true)) ? get_post_meta($post->ID,"_monthlyCharges",true):""; ?>' /><br><span  class='description'><?php echo __('Enter monthly charges.','azull'); ?> </span></td>
        </tr>
        <tr>
            <td><label> <?php echo __('More information','azull'); ?> </label><textarea name='property_meta_finance[moreInformation]'><?php echo (get_post_meta($post->ID,"_moreInformation",true)) ? get_post_meta($post->ID,"_moreInformation",true):""; ?></textarea></td>
        </tr>
    </table>   
    <p class="info"><?php echo __('Field marked * will be accessiable on client website.','azull'); ?> </p>
</div>
