<?php


$html .='<ul class="azull-pdf">';
   if(!empty($ids))
        foreach($ids as $id){
	    $post = get_post($id);
		 /*code for add title and content if not define in language*/
	    $title_array = qtranxf_split($post->post_title); 
	  
	    if(isset($title_array) && !empty($title_array)){
	       if($title_array[$_POST['lng']]!=''){
	        $title=substr(qtranxf_use($_POST['lng'],$post->post_title),0,55);
	       }else{   
	         $title=getTitleContent($id,$_POST['lng']);
	       }
	     }
	    
	    $html .='<li>
		    <a class="azull-pdf-link" target="_blank" rel="noindex,nofollow" download href="" data-id="'.$id.'" data-link="'.get_site_url().'" title="' . $title.'"><img width="128" title="' . get_the_title($id).'"  alt="azull pdf" src="'.AZULL_URL.'images/pdf.png">
		    <h5>Ref.'.get_post_meta($id,'_nreal_id',true).'</h5>
		    <h5>'.azull_short_text($title,false,25).'</h5>
		    </a></li>'; 
	}
$html .='</ul>';

$html .='<script>
		jQuery(document).ready(function() {		
		    setpdflink();
		});
		jQuery("#azull-template").change(function(){
		   setpdflink();
		});
		jQuery("#azull-language").change(function(){
		   setpdflink();
		});
		jQuery("#azull-clients").change(function(){
		   setpdflink();
		});
		function setpdflink(){
                    jQuery("#azullprint").hide();
		    jQuery("a.azull-pdf-link").each(function() {  
			 var _href= jQuery(this).attr("data-link");
			 _href = _href + "?format=pdf";
			_href = _href + "&tpl=" + jQuery("#azull-template").val();
			_href = _href + "&lng=" + jQuery("#azull-language").val();			
			_href = _href + "&clnt=" + jQuery("#azull-clients").val();			
			_href = _href + "&id=" + jQuery(this).attr("data-id");
			jQuery(this).attr("href",_href);
		     });
		    
		}
		</script>';
return $html;

?>