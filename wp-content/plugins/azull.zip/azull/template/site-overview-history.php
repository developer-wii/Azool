<div class="webgroup" id="overview_history">
   <div class='wraper wraper-s'>
     <?php  //azull_nsp_NewStatPressMain(); ?>
     <style>.row-actions{visibility: visible!important;}</style>
   </div>
</div>
<style>.wraper-s{background: none repeat scroll 0 0 hsla(0, 0%, 0%, 0) !important;  position: relative !important;  top: 0 !important;}</style>
