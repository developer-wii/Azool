<?php defined('ABSPATH') or die("No script kiddies please!");?>
<script src="<?php echo WP_PLUGIN_URL ?>/azull/js/tinymce/tinymce.min.js"></script>
<script>
jQuery(document).ready(function(){
    loadaTax();
    tinymce.init({
    selector: "textarea.textareaEditor",
    mode : "textareas",
    menubar : false,
       plugins: ["advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
              "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
              "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"],
       toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
       toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor code",
       toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons |ltr rtl | spellchecker | visualchars visualblocks nonbreaking pagebreak restoredraft",
       menubar: false,
       toolbar_items_size: 'small',
        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });
});

</script>
<form method="post" > 

<div style="background:#fff; padding: 20px;float:left;">
<h1 style="border-bottom: 1px dotted hsl(0, 0%, 80%);margin: 10px 0;padding: 0 0 10px;text-align: center;"><?php _e('Azull Settings','azull'); ?></h1>
	<table>
	    <tr>
                <th style="vertical-align: top; background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left;   width: 300px;"><label><?php _e('Currency','azull'); ?></label></th>
		<td style="background: none repeat scroll 0 0 hsl(0, 0%, 93%)"><input autocomplete='off'  maxlength="4" size="4" type='text' name='azull[currency]'  value="<?php echo (isset($azull['currency']) ? $azull['currency'] :''); ?>" />
                </td>
           </tr>
	    <tr>
                <th style="vertical-align: top; background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left;   width: 300px;"><label><?php _e('Default country','azull'); ?></label></th>
		<td style="background: none repeat scroll 0 0 hsl(0, 0%, 93%)">
		    <?php
		                $html = '';
				$countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
				if ( !empty($countries) && !is_wp_error( $countries ) ){
				     $html .="<select style='width:150px;height:30px;margin-top: 2px;'  class='SlectCountry'  name='azull[c]'>";                                       
				     $html .= "<option value='' disabled selected>Select country</option>";
					  foreach ($countries as $countrie):					
					       $cflag =(!empty($assigned_terms) && in_array($countrie->term_id,$assigned_terms))? $countrie->term_id:'';
					       $html .= "<option value='".$countrie->term_id."' ".((isset($azull['c']) && $azull['c']==$countrie->term_id)? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";
					   endforeach;					
					  $html .="</select>";
				     }else{
					  $html .="<select id='property_meta_country' class='SlectCountry' name='azull[c]'>";
					  $html .= "<option disabled selected>Select country</option>";
					  $html .="</select>";
				}
				echo $html;
				$html='';
		    ?>
                </td>
           </tr>
           <th style="vertical-align: top; background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left; "><label><?php _e('Financial constant','azull'); ?></label></th>
		<td>
		        <div id="azullTax" style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px; text-align: left; width: 97.6%;">
			    <?php
				$countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));		
				$regions=get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
				$provinces=get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));
				$places=get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));
			       
				if ( !empty($countries) && !is_wp_error( $countries ) ){
				     $html .="<select style='width:150px;height:30px;margin-top: 2px;'  class='SlectCountry' id='property_meta_country'  name='country'>";                                       
				     $html .= "<option value='' disabled selected>Select country</option>";
					  foreach ($countries as $countrie):					
					       $cflag =(!empty($assigned_terms) && in_array($countrie->term_id,$assigned_terms))? $countrie->term_id:'';
					       $html .= "<option value='".$countrie->term_id."' ".((!empty($assigned_terms) && in_array($countrie->term_id,$assigned_terms))? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";
					   endforeach;					
					  $html .="</select>";
				     }else{
					  $html .="<select id='property_meta_country' class='SlectCountry' name='country'>";
					  $html .= "<option disabled selected>Select country</option>";
					  $html .="</select>";
				}
				
				if ( !empty( $regions ) && !is_wp_error( $regions ) ){
				     $assigned_terms = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
				     $html .="<select style='width:150px;height:30px;margin-top: 2px;' id='property_meta_region'  class='SlectRegion' name='region'>";                                        
					  $html .= "<option value='' disabled selected>Select region</option>";					
					  foreach ($regions as $region):					
					       $taxonomy_meta = get_option('azull_taxonomy_meta_'.$region->term_id);
					       $rflag =(!empty($assigned_terms) && in_array($region->term_id,$assigned_terms))? $region->term_id:'';
							      
					       if($cflag!='' && $taxonomy_meta['country']==$cflag ){						
						    $html .= "<option value='".$region->term_id."' ".((!empty($assigned_terms) && in_array($countrie->term_id,$assigned_terms))? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";
					       }elseif($cflag==''){	
						    $html .= "<option value='".$region->term_id."' ".((!empty($assigned_terms) && in_array($countrie->term_id,$assigned_terms))? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";
					       }
					  endforeach;
					  $html .="</select>";
				}else{
					  $html .="<select style='width:150px;height:30px;margin-top: 2px;'  class='SlectRegion'  id='property_meta_region' class='SlectRegion' name='region'>";
					  $html .= "<option value='' disabled selected>Select region</option>";
					  $html .="</select>";
				}
				
				if ( !empty( $provinces ) && !is_wp_error( $provinces ) ){
				     $html .="<select id='property_meta_province' style='width:150px;margin-top: 2px;'  class='SlectProvince' name='province'>";                                       
				     $html .= "<option disabled selected>Select province</option>";
				     $assigned_terms = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
							      
				     foreach ($provinces as $province):
					  $taxonomy_meta = get_option('azull_taxonomy_meta_'.$province->term_id);
					  $pflag =(!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? $province->term_id:'';
							      
					       if($cflag !='' && $rflag!='' && $taxonomy_meta['country']==$cflag && $taxonomy_meta['region']==$rflag ){
						    $html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
					       }elseif($cflag!='' && $taxonomy_meta['country']==$cflag){
						    $html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
					       }elseif($rflag!='' && $taxonomy_meta['region']==$rflag){
								      $html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
					       }elseif($cflag=='' && $rflag==''){
						    $html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
					       }					
				     endforeach;
					  $html .="</select>";
				     }else{
					  $html .="<select style='width:150px;height:30px;margin-top: 2px;' class='SlectProvince' id='property_meta_province' name='province'>";
					  $html .= "<option value='' disabled selected>Select province</option>";
					  $html .="</select>";
				     }
				     
				     
				    $html .='</div>';
				    $html .='<table id="taxTable" class="taxTable form-table financial-right"></table>';
				    
				    echo $html; 
			    ?>
			    
			
			
		
              </td>
              </tr>
              <tr>
                <th style="vertical-align: top; background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left; "><label><?php _e('From Email','azull'); ?></label></th>
		<td style="background: none repeat scroll 0 0 hsl(0, 0%, 93%)">
                     <input style="width: 100%;"  type="text" name="azull[from_email]"  value="<?php echo (isset($azull['from_email'])) ? $azull['from_email'] :'';?>" />
                     <span class="description">	
                        <?php
			 //todo:add email validations....
			_e('Enter one email address for property email from section.','azull')?>
		     </span>
		</td>
               <tr>
                <th style="vertical-align: top; background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left; "><label><?php _e('Email signature','azull'); ?></label></th>
		<td>
              <?php
              $html='';		
	      global $aj_config, $post;  $languages = qtranxf_getSortedLanguages();
		
	      echo '<div style="margin: 5px;     text-align: right;" class="epc_language-switcher">';		
	      echo "&nbsp;|&nbsp;";
              
	      foreach($languages as $lang) {
			echo "<a href=\"javascript:emailsignature_switch_lang('".$lang."')\" title='".qtranxf_getLanguageName($lang)."'>".$q_config['language_name'][$lang]."</a>&nbsp|&nbsp;";
		}		
                echo '</div>';
	       $s ='';
               $s .="<script type='text/javascript'>
		//<![CDATA[
			function emailsignature_switch_lang(lang) {
				//Hide all
				";
		foreach($languages as $lang):
		$s .="jQuery('#wp-emailsignature_".$lang."-wrap').hide();";
		endforeach; 
				
		$s .="//Show selected, recount chars
			jQuery('#wp-emailsignature_'+lang+'-wrap').show();
		    }
		//]]>
		</script>";
		echo $s ;
		foreach($languages as $lang) {		
		
		$data =  htmlspecialchars_decode(get_option('emailsignature_'.$lang,false));
		
		if($data!=''){
		   $html=stripslashes($data);
		    
		}
                
                echo '<div id="wp-emailsignature_'.$lang.'-wrap"><textarea style="width:100%;"  class="textareaEditor" rows="15" name="emailsignature_'.$lang.'">'.$html.'</textarea></div>';
		
		}
		echo "
		<script>
		//<![CDATA[
			emailsignature_switch_lang('".$q_config['default_language']."');
		//]]>
		</script>
		";
		$htm ="";
		?>
                <span class="description" style="background: hsl(0, 0%, 93%);padding: 2%;width:98%;display: inline-block;">
                <?php _e('Note:Emaill signature will be added at the bottom of each property emails sent from server. For AZULL CLIENT email signature check site settings.','azull')?>
                </span>
		</td>                
              </tr>
              <tr>
                <th style="vertical-align: top; background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left; "><label><?php _e('PDF Signature','azull'); ?></label></th>
		<td style="background: none repeat scroll 0 0 hsl(0, 0%, 93%)">
                     
                       <?php     echo '<div style="margin: 5px;     text-align: right;" class="epc_language-switcher">';		
                       echo "&nbsp;|&nbsp;";
                       foreach($languages as $lang) {
                               echo "<a href=\"javascript:pdfsignature_switch_lang('".$lang."')\" title='".qtranxf_getLanguageName($lang)."'>".$q_config['language_name'][$lang]."</a>&nbsp|&nbsp;";
                       }		
                       echo '</div>';
                      $s ='';
                      $s .="<script type='text/javascript'>
                       //<![CDATA[
                               function pdfsignature_switch_lang(lang) {
                                       //Hide all
                                       ";
                       foreach($languages as $lang):
                       $s .="jQuery('#wp-pdfsignature_".$lang."-wrap').hide();";
                       endforeach; 
                                       
                       $s .="//Show selected, recount chars
                               jQuery('#wp-pdfsignature_'+lang+'-wrap').show();
                           }
                       //]]>
                       </script>";
                       echo $s ;
                      
                     foreach($languages as $lang) {	
                            $pdfData =  stripslashes(get_option('pdfsignature_'.$lang,false));                            
                            echo '<div id="wp-pdfsignature_'.$lang.'-wrap"><textarea style="width:100%;"  rows="3" name="pdfsignature_'.$lang.'">'.$pdfData.'</textarea></div>';
                     }
                     echo "
                            <script>
                            //<![CDATA[
                                    pdfsignature_switch_lang('".$q_config['default_language']."');
                            //]]>
                            </script>
                      ";
                     $pdfData ="";
                     ?>
                    
                     <span class="description"><?php _e('PDF Signature will be added at the bottom of each pdf page.','azull');?></span>
		</td>
               <tr> 
              
	</table>  
     <p class="submit" style="border-top: 1px dotted hsl(0, 0%, 80%); margin: 10px 0 0;  padding: 10px 0 0; text-align: right;"><input type="submit" name="settings" id="settings" class="button-primary" value="  <?php _e('Save','azull'); ?>  "/></p>
    </div>
</form>