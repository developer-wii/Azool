<div class="webgroup" id="contact">
  <div class='wraper wraper-s'>
     <?php
       //$qickmsg = new Contact_Table();
       //$qickmsg->prepare_items();
       //$qickmsg->display(); 
     ?>
     <style>.row-actions{visibility: visible!important;}</style>
   </div>
</div>
 <style>.wraper-s{background: none repeat scroll 0 0 hsla(0, 0%, 0%, 0) !important;  position: relative !important;  top: 0 !important;}</style>

<?php
class Contact_Table extends WP_List_Table {
    
    
    function __construct(){
     
        global $status;
 
      

        parent::__construct( array(
            'singular'  => __( 'Subscriber', 'azull' ),     //singular name of the listed records
            'plural'    => __( 'Subscriberss', 'zull' ),   //plural name of the listed records
            'ajax'      => false        //does this table support ajax?

         ) );

    //add_action( 'admin_head', array( $this, 'admin_header' ) );            
    //add_action( 'admin_action_subscribers', array('Subscribers_Table','process_bulk_action') );
    }



    function no_items() {
        _e( 'No subscriberss found, dude.' );
    }
    
    function column_default( $item, $column_name ) {
        switch( $column_name ) {
             case 'c-sl':
             case 'c-details':             
             case 'cq-date':
             case 'c-query':
             case 'cr-date':
             case 'c-reply':   
             case 'action':   
                return $item[ $column_name ];
            default:
                return ;//print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
        }
    }


    function get_columns(){

        $columns = array(
            'c-sl'      => __( 'SL', 'azull'  ), 
            'c-details'      => __( 'Details', 'azull'  ),
            'cq-date'      => __( 'Q Date', 'azull'  ),
            'c-query'      => __( 'Query', 'azull'  ),
            'cr-date'      => __( 'R Date', 'azull'  ),
            'c-reply' => __( 'Reply', 'azull' ), 
            'action'        => __( 'Action', 'azull'  ) 
        );
         return $columns;
    }

    function usort_reorder( $a, $b ) {
      // If no sort, default to title
      $orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'subscriberstitle';
      // If no order, default to asc
      $order = ( ! empty($_GET['order'] ) ) ? $_GET['order'] : 'asc';
      // Determine sort order
      $result = strcmp( $a[$orderby], $b[$orderby] );
      // Send final sort direction to usort
      return ( $order === 'asc' ) ? $result : -$result;
    }

   function column_action($item){
     $actions = array(
               'reply'      => sprintf('<a href="#">Reply</a>'),
               'delete'    => sprintf('<a href="#">Delete</a>'),
           );
   
     return sprintf('%1$s %2$s', $item['id'], $this->row_actions($actions));
   }
   
   function prepare_items() {
               global $post;
        $obj = new Xmlrpc_Client($post->ID);
        $request = $obj->get_client_infoRequest(4);
       
        
        $i = count( $request);
        foreach( $request as $info):          
          $q_data[] =array('b-sl' => $i,                          
                          'b-details' =>'Name:'.$info->name.'<br/>Email:'.$info->email.'<br/>Phone:'.$info->phone.'<br/>Zip:'.$info->zip.'<br/>Language:'.$info->language.'<br/>IP:'.$info->ip,
                          'bq-date' => $info->qtime,
                          'b-query' => $info->msg,
                          'br-date' => $info->rtime,
                          'b-reply' => $info->reply,
                           );
          
          $i--;
          
        endforeach;
        $data = $q_data;
      
      $columns  = $this->get_columns();
      $hidden   = array();
     
     // $sortable = $this->get_sortable_columns();
      $this->_column_headers = array( $columns, $hidden, $sortable );
     // $this->process_bulk_action();
      //usort( $data, array( &$this, 'usort_reorder' ) );
      
      
      
      $per_page = 5;
      $current_page = $this->get_pagenum();
      $total_items = count( $data );
    
      // only ncessary because we have sample data
      $this->found_data = array_slice( $data,( ( $current_page-1 )* $per_page ), $per_page );
    
      $this->set_pagination_args( array(
        'total_items' => $total_items,                  //WE have to calculate the total number of items
        'per_page'    => $per_page                     //WE have to determine how many items to show on a page
      ) );
      $this->items = $this->found_data;
      
    }
   function display_tablenav( $which ) {
    if ( 'top' == $which )
    //wp_nonce_field( 'bulk-' . $this->_args['plural'] );
    ?>
      <div class="tablenav <?php echo esc_attr( $which ); ?>">
      <div class="alignleft actions bulkactions">
    <?php $this->bulk_actions( $which ); ?>
    </div>
      <?php
      $this->extra_tablenav( $which );
      $this->pagination( $which );
      ?>
     <br class="clear" />
     </div>
    <?php
    }


} //class