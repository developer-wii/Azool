<script src="<?php echo WP_PLUGIN_URL ?>/azull/js/tinymce/tinymce.min.js"></script>
<script>
jQuery(document).ready(function($) {
    jQuery('#w_m_active_lang_nl').css("font-weight", "bold");
    jQuery('#header_active_lang_nl').css("font-weight", "bold");
    jQuery('#info_active_lang_nl').css("font-weight", "bold");
    jQuery('#email_sign_active_lang_nl').css("font-weight", "bold");
    jQuery('#club_active_lang_nl').css("font-weight", "bold");
    jQuery('#e_c_active_lang_nl').css("font-weight", "bold");
    jQuery('#e_m_active_lang_nl').css("font-weight", "bold");
    jQuery('#e_title_active_lang_nl').css("font-weight", "bold");
    jQuery('#email_txt_active_lang_nl').css("font-weight", "bold");
    jQuery('#infodays_url_active_lang_nl').css("font-weight", "bold");
    jQuery('#infodays_url2_active_lang_nl').css("font-weight", "bold");
    jQuery('#t_c_active_lang_nl').css("font-weight", "bold");
    jQuery('#u_c_active_lang_nl').css("font-weight", "bold");
	/* get added page order
	   Date:- 16-july-2016
	*/
	
	var  blockval = jQuery('#block').val();
	var  siteid = jQuery('#siteId').val();  
	jQuery("#block").show();
	var layout= jQuery('input[name=layout]:checked', '#post').val();
    if(blockval && siteid){
		 var data = {
		      'action': 'loadPageDropDown',     
		      'ID' : blockval,
		      'site_id':siteid,
		      'layout':layout
		   };
		   jQuery.post(ajaxurl, data, function(response) {                
		      jQuery("#display_id").html(response);
		  }); 
    }
    jQuery('#post input').on('change', function() {
    	var layout= jQuery('input[name=layout]:checked', '#post').val();
    	if(layout == 'mobile'){
           jQuery("#block").hide();
    	}else{
    		jQuery("#block").show();
    	}
    	
    	var  blockval = jQuery('#block').val();
	    var  siteid = jQuery('#siteId').val();  
         var data = {
		      'action': 'loadPageDropDown',     
		      'ID' : blockval,
		      'site_id':siteid,
		      'layout':layout
		   };
		   jQuery.post(ajaxurl, data, function(response) {                
		      jQuery("#display_id").html(response);
		  }); 
    });
    /*
    * Date: 02-sep-2016
    * Method: function for get email title by email type
    */
    jQuery('#email_type').on('change', function(){
        var email_type = jQuery("#email_type option:selected").val();
        var siteid = jQuery('#siteId').val();
        if(email_type){
            var data = {
                  'action': 'get_email_title',     
                  'email_type' : email_type,
                  'siteid':siteid
               };
            jQuery.post(ajaxurl, data, function(response) {
                var obj = jQuery.parseJSON(response);

                if(obj!=''){
                    if(obj.email_title!=''){
                        jQuery.each(obj.email_title, function(email_title_id, email_title_val) {
                            if(email_title_val!=''){
                                jQuery("#email_title_text_"+email_title_id).val(email_title_val);
                            }else{
                                jQuery("#email_title_txt_"+email_title_id).val('');
                            }         
                        });
                    }else{
                        jQuery(".email_title_txt").val('');
                    }
                    if(obj.email_txt!=''){
                        jQuery.each(obj.email_txt, function(email_txt_id, email_text_val) {
                            if(email_text_val!='' && email_text_val!='undefined'){
                                tinyMCE.get("email_text_"+email_txt_id).setContent(email_text_val);
                            }else{
                                tinyMCE.get("email_text_"+email_txt_id).setContent('');
                            }         
                        });
                    }else{
                        tinyMCE.get('email_text_en').setContent('');
                        tinyMCE.get('email_text_fr').setContent('');
                        tinyMCE.get('email_text_nl').setContent('');
                    }
                }
            });
        }else{
            jQuery(".email_title_txt").val('');
            tinyMCE.get('email_text_en').setContent('');
            tinyMCE.get('email_text_fr').setContent('');
            tinyMCE.get('email_text_nl').setContent('');
        } 
    });
    /*jQuery('#email_type').on('change', function() {
        var email_type = jQuery("#email_type option:selected").val();
        var siteid = jQuery('#siteId').val();
        if(email_type){
            var data = {
                  'action': 'get_email_title',     
                  'email_type' : email_type,
                  'siteid':siteid
               };
            jQuery.post(ajaxurl, data, function(response) {
                var obj = jQuery.parseJSON(response);
                if(obj!=''){
                    jQuery.each(obj, function(idx, obj) {
                        jQuery("#email_title_text_"+idx).val(obj);           
                    });
                }else{
                    jQuery('.email_title_txt').val('');
                }
            });
        }else{
            jQuery('.email_title_txt').val('');
        } 
    });*/


    jQuery( "#post-body" ).removeClass( "columns-2" );
    jQuery("#upload_logo").click(function(){
       
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
	    window.send_to_editor = function(html) {

        imgurl = jQuery('img',html).attr('src');
        
        jQuery("input[name = 'general[logo]']").val(imgurl);
        jQuery("#logo").attr('src',imgurl);
        tb_remove();
        return false; 
    }
    });

    jQuery("#upload_flag1").click(function(){
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function(html) {
   
        imgurl = jQuery('img',html).attr('src');
        altTag1 = jQuery('img',html).attr('alt');
        jQuery("input[name = 'general[flag1]']").val(imgurl);
        if(imgurl){
           var data = { 
                  'action': 'get_flag_descrption',   
                  'uri' : imgurl
               };
            jQuery.post(ajaxurl, data, function(response) {
                if(response!=''){
                jQuery("input[name = 'general[flag1desc]']").val(response);
                }
            });   
        }
        
        jQuery("#flag1").attr('src',imgurl);
        jQuery("#flag1").attr('alt',altTag1);
        jQuery("input[name = 'general[flag1alt]']").val(altTag1);
        jQuery("#alt1").html(altTag1);
        tb_remove();

        return false; 
    }
    });

    jQuery("#upload_flag2").click(function(){
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
        window.send_to_editor = function(html) {
        imgurl = jQuery('img',html).attr('src');
        altTag2 = jQuery('img',html).attr('alt');
        if(imgurl){
           var data = { 
                  'action': 'get_flag_descrption',   
                  'uri' : imgurl
               };
            jQuery.post(ajaxurl, data, function(response) {
                if(response!=''){
                    jQuery("input[name = 'general[flag2desc]']").val(response);
                }
            });   
        }
        jQuery("input[name = 'general[flag2]']").val(imgurl);
        jQuery("#flag2").attr('src',imgurl);
        jQuery("#flag2").attr('alt',altTag2);
        jQuery("input[name = 'general[flag2alt]']").val(altTag2);
        jQuery("#alt2").html(altTag2);
        tb_remove();
        return false; 
    }
    });
    
   
    tinymce.init({
    selector: "textarea.textareaEditor",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });


    tinymce.init({
    selector: "textarea.welcomeEditor",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });
    tinymce.init({
    selector: "textarea.theEditor",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });

    tinymce.init({
    selector: "textarea.pInfoRequest",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });

    tinymce.init({
    selector: "textarea.expEditor",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });

    tinymce.init({
    selector: "textarea.emailTxtEditor",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });
/*tinymce.init({
    selector: "textarea.trackingCodeEditor",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });*/

   
setTimeout(function(){ jQuery("div.mce-btn > button > i").addClass("mce-ico"); }, 3000);
    jQuery("#upload_favicon").click(function(){
       
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
	
            window.send_to_editor = function(html) {

                imgurl = jQuery('img',html).attr('src');
                jQuery("input[name = 'general[favicon]']").val(imgurl);
                jQuery("#favicon").attr('src',imgurl) ;
                tb_remove();
                return false; 
        }
    });

     
    
 }); 

</script>
<style>#side-sortables{display:none!important;}</style>
<?php  global $aj_config, $post;  $languages = qtranxf_getSortedLanguages();
$general = get_post_meta($post->ID,'general',true);
$altText = get_post_meta($post->ID,'_wp_attachment_image_alt',true);
$lng = get_post_meta($post->ID,'language',true);


?>
 <script type="text/javascript">//<![CDATA[
			function header_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#header_language_{$lang}').hide();"; endforeach; ?>
				jQuery('#header_language_'+lang).show();
                jQuery(".header_epc_language-switcher a").css("font-weight", "normal");
                jQuery('#header_active_lang_' + lang).css("font-weight", "bold");
			}
		//]]>
</script>
 <script type="text/javascript">//<![CDATA[
			function epc_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#epc_language_{$lang}').hide();"; endforeach; ?>
				jQuery('#epc_language_'+lang).show();
			}
		//]]>
</script>
<script type="text/javascript">//<![CDATA[
			function footer_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#footer_language_{$lang}').hide();"; endforeach; ?>
				jQuery('#footer_language_'+lang).show();
			}
		//]]>
</script>

<script type="text/javascript">//<![CDATA[
			function mail_signature_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#email_signature_{$lang}').hide();"; endforeach; ?>
				jQuery('#email_signature_'+lang).show();
                jQuery(".es_epc_language-switcher a").css("font-weight", "normal");
                jQuery('#email_sign_active_lang_' + lang).css("font-weight", "bold");
			}
		//]]>
</script>

<script type="text/javascript">//<![CDATA[
	function club_lang(lang) {
		//Hide all
		<?php foreach($languages as $lang): echo "jQuery('#club_{$lang}').hide();"; endforeach; ?>
		jQuery('#club_'+lang).show();
        jQuery(".club_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#club_active_lang_' + lang).css("font-weight", "bold");
	}
//]]>
</script>
<script type="text/javascript">//<![CDATA[
	function info_lang(lang) {
		//Hide all
		<?php foreach($languages as $lang): echo "jQuery('#info_{$lang}').hide();"; endforeach; ?>
		jQuery('#info_'+lang).show();
        jQuery(".info_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#info_active_lang_' + lang).css("font-weight", "bold");
	}
//]]>
</script>

<script type="text/javascript">
	function website_msg(lang) {
		//Hide all
		<?php foreach($languages as $lang): echo "jQuery('.website_msg_{$lang}').hide();"; endforeach; ?>
		jQuery('.website_msg_'+lang).show();
        jQuery(".wc_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#w_m_active_lang_' + lang).css("font-weight", "bold");
	}
	function tracking_code(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.track_code_{$lang}').hide();"; endforeach; ?>
        jQuery('.track_code_'+lang).show();
        jQuery(".tc_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#t_c_active_lang_' + lang).css("font-weight", "bold");
    }
    function unbounce_code(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.unbounce_code_{$lang}').hide();"; endforeach; ?>
        jQuery('.unbounce_code_'+lang).show();
        jQuery(".uc_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#u_c_active_lang_' + lang).css("font-weight", "bold");
    }
</script>

<script type="text/javascript">
	function  explanation_text(lang) {
		//Hide all
		<?php foreach($languages as $lang): echo "jQuery('.explanation_text_{$lang}').hide();"; endforeach; ?>
		jQuery('.explanation_text_'+lang).show();
        jQuery(".ex_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#e_m_active_lang_' + lang).css("font-weight", "bold");
	}
	function  email_title_text(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.e_title_text_{$lang}').hide();"; endforeach; ?>
        jQuery('.e_title_text_'+lang).show();
        jQuery(".e_title_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#e_title_active_lang_' + lang).css("font-weight", "bold");
    }
    function  email_text(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.email_txt_{$lang}').hide();"; endforeach; ?>
        jQuery('.email_txt_'+lang).show();
        jQuery(".email_txt_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#email_txt_active_lang_' + lang).css("font-weight", "bold");
    }
    function  infodays_url(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.infodays_url_{$lang}').hide();"; endforeach; ?>
        jQuery('.infodays_url_'+lang).show();
        jQuery(".infodays_url_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#infodays_url_active_lang_' + lang).css("font-weight", "bold");
    }
    function  infodays_url2(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.infodays_url2_{$lang}').hide();"; endforeach; ?>
        jQuery('.infodays_url2_'+lang).show();
        jQuery(".infodays_url2_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#infodays_url2_active_lang_' + lang).css("font-weight", "bold");
    }

    function  button1_link_url(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.button1_link_url_{$lang}').hide();"; endforeach; ?>
        jQuery('.button1_link_url_'+lang).show();
        jQuery(".button1_link_url_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#button1_link_url_active_lang_' + lang).css("font-weight", "bold");
    }
    function  button2_link_url(lang) {
        //Hide all
        <?php foreach($languages as $lang): echo "jQuery('.button2_link_url_{$lang}').hide();"; endforeach; ?>
        jQuery('.button2_link_url_'+lang).show();
        jQuery(".button2_link_url_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#button2_link_url_active_lang_' + lang).css("font-weight", "bold");
    }

</script>

<script type="text/javascript">//<![CDATA[
			function emailContent_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#emailContent_{$lang}').hide();"; endforeach; ?>
				jQuery('#emailContent_'+lang).show();
                jQuery(".ec_epc_language-switcher a").css("font-weight", "normal");
                jQuery('#e_c_active_lang_' + lang).css("font-weight", "bold");
			}
		//]]>
</script>



<div  id="general" class="webgroup">
	<table>

	    <tr>
                <th><label>Currency </label></th>
		<td>
		    <label style="text-align: right;line-height: 39px; padding: 5px;"><?php _e("Symbols","azull");?>:</label><input type="text" size="3" name="general[csymbols]"class=""  value="<?php echo (isset($general['csymbols']) && $general['csymbols']) ? $general['csymbols'] :'';?>" />
		    <label style="text-align: right;ine-height: 39px; padding: 5px;"><?php _e("Exchange rate:","azull");?></label><input style="text-align: right;" type="text" name="general[cxchange]"  class=""  value="<?php echo (isset($general['cxchange']) && $general['cxchange']) ? $general['cxchange'] :'';?>" />
		    <!--select style="width: 20%; ">
			    <option  value="fa fa-btc" class="fa fa-btc"></option>
			    <option  value="fa fa-jpy" class="fa fa-jpy"></option>
			    <option  value="fa fa-usd" class="fa fa-usd"></option>
			    <option  value="fa fa-eur" class="fa fa-eur"></option>
			    <option  value="fa fa-gbp" class="fa fa-gbp"></option>
			    <option  value="fa fa-ils" class="fa fa-ils"></option>
			    <option  value="fa fa-rub" class="fa fa-rub"></option>
			    <option  value="fa fa-try" class="fa fa-try"></option>
                            <option  value="fa fa-inr" class="fa fa-inr"></option>
                           
                        </select-->
	       </td>                
	    </tr>
	    <tr>
                <th><label><?php _e("Website header","azull");?></label></th>
		<td class="website-header">
                  
                <div style="margin: 5px;     text-align: right;" class="header_epc_language-switcher">
		<?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:header_switch_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"header_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div>
                </div>
                    <div class="website-header-bottom">
                        <div  class="logo">
                            <img style="width: 115px;height: 100px; display: block;" id="logo" src="<?php echo (isset($general['logo'])) ? $general['logo'] :'';?>" />
                            <input type="hidden" name="general[logo]"  value="<?php echo (isset($general['logo'])) ? $general['logo'] :'';?>">
                            <input class="button" id="upload_logo" value="<?php (isset($general['logo'])) ?_e("Change logo","azull"):_e("Add logo","azull") ;?>" />
                            
                        </div>
                        <div  class="social">
                            <ul>
                                <li><input type="text" name="general[f]"  value="<?php echo (isset($general['f'])) ? $general['f'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/f.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[t]" value="<?php echo (isset($general['t'])) ? $general['t'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/t.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[g]" value="<?php echo (isset($general['g'])) ? $general['g'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/g.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[in]" value="<?php echo (isset($general['in'])) ? $general['in'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/in.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[yt]" value="<?php echo (isset($general['yt'])) ? $general['yt'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/yt.jpeg') no-repeat scroll 1px 1px #fff;"></li>
                                <li><input type="text" name="general[em]" value="<?php echo (isset($general['em'])) ? $general['em'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/em.jpeg') no-repeat scroll 1px 3px #fff;"></li>
                                <li><input type="text" name="general[instagram]" value="<?php echo (isset($general['instagram'])) ? $general['instagram'] :'';?>" style="background: url('<?php echo WP_PLUGIN_URL ?>/azull/images/instagram.jpg') no-repeat scroll 0px 0px #fff;"></li>
                            </ul>
                        </div>
                        <div  class="menue">
			    <?php $menus = get_terms( 'nav_menu', array( 'hide_empty' => false )); ?>
                            <select name="general[mheader]"  style="width: 206px;">
                                <option value=''>select menue</option>
                                 <?php foreach ($menus as $menu ):?>                               
				    <option value="<?php echo $menu->term_id; ?>" <?php echo (isset($general['mheader']) && $general['mheader']==$menu->term_id)?'selected':'';?>><?php echo $menu->name; ?></option>                           
			        <?php endforeach;?>                         
                            </select>
                            <?php foreach($languages as $lang): ?>
                            <div id="header_language_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
                                <input name="general[wptitle][<?php echo $lang;?>]" type="text" placeholder="<?php _e('Website title','azull')?>" value="<?php echo (isset($general['wptitle'][$lang])) ? $general['wptitle'][$lang] :'';?>">
                                <input name="general[wptagline][<?php echo $lang;?>]" type="text" placeholder="<?php _e('Website tag line','azull')?>" value="<?php echo (isset($general['wptagline'][$lang])) ? $general['wptagline'][$lang] :'';?>">
                            </div>        
                            <?php endforeach; ?>
                            <div class="favicon">
                            <img width="32" height="32"  id="favicon" src="<?php echo (isset($general['favicon'])) ? $general['favicon'] :'';?>" />    
                            <input type="hidden"name="general[favicon]" value="<?php echo (isset($general['favicon'])) ? $general['favicon'] :'';?>">
                            <input class="button"  id="upload_favicon" value="<?php (isset($general['favicon'])) ?_e("Change favicon","azull"): _e("Add favicon","azull");?>" />
                            </div>
                            
                        </div>
                    </div> 
		</td>
                
	    </tr>
            <tr>
                
                <th><label>Website country</label></th>
		<td>
		    <?php			    
			    $countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
			   
			    if ( !empty( $countries) && !is_wp_error( $countries) ){
					$html .="<select  title='Select country'  style=' margin: 0 0 0 50px;width:225px;'   name='general[remoteCountry]'>";                                       
					$html .= "<option  selected>Select country</option>";
					foreach ($countries as $country):
					        $html .= "<option value='".$country->term_id."' ".((isset($general['remoteCountry']) && $country->term_id==$general['remoteCountry'])? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$country->name)."</option>";
					endforeach;
					
					     $html .="</select>";
					}else{
					     $html .="<select style=' margin: 0 0 0 50px;width:225px;'    name='general[remoteCountry]'  multiple>";
					     $html .= "<option value='' disabled selected>Select Country</option>";
					     $html .="</select>";
				}
				 echo $html;
				$html ='';
				?>
		</td>
                
	    </tr>

	    
            <tr>
                <th><label>Defatul language</label></th>
		<td><ul class="lang">
                    <?php global $q_config; foreach($languages as $lang): ?>
                     <li><img  src="<?php echo WP_PLUGIN_URL ?>/azull/flags/<?php echo $q_config['flag'][$lang] ?>"><input type="radio" name="language[d]" value="<?php echo $lang; ?>" <?php echo (isset($lng['d']) && ($lng['d']==$lang)  ? "checked" : ""); ?> /><?php echo  $q_config['language_name'][$lang] ?></li>
                    <?php endforeach; ?>
                    </ul>
		</td>
                
	    </tr>
            <tr>
                <th><label>Active language</label></th>
		<td><ul class="lang">
		    <?php foreach($languages as $lang): ?>
                     <li><img  src="<?php echo WP_PLUGIN_URL ?>/azull/flags/<?php echo $q_config['flag'][$lang] ?>"><input type="checkbox" name="language[a][<?php echo  $lang; ?>]" value="<?php echo $lang ?>" <?php echo (isset($lng['a'][$lang]) && ($lng['a'][ $lang]==$lang) ? "checked" :""); ?> /><?php echo  $q_config['language_name'][$lang] ?></li>
                    <?php endforeach; ?>
                    </ul>
		</td>                
	    </tr>
	    <tr>
            <th><label>Phone Number</label></th>
			<td>
			    <input type="text"  name="general[phoneNumber]" value="<?php echo (isset($general['phoneNumber']))? $general['phoneNumber']:'';?>" style="width:100%"/>
			</td>
	    </tr>
        <tr>
                <th><label>Home Page Layout</label></th>
		<td><ul class="lang">
                     <li>
                     <input type="radio" name="general[homeLayout]" value="1" <?php echo (isset($general['homeLayout']) && ($general['homeLayout']==1)  ? "checked" : ""); ?> />Left</li>
                     <li>
                     <input type="radio" name="general[homeLayout]" value="2" <?php echo (isset($general['homeLayout']) && ($general['homeLayout']==2)  ? "checked" : ""); ?> />Center</li>
                     <li>
                     <input type="radio" name="general[homeLayout]" value="3" <?php echo (isset($general['homeLayout']) && ($general['homeLayout']==3)  ? "checked" : ""); ?> />Right</li>
                    </ul>
		</td>
                
	    </tr>

     
    <tr>
            <th><label>Interest Rate</label></th>
			<td>
			    <input type="text"  name="general[interestRate]" value="<?php echo (isset($general['interestRate']))? $general['interestRate']:'';?>" />&nbsp;%
			</td>
	    </tr>
	    <tr>
                <th><label><?php _e('Carasole block','azull');?></label></th>
		<td>
		    <div style="width:100%; ">
			<div style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);margin: 0 ;padding:0;width: 100%;">			
			<?php			    
			    $countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
			  
			   if ( !empty($countries) && !is_wp_error( $countries ) ){
				    	$html .="<select title='Select country' style='width:225px;' taxonomy='country' id='property_meta_country' >";                                       
					$html .= "<option value=''>--</option>";
					
					$assigned_terms = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
					
					foreach ($countries as $countrie):
					$html .= "<option value='".$countrie->term_id."' ".((isset($general['remoteCountry']) && $countrie->term_id==$general['remoteCountry'])? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";
					endforeach;
					
					$html .="</select>";
				 }else{
					$html .="<select title='Select country' style='width:225px;' taxonomy='country' id='property_meta_country'>";
                                        $html .= "<option value='' selected='selected'>--</option>";
					$html .="</select>";
				}
				$html .="<select title='Select region' style='width:225px;' taxonomy='region' id='property_meta_region' name='property_meta_essential[provinces]'>";
                                $html .= "<option  selected='selected'>--</option>";
				$html .="</select><a title='Add selected region' class='add-button' href='JavaScript:void(0);' id='region-add'>+</a>";
				
				$html .="<select title='Select province' style='width:225px;' taxonomy='provinces' id='property_meta_province' name='property_meta_essential[provinces]'>";
                                $html .= "<option  selected='selected'>--</option>";
				$html .="</select><a title='Add selected provinces' class='add-button' href='JavaScript:void(0);' id='province-add'>+</a>";
				
				$html .="<select title='Select place' style='width:225px;' taxonomy='place' id='property_meta_place' name='property_meta_essential[provinces]'>";
                                $html .= "<option  selected='selected'>--</option>";
				$html .="</select><a title='Add selected place' class='add-button' href='JavaScript:void(0);' id='place-add'>+</a>"; 
				$html  .="<div style='width:100%;' id='carasoleBlock'><ul data-id='".$post->ID."'>";
				
				$carasoleBlocks = json_decode(get_post_meta($post->ID,'_carasoleBlock',true),true);
				
				if(isset($carasoleBlocks)){
				    foreach($carasoleBlocks as $carasoleBlock){
					$text ="";
					if($carasoleBlock['taxonomy']='region'){
					    $term = get_term_by('id', (int)$carasoleBlock['term'], 'region');
					    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
					     
					    $country = get_term_by('id', (int)$taxonomy_meta['country'], 'country');
					    $text .="Country : ".qtranxf_use(qtranxf_getLanguage(),$country->name)."<br>";
					     
					    $text .="Region : ". qtranxf_use(qtranxf_getLanguage(),$term->name)."<br>";
					}elseif($carasoleBlock['provinces']='provinces'){
					    $term = get_term_by('id', (int)$carasoleBlock['term'], 'provinces');
					    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
					     
					    $country = get_term_by('id', (int)$taxonomy_meta['country'], 'country');
					    $text .="Country : ".qtranxf_use(qtranxf_getLanguage(),$country->name)."<br>";
					     
					    $region = get_term_by('id', (int)$taxonomy_meta['Region'], 'region');
					    $text .="Region : ".qtranxf_use(qtranxf_getLanguage(),$region->name)."<br>";
					     
					    $text .="Provinces : ". qtranxf_use(qtranxf_getLanguage(),$term->name)."<br>";
					    
					}elseif($carasoleBlock['provinces']='place'){
					    $term = get_term_by('id', (int)$carasoleBlock['term'], 'place');
					    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
					     
					    $country = get_term_by('id', (int)$taxonomy_meta['country'], 'country');
					    $text .="Country : ".qtranxf_use(qtranxf_getLanguage(),$country->name)."<br>";
					     
					    $region = get_term_by('id', (int)$taxonomy_meta['Region'], 'region');
					    $text .="Region : ".qtranxf_use(qtranxf_getLanguage(),$region->name)."<br>";
					    
					    $provinces = get_term_by('id', (int)$taxonomy_meta['province'], 'provinces');
					    $text .=" Provinces : ".qtranxf_use(qtranxf_getLanguage(),$provinces->name)."<br>";					     
					    
					    $text .="Place : ". qtranxf_use(qtranxf_getLanguage(),$term->name)."<br>";
					}else{}
					$html  .="<li   taxonomy='".$carasoleBlock['taxonomy']."' term='".$carasoleBlock['term']."'>".$text."<span >-</span></li>";
				    }
				}
				$html  .="</ul></div>";                
				echo $html;
                if (isset($general['remoteCountry']) && $general['remoteCountry'] != "") {
                    echo "<script>jQuery(document).ready(function() { jQuery('#property_meta_country').change(); });</script>";
                }
				?>
			</div>

			    
		    <br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
		    <span class="description"> Note: Depending region/provinces/place assignment home page property carasole block will be shown. Block should be multiple of 3.
		    </span>
		    </div>		 

		    
		</td>                
	    </tr>
	    <tr>
                <th><label>Access</label></th>
		<td>
                    <input type="checkbox" name="general[backend]"   value="1" />&nbsp; Enable backend access.
                    <br>		  
                    <span class='description'>Allow wordpress backend access on client website.</span>
		</td>
                
	    </tr>
	    

            <tr>
                <th><label>Website Footer</label></th>
		<td class="website-footer">
		    
		<div class="website-footer-bottom">
		<input style="float: right;" type="text" name="general[greenlink]" placeholder="<?php _e('Green certificate link','azull'); ?>" value="<?php echo(isset($general[greenlink])) ?$general[greenlink]:''; ?>"/>
		<?php $menus = get_terms( 'nav_menu', array( 'hide_empty' => false )); ?>
                            <select style="float:right; width: 206px;" name="general[mfooter]" >
                                <option value=''>select menue</option>
                                 <?php foreach ($menus as $menu ):?>                               
				    <option value="<?php echo $menu->term_id; ?>" <?php echo (isset($general['mfooter']) && $general['mfooter']==$menu->term_id)?'selected':'';?>><?php echo $menu->name; ?></option>                           
			        <?php endforeach;?>                         
                            </select>
	        </div>		    
		</td>
                
	    </tr>
	    <tr>
                <th><img src="<?php echo WP_PLUGIN_URL ?>/azull/images/salesforce.png"/></th>
		<td class="website-footer">
		        <div style="width: 230px; float: left;">
		        <input style="width: 230px" type="text"  name="general[oid]" value="<?php echo (isset($general['oid']))? $general['oid']:'';?>" /><br/>
			<span class="description" style="display: inline-block;width: 230px;clear: both;"> Set <strong>Salesforce web-to-lead form</strong>  oid.
			</span>
			</div>
			<div style="width: 725px;float: right;font-style: italic;font-size: 12px;line-height: 16px;">
			    Check "How to create web-to-lead form? <a target="_blank" href="https://help.salesforce.com/apex/HTViewHelpDoc?id=setting_up_web-to-lead.htm&language=en">here</a>. Paste the oid from the form you have created. The form should contain following fields <strong>title, url,first name, last-name, email, phone,zip and description</strong>. Azull form will be mapped with it and data will be sent on your salesforce account. You don't need to set return url.
			</div>
		</td>
                
	    </tr>
	    <tr>
                <th><img title="Analytic script" src="<?php echo WP_PLUGIN_URL ?>/azull/images/js.png"/></label></th>
		<td class="website-footer">		    
			<textarea style="width:100%;background: hsl(0, 0%, 95%);" rows="10" name="general[formjs]"><?php echo (isset($general['formjs']))? $general['formjs']:'';?></textarea>	    
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			<span class="description"> Note: Don't forget to incude script tags and replace shorthand "$" with "jQuery". JS will be included on all azull thanks page.
			</span>
		</td>
                
	    </tr>
	    
	    
	    <tr>
                <th><label><?php _e('Email signature','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="es_epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:mail_signature_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"email_sign_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="email_signature_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
			<textarea  class="textareaEditor" id="textareaeditor_<?php echo $lang ?>" style="width:100%;background: hsl(0, 0%, 95%);" rows="10" name="general[emailSignature][<?php echo $lang;?>]"><?php echo (isset($general['emailSignature'][$lang]))? $general['emailSignature'][$lang]:'';?></textarea>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>
	    <tr>
                <th><label><?php _e('Azull club','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="club_epc_language-switcher">
		 
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:club_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"club_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="club_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
		    
			<textarea class="theEditor" id="theEditor_<?php echo $lang;?>" style="width:100%;background: hsl(0, 0%, 95%);" rows="6" name="general[azullClub][<?php echo $lang;?>]"><?php echo (isset($general['azullClub'][$lang]))? $general['azullClub'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed AULL CLUB','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>
	    <tr>
                <th><label><?php _e('Property info request','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="info_epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:info_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"info_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="info_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
		    
		    
			<textarea class="pInfoRequest" id="pInfoRequest_<?php echo $lang;?>" style="width:100%;background: hsl(0, 0%, 95%);" rows="6" name="general[infoContent][<?php echo $lang;?>]"><?php echo (isset($general['infoContent'][$lang]))? $general['infoContent'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed request info popup box.','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>	    
	    
	    <tr>
                <th><label><?php _e('Property send email','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="ec_epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:emailContent_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"e_c_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div id="emailContent_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
			<textarea style="width:100%;background: hsl(0, 0%, 95%);" rows="3" name="general[emailContentTop][<?php echo $lang;?>]"><?php echo (isset($general['emailContentTop'][$lang]))? $general['emailContentTop'][$lang]:'';?></textarea>
			<textarea style="width:100%;background: hsl(0, 0%, 95%);" rows="3" name="general[emailContentBottom][<?php echo $lang;?>]"><?php echo (isset($general['emailContentBottom'][$lang]))? $general['emailContentBottom'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed send email popup box.','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>

        <tr>
                <th><label><?php _e('Welcome message','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="wc_epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";

		foreach($languages as $lang) {
			echo "<a href=\"javascript:website_msg('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"w_m_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div class="website_msg_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
		    
		    
			<textarea class="welcomeEditor" style="width:100%;background: hsl(0, 0%, 95%);" rows="6" id="welcomeEditor_<?php echo $lang;?>" name="general[welcome_message][<?php echo $lang;?>]"><?php echo (isset($general['welcome_message'][$lang]))? $general['welcome_message'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed website popup box.','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>

<tr>
                <th><label><?php _e('Explanation text','azull'); ?></label></th>
		<td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="ex_epc_language-switcher">   
                <?php
		echo "&nbsp;|&nbsp;";

		foreach($languages as $lang) {
			echo "<a href=\"javascript:explanation_text('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"e_m_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div class="explanation_text_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
		    
		    
			<textarea class="expEditor" style="width:100%;background: hsl(0, 0%, 95%);" rows="6" id="expEditor_<?php echo $lang;?>" name="general[explanation_text][<?php echo $lang;?>]"><?php echo (isset($general['explanation_text'][$lang]))? $general['explanation_text'][$lang]:'';?></textarea>
			<br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
			 <span class="description"> <?php _e('Add content to be displayed  explanation popup window.','azull');?>
			</span>
		    </div> 
                <?php endforeach; ?>			    
		</td>                
	    </tr>
        <tr>
            <th><label>Email Type</label></th>
            <td>
            <?php //print('<pre>');print_r($general);die;            
                $emailArr = array('lost_password'=>'Lost password',
                    'password_change'=>'Password change',
                    'property_detail'=>'Property detail',
                    'profile_email_change'=>'Profile email change',
                    'property_add_mail_with_selection_criteria'=>'Receive email when new property is listed matching your selection criteria',
                    'registration'=>'Registration',
                    'reset_password'=>'Reset password');
                    $email_list = "<select title='Select email type' name='email_type' id='email_type'><option value=''>Select email type</option>";                                       
                    foreach ($emailArr as $key=>$val):
                        $email_list .= "<option value='".$key."'>".$val."</option>";
                    endforeach;
                    $email_list .="</select>";
                 echo $email_list;
                ?>
        </td>
        </tr>
        <tr>
            <th><label>Email Title</label></th>
            <td>
                <div style="margin: 5px;text-align: right;" class="e_title_epc_language-switcher">   
                <?php
                    echo "&nbsp;|&nbsp;";
                    foreach($languages as $lang) {
                        echo "<a href=\"javascript:email_title_text('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"e_title_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
                    }
                ?>
                </div>
                <?php foreach($languages as $lang): ?>
                    <div class="e_title_text_<?php echo $lang ?>" <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <input type="text" class="email_title_txt" name="email_title_text[<?php echo $lang;?>]" id="email_title_text_<?php echo $lang;?>" style="width:100%"/>
            </div> 
                <?php endforeach; ?>    
            </td>
        </tr>
        <tr>
                <th><label><?php _e('Email text','azull'); ?></label></th>
        <td class="website-footer">
                <div style="margin: 5px;text-align: right;" class="email_txt_epc_language-switcher">   
                <?php
        echo "&nbsp;|&nbsp;";

        foreach($languages as $lang) {
            echo "<a href=\"javascript:email_text('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"email_txt_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
        }
        ?>
                </div> 
                    <?php foreach($languages as $lang): ?>
                    <div class="email_txt_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <textarea class="emailTxtEditor" style="width:100%;background: hsl(0, 0%, 95%);" rows="6" id="email_text_<?php echo $lang;?>" name="email_text[<?php echo $lang;?>]"></textarea>
            <br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
             <span class="description"> <?php _e("Add content to be displayed in email content that will send to mi Azull users from cleint's website.","azull");?>
            </span>
            </div> 
                <?php endforeach; ?>                
        </td>                
        </tr>
        <tr>
                <th><label><?php _e('Tracking Code','azull'); ?></label></th>
        <td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="tc_epc_language-switcher">   
                <?php
        echo "&nbsp;|&nbsp;";

        foreach($languages as $lang) {
            echo "<a href=\"javascript:tracking_code('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"t_c_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
        }
        ?>
            </div> 
            <?php foreach($languages as $lang): ?>
            <div class="track_code_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <textarea style="width:100%;" rows="12" id="trackingCodeEditor_<?php echo $lang;?>" name="general[tracking_code][<?php echo $lang;?>]"><?php echo (isset($general['tracking_code'][$lang]))? $general['tracking_code'][$lang]:'';?></textarea>
            <br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
             <span class="description"> <?php _e('Add tracking code to be displayed on website.','azull');?>
            </span>
            </div> 
                <?php endforeach; ?>                
        </td>                
        </tr>

        <tr>
                <th><label><?php _e('Unbounce Code','azull'); ?></label></th>
        <td class="website-footer">
                <div style="margin: 5px;     text-align: right;" class="uc_epc_language-switcher">   
                <?php
        echo "&nbsp;|&nbsp;";

        foreach($languages as $lang) {
            echo "<a href=\"javascript:unbounce_code('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"u_c_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
        }
        ?>
            </div> 
            <?php foreach($languages as $lang): ?>
            <div class="unbounce_code_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <textarea style="width:100%;" rows="12" id="unbounceCodeEditor_<?php echo $lang;?>" name="general[unbounce_code][<?php echo $lang;?>]"><?php echo (isset($general['unbounce_code'][$lang]))? $general['unbounce_code'][$lang]:'';?></textarea>
            <br style=" clear: both;display: block;height: 2px;margin: 10px !important;"/>
             <span class="description"> <?php _e('Add unbounce code to be displayed on website.','azull');?>
            </span>
            </div> 
                <?php endforeach; ?>                
        </td>                
        </tr>

          <tr>
            <th><label>Infodays url1</label></th>
            <td>
                <div style="margin: 5px;text-align: right;" class="infodays_url_epc_language-switcher">   
                <?php
                    echo "&nbsp;|&nbsp;";
                    foreach($languages as $lang) {
                        echo "<a href=\"javascript:infodays_url('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"infodays_url_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
                    }
                ?>
                </div>
                <?php foreach($languages as $lang): ?>
                    <div class="infodays_url_<?php echo $lang ?>" <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <input type="text" class="infodays_url" name="general[infodays_url][<?php echo $lang;?>]" id="infodays_url_<?php echo $lang;?>" value="<?php echo (isset($general['infodays_url'][$lang]))? $general['infodays_url'][$lang]:'';?>" style="width:100%"/>
            </div> 
                <?php endforeach; ?>    
            </td>
        </tr>

        <tr>
            <th><label>Infodays url2</label></th>
            <td>
                <div style="margin: 5px;text-align: right;" class="infodays_url2_epc_language-switcher">   
                <?php
                    echo "&nbsp;|&nbsp;";
                    foreach($languages as $lang) {
                        echo "<a href=\"javascript:infodays_url2('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"infodays_url2_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
                    }
                ?>
                </div>
                <?php foreach($languages as $lang): ?>
                    <div class="infodays_url2_<?php echo $lang ?>" <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <input type="text" class="infodays_url2" name="general[infodays_url2][<?php echo $lang;?>]" id="infodays_url2_<?php echo $lang;?>" value="<?php echo (isset($general['infodays_url2'][$lang]))? $general['infodays_url2'][$lang]:'';?>" style="width:100%"/>
            </div> 
                <?php endforeach; ?>    
            </td>
        </tr>
<!-- Code for add language button on  -->
        <tr>
            <th><label>Website language button1</label></th>
            <td class="website-flag">
                <div style="margin: 5px;text-align: right;" class="button1_link_url_language-switcher">   
                <?php
                    echo "&nbsp;|&nbsp;";
                    foreach($languages as $lang) {
                        echo "<a href=\"javascript:button1_link_url('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"button1_link_url_active_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
                    }
                ?>
                </div>
                <?php foreach($languages as $lang): ?>
                    <div class="button1_link_url_<?php echo $lang ?>" <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <input type="text" class="button1_link_url" name="general[button1_link_url][<?php echo $lang;?>]" id="button1_link_url_<?php echo $lang;?>" value="<?php echo (isset($general['button1_link_url'][$lang]))? $general['button1_link_url'][$lang]:'';?>" style="width:100%"/>
            
            </div> 

                <?php endforeach; 
                ?>  
<div  class="lngFlag1">
    <img width="18px" height="12px" style="display: block;margin-left: 37px; margin-top: 23px;" id="flag1" alt="<?php echo (isset($general['flag1alt'])) ? $general['flag1alt'] :'';?>" src="<?php echo (isset($general['flag1'])) ? $general['flag1'] :'';?>" />
    <span id="alt1" style="font-size: 9px;">
    <?php echo (isset($general['flag1alt'])) ? $general['flag1alt'] :'';
    /*global $wpdb;
    $guid=$general['flag1'];
    $query = "SELECT wp_posts.post_content FROM wp_posts where wp_posts.guid= '$guid'";
    $postArray= $wpdb->get_row($query);
    $imgDesc=$postArray->post_content;*/
    ?>
    </span>   
    <input type="hidden" id="flag1alt" name="general[flag1alt]"  value="<?php echo (isset($general['flag1alt'])) ? $general['flag1alt'] :'';?>">
    <input type="hidden" id="flag1desc" name="general[flag1desc]"  value="<?php echo (isset($general['flag1desc'])) ? $general['flag1desc'] :'';?>">
    <input type="hidden" name="general[flag1]"  value="<?php echo (isset($general['flag1'])) ? $general['flag1'] :'';?>">
    <input class="button" id="upload_flag1" value="<?php (isset($general['flag1'])) ?_e("Update flag","azull"):_e("Add flag","azull") ;?>" /> 

</div> 
           <div id="lay_01">
           <?php 
                    $chk1yes='';
                    $chk1no='';
                   if($general['display_link1']!='' && $general['display_link1']=='yes'){
                     $chk1yes='checked';
                   }else{
                     $chk1no='checked';
                   }
            ?>            
            Display:- &nbsp; &nbsp;&nbsp;&nbsp;
            <input type="radio" id="b1_yes" value="yes" name="general[display_link1]" <?php echo $chk1yes;?> >Yes&nbsp;
            <input <?php echo $chk1no;?> type="radio" id="b1_no"  value="no" name="general[display_link1]" >  No  
            </div>
            </td>
        </tr>
        <tr>
            <th><label>Website language button2</label></th>
            <td class="website-flag">
                <div style="margin: 5px;text-align: right;" class="button2_link_url_switcher">   
                <?php
                    echo "&nbsp;|&nbsp;";
                    foreach($languages as $lang) {
                        echo "<a href=\"javascript:button2_link_url('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"button2_link_url_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
                    }
                ?>
                </div>
                <?php foreach($languages as $lang): ?>
        <div class="button2_link_url_<?php echo $lang ?>" <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
            <input type="text" class="button2_link_url" name="general[button2_link_url][<?php echo $lang;?>]" id="button2_link_url_<?php echo $lang;?>" value="<?php echo (isset($general['button2_link_url'][$lang]))? $general['button2_link_url'][$lang]:'';?>" style="width:100%"/>
        </div> 
        <?php endforeach; ?>

<div  class="lngFlag2">
    <img width="18px" height="12px" style="display: block;margin-left: 37px; margin-top: 23px;" id="flag2" alt="<?php echo (isset($general['flag2alt'])) ? $general['flag2alt'] :'';?>" src="<?php echo (isset($general['flag2'])) ? $general['flag2'] :'';?>" />
    
    <span style="font-size: 9px;" id="alt2"><?php echo (isset($general['flag2alt'])) ? $general['flag2alt'] :'';?></span>
    <input type="hidden" id="flag2desc" name="general[flag2desc]"  value="<?php echo $imgDesc2;?>">   
    <input type="hidden" id="flag2alt" name="general[flag2alt]"  value="<?php echo (isset($general['flag2alt'])) ? $general['flag2alt'] :'';?>">
    <input type="hidden" name="general[flag2]"  value="<?php echo (isset($general['flag2'])) ? $general['flag2'] :'';?>">
    <input class="button" id="upload_flag2" value="<?php (isset($general['flag2'])) ?_e("Update flag","azull"):_e("Add flag","azull") ;?>" />       
</div> 

    <div id="lay_02">
                <?php 
                    $chk2yes='';
                    $chk2no='';
                   if($general['display_link2']!='' && $general['display_link2']=='yes'){
                     $chk2yes='checked';
                   }else{
                     $chk2no='checked';
                   }
                ?>   
            Display:- &nbsp; &nbsp;&nbsp;&nbsp;
        <input type="radio" id="b2_yes" value="yes" name="general[display_link2]" <?php echo $chk2yes;?> >Yes&nbsp;
        <input type="radio" id="b2_no"  value="no" name="general[display_link2]" <?php echo $chk2no;?>>  No 
            </td>
    </div>        
        </tr>

         <tr>
                <th><label>Website layout</label></th>
         
         <td>
<input type="hidden" name="siteID" id="siteId" value="<?php echo $_GET['post'];?>">
  <input type="radio" id="mob"checked="checked" value="desktop" name="layout">Desktop&nbsp;<input type="radio" id="desktop"  name="layout" value="mobile">	Mobile &nbsp; &nbsp;&nbsp;&nbsp;<select name="block" id="block" onchange="return loadpages(this.value,<?php echo $_GET['post']?>);">
            <option value="main_block">Main Block</option>
            <option value="side_block">Side Block</option>
            </select> 
         </td>  
	    </tr>
        <tr>
         <td></td>
         <td id="display_id"></td>
        </tr>

	   
	</table>  
    </div>
    <style>
  
	#normal-sortables .postbox .submit {
	    background: 0 0;
	    border: 0;
	    float: left;
	    padding: 5px 2%;
	    margin: 0;
	    width: 95.6%;
	    text-align: right;
	    background: #000;
	    margin: 2px;
	    }
    </style>
    