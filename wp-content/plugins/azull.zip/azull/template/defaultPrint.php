<?php
defined('ABSPATH') or die("No script kiddies please!");
		foreach($ids as $val){
		    $post = get_post($val);
		    $term = get_the_terms($post->ID, 'category'); //property taxonomy
		    $html .='<div id="template0">';
		    	    $html .='<div class="header">';	

					    $html .='<div class="logo">';
						$html .='<img style="width:100%;max-height: 438px;" src="'.get_bloginfo('template_url').'/azull.jpeg"/>';
					    $html .='</div>';
			    
					    $html .='<div class="title">';
						$html .='<h1>'.qtranxf_use($template['l'],get_the_title($post->ID)).' '.__('Ref','azull').':-'.$post->ID.'</h1>';			
					    $html .='</div>';
			    
					$html .='</div>';
			
			$html .='<div class="col-left">';
			    $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
			    $html .='<div class="featured-mage">';
				$html .='<img  style="float: left;  padding: 0;width:100%;" src="'.$url.'"/>';
			    $html .='</div>';
			    
			    $html .='<div class="content">';
				if(qtranxf_use($template['l'],$post->post_content)!='')
				$html .=qtranxf_use($template['l'],$post->post_content);
			    $html .='</div>';
			    
			    $html .='<div class="meta">';
					$html .='<div>';				
					    $html .='<h4 >'.__('Sales Price','azull').' : '.$aj_config['currency'].azull_price('Sales price',$post->ID).'</h4>';                     
					    $html .='<h4 >'.__('Total Price','azull').' : '.$aj_config['currency'].azull_price('Total price',$post->ID).'</h4>';
					    $html .='<p style="font-size: 10px; margin: 0 0 5px;padding:0px;">'.__('Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.','azull').'</p>';
					    $html .='<h4 >'.__('Old Price','azull').' : '.$aj_config['currency'].azull_price('Old price',$post->ID).'</h4>';
             		$html .='</div>';
				$html .='<div>';
				
			    $html .='<h4 >'.__('Category','azull').' : '.$q_config['term_name'][$term[0]->name][$template['l']].'</h4>';                   
			    $html .='<h4 >'.__('Status','azull').' : '.property_status($post->ID).'</h4>';
			    $html .='<h4 >'.__('Build Year','azull').' : '.build_year($post->ID).'</h4>';
			    $html .='<h4 >'.__('Location','azull').' : '.property_location($post->ID,false).'</h4>';
				    
				 $html .='</div>';
			$html .='</div>';		
			    
			$html .='</div>';
			
			$html .='<div class="col-right">';
			    $html .='<div class="template0-gallery">';				
				$html .=azull_gallery($post->ID,6);				
			    $html .='</div>';
			    $html .='<div class="features">';
			            $html .=features_icon($post->ID);
			    $html .='</div>';			
			
			$html .='</div>';
		   
		    $html .='<div>';
		 }