<?php defined('ABSPATH') or die("No script kiddies please!");

global $post, $aj_config, $q_config;
$languages = qtranxf_getSortedLanguages();
$l = $q_config['default_language'];
$obj = new Azull_Subscriber(); 
 ?>
<script>
jQuery(document).ready(function() {
	     jQuery(".term_proprietor_div").hide();
  jQuery("#term_contact_<?php echo $q_config['default_language'];?>").show();
  jQuery("#term_comment_<?php echo $q_config['default_language'];?>").show();
  jQuery("#term_street_<?php echo $q_config['default_language'];?>").show();
  jQuery("#term_house_<?php echo $q_config['default_language'];?>").show(); 
  jQuery("#term_opninghrs_<?php echo $q_config['default_language'];?>").show(); 

         jQuery(".wrap").on("click","ul.qtranxs-lang-switch-wrap li.qtranxs-lang-switch",function(n){
            var lang = jQuery(this).attr("lang");
            jQuery(".term_proprietor_div").hide();
            jQuery("#term_contact_"+lang).show();
            jQuery("#term_comment_"+lang).show();
            jQuery("#term_house_"+lang).show();
            jQuery("#term_street_"+lang).show();
            jQuery("#term_opninghrs_"+lang).show();
         });
});      
</script>
<style>
    .form-table td {padding: 4px 0px;}
    .form-table th {padding: 8px 10px 20px 0;}
</style>


<tr  class="form-field">
    <th   scope="row" valign="top"><label for="taxonomy_meta[phone]"><?php echo $obj->getTranslatedString('en','nl','Phone Number:'); ?></label></th>
	<td>        
	<input type="text" name="taxonomy_meta[phone]" id="taxonomy_meta[phone]" value="<?php echo ((isset($taxonomy_meta['phone']))? $taxonomy_meta['phone']:'' ); ?>">
	<p class="description"><?php  echo $obj->getTranslatedString('en','nl','Enter phone Number');?></p>
	</td>
</tr>
<!--
<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[mobile]"><?php //_e( 'Mobile Number:', 'azull' ); ?></label></th>
	<td>        
	<input type="text" name="taxonomy_meta[mobile]" id="taxonomy_meta[mobile]" value="<?php //echo ((isset($taxonomy_meta['mobile']))? $taxonomy_meta['mobile']:'' ); ?>">
	<p class="description"><?php //_e( 'Enter Mobile Number','azull' ); ?></p>
	</td>
</tr> -->
<!--<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[email]"><?php _e( 'Email Address:', 'azull' ); ?></label></th>
	<td>        
	<input type="text" name="taxonomy_meta[email]" id="taxonomy_meta[email]" value="<?php echo ((isset($taxonomy_meta['email']))? $taxonomy_meta['email']:'' ); ?>">
	<p class="description"><?php //_e( 'Enter Agent email address','azull' ); ?></p>
	</td> -->
</tr>
<?php  global $aj_config, $post,$q_config;  $languages = qtranxf_getSortedLanguages(); ?>

<tr  class="form-field">
    <th scope="row" valign="top">
   <?php echo $obj->getTranslatedString('en','nl','Agent Address:');?>
    </th>
    <td>
	<?php foreach($languages as $lang): ?>
<?php /*<div id="term_house_<?php echo $lang ?>" class="term_proprietor_div">
	    <div  class="form-field">
	    	<input type="text" name="taxonomy_meta[house][<?php echo $lang; ?>]" id="taxonomy_meta[house][<?php echo $lang; ?>]" value="<?php echo ((isset($taxonomy_meta['house'][$lang]))? $taxonomy_meta['house'][$lang]:'' ); ?>">
		    <p class="description"><?php _e( 'Enter house Number','azull' ); ?></p>
	    </div>	
</div> */?>
	<?php endforeach; ?>


 <?php 
     echo $html =self::location_fields($taxonomy_meta); 
  ?>
<?php foreach($languages as $lang): ?>
<div id="term_street_<?php echo $lang ?>" class="term_proprietor_div">	
	    <div  class="form-field">
	    	<input type="text" name="taxonomy_meta[street][<?php echo $lang; ?>]" id="taxonomy_meta[street][<?php echo $lang; ?>]" value="<?php echo ((isset($taxonomy_meta['street'][$lang]))? $taxonomy_meta['street'][$lang]:'' ); ?>">
		    <p class="description"><?php _e( 'Enter street','azull' ); ?></p>
	    </div>
</div>
	<?php endforeach; ?>
   
    </td>
</tr>

<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[zip]">
    	
    	<?php echo $obj->getTranslatedString('en','nl','Agent Zip:');?>
    </label></th>
	<td> 
        <input type="text" name="taxonomy_meta[zip]" id="taxonomy_meta[zip]" value="<?php echo ((isset($taxonomy_meta['zip']))? $taxonomy_meta['zip']:'' ); ?>">
        <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter zip:') ?></p>
	</td>
</tr>
<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[zip]">
    	<?php echo $obj->getTranslatedString('en','nl','Website:') ?>
    </label></th>
	<td> 
        <input type="text" name="taxonomy_meta[web]" id="taxonomy_meta[web]" value="<?php echo ((isset($taxonomy_meta['web']))? $taxonomy_meta['web']:'' ); ?>">
        <p class="description">
        	<?php echo $obj->getTranslatedString('en','nl','Enter website url') ?>
        </p>
	</td>
</tr>
<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[price]">
    <?php echo $obj->getTranslatedString('en','nl','Pricelist') ?>:</label></th>
   <td> 
  <input type="text" name="taxonomy_meta[price]" id="taxonomy_meta[price]" value="<?php echo ((isset($taxonomy_meta['price']))? $taxonomy_meta['price']:'' ); ?>">
        <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter proprietor price'); ?></p>
   </td>
</tr>

<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[plan]">
    <?php echo $obj->getTranslatedString('en','nl','Plan') ?>:</label></th>
   <td> 
  <input type="text" name="taxonomy_meta[plan]" id="taxonomy_meta[plan]" value="<?php echo ((isset($taxonomy_meta['plan']))? $taxonomy_meta['plan']:'' ); ?>">
        <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter proprietor plan'); ?></p>
   </td>
</tr>


<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[status]">
   <?php echo $obj->getTranslatedString('en','nl','Status') ?>:</label></th>
   <td> 
  <input type="text" name="taxonomy_meta[status]" id="taxonomy_meta[status]" value="<?php echo ((isset($taxonomy_meta['status']))? $taxonomy_meta['status']:'' ); ?>">
      <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter proprietor status'); ?></p>
   </td>
</tr>

<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[extra_information]">
    <?php echo $obj->getTranslatedString('en','nl','Extra information') ?>:</label></th>
   <td> 
  <input type="text" name="taxonomy_meta[extra_information]" id="taxonomy_meta[extra_information]" value="<?php echo ((isset($taxonomy_meta['extra_information']))? $taxonomy_meta['extra_information']:'' ); ?>">
        <p class="description"><?php echo $obj->getTranslatedString('en','nl','Extra information'); ?></p>
   </td>
</tr>


<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[photos]">
    <?php echo stripslashes($obj->getTranslatedString('en','nl','Azull photos')) ?>:</label></th>
   <td> 
  <input type="text" name="taxonomy_meta[photos]" id="taxonomy_meta[photos]" value="<?php echo ((isset($taxonomy_meta['photos']))? $taxonomy_meta['photos']:'' ); ?>">
        <p class="description"><?php echo stripslashes($obj->getTranslatedString('en','nl','Azull photos')); ?></p>
   </td>
</tr>


<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[opningHrs]">
    <?php echo $obj->getTranslatedString('en','nl','Opening Hours') ?>:</label>
   <td> 
 <?php
 foreach($languages as $lang):
      $opning_hrs = (isset($taxonomy_meta['prop_opening_hrs'][$lang]) && !empty($taxonomy_meta['prop_opening_hrs'][$lang]))?$taxonomy_meta['prop_opening_hrs'][$lang]:''
?>
  <div id="term_opninghrs_<?php echo $lang ?>" class="term_proprietor_div">
   <textarea rows="6" name="taxonomy_meta[prop_opening_hrs][<?php echo $lang;?>]" ><?php echo ((isset($opning_hrs))? $opning_hrs:'' ); ?></textarea>
    </div>
<?php
      endforeach;
?>
<p class="description"><?php echo $obj->getTranslatedString('en','nl','Opening Hours'); ?></p>
   </td>
</tr>




<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[contactperson]">
    <?php echo $obj->getTranslatedString('en','nl','Contact person') ?>:</label></th>
   <td> 
<?php
 foreach($languages as $lang):
      $p_contact_p = (isset($taxonomy_meta['contact_p'][$lang]) && !empty($taxonomy_meta['contact_p'][$lang]))?$taxonomy_meta['contact_p'][$lang]:''
?>
<div id="term_contact_<?php echo $lang ?>" class="term_proprietor_div">
 <input type="text" name="taxonomy_meta[contact_p][<?php echo $lang;?>]" value="<?php echo ((isset($p_contact_p))? $p_contact_p:'' );?>">
</div>
<?php endforeach; ?>   
    <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter proprietor contact person'); ?></p>
   </td>
</tr>


<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[contactP_email]">
   <?php echo $obj->getTranslatedString('en','nl','Email') ?>:
</label></th>
   <td> 
        <input type="text" name="taxonomy_meta[contactP_email]" id="taxonomy_meta[contactP_email]" value="<?php echo ((isset($taxonomy_meta['contactP_email']))? $taxonomy_meta['contactP_email']:'' ); ?>">
      <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter proprietor contact person email'); ?></p>
   </td>
</tr>

<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[contactP_phone]">
    <?php echo $obj->getTranslatedString('en','nl','Phone') ?>:</label></th>
   <td> 
        <input type="text" name="taxonomy_meta[contactP_phone]" id="taxonomy_meta[contactP_phone]" value="<?php echo ((isset($taxonomy_meta['contactP_phone']))? $taxonomy_meta['contactP_phone']:'' ); ?>">
    <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter proprietor contact person phone'); ?></p>
   </td>
</tr>
<!-- code for add VAT No -->
<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[vat_no]">
    <?php echo $obj->getTranslatedString('en','nl','VAT') ?>:</label></th>
   <td> 
        <input type="text" name="taxonomy_meta[vat_no]" id="taxonomy_meta[vat_no]" value="<?php echo ((isset($taxonomy_meta['contactP_phone']))? $taxonomy_meta['vat_no']:'' ); ?>">
    <p class="description"><?php echo $obj->getTranslatedString('en','nl','Enter proprietor VAT number'); ?></p>
   </td>
</tr>
<!-- end code -->
<tr class="form-field">
    <th scope="row" valign="top"><label for="taxonomy_meta[comment]">
    <?php echo $obj->getTranslatedString('en','nl','Comment') ?>:</label>
   <td> 
 <?php
 foreach($languages as $lang):
      $p_comment = (isset($taxonomy_meta['comment'][$lang]) && !empty($taxonomy_meta['comment'][$lang]))?$taxonomy_meta['comment'][$lang]:''
?>
  <div id="term_comment_<?php echo $lang ?>" class="term_proprietor_div">
   <textarea rows="6" name="taxonomy_meta[comment][<?php echo $lang;?>]" ><?php echo ((isset($p_comment))? $p_comment:'' ); ?></textarea>
    </div>
<?php
      endforeach;
?>
   </td>
</tr>
<script>
    jQuery('#term_address_<?php echo $q_config['default_language'];?>').show()

</script>
