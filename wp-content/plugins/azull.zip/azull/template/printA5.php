<?php
defined('ABSPATH') or die("No script kiddies please!");
global $wpdb;
$old_locale = get_locale();
$lng = strtoupper(substr($new_locale, 0, 2));
$settings=get_option('azullsettings');
$clientId = $_POST['clnt']; 
$results = get_post($clientId);	
$color=    get_post_meta($clientId, '_companyclr', true);
$cName=    get_post_meta($clientId, '_companyname', true);
$cDisclaimer = qtranxf_use(qtrans_getLanguage(), $results->post_content);
if (strlen($cDisclaimer) <= 330 ) {
	$fixheight = 1450;
} else {
	$fixheight = 1420;
}
  $logourl=  get_post_meta($clientId, 'wp_custom_attachment', true);
  if($logourl!=''){
     $logo=$logourl['url'];
  }else{
     $logo='';
  }


$obj = new Azull_Subscriber();  

 
	  /*$table_name = $wpdb->prefix . "company";
	  $results = $wpdb->get_row( 
		      $wpdb->prepare("SELECT * FROM {$table_name} WHERE id =%d", $clientId) 
		   );
       $logo=    $results->cmp_logo;
     $cName=   $results->cmp_name;*/
     $content= qtranxf_use(qtranxf_getLanguage(),$results->post_content);


   /*$c_records = get_post_meta($clientId, 'general', true);
   switch ($clientId) {
   	case 7933:
   			$color = '#00a1e4';
   			$logo =  $c_records['logo'];
   			$content = stripslashes(get_option('pdfsignature_'.$lng,false));
   			$cName = "Azull";
			$content = str_replace("Azull",$cName,$content); 
   		break;
   	case 50933:
   			$color = '#20A342';
   			$logo =  $c_records['logo'];
   			$content = stripslashes(get_option('pdfsignature_'.$lng,false));
   			$cName = "Inmo España";
   			$content = str_replace("Azull",$cName,$content); 
   		break;
	 case 50913:
   			$color = '#00a1e4';
   			$logo =  $c_records['logo'];
   			$content = stripslashes(get_option('pdfsignature_'.$lng,false));
   			$cName = "Azull Be";
   			$content = str_replace("Azull",$cName,$content); 
   	       break;      
	       
	       
   }*/
     //print_r($c_records['logo']); die; 

    $html .='<div id="template2" class="template" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:14px;background:#fff none repeat scroll 0 0;">';
    if(!empty($ids))
    foreach($ids as $val){
	
	$post = get_post($val);
   /*code for add title and content if not define in language*/
    $title_array = qtranxf_split($post->post_title); 
    $content_array=qtranxf_split($post->post_content); 

    if(isset($title_array) && !empty($title_array)){
       if($title_array[$_POST['lng']]!=''){
        $title=substr(qtranxf_use($_POST['lng'],$post->post_title),0,55);
       }else{   
       	 $title=getTitleContent($post->ID,$_POST['lng']);
       }
     }
    if(isset($content_array) && !empty($content_array)){
       if($content_array[$_POST['lng']]!=''){
        $content=qtranxf_use($_POST['lng'],$post->post_content);
       }else{   
       	 $content=getTitleContent($post->ID,$_POST['lng']);
       }
     }
     /*end code*/
	$term = get_the_terms($post->ID, 'category'); //property taxonomy 
	global $aj_config;
	$html .= '<table   width="100%" cellspacing="10px" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:18px;page-break-inside: avoid; height: '.$fixheight.'px">';
	$html .= '<tr><td style="height: '.$fixheight.'px; vertical-align: top;">';
	$html .='<table   width="100%" cellspacing="10px" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:18px;page-break-inside: avoid; page-break-after: always;">';	
	$html .='<tr>'; 
	    $html .='<td valign="top" style="width:13%;" colspan="1" ><img width="120" height="120" alt="Azull.info" src="'.$logo.'"></td>';
	     $html .='<td valign="middle" colspan="9" ><span style="font-family:Arial, Helvetica, sans-serif; font-size:22px; text-transform:uppercase; padding:0;text-align:left; font-weight:bold;color:#333;line-height:35px;">'.$title.'</span><br>'.property_location($post->ID,false).'</td>';		    
	    $html .='<td valign="bottom"  colspan="2" style="font-family:Arial, Helvetica, sans-serif; color:#333; font-size:22px; line-height:35px;text-transform:capitalize; padding:0;text-align:right;" nowrap>Ref. '.get_post_meta($post->ID,'_nreal_id',true).'<br><strong style="color:'.$color.';">'.number_format ( (integer)azull_price('Sales Price',$post->ID) , 0 , "" , "." ).$settings['currency'].'</strong></td>';		        
	$html .='</tr>';    
	$html .='</table>';
	$html .='<table   width="100%" cellspacing="10px" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:18px;page-break-inside: avoid; page-break-after: always;">';
	$html .='<tr>';
	  $html .='<td colspan="12">';
		$url =wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );

		$url = fly_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'print-1024-550', array('center', 'center') );
		if ($url['width'] < 1024) {
			$url = fly_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'print-512-250', array('center', 'center') );
		}
        $url = str_replace('-cc', '-', $url["src"]);

		$html .='<img id="fImg" width="1024px" height="550px" style="float: left;  padding: 0;width:100%;" src="'.$url.'"/>';
	     $html .='</td>';
	$html .='</tr>';
	$html .='<tr >';
	$html.=print_gallery_A5($post->ID,3); 
	$html .='</tr>';	
		$html .='</table>';
		 $cnt = print_featuresIcon_count_A5($post->ID);
		  $height="120px";
		  $heidescrption = "210px";
		 if($cnt>=12){ $height="200px"; $heidescrption="inherit";}
		 else{
		 	$heidescrption="inherit";
		 }
   
		$html .='<div style="height:'.$height.';max-height:'.$height.';padding-top:5px;">';
		$html .='<table   width="100%" cellspacing="10px" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333;  font-size:18px;page-break-inside: avoid; page-break-after: always;">';
	
        $html .=print_featuresIcon_A5($post->ID,$color);
		$html .='</table>';
		$html .='</div>';
		$html.='<style>
				.pMsgCnt {
				    padding-left: 22px !important;
			    }
			    .pMsgCnt li{
			    	line-height:0px !important;
			    }
				 table .pMsgCnt ul {
				    list-style: inherit;
				    width: 100%;
				 }
		   </style>';
		$html .='<table   width="100%" cellspacing="10px" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333;  font-size:18px;page-break-inside: avoid; page-break-after: always;"" id="features'.$post->ID.'">';
     
	$html .='<tr>';
	    $html .='<td colspan="12">';
	    	$html .='<div class="pMsgCnt" id="pMsgCnt'.$post->ID.'" style="height:'.$heidescrption.';max-height:'.$heidescrption.';">';
		if(qtranxf_use($_POST['lng'],$post->post_content)!=''){
				
				 if($cnt<12){
				 	//$html .= '<pre>'.strip_tags(substr(qtranxf_use($_POST['lng'],$post->post_content),280,350 ),'<br/>').'</pre>';
				 	//$str="<pre>".qtranxf_use($_POST['lng'],$post->post_content)."</pre>";
				 	$str="<pre>".$content."</pre>";
				 	$html .= $str;
				 }
				 	else{
					//$html .= "<pre>".substr(qtranxf_use($_POST['lng'],$post->post_content),0,350 )."</pre>";
				 		$html .= "<pre>".substr($content,0,350 )."</pre>";

				 		
				 	}
				
				//$html .= '<pre>'.$post->post_content.'</pre>';
			}

	$html .='</div>';
	    $html .='</td>';
	$html .='</tr>';

	$html .='</table>';

	$html .='<table   width="100%" cellspacing="10px" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:18px;page-break-inside: avoid; page-break-after: always;">';
	

	$html .='<tr>';   
	  $html .='<td colspan="6" bgcolor="#F1F3F2" style="padding:15px;background-color:#F1F3F2;">';
		//$html .='<strong>'.__('Category1','azull').'</strong> : '.property_category($post->ID).'</h4><br>'; 
		$html .='<strong>'.$obj->getTranslatedString('en','nl','Category').'</strong> : '.property_category($post->ID).'</h4><br>'; 

		//$html .='<strong>'.__('Status','azull').'</strong> : '.property_status($post->ID).'<br>';

		$html .='<strong>'.$obj->getTranslatedString('en','nl','Status').'</strong> : '.property_status($post->ID).'<br>';

		if(build_year($post->ID))
		/*$html .='<strong>'.__('Build Year','azull').'</strong> : '.build_year($post->ID).'<br>';
		$html .='<strong>'.__('Location','azull').'</strong> : '.property_location($post->ID,false).'<br>';
         $html .='</td>';*/
          $html .='<strong>'.$obj->getTranslatedString('en','nl','Build Year').'</strong> : '.build_year($post->ID).'<br>';
		$html .='<strong>'.$obj->getTranslatedString('en','nl','Location').'</strong> : '.property_location($post->ID,false).'<br>';
         $html .='</td>';


	   $html .='<td colspan="6" bgcolor="#F1F3F2" style="padding:15px;">';
	  	
	  	/*$html .='<strong>'.__('Sales Price','azull').'</strong> : '.number_format ( (integer)azull_price('Sales price',$post->ID) , 0 , "" , "." ).$settings['currency'].'<br>';                     
		$html .='<strong>'.__('Total Price','azull').'</strong> : '.number_format ( (integer)azull_price('Total price',$post->ID) , 0 , "" , "." ).$settings['currency'].'</br>';
		$html .="<span style='font-size:9px;'>( ".__('Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.','azull')." )</span>";*/
        $html .='<strong>'.$obj->getTranslatedString('en','nl','Sales Price').'</strong> : '.number_format ( (integer)azull_price('Sales price',$post->ID) , 0 , "" , "." ).$settings['currency'].'<br>';                     
		$html .='<strong>'.$obj->getTranslatedString('en','nl','Total Price').'</strong> : '.number_format ( (integer)azull_price('Total price',$post->ID) , 0 , "" , "." ).$settings['currency'].'</br>';
		$html .="<span style='font-size:9px;'>( ".$obj->getTranslatedString('en','nl','Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.')." )</span>";
		if(azull_price('Old price',$post->ID)!='')
		$html .='<br><strong>'.$obj->getTranslatedString('en','nl','Old Price').'</strong> : '.number_format ( (integer)azull_price('Old price',$post->ID), 0 , "" , "." ).$settings['currency'].'</br>';	   
	 $html .='</td>';
	$html .='</tr>';   
	$html .='</table>'; 

	//Closing the table to flush text to the end
	$html .='</td>';
	$html .='</tr>';
	$html .='</table>';

	$html .='<table   width="100%" cellspacing="10px" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:18px;page-break-inside: avoid; page-break-after: always;">';  
	$html .= '<tr>';
	 $html .= '<td style="font-size: 12px;font-style: italic;">';
	 //$html .=  $content;
	 $html .= $cDisclaimer;
	  $html .= '</td>';
	$html .= '</tr>';
	$html .= '<tr>';
	 $html .= '<td style="text-align: left;color:hsl(0, 0%, 45%);width:600px; " id = "lastblock'.$post->ID.'">'; 
	 $html .= '© '.date('Y') .' - '.$cName.'</td>';
	 $html .= '</td>';
	$html .= '</tr>';

	
      $html .='</table>';
      //$html .='<script>jQuery("#lastblock'.$post->ID.'").height(240 - jQuery("#pMsgCnt'.$post->ID.'").height() - jQuery("#features'.$post->ID.'").height());</script>';
      //$_GET['lng']
	
    }

     $html .='</div>';
          
     if($_POST['lng']=='en'){
    	 $html .='<style>pre {
   			white-space:pre-wrap !important ;
   			font-family: inherit !important;
   		}</style>';		
    	}
       $html .='<script>
		jQuery(document).ready(function() {	
		     jQuery("#azullprint").show();
		});
		</script><style>td p{ font-size:18px !important;}
       #template0 table, #template1 table, #template2 table{
       		margin-bottom: -13px !important;
   		}
   		pre {
font-family: inherit !important;
white-space:pre-wrap !important ;
   		}
   		

       </style>';
    function print_gallery_A5($post_id,$limit,$size='full'){    
    $html="";                 
    $i=0;  
            foreach (  Property_Meta::azull_gallery($post_id) as $id ) {
		
               if(get_post_thumbnail_id( $post_id )!=$id && $i< $limit && $id!=''):
		$html .= '<td colspan="4">';
		$url =wp_get_attachment_image_src( $id, 'pdf-small' );	

		$url = fly_get_attachment_image_src( $id, 'print-335-250', array('center', 'center') );
        $url = str_replace('-cc', '-', $url["src"]);

		$html .= '<img width="335px" height="250px" src="'.$url.'"/>';
		$html .= '</td>';
                $i++;
              endif;
	    }    

	     if($i==2){
	     	$html .= '<td colspan="4">';
	     	$html .= '<img width="335px" height="250px" src="http://azull.biz/cisin/wp-content/uploads/asfalt-light.png"/>';
			$html .= '</td>';
	     }
    return $html;               
    }

    /*function get_termName($termId) {
    global $wpdb;
    $terms = $wpdb->get_results('SELECT name FROM wp_terms WHERE term_id =' . $termId, ARRAY_A);
    if (isset($terms[0]['name']))
        return $terms[0]['name'];
    return false;
    }*/

    function print_featuresIcon_A5($post_id,$color){    
	
	    $i=1;
	    $j=0;
	    $checkclm= 0;
	    $html ='';	
	    
	    $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
	     if ( !empty( $terms ) && !is_wp_error( $terms ) ){	
		$taxonomy_meta['type']=1;$taxonomy_meta['search']=0;
		  foreach ( $terms as $term ) {
		   $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
			if($taxonomy_meta['type']==2 && get_post_meta($post_id,'_feature_'.$term->term_id,true)!='' && z_taxonomy_image_url($term->term_id)!=''){
			    $fnuber= get_post_meta($post_id,'_feature_'.$term->term_id,true);
			    $fnuber =(isset($fnuber ) && is_numeric($fnuber)) ? $fnuber: $fnuber;					 
			    $fnuber =(isset($fnuber ) && !is_numeric($fnuber)) ?__($fnuber,'azull'): $fnuber;
			    if($i%12==1)
			    $html .='<tr>';	
			    if($fnuber && $fnuber!=0){		
			    $html .='<td width="8.33%" style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
						    <p style="margin:0; border:1px solid '.$color.'; background-color:#fff; padding:5px; color:'.$color.';">'.$fnuber.'</p>
						    </td>';
                }
			    if($i%12==0)			
			    $html .='</tr>';
			    $i++;
			    $j++;
			    $checkclm++;
			}
		      $taxonomy_meta['search']=0;  
		   } 
	    }
	    
	    $terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );  
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		  $distance="";
		  $val=get_post_meta($post_id,'_scores_'.$term->term_id,true);
		  if(isset($val) && $val!="" && z_taxonomy_image_url($term->term_id)!='' && $val!=0){
		    $distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km' : number_format((float)$val,0,".","") .'m';
		    if($i%12==1)
			$html .='<tr>';			
			$html .='<td width="8.33%" style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
			    <p style="margin:0; border:1px solid '.$color.'; background-color:#fff; padding:5px; color:'.$color.';">'.$distance.'</p></td>';		    
		    if($i%12==0)
			$html .='</tr>';
		    $i++;
		    $j++;
		    $checkclm++;
		  }
		}
	    }
	    
	    $terms  = get_terms( 'dimensions', 'orderby=id&hide_empty=0' ); 
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		  $distance="";
		  $val=get_post_meta($post_id,'_dimensions_'.$term->term_id,true);
		  if(isset($val) && $val!="" && z_taxonomy_image_url($term->term_id)!=''&& $val!=0){
		    $distance .= ((float)$val>999) ? number_format(((float)$val),0,".","").'m²' : number_format((float)$val,0,".","") .'m'; 	    
              //$distance .=  number_format((float)$val,0,".","") .'m²'; 	 
		      if($val !=0){
		    if($i%12==1)
		    $html .='<tr>';				
		    $html .='<td width="8.33%"  style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
		     <p style="margin:0; border:1px solid '.$color.'; background-color:#fff; padding:5px; color:'.$color.';">'.$distance.'</p>
		    </td>';	 
		    if($i%12==0)
		    $html .='</tr>';
		    $i++;
		    $j++;
		    $checkclm++;
		}
		  }
		}
	    }
	    
	    $taxonomys= array('locality','feature','interior','exterior');
	    
	    foreach($taxonomys as $taxonomy){
	    $terms = wp_get_post_terms($post_id, $taxonomy);
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {
	      	if(isset($term) && $term!="" && z_taxonomy_image_url($term->term_id)!=''){
		    if($i%12==1)
			$html .='<tr>';
				
		    $html .='<td width="8.33%" style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" /></td>';
		 if($i%12==0 )
			{
				$html .='</tr>';
				
			}
			if($i==23 || $checkclm > 23){
				break;
			}
		    $i++;
		    $j++;

		    $checkclm++;
		  }
	       }
	    }
	}	

	 if($checkclm<=12){
	 		@$calc = 100/$checkclm;
	 		$calc = 100-$calc;
	 			$html .='<td width="'.$calc.'"></td>';
	 }
	return $html;
    }


    function print_featuresIcon_count_A5($post_id){    
	
	  
	    $i=1;
	    $j=0;
	    $checkclm= 0;
	    $html ='';	
	    
	    $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
	     if ( !empty( $terms ) && !is_wp_error( $terms ) ){	
		$taxonomy_meta['type']=1;$taxonomy_meta['search']=0;
		  foreach ( $terms as $term ) {
		   $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
			if($taxonomy_meta['type']==2 && get_post_meta($post_id,'_feature_'.$term->term_id,true)!=''){
			    $fnuber= get_post_meta($post_id,'_feature_'.$term->term_id,true);
			    $fnuber =(isset($fnuber ) && is_numeric($fnuber)) ? $fnuber: $fnuber;					 
			    $fnuber =(isset($fnuber ) && !is_numeric($fnuber)) ?__($fnuber,'azull'): $fnuber;
			    if($i%12==1)
			    $html .='<tr>';				
			    $html .='<td width="8.33%" style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
						    <p style="margin:0; border:1px solid '.$color.'; background-color:#fff; padding:5px; color:'.$color.';">'.$fnuber.'</p>
						    </td>';
			    if($i%12==0)			
			    $html .='</tr>';
			    $i++;
			    $j++;
			    $checkclm++;
			}
		      $taxonomy_meta['search']=0;  
		   } 
	    }
	    
	    $terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );  
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		  $distance="";
		  $val=get_post_meta($post_id,'_scores_'.$term->term_id,true);
		  if(isset($val) && $val!=""){
		    $distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km' : number_format((float)$val,0,".","") .'m'; 	    
    
		      
		    if($i%12==1)
			$html .='<tr>';			
			$html .='<td width="8.33%" style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
			    <p style="margin:0; border:1px solid '.$color.'; background-color:#fff; padding:5px; color:'.$color.';">'.$distance.'</p></td>';		    
		    if($i%12==0)
			$html .='</tr>';
		    $i++;
		    $j++;
		    $checkclm++;
		  }
		}
	    }
	    
	    $terms  = get_terms( 'dimensions', 'orderby=id&hide_empty=0' ); 
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		  $distance="";
		  $val=get_post_meta($post_id,'_dimensions_'.$term->term_id,true);
		  if(isset($val) && $val!=""){
		    //$distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km²' : number_format((float)$val,0,".","") .'m²'; 
		    $distance .= ((float)$val>999) ? number_format(((float)$val),0,".","").'m²' : number_format((float)$val,0,".","") .'m²'; 	    
    
		      
		    if($i%12==1)
		    $html .='<tr>';				
		    $html .='<td width="8.33%"  style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
		     <p style="margin:0; border:1px solid '.$color.'; background-color:#fff; padding:5px; color:'.$color.';">'.$distance.'</p>
		    </td>';	 
		    if($i%12==0)
		    $html .='</tr>';
		    $i++;
		    $j++;
		    $checkclm++;
		  }
		}
	    }
	    
	    $taxonomys= array('locality','feature','interior','exterior');
	    
	    foreach($taxonomys as $taxonomy){
	    $terms = wp_get_post_terms($post_id, $taxonomy);
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		    if($i%12==1)
			$html .='<tr>';
				
		    $html .='<td width="8.33%" style="background-color:'.$color.';" bgcolor="'.$color.'" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" /></td>';
		 if($i%12==0 )
			{
				$html .='</tr>';
				
			}
			if($i==23 || $checkclm > 23){
				break;
			}
		    $i++;
		    $j++;

		    $checkclm++;
		  }
	       
	    }
	}	

	
	return $checkclm;

    }