<div class="webgroup" id="subscriber">
  <div class='wraper wraper-s'>
     <?php
       $subscribers = new Subscribers_Table();
       $subscribers->prepare_items();
       $subscribers->display(); 
     ?>
     <style>.row-actions{visibility: visible!important;}</style>
   </div>
</div>
 <style>.wraper-s{background: none repeat scroll 0 0 hsla(0, 0%, 0%, 0) !important;  position: relative !important;  top: 0 !important;}</style>

<?php
class Subscribers_Table extends WP_List_Table {
    
    
    function __construct(){
     
        global $status;
 
      

        parent::__construct( array(
            'singular'  => __( 'Subscriber', 'azull' ),     //singular name of the listed records
            'plural'    => __( 'Subscriberss', 'zull' ),   //plural name of the listed records
            'ajax'      => false        //does this table support ajax?

         ) );

    //add_action( 'admin_head', array( $this, 'admin_header' ) );            
    //add_action( 'admin_action_subscribers', array('Subscribers_Table','process_bulk_action') );
    }

    function admin_header() {
        $page = ( isset($_GET['page'] ) ) ? esc_attr( $_GET['page'] ) : false;
        if( 'my_list_test' != $post )
        return;
        echo '<style type="text/css">';
        echo '.wp-list-table .column-id { width: 5%; }';
        echo '.wp-list-table .column-subscriberstitle { width: 40%; }';
        echo '.wp-list-table .column-author { width: 35%; }';
        echo '.wp-list-table .column-isbn { width: 20%;}';
        echo '</style>';
    }

    function no_items() {
        _e( 'No subscriberss found, dude.' );
    }

    function column_default( $item, $column_name ) {
        switch( $column_name ) {
           case 's-lang':
                  global $q_config; 
                  return $q_config['language_name'][$item[ $column_name ]];
             case 's-date':
              return date('d-m-Y H:i',strtotime($item[ $column_name ]))  ;   
            case 's-sl':
            case 's-name':
            case 's-email':
            case 's-address':
            case 's-ip':
            case 'action':
                return $item[ $column_name ];
            default:
                return ;//print_r( $item, true ) ; //Show the whole array for troubleshooting purposes
        }
    }


    function get_columns(){

        $columns = array(
            's-sl'      => __( 'SL', 'azull'  ),             
            's-date'      => __( 'Date', 'azull'  ),
            's-lang'      => __( 'Language', 'azull'  ),
            's-name' => __( 'Name', 'azull' ),
            's-email'    => __( 'Email', 'azull'  ),
            's-address'      => __( 'Address', 'azull'  ),
            's-ip'      => __( 'IP address', 'azull'  ),
            'action'        => __( 'Action', 'azull'  ) 
        );
         return $columns;
    }

    function usort_reorder( $a, $b ) {
      // If no sort, default to title
      $orderby = ( ! empty( $_GET['orderby'] ) ) ? $_GET['orderby'] : 'subscriberstitle';
      // If no order, default to asc
      $order = ( ! empty($_GET['order'] ) ) ? $_GET['order'] : 'asc';
      // Determine sort order
      $result = strcmp( $a[$orderby], $b[$orderby] );
      // Send final sort direction to usort
      return ( $order === 'asc' ) ? $result : -$result;
    }

   function column_action($item){
    
     $actions = array(
               'edit'      => sprintf('<a href="">Edit</a>'),
               'delete'    => sprintf('<a href="">Delete</a>'),
           );
   
     return sprintf('%1$s %2$s', $item['id'], $this->row_actions($actions) );
   }
   function display_tablenav( $which ) {
    if ( 'top' == $which )
    //wp_nonce_field( 'bulk-' . $this->_args['plural'] );
    ?>
      <div class="tablenav <?php echo esc_attr( $which ); ?>">
      <div class="alignleft actions bulkactions">
    <?php $this->bulk_actions( $which ); ?>
    </div>
      <?php
      $this->extra_tablenav( $which );
      $this->pagination( $which );
      ?>
     <br class="clear" />
     </div>
    <?php
    }
   function prepare_items() {
       global  $post ; 
       $access = get_post_meta( $post->ID, 'access', true);
       if(!isset($access['mailChipKey']))
            return;
          
        if(!isset($access['mailListID']))
            return;
          
       $subscribers = Settings::lists_members(($access['mailChipKey']) ? $access['mailChipKey']:'', ( $access['mailListID'] )?$access['mailListID'] : '');
              
        $i=count( $subscribers);
        foreach($subscribers['data'] as $subscriber ):
        
        $subscribers_data[] =array( 's-sl' =>$i,'s-id' => $subscriber['merges']['UID'].":".$subscriber['email'],'s-date' => $subscriber['timestamp_opt'],
                                    's-lang' => $subscriber['language'],
                                    's-name' => $subscriber['merges']['FNAME']." ".$subscriber['merges']['LNAME'],
                                    's-email' => $subscriber['email'],
                                    's-address' =>"Street:".$subscriber['merges']['STREET']."<br/>"
                                                  ."City:".$subscriber['merges']['CITY']."<br/>"
                                                  ."State:".$subscriber['merges']['STATE']."<br/>"
                                                  ."Country:".$subscriber['merges']['COUNTRY']."<br/>"
                                                  ."Zip:".$subscriber['merges']['ZIP']."<br/>"
                                                  ."Phone:".$subscriber['merges']['PHONE']."<br/>"
                                                  ."Mobile:".$subscriber['merges']['MOBILE']."<br/>"
                                                  ,
                                    's-ip' => $subscriber['ip_opt']                                   
                                 );
            //todo: implement it in phase 3...
         /* if(isset($subscriber['merges']['UID']) && $subscriber['merges']['UID']!=''){
            global $post;
            $obj = new Xmlrpc_Client($post->ID);
            $result=$obj->xmlrpc_searchCriteria((integer)$subscriber['merges']['UID']);
            print_r($result); die;
          }*/
          
        $i--;
        endforeach;
        $data = $subscribers_data;
      
      $columns  = $this->get_columns();
      $hidden   = array();
     
     // $sortable = $this->get_sortable_columns();
      $this->_column_headers = array( $columns, $hidden, $sortable );
     // $this->process_bulk_action();
      usort( $data, array( &$this, 'usort_reorder' ) );
      
      
      
      $per_page = 5;
      $current_page = $this->get_pagenum();
      $total_items = count( $data );
    
      // only ncessary because we have sample data
      $this->found_data = array_slice( $data,( ( $current_page-1 )* $per_page ), $per_page );
    
      $this->set_pagination_args( array(
        'total_items' => $total_items,                  //WE have to calculate the total number of items
        'per_page'    => $per_page                     //WE have to determine how many items to show on a page
      ) );
      $this->items = $this->found_data;
      
    }
    


} //class