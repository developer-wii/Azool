<?php
defined('ABSPATH') or die("No script kiddies please!");
	
setlocale(LC_ALL, $new_locale);
$q_config['language'] = substr($new_locale, 0, 2);
	


    $html .='<div id="template1" class="template" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:14px;width:1024">';

    
    if(!empty($ids))
    foreach($ids as $val){
	$post = get_post($val);
	$term = get_the_terms($post->ID, 'category'); //property taxonomy
	
	global $aj_config;
	    $html .='<tr>';
	    $html .='<td>';
	$html .='<table  width="1024" cellspacing="0" cellpadding="0" align="center" style=" font-family:Arial, Helvetica, sans-serif;  color:#333; font-size:14px;page-break-inside: avoid; page-break-after: always;">';	
	$html .='<tr>';
	    $html .='<td colspan="2">';
		$html .='<table width="100%" cellspacing="10" cellpadding="0">';
		    $html .='<tr>';
			$html .='<td valing="top" style="vertical-align:top;width: 66px;">';
			    $html .='<img width="66" height="66" alt="Azull.info" src="'.WP_PLUGIN_URL.'/azull/images/logo.jpeg">';
			$html .='</td>';
			
			$html .='<td style="vertical-align:top;" valing="top">';
			    $html .='<table width="100%" cellspacing="0" cellpadding="0">';
				    $html .='<tr>';
						    $html .='<td valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:22px; text-transform:uppercase; padding:0;text-align:left; font-weight:bold;color:#333;line-height:35px;">'.qtranxf_use($_POST['lng'],$post->post_title).'</td>';		    
						    $html .='<td valign="bottom"  style="font-family:Arial, Helvetica, sans-serif; color:#333; font-size:22px; line-height:35px;text-transform:capitalize; padding:0;text-align:right;">Ref. '.get_post_meta($post->ID,'_nreal_id',true).'<br><strong style="color:#00a1e4;">'.number_format ( (integer)azull_price('Sales Price',$post->ID) , 0 , "" , "." ).$aj_config['currency'].'</strong></td>';
				    $html .='</tr>';	
					
			    $html .='</table>';
			$html .='</td>';
		    $html .='</tr>';
		$html .='</table>';
		
	    $html .='</td>';
	   
	$html .='</tr>';
	
	$html .='<tr>';
	    $html .='<td valing="top" style="vertical-align:top;">';
		$html .='<table width="100%" cellspacing="10" cellpadding="0">';
		    $html .='<tr>';
			$html .='<td colspan="8">';
			    	    $url =wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full' );
				    $html .='<img  width="680px" height="320px" style="float: left;  padding: 0;width:100%;" src="'.$url[0].'"/>';
			$html .='</td>';
		$html .='</tr>';
		$html .=print_gallery_A4($post->ID,4);
		$html .=print_featuresIcon_A4($post->ID);		
		$html .='</table>';
	    $html .='</td>';	    
	    $html .='<td valing="top" style="width:30%;vertical-align:top; padding-top:10px;">';
	    
		if(qtranxf_use($_POST['lng'],$post->post_content)!='')
		$html .=qtranxf_use($_POST['lng'],$post->post_content);
		
		$html .='<br><br><strong>'.__('Category','azull').'</strong> : '.property_category($post->ID).'</h4><br>';                   
		$html .='<strong>'.__('Status','azull').'</strong> : '.property_status($post->ID).'<br>';
		if(build_year($post->ID))
		$html .='<strong>'.__('Build Year','azull').'</strong> : '.build_year($post->ID).'<br>';
		$html .='<strong>'.__('Location','azull').'</strong> : '.property_location($post->ID,false);
		
		$html .='<br><br><strong>'.__('Sales Price','azull').'</strong> : '.number_format ( (integer)azull_price('Sales price',$post->ID) , 0 , "" , "." ).$aj_config['currency'].'<br>';                     
		$html .='<strong>'.__('Total Price','azull').'</strong> : '.number_format ( (integer)azull_price('Total price',$post->ID) , 0 , "" , "." ).$aj_config['currency'].'<br>';
		$html .="<span style='font-size:8px;'>( ".__('Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.','azull')." )</span>";
		if(azull_price('Old price',$post->ID)!='')
		$html .='<br><strong>'.__('Old Price','azull').'</strong> : '.number_format ( (integer)azull_price('Old price',$post->ID), 0 , "" , "." ).$aj_config['currency'];
		
	    $html .='</td>';
	$html .='</tr>';
	$html .='</table>';

	

    }

$html .='</div>';


function print_gallery_A4($post_id,$limit){    
    $html='';                 
    $i=1;  
            foreach (  Property_Meta::azull_gallery($post_id) as $id ) {
		
               if(get_post_thumbnail_id( $post_id )!=$id && $i<=$limit):
	       
	        if($i%2==1)
		$html .='<tr>';
		
		$html .= '<td colspan="4">';
		$url =wp_get_attachment_image_src( $id, 'pdf-small' );				
		$html .= '<img width="348px" height="220px" src="'.$url[0].'"/>';
		$html .= '</td>';
		
		 if($i%2==0)
		$html .='</tr>';
                $i++;
              endif;
	    }
    $html.='';                 	    
	    
    return $html;               
    }
    function print_featuresIcon_A4($post_id){    
	
	    $i=1;
	    $j=0;
	    $html ='';	
	    
	    $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
	     if ( !empty( $terms ) && !is_wp_error( $terms ) ){	
		$taxonomy_meta['type']=1;$taxonomy_meta['search']=0;
		  foreach ( $terms as $term ) {
		   $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
			if($taxonomy_meta['type']==2 && get_post_meta($post_id,'_feature_'.$term->term_id,true)!=''){
			    $fnuber= get_post_meta($post_id,'_feature_'.$term->term_id,true);
			    $fnuber =(isset($fnuber ) && is_numeric($fnuber)) ? $fnuber: $fnuber;					 
			    $fnuber =(isset($fnuber ) && !is_numeric($fnuber)) ?__($fnuber,'azull'): $fnuber;
			    if($i%8==1)
			    $html .='<tr>';				
			    $html .='<td bgcolor="#1566B1" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
						    <p style="margin:0; border:1px solid #1566B1; background-color:#fff; padding:5px; color:#1566B1;">'. $fnuber.'</p>
						    </td>';
			    if($i%8==0)			
			    $html .='</tr>';
			    $i++;
			    $j++;
			}
		      $taxonomy_meta['search']=0;  
		   } 
	    }
	    
	    $terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );  
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		  $distance="";
		  $val=get_post_meta($post_id,'_scores_'.$term->term_id,true);
		  if(isset($val) && $val!=""){
		    $distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km' : number_format((float)$val,0,".","") .'m'; 	    
    
		      
		    if($i%8==1)
			$html .='<tr>';
			
			$html .='<td bgcolor="#1566B1" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
			    <p style="margin:0; border:1px solid #1566B1; background-color:#fff; padding:5px; color:#1566B1;">'.$distance.'</p></td>';		    
		    if($i%8==0)
			$html .='</tr>';
		    $i++;
		    $j++;
		  }
		}
	    }
	    
	    $terms  = get_terms( 'dimensions', 'orderby=id&hide_empty=0' ); 
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		  $distance="";
		  $val=get_post_meta($post_id,'_dimensions_'.$term->term_id,true);
		  if(isset($val) && $val!=""){
		    $distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km²' : number_format((float)$val,0,".","") .'m²'; 	    
    
		      
		    if($i%8==1)
		    $html .='<tr>';				
		    $html .='<td bgcolor="#1566B1" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" />
		     <p style="margin:0; border:1px solid #1566B1; background-color:#fff; padding:5px; color:#1566B1;">'.$distance.'</p>
		    </td>';	 
		    if($i%8==0)
		    $html .='</tr>';
		    $i++;
		    $j++;
		  }
		}
	    }
	    
	    $taxonomys= array('locality','feature','interior','exterior');
	    
	    foreach($taxonomys as $taxonomy){
	    $terms = wp_get_post_terms($post_id, $taxonomy);
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {	
		    if($i%8==1)
			$html .='<tr>';
				
		    $html .='<td bgcolor="#1566B1" align="center"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66px" height="66px" /></td>';
		 if($i%8==0)
			$html .='</tr>';
		    $i++;
		    $j++;
		  }
	       
	    }
	}	
	    
	return $html;
    }