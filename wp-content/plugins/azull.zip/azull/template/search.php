<?php defined('ABSPATH') or die("No script kiddies please!"); ?>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.js"></script>

    <div id="search-form">
        <div class="search-icon"><img src="<?php echo WP_PLUGIN_URL ?>/azull/images/advancesearch.gif"></div>
        <div class="search-form">
           <form role="search" method="post" id="searchform" action="<?php echo $_SERVER['REQUEST_URI'];?>">
            <ul>
                <li class="span2 spanfull">
                <table>
                    <tr><th>Category</th>
                        <th>Type</th>
                    </tr>
                    <tr>
                        <td>
                            <?php $terms  = get_terms( 'categories', 'orderby=id&hide_empty=0' ); ?>
                            <select id="property_category" name="property_category[]" multiple >
                                <?php foreach ( $terms as $term ) {   ?>
                                    <option value='<?php echo $term->term_id; ?>' ><?php echo $term->name; ?></option>
                                <?php } ?>
                            </select>
                            <input value="activate selectator" id="activate_property_category" type="hidden">
                        </td>
                        <td>
                            <?php $terms  = get_terms( 'type', 'orderby=id&hide_empty=0' ); ?>
                            <select id="property_type" name="property_type[]" multiple >
                                <?php foreach ( $terms as $term ) { ?>
                                    <option value='<?php echo $term->term_id; ?>' ><?php echo $term->name; ?></option>
                                <?php } ?>
                            </select>
                            <input value="activate selectator" id="activate_property_type" type="hidden">
                        </td>
                    </tr>
                </table> 
            </li>
            
           <li class="span2 spanfull">
                <table>
                    <tr><th>View</th>
                        <th>Orientation</th>
                    </tr>
                    <tr>
                        <td>
                               <?php $terms  = get_terms( 'view', 'orderby=id&hide_empty=0' ); ?>    
                                <select id="property_view" name="property_view[]" multiple >
                                    <?php foreach ( $terms as $term ) { ?>
                                        <option value='<?php echo $term->term_id; ?>' ><?php echo $term->name; ?></option>
                                    <?php } ?>
                                </select>
                                <input value="activate selectator" id="activate_property_view" type="hidden"> 
                        </td>
                        <td>
                                    <?php $terms  = get_terms( 'orientation', 'orderby=id&hide_empty=0' ); ?> 
                                    <select class="selectator" id="property_orientation" name="property_orientation">
                                        <?php foreach ( $terms as $term ) { ?>
                                            <option value='<?php echo $term->term_id; ?>' ><?php echo $term->name; ?></option>
                                        <?php } ?>
                                    </select>
                                     
                        </td>
                    </tr>
                </table> 
            </li>
            
            <li class="span2 spanfull">
                <table>
                    <tr><th>Proprietor</th>
                        <th>Agent</th>
                    </tr>
                    <tr>
                        <td>
                            <select id="activate_proprietor" name='activate_proprietor'>
                                  <option value=''>&nbsp;</option>
                                  <?php $parent_terms = get_terms('proprietor', array('parent' => 0, 'orderby' => 'slug', 'hide_empty' => false)); ?>
                                  <?php foreach ($parent_terms as $pterm):?>
                                    <optgroup style="margin: 0 0 0 5px;" label="<?php echo $pterm->name; ?>">
                                     <?php
                                      $cterms = get_terms("keyholder", array('child_of' => $pterm->term_id, 'parent' => $pterm->term_id, 'orderby' => 'group_name', 'hide_empty' => false));
                                     foreach ($cterms as $cterm):
                                     $taxonomy_meta = get_option('azull_taxonomy_meta_'.$cterm->term_id);
                                     $phone= (isset($taxonomy_meta['phone']))? $taxonomy_meta['phone']:'';
                                     $email= (isset($taxonomy_meta['email']))? $taxonomy_meta['email']:'';   
                                     ?>
                                        <option value='<?php echo $cterm->term_id;?>' data-subtitle="<?php echo "Phone :". $phone ."<br/>Email:".$email ;?>"  data-left="<img src='<?php echo z_taxonomy_image_url($cterm->term_id); ?>'>" data-right="<?php echo $cterm->term_id;?>"><?php echo $cterm->name;?></option>
                                     <?php endforeach;?>
                                    </optgroup>
                                 <?php endforeach; ?>
                                </select>                                
                                <input value="activate selectator" id="activate_proprietor_click" type="hidden"> 

                        </td>
                        <td>
                                <select id="activate_agent" name='activate_agent'>
                                  <option value=''>&nbsp;</option>
                                     <?php
                                      $terms = get_terms('agent', array('parent' => 0, 'orderby' => 'slug', 'hide_empty' => false));
                                     foreach ($terms as $term):
                                     $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
                                     $phone= (isset($taxonomy_meta['phone']))? $taxonomy_meta['phone']:'';
                                     $email= (isset($taxonomy_meta['email']))? $taxonomy_meta['email']:'';   
                                     ?>
                                        <option value='<?php echo $term->term_id;?>' data-subtitle="<?php echo "Phone :". $phone ."<br/>Email:".$email ;?>"  data-left="<img src='<?php echo z_taxonomy_image_url($term->term_id); ?>'>" data-right="<?php echo $term->term_id;?>"><?php echo $term->name;?></option>
                                     <?php endforeach;?>
                                </select>
                                
                                <input value="activate selectator" id="activate_agent_click" type="hidden"> 
                        </td>
                    </tr>
                </table> 
            </li>
            
            <li class="span2 spanfull">
                <table>
                    <tr><th>Financial status</th>
                        <th>Availability</th>
                    </tr>
                    <tr>
                        <td>
                                <select class="selectator" name='property_financial'>
                                    <option value='0'>--</option>
                                    <option value='1' >Sold</option>
                                    <option value='2'>In process</option>
                                </select>
                        </td>
                        <td>
                                <select class="selectator" name='property_availability'>
                                  <option value='0'>--</option>      
                                  <option value='1'>Not for sale</option>
                                  <option value='2' >For sale</option>
                                 </select>
                        </td>
                    </tr>
                </table> 
            </li>
            

            
            <li class="span2 spanfull">
                <table>
                    <tr><th>Features</th>
                        <th>Interior</th>
                    </tr>
                    <tr>
                        <td>
                            <?php $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' ); ?>    
                            <select id="property_feature" name="property_feature[]" multiple>
                                <?php foreach ( $terms as $term ) { ?>
                                    <option value='<?php echo $term->term_id; ?>' ><?php echo $term->name; ?></option>
                                <?php } ?>
                            </select>
                            <input value="activate selectator" id="activate_property_feature" type="hidden">
                        </td>
                        <td>
                            <?php $terms  = get_terms( 'interior', 'orderby=id&hide_empty=0' ); ?>   
                            <select id="property_interior" name="property_interior[]" multiple>
                                <?php foreach ( $terms as $term ) { ?>
                                    <option value='<?php echo $term->term_id; ?>' ><?php echo $term->name; ?></option>
                                <?php } ?>
                            </select>
                            <input value="activate selectator" id="activate_property_interior" type="hidden">
                        </td>
                    </tr>
                </table> 
            </li>

            
            <li class="span2 spanhalf">
                <table>
                    <tr>
                        <th >Exterior</th>
                        <th>Build year</th>
                    </tr>
                    <tr>
                        <td>                            
                                      <select id="property_exterior" name="property_exterior[]" multiple>
                                        <?php foreach ( $terms as $term ) { ?>
                                            <option value='<?php echo $term->term_id; ?>' ><?php echo $term->name; ?></option>
                                        <?php } ?>
                                    </select>
                                    <input value="activate selectator" id="activate_property_exterior" type="hidden">
                        
                        </td>
                        <td>
                          <input class="numeric" name="min-year" maxlength="4" autocomplete="off" type="text">-<input maxlength="4" autocomplete="off" name="max-year" class="numeric" type="text">    
                        </td>                        
                    </tr>
                </table>  
            </li>

            <li class="span2 spanfull-2">
                <table>
                    <tr>
                        <th colspan="2" >Sale Price</th>
                        <th colspan="0"></th>
                    </tr>
                    <tr>
                        <td>                            
                           <input class="decimal" placeholder="Min"  autocomplete="off" name="min-sale-price" type="text"><span>-<span>
                        
                        </td>
                        <td>
                           <input placeholder="Max" class="decimal" autocomplete="off" name="max-sale-price" type="text">
                        </td>                        
                    </tr>
                </table>  
            </li>

            <li class="span2 spanfull-2">
                <table>
                    <tr>
                        <th colspan="2" >Total price</th>
                        <th colspan="0"></th>
                    </tr>
                    <tr>
                        <td>                            
                           <input class="decimal" placeholder="Min"  autocomplete="off" name="min-total-price" type="text"> <span>-<span>
                        
                        </td>
                        <td>
                            <input placeholder="Max" class="decimal" autocomplete="off" name="max-total-price" type="text">
                        </td>                        
                    </tr>
                </table>  
            </li>
            
            <li class="span2 spanfull-2">
                <table>
                    <tr>
                        <th colspan="2" >Old price</th>
                        <th colspan="0"></th>
                    </tr>
                    <tr>
                        <td>                            
                           <input class="decimal" placeholder="Min"  autocomplete="off" name="min-old-price" type="text"><span>-<span>
                        
                        </td>
                        <td>
                            <input placeholder="Max" class="decimal" autocomplete="off" name="max-old-price" type="text">
                        </td>                        
                    </tr>
                </table>  
            </li>
            
            <li class="span2 spanfull-2">
                <table>
                    <tr>
                        <th colspan="2" >Reservation amount</th>
                        <th colspan="0"></th>
                    </tr>
                    <tr>
                        <td>                            
                           <input class="decimal" placeholder="Min"  autocomplete="off" name="min-reservation-amount" type="text"><span>-<span>
                        
                        </td>
                        <td>
                            <input placeholder="Max" class="decimal" autocomplete="off" name="max-reservation-amount" type="text">
                        </td>                        
                    </tr>
                </table>  
            </li>
            
            

            <li class="span2 spanhalf">
                <table>
                    <tr><th>No of bedrooms</th>
                        <th>No of bathrooms</th>
                    </tr>
                    <tr>
                        <td>                            
                            <input  placeholder="Min" class="numeric" maxlength="3" autocomplete="off" name="min-bedrooms" type="text">-<input  placeholder="Max" class="numeric" maxlength="3" autocomplete="off" name="max-bedrooms" type="text">
                        </td>
                        <td>
                            
                            <input  placeholder="Min" maxlength="3" class="numeric" autocomplete="off" name="min-bathrooms" type="text">-<input  placeholder="Max" maxlength="3" class="numeric" autocomplete="off" name="max-bathrooms" name="country" type="text">
                        </td>
                        
                    </tr>
                </table>  
            </li>

            <li class="span2 spanhalf">
                <table>
                    <tr><th>Storey</th>
                        <th>No of storeys</th>
                    </tr>
                    <tr>
                        <td>                            
                            <input  placeholder="Min" class="numeric" maxlength="3" autocomplete="off" name="min-storey" type="text">-<input  placeholder="Max" class="numeric" maxlength="3" autocomplete="off" name="max-storey" type="text">
                        </td>
                        <td>
                            
                            <input  placeholder="Min" maxlength="3" class="numeric" autocomplete="off" name="min-storeys" type="text">-<input  placeholder="Max" maxlength="3" class="numeric" autocomplete="off" name="max-storeys" name="country" type="text">
                        </td>
                        
                    </tr>
                </table>  
            </li>
            
            <li class="span2 spanfull-3">
                <table>
                    <tr><th>Country</th>
                        <th>Region</th>
                        <th>Place</th>
                    </tr>
                    <tr>
                        <td><input  name="country" type="text"></td>
                        <td><input  name="state" type="text"></td>
                        <td><input  name="city" type="text"></td>
                    </tr>
                </table>    
            
            </li>
               
            <li class="span2">
            
            <input  class="button button-primary button-large" type="submit" style="width: 100%;text-align: center;margin: 20px 0 0 0;text-transform:uppercase;" value="submit query">
            </li>
            
            </ul>
           </form>
        </div>
    </div>
    <div id="search-content">


        <?php

            $paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
            if(isset($_GET['paged']))
            $paged = absint($_GET['paged']);
            $custom_query = new WP_Query(array(
                                            'post_status' => 'publish',
                                            'post_type' => 'property',
                                            'order' => 'ASC',
                                            'posts_per_page' => 5,                                           
                                            'paged' => $paged
                                        ));
        
            $args = array(
                'posts_per_page' => 5,
                'post_type' => 'property',
                'paged' => $paged,
        );
            $custom_query= new WP_Query( $args );
        	
            global $q_config;
	    $languages = qtranxf_getSortedLanguages();
        ?>
        
            <script type="text/javascript">
		//<![CDATA[
			function property_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('.property_language_{$lang}').hide();"; endforeach; ?>
				
				//Show selected, recount chars
				jQuery('.property_language_'+lang).show();
				
			}
		//]]>
	    </script>
            <div class="property_language-switcher">
		<?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:property_switch_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
		</div>
           <?php while ( $custom_query->have_posts() ) : $custom_query->the_post();
           $val = get_post_meta( get_the_ID(),'property_meta_finance',true );
           $meta = Azull_Location::load_meta(get_the_ID());

           ?>

           <?php  //print_r($val['salePrice']); ?>
            <section  id="property-<?php echo get_the_ID(); ?>" class="property">
                <button title="Print this" class="print-link no-print" onclick="jQuery.print('#property-<?php echo get_the_ID(); ?>')"> &nbsp;</button>
                <header>
                    <div class="azull-logo"><img width="90" height="90" alt="Azull.info" src="<?php echo WP_PLUGIN_URL ?>/azull/images/logo.jpeg"></img></div>
                    <div class="title">
                         <?php foreach($languages as $lang) : ?>
                         <h1 class="property_language_<?php echo $lang; ?>">  <?php echo qtranxf_use($lang,get_the_title()); ?></h1>
                         <?php  endforeach; ?>
                         
                        <h4>
                            <?php foreach($languages as $lang) : ?>
                            <span class="property_language_<?php echo $lang; ?>">#<?php echo (! $text = AzullServer::traslate_word($lang,"Ref")) ? "Ref" : $text; ?>:&nbsp;<?php echo get_the_ID(); ?></span>&nbsp;&nbsp
                            <span class="property_language_<?php echo $lang; ?>">#<?php echo (! $text = AzullServer::traslate_word($lang,"Proprietor")) ? "Proprietor" : $text; ?>&nbsp;<?php echo (! $text = AzullServer::traslate_word($lang,"Ref")) ? "Ref" : $text; ?>:</span>&nbsp;&nbsp
                            <span class="property_language_<?php echo $lang; ?>"><?php echo (! $text = AzullServer::traslate_word($lang,"price")) ? "price" : $text; ?> : </span>
                             <?php  endforeach; ?>
                             <?php echo (isset($val['totalPrice'][99])) ? $val['totalPrice'][99] :''; ?>
                        </h4>
                        
                    </div>                    
                </header>
                
                <div class="content-wrapper">       
                    <aside>
                        <div class="fetured">
                            <?php if (has_post_thumbnail( $custom_query->ID ) ): ?>
                            <?php $url = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID(), 'thumbnail') ); ?>
                                <img src="<?php echo $url ?>" />
                            <?php endif; ?>
                        </div>
                        <div class="gallery">
                            
                            <?php
                               $values = get_post_custom(get_the_ID());

                         
                               if(isset($values['property_gallery'])) {           
                                    $ids = json_decode(base64_decode($values['property_gallery'][0]));
                                }
                                else {
                                    $ids = array();
                                }
                               
                            ?>    
                            <ul>
                                <?php foreach ($ids as $id) : $url = wp_get_attachment_image_src($id);?>
                                <li><img src="<?php echo $url[0]; ?>"></li>
                                 <?php endforeach; ?>
                            </ul>   
                        </div>
                    </aside>
                    
                    <div class="content">
                        <?php foreach($languages as $lang) : ?>
                        <p class="property_language_<?php echo $lang; ?>"><?php echo qtranxf_use($lang,get_the_content()); ?></p>
                        <?php  endforeach; ?>
                        <div class="meta">
                          <br>                          
                            <?php foreach($languages as $lang) : ?>
                            <p class="property_language_<?php echo $lang; ?>"><strong><?php echo (! $text = AzullServer::traslate_word($lang,"Location")) ? "Location" : $text; ?>&nbsp:&nbsp;</strong>
                            <?php echo $meta['address'][$lang]; ?><br/>
                            <?php echo $meta['place'][$lang]; ?>,<?php echo $meta['region'][$lang];?>,<?php echo $meta['country'][$lang]; ?>-<?php echo $meta['zip'][$lang]; ?>
                            
                            </p>
                            <?php  endforeach; ?>                          
                          <br>
                          <?php foreach($languages as $lang) : ?>
                          <p class="property_language_<?php echo $lang; ?>"><strong>
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Sales")) ? "Sales" : $text; ?>&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Price")) ? "Price" : $text; ?>&nbsp;
                                        &nbsp:&nbsp;<?php echo $q_config['c']; ?><?php echo (isset($val['salePrice'][99])) ? $val['totalPrice'][99] :''; ?>
                          </strong></p>
                          <?php  endforeach; ?>
                          
                          <?php foreach($languages as $lang) : ?>
                          <p class="property_language_<?php echo $lang; ?>"><strong>
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Sales")) ? "Total" : $text; ?>&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Price")) ? "Price" : $text; ?>&nbsp;
                                        &nbsp:&nbsp;<?php echo $q_config['c']; ?><?php echo (isset($val['totalPrice'][99])) ? $val['totalPrice'][99] :''; ?>
                          </strong></p>
                          <?php  endforeach; ?> 
                          
                          <?php foreach($languages as $lang) : ?>
                          <p style="font-size:8px;"class="property_language_<?php echo $lang; ?>"><strong>(&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Estimation")) ? "Estimation" : $text; ?>&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"incl.")) ? "incl." : $text; ?>&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"VAT")) ? "VAT" : $text; ?>,&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Notary")) ? "Notary" : $text; ?>,&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Lawyer")) ? "Lawyer" : $text; ?>,&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Transfer")) ? "Transfer" : $text; ?>,&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"&")) ? "&" : $text; ?>&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Registry")) ? "Registry" : $text; ?>,&nbsp;
                                        <?php echo (! $text = AzullServer::traslate_word($lang,"Tax")) ? "Tax" : $text; ?>.&nbsp;)
                          </strong></p>
                          <?php  endforeach; ?>                         
                          
                          <br>
                        <?php foreach($languages as $lang) : ?>
                            <p class="property_language_<?php echo $lang; ?>"><strong><?php echo (! $text = AzullServer::traslate_word($lang,"Category")) ? "Category" : $text; ?>&nbsp:&nbsp;</strong></p>
                        <?php  endforeach; ?>
                        <?php foreach($languages as $lang) : ?>
                            <p class="property_language_<?php echo $lang; ?>"><strong><?php echo (! $text = AzullServer::traslate_word($lang,"Condition")) ? "Condition" : $text; ?>&nbsp:&nbsp;</strong></p>
                        <?php  endforeach; ?>
                        <?php foreach($languages as $lang) : ?>
                            <p class="property_language_<?php echo $lang; ?>"><strong><?php echo (! $text = AzullServer::traslate_word($lang,"Bedrooms")) ? "Bedrooms" : $text; ?>&nbsp:&nbsp;</strong></p>
                        <?php  endforeach; ?>
                        <?php foreach($languages as $lang) : ?>
                            <p class="property_language_<?php echo $lang; ?>"><strong><?php echo (! $text = AzullServer::traslate_word($lang,"Bathrooms")) ? "Bathrooms" : $text; ?>&nbsp:&nbsp;</strong></p>
                        <?php  endforeach; ?> 

                        </div>
                    </div>
               </div> 
            </section>           
           <script type="text/javascript">
           //<![CDATA[
           property_switch_lang('<?php echo $q_config['default_language'] ?>');
           //]]>
           </script>
           <?php endwhile; ?>
           
	    <div class="wp-azull-pagination">
                <div class="wpsp-page-nav">
                    <?php
                        $big = 999999999; // need an unlikely integer
                        
                        echo paginate_links( array(
                                'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                                'format' => '?paged=%#%',
                                'current' => max( 1,  $paged ),
                                'total' => $custom_query->max_num_pages
                        ) );
                    ?>
		</div>
	    </div><!-- /.wp-azull-pagination -->
        <?php wp_reset_postdata();?>
    </div>
<script>
(function($) {"use strict";
    // A nice closure for our definitions

    function getjQueryObject(string) {
        // Make string a vaild jQuery thing
        var jqObj = $("");
        try {
            jqObj = $(string).clone();
        } catch(e) {
            jqObj = $("<span />").html(string);
        }
        return jqObj;
    }

    function isNode(o) {
        /* http://stackoverflow.com/a/384380/937891 */
        return !!( typeof Node === "object" ? o instanceof Node : o && typeof o === "object" && typeof o.nodeType === "number" && typeof o.nodeName === "string");
    }


    $.print = $.fn.print = function() {
        // Print a given set of elements

        var options, $this, self = this;

        // console.log("Printing", this, arguments);

        if ( self instanceof $) {
            // Get the node if it is a jQuery object
            self = self.get(0);
        }

        if (isNode(self)) {
            // If `this` is a HTML element, i.e. for
            // $(selector).print()
            $this = $(self);
            if (arguments.length > 0) {
                options = arguments[0];
            }
        } else {
            if (arguments.length > 0) {
                // $.print(selector,options)
                $this = $(arguments[0]);
                if (isNode($this[0])) {
                    if (arguments.length > 1) {
                        options = arguments[1];
                    }
                } else {
                    // $.print(options)
                    options = arguments[0];
                    $this = $("html");
                }
            } else {
                // $.print()
                $this = $("html");
            }
        }

        // Default options
        var defaults = {
            globalStyles : true,
            mediaPrint : false,
            stylesheet : null,
            noPrintSelector : ".no-print",
            iframe : true,
            append : null,
            prepend : null
        };
        // Merge with user-options
        options = $.extend({}, defaults, (options || {}));

        var $styles = $("");
        if (options.globalStyles) {
            // Apply the stlyes from the current sheet to the printed page
            $styles = $("style, link, meta, title");
        } else if (options.mediaPrint) {
            // Apply the media-print stylesheet
            $styles = $("link[media=print]");
        }
        if (options.stylesheet) {
            // Add a custom stylesheet if given
            $styles = $.merge($styles, $('<link rel="stylesheet" href="' + options.stylesheet + '">'));
        }

        // Create a copy of the element to print
        var copy = $this.clone();
        // Wrap it in a span to get the HTML markup string
        copy = $("<span/>").append(copy);
        // Remove unwanted elements
        copy.find(options.noPrintSelector).remove();
        // Add in the styles
        copy.append($styles.clone());
        // Appedned content
        copy.append(getjQueryObject(options.append));
        // Prepended content
        copy.prepend(getjQueryObject(options.prepend));
        // Get the HTML markup string
        var content = copy.html();
        // Destroy the copy
        copy.remove();

        var w, wdoc;
        if (options.iframe) {
            // Use an iframe for printing
            try {
                var $iframe = $(options.iframe + "");
                var iframeCount = $iframe.length;
                if (iframeCount === 0) {
                    // Create a new iFrame if none is given
                    $iframe = $('<iframe height="0" width="0" border="0" wmode="Opaque"/>').prependTo('body').css({
                        "position" : "absolute",
                        "top" : -999,
                        "left" : -999
                    });
                }
                w = $iframe.get(0);
                w = w.contentWindow || w.contentDocument || w;
                wdoc = w.document || w.contentDocument || w;
                wdoc.open();
                wdoc.write(content);
                wdoc.close();
                setTimeout(function() {
                    // Fix for IE : Allow it to render the iframe
                    w.focus();
                    w.print();
                    setTimeout(function() {
                        // Fix for IE
                        if (iframeCount === 0) {
                            // Destroy the iframe if created here
                            $iframe.remove();
                        }
                    }, 100);
                }, 250);
            } catch (e) {
                // Use the pop-up method if iframe fails for some reason
                console.error("Failed to print from iframe", e.stack, e.message);
                w = window.open();
                w.document.write(content);
                w.document.close();
                w.focus();
                w.print();
                w.close();
            }
        } else {
            // Use a new window for printing
            w = window.open();
            w.document.write(content);
            w.document.close();
            w.focus();
            w.print();
            w.close();
        }
        return this;
    };

})(jQuery);
</script>
