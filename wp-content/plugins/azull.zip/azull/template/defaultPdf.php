<?php
defined('ABSPATH') or die("No script kiddies please!");
  
  
   global $q_config;
   $new_locale =(isset($_GET['lng'])) ? $_GET['lng'] :qtranxf_getLanguage();	
   $old_locale = get_locale();
   setlocale(LC_ALL, $new_locale);
   $q_config['language'] = substr($new_locale, 0, 2);
   $post = get_post($_GET['id']);
	 /*code for add title and content if not define in language*/
    $title_array = qtranxf_split($post->post_title); 
    $content_array=qtranxf_split($post->post_content); 

    if(isset($title_array) && !empty($title_array)){
       if($title_array[$_GET['lng']]!=''){
        $title=substr(qtranxf_use($_GET['lng'],$post->post_title),0,55);
       }else{   
         $title=getTitleContent($post->ID,$_GET['lng']);
       }
     }
    if(isset($content_array) && !empty($content_array)){
       if($content_array[$_GET['lng']]!=''){
        $content=qtranxf_use(qtranxf_getLanguage(),$post->post_content);  
       }else{   
         $content=getTitleContent($post->ID,$_GET['lng']);
       }
     }
     /*end code*/

   $mpdf=new  mPDF('', '', '','', 15, 15, 11, 15,3, 5);
   $mpdf->charset_in = 'UTF-8';		
   $mpdf->SetDisplayMode('fullpage');
   $mpdf->allowCJKorphans = true; 
   $mpdf->SetTitle(qtranxf_use($_GET['lng'],$post->post_title));
   $mpdf->autoScriptToLang = true;
 
  $clientId = $_GET['clnt'];
 /*global $wpdb;
 $table_name = $wpdb->prefix . "company";
        $results = $wpdb->get_row( 
                    $wpdb->prepare("SELECT * FROM {$table_name} WHERE id =%d", $clientId) 
                 );
     $logo=    $results->cmp_logo;
     $cName=   $results->cmp_name;
     $content= qtranxf_use(qtranxf_getLanguage(),$results->cmp_text);
     $color=   $results->color;
  */
 
$results = get_post($clientId);	
$color=    get_post_meta($clientId, '_companyclr', true);
$cName=    get_post_meta($clientId, '_companyname', true);
  $logourl=  get_post_meta($clientId, 'wp_custom_attachment', true);
  if($logourl!=''){
     $logo=$logourl['url'];
  }else{
     $logo='';
  }

 
 
/*echo  $clientId;die;
   $c_records = get_post_meta($clientId, 'general', true);
   switch ($clientId) {
    case 7933:
        $color = '#00a1e4';
        $logo =  $c_records['logo'];
        $content = stripslashes(get_option('pdfsignature_'.$_GET['lng'],false));
        $cName = "Azull";
      break;
    case 50933:
        $color = '#20A342';
      //  $logo =  WP_PLUGIN_URL."/azull/images/logo.jpeg";
        $logo =  'http://azull.biz/cisin/wp-content/uploads/2016/05/IE_logo1-medium.png';
        $content = stripslashes(get_option('pdfsignature_'.$_GET['lng'],false));
        $cName = "Inmo España";
        $content = str_replace("Azull",$cName,$content);

      break;  
   }*/

   
   $html .="<style>
	       body { font-family: ".(($l=='zh') ? 'wt021' :'DejaVuSansCondensed').", sans-serif; font-size: 8pt; color:#0E4F8B;margin: 0;	height: 100%;	width: 100%;}
	       p{ text-align: justify; margin-bottom: 4pt;  margin-top:0pt;color:#0E4F8B;  }
	       h1 {font-size: 1em;color: white;}
	       h2 {font-size: 1.4em;}
	       h4 {font-size: .5em;}
	       span{font-size:14px;}
	       h1,h4 {text-decoration: none;	color: #0E4F8B;line-height:0px;vertical-align:top;text-transform: capitalize;}
	    </style>" ;
	    
   $mpdf->SetHTMLHeader('<table cellpadding="0"  cellspacing="0" width="100%" style="vertical-align: bottom; font-family: serif; font-size: 8pt;color: hsl(0, 0%, 45%); font-weight: normal; font-style: italic;border-bottom:1px dotted hsl(0, 0%, 45%);">
			<tr>
                          <td  style="text-align: left;color:hsl(0, 0%, 45%); ">'.$title.' - Ref.'.get_post_meta($post->ID,'_nreal_id',true).'</td>
                          <td  style="text-align: right;color:hsl(0, 0%, 45%); "></td>
                       </tr>
                  </table>'
		     );

  $mpdf->SetHTMLFooter('<table cellpadding="0"  cellspacing="0" width="100%" style="vertical-align: bottom; font-family: serif; font-size: 8pt;color: hsl(0, 0%, 45%); font-weight: normal; font-style: italic;border-top:1px dotted hsl(0, 0%, 45%);">
            <tr>
                          <td style="text-align: left; ">
            <table cellpadding="0"  cellspacing="0" style="vertical-align: bottom; font-family: serif; font-size: 8pt;color: hsl(0, 0%, 45%); font-weight: normal; font-style: italic;">
         <tr>
           <td style="text-align: left;color:hsl(0, 0%, 45%);width:600px; "></td>
           <td style="text-align: right;color:hsl(0, 0%, 45%);width:250px; ">Page : {PAGENO}/{nbpg}</td>
         </tr>
           </table>
        </td> 
                       </tr>
                      </table>'
         );


   
		     
		     
   $mpdf->SetColumns(1,'J',0);

   if (has_post_thumbnail($post->ID) ):
      $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID, 'pdf-large') );
     $mpdf->WriteHTML("<div style='margin-bottom:5px;'>
      <img width='48'  alt='Azull.info' src='".$logo."' /> </div>"); 

      $mpdf->WriteHTML("<div style='margin:0;'><img style='margin:0px;padding:0px;width:100%;float:left;height:auto;' src='".$url."' /></div>");
    endif;
    
   //$mpdf->WriteHTML('<h1 style="font-size:14px;padding:5px 0;margin:10px 0 10px 0;color:'.$color.';text-transform:uppercase;">'.qtranxf_use($_GET['lng'],$post->post_title).' Ref.'.get_post_meta($post->ID,'_nreal_id',true).'</h1>');
   $mpdf->WriteHTML('<h1 style="font-size:14px;padding:5px 0;margin:10px 0 10px 0;color:'.$color.';text-transform:uppercase;">'.$title.' Ref.'.get_post_meta($post->ID,'_nreal_id',true).'</h1>');
   $mpdf->WriteHTML(azull_Utility::azull_features_pdf_icons($post->ID,$color));

   $mpdf->SetColumns(1);
   //$mpdf->WriteHTML('<div style="margin:15px 0 0 0;padding:0;font-size:9pt;color:'.$color.';">'.qtranxf_use($_GET['lng'],$post->post_content)."</div>",null,'UTF-8');
   $mpdf->WriteHTML('<div style="margin:15px 0 0 0;padding:0;font-size:9pt;color:'.$color.';">'.$content."</div>",null,'UTF-8');
   $mpdf->WriteHTML('<div>&nbsp;</div>');
   
   $mpdf->WriteHTML(Azull_Utility::azull_meta_pdf($post->ID,$color));
   $mpdf->WriteHTML(Azull_Utility::azull_gallery_pdf($post->ID));
   $mpdf->WriteHTML('<div>&nbsp;</div>');

   $clientId = $_REQUEST['clnt']; 
    $results = get_post($clientId); 
    $color=    get_post_meta($clientId, '_companyclr', true);
    $cName=    get_post_meta($clientId, '_companyname', true);
    $cDisclaimer = qtranxf_use(qtrans_getLanguage(), $results->post_content);


   $mpdf->SetHTMLFooter('<table cellpadding="0"  cellspacing="0" width="100%" style="vertical-align: bottom; font-family: serif; font-size: 8pt;color: hsl(0, 0%, 45%); font-weight: normal; font-style: italic;border-top:1px dotted hsl(0, 0%, 45%);">
      <tr>
                          <td width="100%" tyle="text-align: left; ">
            <table cellpadding="0"  cellspacing="0" width="100%" style="vertical-align: bottom; font-family: serif; font-size: 8pt;color:hsl(0, 0%, 45%);font-weight: normal; font-style: italic;border:none;">
         <tr>
            <td style="text-align: left; ">
               <img width="48"  alt="Azull.info" src="'.$logo.'" />      
            </td>
            <td  style="text-align: left;vertical-align: bottom;color:hsl(0, 0%, 45%);font-size:10pt;">        
               '. $cDisclaimer.'
            </td> 
         </tr>
            </table>
        </td> 
                       </tr>
            <tr>
                          <td style="text-align: left; ">
            <table cellpadding="0"  cellspacing="0" style="vertical-align: bottom; font-family: serif; font-size: 8pt;color: hsl(0, 0%, 45%); font-weight: normal; font-style: italic;">
         <tr>
           <td style="text-align: left;color:hsl(0, 0%, 45%);width:600px; ">© '.date('Y') .' - '.$cName.'</td>
           <td style="text-align: right;color:hsl(0, 0%, 45%);width:250px; ">Page : {PAGENO}/{nbpg}</td>
         </tr>
           </table>
        </td> 
                       </tr>
                      </table>'
         );


   $fileName = "AZULL-".strtoupper($_GET['lng'])."-REF-".get_post_meta($post->ID,'_nreal_id',true).".pdf";  
   $mpdf->Output($fileName,'I');
   setlocale(LC_ALL, $old_locale);	
   $q_config['language'] = substr($old_locale, 0, 2);
   exit;