Node.prototype.prependChild = function(el) {
    this.childNodes[1] && this.insertBefore(el, this.childNodes[1]) || this.appendChild(el);
}

function setCookie(key, value) {
    var expires = new Date();
    expires.setTime(expires.getTime() + (1 * 24 * 60 * 60 * 1000));
    document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}

function getCookie(key) {
    var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
    return keyValue ? keyValue[2] : null;
}

function calculateCommission(elem){
    var salesPrice=0;
    var percentage=0;
    salesprice = parseFloat(jQuery('#salesPrice').val());
    percentage =parseFloat(jQuery('#commissionPer').val());
    var commission = (percentage / 100) * salesprice;   
    jQuery('#commissionAmount').val(parseFloat(commission));    
}

function loadaTax(){
    var data = {
		'action': 'loadaTax',		
		'country' :jQuery('#property_meta_country').val(),
		'region' :jQuery('#property_meta_region').val(),
		'provinces' :jQuery('#property_meta_province').val()
	};
	
	jQuery.post(ajaxurl, data, function(response) {                
		jQuery("#taxTable").html(response);
		
				jQuery("input.numeric").bind("keydown", function(e) {

			var keyCode = e.which ? e.which : e.keyCode
			var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
			if (ret) {
			    jQuery(this).siblings(".description").removeClass("error");
			} else
			{
			    jQuery(this).siblings(".description").addClass("error");
			}
		
			return ret;
		    });
		    jQuery("input.numeric").bind("paste", function(e) {
			return false;
		    });
		    jQuery("input.numeric").bind("drop", function(e) {
			return false;
		    });
		
		
		    //decimal validation
		    jQuery("input.decimal").bind("keypress", function(e) {
		
		      
			var keyCode = e.which ? e.which : e.keyCode
		       
		
			var ret = (((keyCode >= 48 && keyCode <= 57) || keyCode == 46) || specialKeys.indexOf(keyCode) != -1);
		
			if (ret) {
			    jQuery(this).siblings(".description").removeClass("error");
			} else
			{
			    jQuery(this).siblings(".description").addClass("error");
			}
		
			return ret;
		});
	})
}

function loadaFinincialData(post_id){
    var data = {
		'action': 'loadaFinincialData',		
		'country' :jQuery('#property_meta_country').val(),
		'region' :jQuery('#property_meta_region').val(),
		'provinces' :jQuery('#property_meta_province').val(),
		'post_id' : post_id
	};
	
	jQuery.post(ajaxurl, data, function(response) {                
		jQuery("#finance_override").html(response);
		jQuery('.meta_sale_price').trigger('keyup');
		
		jQuery("input.numeric").bind("keydown", function(e) {

			var keyCode = e.which ? e.which : e.keyCode
			var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
			if (ret) {
			    jQuery(this).siblings(".description").removeClass("error");
			} else
			{
			    jQuery(this).siblings(".description").addClass("error");
			}
		
			return ret;
		    });
		    jQuery("input.numeric").bind("paste", function(e) {
			return false;
		    });
		    jQuery("input.numeric").bind("drop", function(e) {
			return false;
		    });
		
		
		    //decimal validation
		    jQuery("input.decimal").bind("keypress", function(e) {
		
		      
			var keyCode = e.which ? e.which : e.keyCode
		       
		
			var ret = (((keyCode >= 48 && keyCode <= 57) || keyCode == 46) || specialKeys.indexOf(keyCode) != -1);
		
			if (ret) {
			    jQuery(this).siblings(".description").removeClass("error");
			} else
			{
			    jQuery(this).siblings(".description").addClass("error");
			}
		
			return ret;
		});
		    
		calculateCommission();    
                
	})
}


var specialKeys = new Array();
specialKeys.push(8); //Backspace
jQuery.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results==null){
       return null;
    }
    else{
       return results[1] || 0;
    }
}
jQuery(document).ready(function($) {
	
/*
 code to remove default SEO data when add new property
 24/Jan/2017
*/
var post_type = jQuery("#post_type").val();
var original_post_status =  jQuery("#original_post_status").val();
var p_title =  jQuery("#title").val();



var langArray = new Array("en", "fr", "nl");
    if(original_post_status=='auto-draft' && post_type=='property'){
       $.each(langArray, function(key,val) {             
         jQuery("#property_meta_title_"+val).val('');
         jQuery("#property_meta_keywords_"+val).val('');
         jQuery("#property_meta_description_"+val).val('');
		
		jQuery('#property_meta_country').on('change', function() {
		       update_property_seo_data();
		});
		jQuery('#property_meta_region').on('change', function() { 
		       update_property_seo_data();
		});

		jQuery('#property_meta_place').on('change', function() { 
		       update_property_seo_data();
		});

		jQuery('#property_category').on('change', function() {
		       update_property_seo_data();
		});
     });
    }

/*
 function to diplay SEO data default value when add new property
 24/Jan/2017
*/
function update_property_seo_data(){

    var cnt= jQuery("#property_meta_country").val();
    var region= jQuery("#property_meta_region").val();
    var place= jQuery("#property_meta_place").val();
    var nrealid =jQuery("#nrealid").val();
    var data = {
	'action': 'get_add_seo_meta',		
	'country': jQuery("#property_meta_country").val(),
	'region' :jQuery("#property_meta_region").val(),
	'nrealid':nrealid,
	'category':jQuery("#property_category").val(),
	'place' :jQuery("#property_meta_place").val(),
	'en_tname' :jQuery('input[name=qtranslate-fields\\[post_title\\]\\[en\\]]').val(),
	'fr_tname' :jQuery('input[name=qtranslate-fields\\[post_title\\]\\[fr\\]]').val(),
	'nl_tname' :jQuery('input[name=qtranslate-fields\\[post_title\\]\\[nl\\]]').val()
   };  
    jQuery.post(ajaxurl, data, function(result) {	
	       var dataResult = $.parseJSON(result);
	   if(dataResult!=''){
	   	$.each(dataResult, function(key,val) {             
	        if(key=='title'){
	            jQuery("#property_meta_title_en").val(dataResult.title.en);
	            jQuery("#property_meta_title_fr").val(dataResult.title.fr);
	            jQuery("#property_meta_title_nl").val(dataResult.title.nl);
	        }
	        if(key=='keywords'){
	            jQuery("#property_meta_keywords_en").val(dataResult.keywords.en);
	            jQuery("#property_meta_keywords_fr").val(dataResult.keywords.fr);
	            jQuery("#property_meta_keywords_nl").val(dataResult.keywords.nl);
	        }
	        if(key=='description'){
	            jQuery("#property_meta_description_en").val(dataResult.description.en);
	            jQuery("#property_meta_description_fr").val(dataResult.description.fr);
	            jQuery("#property_meta_description_nl").val(dataResult.description.nl);
	         
	        }
	    });
	   }
  });
}


  
/*
	* Date: 22-Nov-2016
	* Method : function for display property as selected if already selected for export on property overview page
*/
	var data = {'action': 'getSessionProperties'};
	jQuery.post(ajaxurl, data, function(response) {
		var obj = jQuery.parseJSON(response);
		if(obj){
			jQuery.each( obj, function( key, value ) {
			  jQuery('#cb-select-'+value).prop('checked', true);
			});
		}
	});
//jQuery("#the-list tr.status-pending").css( "display", "none" )

var mySelect = jQuery('select[name=page').val();
if(mySelect==11){

	jQuery("#post_slider_text").show();
	jQuery("div.mce-btn > button i.mce-ico").removeClass("mce-ico");
}else{
	jQuery("#post_slider_text").hide();
}

setTimeout(function(){ 
jQuery("div.mce-btn > button i.mce-ico").removeClass("mce-ico");

}, 3000);

    jQuery("#btnFocusDiv").click(function(){
	var refid=jQuery("#searchfiels").val();
	var tmpcolVal = '';
    jQuery(".wrap table.wp-list-table.widefat tr").each(function(n){
       tmpcolVal = jQuery(this).find('td:eq(1)').text();       
       if(tmpcolVal == refid){
       	//jQuery(this).focus();
            if(jQuery(this).find('th:eq(0)').find('input:first').length){
    			jQuery(this).find('th:eq(0)').find('input:first').focus();
			}else{
             	jQuery(".page-title").find('input:first').focus();
			}
             
         }
    });
    });
    
    
    //add client list at add/edit menu page
	var data = {action: 'get_client_list',type: 'POST',dataType:'json','menu_id':jQuery.urlParam('menu')};
    jQuery.post( ajaxurl, data, function( response ) {
    	jQuery('div.menu-settings').append('<dl><dt class="howto">Client visibility</dt><dd>'+response+'</dd></dl>');
    });
    jQuery('#bulk-action-selector-top').change(function() {
     optionValue = jQuery('#bulk-action-selector-top').val();
       if (optionValue =='copy_site' || optionValue=='remove_site' || optionValue=='publish_copy_site') {
       
                            var data = {
                                    action: 'get_client_dropdown',
                                    type: 'POST',
                                    dataType:'json'                                  
                                    };         

                                    jQuery.post( ajaxurl, data, function( response ) {
                                      				      
        jQuery( "#customdiv" ).remove();
        jQuery("#bulk-action-selector-top" ).after( "<div id='customdiv' style='float: left;margin-right: 21px'>"+response+"</div>" );
                                                                                
                            });  
       }else{
	jQuery( "#customdiv" ).remove();
       }
    });
    
    
    
    jQuery('#property_meta_country_site_setting').click(function() {
        var data = {
		'action': 'terms_region_place',		
		'country': jQuery('#property_meta_country_site_setting').val(),
		'region' :'',
		'provinces' :''
	};
        
	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {	   
	       
        select = document.getElementById('property_meta_region1');		
        var obj = jQuery.parseJSON(response);

		if (select) {
			select.options.length = 0;
			jQuery.each(obj.regions, function(idx, obj) {                 
			    select.options.add(new Option(obj.name,obj.term_id));               
			});
		} 
		select = document.getElementById('property_meta_region2');
		if (select) {
			select.options.length = 0;
			jQuery.each(obj.regions, function(idx, obj) {                 
			    select.options.add(new Option(obj.name,obj.term_id));               
			});
		}
		    
		select = document.getElementById('property_meta_region3');
		 if (select) {
			select.options.length = 0;
			jQuery.each(obj.regions, function(idx, obj) {                 
			    select.options.add(new Option(obj.name,obj.term_id));               
			});
		}  
	})
        
 });
    
    jQuery('#country_terms').change(function() {
        var data = {
		'action': 'terms_region_provinces',		
		'country': jQuery('#country_terms').val(),
		'region' :''
	};
        
	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {
	   
	       
                select = document.getElementById('region_terms');  
                var obj = jQuery.parseJSON(response);
		
		    if (select) {
			select.options.length = 0;
			jQuery.each(obj.regions, function(idx, obj) {                 
			    select.options.add(new Option(obj.name,obj.term_id));               
			});
		    }
		
                select = document.getElementById('provinces_terms');  
               
                if (select) {
		     select.options.length = 0;
		    jQuery.each(obj.provinces, function(idx, obj) {                 
			select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}    
	})
        
    });
    
    
    //country default ajax...
    jQuery('select[name="general[remoteCountry]"]').change(function() {
    	jQuery('#property_meta_country').val(jQuery(this).val());
    	jQuery('#property_meta_country').change();
	});
    
    //location ajax...
    jQuery('#property_meta_country').change(function() {
        var data = {
		'action': 'azull_region',		
		'country': jQuery('#property_meta_country').val()
	};
        
	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {
                select = document.getElementById('property_meta_region');
                var obj = jQuery.parseJSON(response);		
		if (select) {
		    select.options.length = 0;
		    jQuery.each(obj.regions, function(idx, obj) {                 
			select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}
       select = document.getElementById('property_meta_province');  
       if (select) {
		    select.options.length = 0;
		    jQuery.each(obj.provinces, function(idx, obj) {                 
			select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}                
		select = document.getElementById('property_meta_place');               
                if (select) {
		    select.options.length = 0;
		    jQuery.each(obj.places, function(idx, obj) {                 
			select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}
		
		select = document.getElementById('azullTax');		
                if (select) {
		        loadaTax();  
		}
		
		select = document.getElementById('finance_override');		
                if (select) {
		        
		        loadaFinincialData(jQuery('#property_meta_country').attr("postid"));  
		}
		
		
	})
        
    });
        //location ajax...
    jQuery('#property_country').change(function() {
        var data = {
		'action': 'azull_region',		
		'country': jQuery('#property_country').val()
	};
        
	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {
                select = document.getElementById('property_region');
		
                var obj = jQuery.parseJSON(response);		
		if (select) {
		    select.options.length = 0;
		    jQuery.each(obj.regions, function(idx, obj) {                 
			select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}
                
		
                
                select = document.getElementById('property_meta_place');               
                if (select) {
		    select.options.length = 0;
		    jQuery.each(obj.places, function(idx, obj) {                 
			select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}
		
		
	})
        
    });
    
    jQuery('#property_region').change(function() {
        var data = {
		'action': 'azull_place',		
		'region': jQuery('#property_region').val(),
		'country': jQuery('#property_country').val()
	};

	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {
                var obj = jQuery.parseJSON(response);

               
                select = document.getElementById('property_meta_place');  
                if (select) {
		    select.options.length = 0;
		   jQuery.each(obj.places, function(idx, obj) {                 
                    select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}
		
	})
        
    });
    
    //location ajax...
    jQuery('#property_meta_region').change(function() {
        var data = {
		'action': 'azull_province',		
		'region': jQuery('#property_meta_region').val(),
		'country': jQuery('#property_meta_country').val()
	};

	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {
                var obj = jQuery.parseJSON(response);

                select = document.getElementById('property_meta_province');  
                if (select) {
		    select.options.length = 0;
		    jQuery.each(obj.provinces, function(idx, obj) {                 
                    select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}
		
                
               
                select = document.getElementById('property_meta_place');  
                if (select) {
		    select.options.length = 0;
		   jQuery.each(obj.places, function(idx, obj) {                 
                    select.options.add(new Option(obj.name,obj.term_id));               
		    });
		}
		
		select = document.getElementById('azullTax');		
                if (select) {
		        loadaTax();  
		}
		select = document.getElementById('finance_override');		
                if (select) {
		        loadaFinincialData(jQuery('#property_meta_country').attr("postid"));  
		}
	})
        
    });
    
        //location ajax...
    jQuery('#property_meta_province').change(function() {
        var data = {
		'action': 'azull_place',
		'province': jQuery('#property_meta_province').val(),
		'region': jQuery('#property_meta_region').val(),
		'country': jQuery('#property_meta_country').val()
	};
        
	// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
	jQuery.post(ajaxurl, data, function(response) {
                var obj = jQuery.parseJSON(response);
                select = document.getElementById('property_meta_place');  
               if (select) {
		    select.options.length = 0;
		    jQuery.each(obj.places, function(idx, obj) {                 
			select.options.add(new Option(obj.name,obj.term_id));               
		    });
	       }
	       
	       select = document.getElementById('azullTax');		
                if (select) {
		        loadaTax();  
		}	
		
		select = document.getElementById('finance_override');		
                if (select) {		    
		        loadaFinincialData(jQuery('#property_meta_country').attr("postid"));  
		}
                
	})
        
    });
    
    
    jQuery('#salesPrice').keyup();    
        
    jQuery("input.numeric").bind("keydown", function(e) {

        var keyCode = e.which ? e.which : e.keyCode
        var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
        if (ret) {
            jQuery(this).siblings(".description").removeClass("error");
        } else
        {
            jQuery(this).siblings(".description").addClass("error");
        }

        return ret;
    });
    jQuery("input.numeric").bind("paste", function(e) {
        return false;
    });
    jQuery("input.numeric").bind("drop", function(e) {
        return false;
    });


    //decimal validation
    jQuery("input.decimal").bind("keypress", function(e) {

      
        var keyCode = e.which ? e.which : e.keyCode
       

        var ret = (((keyCode >= 48 && keyCode <= 57) || keyCode == 46) || specialKeys.indexOf(keyCode) != -1);

        if (ret) {
            jQuery(this).siblings(".description").removeClass("error");
        } else
        {
            jQuery(this).siblings(".description").addClass("error");
        }

        return ret;
    });
    jQuery("input.decimal").bind("paste", function(e) {
        return false;
    });
    
    
    jQuery("input.decimal").bind("drop", function(e) {
        return false;
    });

 jQuery('#term_id').selectator({
                useDimmer: false,
                width: 200,
                hieght: 800,
                labels: {
                    search: 'Search...'
                }
            });


    jQuery("#activate_proprietor_click").click(function() {
        if (jQuery('#activate_proprietor').data('selectator') === undefined) {
            jQuery('#activate_proprietor').selectator({
                useDimmer: false,
                width: 167,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_proprietor_click').val('destroy selectator');
        } else {
            jQuery('#activate_proprietor').selectator('destroy');
            jQuery('#activate_proprietor_click').val('activate selectator');
        }


    });

    jQuery("#activate_property_category").click(function() {
        if (jQuery('#property_category').data('selectator') === undefined) {
            jQuery('#property_category').selectator({
                useDimmer: false,
                width: 167,
                showAllOptionsOnFocus: true,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_property_category').val('destroy selectator');
        } else {
            jQuery('#property_category').selectator('destroy');
            jQuery('#activate_property_category').val('activate selectator');
        }


    });

    jQuery('#activate_property_category').trigger('click');

    jQuery("#activate_property_type").click(function() {
        if (jQuery('#property_type').data('selectator') === undefined) {
            jQuery('#property_type').selectator({
                useDimmer: false,
                width: 200,
                showAllOptionsOnFocus: true,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_property_type').val('destroy selectator');
        } else {
            jQuery('#property_type').selectator('destroy');
            jQuery('#activate_property_type').val('activate selectator');
        }


    });

    jQuery('#activate_property_type').trigger('click');

    jQuery("#activate_property_view").click(function() {
        if (jQuery('#property_view').data('selectator') === undefined) {
            jQuery('#property_view').selectator({
                useDimmer: false,
                width: 200,
                showAllOptionsOnFocus: true,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_property_view').val('destroy selectator');
        } else {
            jQuery('#property_view').selectator('destroy');
            jQuery('#activate_property_view').val('activate selectator');
        }


    });
    jQuery('#activate_property_view').trigger('click');

    jQuery("#activate_property_feature").click(function() {
        if (jQuery('#property_feature').data('selectator') === undefined) {
            jQuery('#property_feature').selectator({
                useDimmer: false,
                width: 200,
                showAllOptionsOnFocus: true,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_property_feature').val('destroy selectator');
        } else {
            jQuery('#property_feature').selectator('destroy');
            jQuery('#activate_property_feature').val('activate selectator');
        }


    });
    jQuery('#activate_property_feature').trigger('click');

    jQuery("#activate_property_interior").click(function() {
        if (jQuery('#property_interior').data('selectator') === undefined) {
            jQuery('#property_interior').selectator({
                useDimmer: false,
                width: 200,
                showAllOptionsOnFocus: true,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_property_interior').val('destroy selectator');
        } else {
            jQuery('#property_interior').selectator('destroy');
            jQuery('#activate_property_interior').val('activate selectator');
        }


    });
    jQuery('#activate_property_interior').trigger('click');

    jQuery("#activate_property_exterior").click(function() {
        if (jQuery('#property_exterior').data('selectator') === undefined) {
            jQuery('#property_exterior').selectator({
                useDimmer: false,
                width: 200,
                showAllOptionsOnFocus: true,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_property_exterior').val('destroy selectator');
        } else {
            jQuery('#property_interior').selectator('destroy');
            jQuery('#activate_property_exterior').val('activate selectator');
        }


    });
    jQuery('#activate_property_exterior').trigger('click');


    jQuery("h3.qtranxf_title_lang").live("click", function(e) {
        var id = this.id;
        var id = 'lang_title' + id;
        var id2 = 'essential_project_name' + this.id;
        jQuery('.qtranxf_title_lang').removeClass('active_title');
        jQuery(this).addClass('active_title');
        jQuery('.postarea_ln').removeClass('zindex');
        jQuery('.essential_project_name').removeClass('zindex');
        jQuery('#' + id).addClass('zindex');
        jQuery('#' + id2).addClass('zindex');


        return;
    });
    jQuery("h5.qtranxf_term_title").live("click", function(e) {
        var id = this.id;
        var id = 'term_title' + id;

        jQuery('.qtranxf_term_title').removeClass('active_title');
        jQuery(this).addClass('active_title');
        jQuery('.qtranxf_term_div').removeClass('zindex');
        jQuery('#' + id).addClass('zindex');


        return;
    });

    jQuery("h4.qtranxf_term_title").live("click", function(e) {
        var id = this.id;
        var id1 = 'term_name' + id;
        var id2 = 'term_address' + id;
        jQuery('tr.qtrans-name-lang').addClass('term_name_tr');
        jQuery('h4.qtranxf_term_title').removeClass('active_title');
        jQuery(this).addClass('active_title');
        jQuery('.term_address_div').removeClass('zindex');
        jQuery('#' + id1).removeClass('term_name_tr');
        jQuery('#' + id2).addClass('zindex');
        
        return;
    });

    jQuery("#tag-slug").parent(".form-field").css("display", "none");    
    jQuery("#tag-description").parent(".form-field").css("display", "none");
    //jQuery("#slug").closest(".form-field").css("display", "none");
    //jQuery("#description").closest(".form-field").css("display", "none");
    jQuery(".postarea_a").live("click", function(e) {
        var url = this.href;
        var type = url.split('#');
        var hash = '';
        if (type.length > 1) {
            hash = type[1];
            jQuery('.postarea').removeClass('zindex');
            jQuery('#' + hash).addClass('zindex');
        }
        e.preventDefault();
        return;
    });

    jQuery("#activate_proprietor_click").trigger("click");
    jQuery("#activate_agent_click").click(function() {
        if (jQuery('#activate_agent').data('selectator') === undefined) {
            jQuery('#activate_agent').selectator({
                useDimmer: false,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_agent_click').val('destroy selectator');
        } else {
            jQuery('#activate_agent').selectator('destroy');
            jQuery('#activate_agent_click').val('activate selectator');
        }
    });

    jQuery("#activate_agent_click").trigger("click");
    
    
    
    jQuery("#activate_emails_click").click(function() {
        if (jQuery('#activate_emails').data('selectator') === undefined) {
            jQuery('#activate_emails').selectator({
                useDimmer: false,
                labels: {
                    search: 'Search...'
                }
            });
            jQuery('#activate_emails_click').val('destroy selectator');
        } else {
            jQuery('#activate_emails').selectator('destroy');
            jQuery('#activate_emails_click').val('activate selectator');
        }
    });

    jQuery("#activate_emails_click").trigger("click");
    

    
    if (getCookie('_hash')) {
	    var currentAttrValue = getCookie('_hash');	   
	    jQuery(currentAttrValue).addClass('zindex').siblings().removeClass('zindex');
	    jQuery('.tabs ' + currentAttrValue).show().siblings().hide();            
	    jQuery('a[href=' + currentAttrValue + ']').closest("li").addClass("active").siblings().removeClass('active');;
    }
    
    jQuery('.tabbed-area .tabs li a').on('click', function(e) {

        currentAttrValue = jQuery(this).attr('href');
	setCookie('_hash',currentAttrValue);	
        jQuery(currentAttrValue).addClass('zindex').siblings().removeClass('zindex');
        jQuery('.tabs ' + currentAttrValue).show().siblings().hide();
        jQuery(this).parent('li').addClass('active').siblings().removeClass('active');
        e.preventDefault();
    });
    
    

    jQuery('#property_gallery div.inside div.gallery br').remove();
    var gid = jQuery('#property_gallery div.inside .gallery[id]:first').prop('id');
    jQuery('#property_gallery div.inside').prepend("<div id='galleryholder' class='holder'></div>");
    var width = jQuery(window).width();
    page=10;
   //alert(width);
    /*var page=10;
   
    switch(width){
    	case 1920 : page = 15; break;
    	case 1280 : page = 12; break;
    }*/
    if(width >=1895 && width != 1280){
       page = 16; 
    }
    
    else if(width <= 1024 && width != 768){
       page = 6; 
    }
    else if(width <= 1280 && width >= 1024){
       page = 8; 
    }
    else if(width == 768){
       page = 8; 
    }
    
   // alert(page);
    jQuery('div#galleryholder').jPages({containerID: gid, perPage: page});

    jQuery.urlParam = function(name){
	    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	    if (results==null){
	       return null;
	    }
	    else{
	       return results[1] || 0;
	    }
	}
	/*
	* Date: 21-Nov-2016
	* Method : get check box click event on property overview list page
	*/
    jQuery('table.wp-list-table tbody#the-list th.check-column input:checkbox').change(function(){
    	var post_id = this.value;
    	var post_type = jQuery.urlParam('post_type');
    	var taxonomy = jQuery.urlParam('taxonomy');
    	if(post_id && post_type=='property' && taxonomy==null){
    		var is_checked;
		    if(jQuery(this).is(":checked")) {
		    	is_checked = 1;
		    } else {
		    	is_checked = 0;
		    }
		    var data = {
				'action': 'setPropertyExportList',		
				'p_id': post_id,
				'is_checked': is_checked
			};
			jQuery.post(ajaxurl, data, function(response) {
				//alert(response);
				var obj = jQuery.parseJSON(response);
				if(obj.is_properties == 1){
					jQuery('#export_btn_box').show();
				}else{
					jQuery('#export_btn_box').hide();
				}
				
			})
	    }
	});
	/*
	* Date: 21-Nov-2016
	* Method : function for get check box click event on property overview list page
	*/
    jQuery('table.wp-list-table td#cb input:checkbox#cb-select-all-1').change(function(){
    	var taxonomy = jQuery.urlParam('taxonomy');
    	var post_type = jQuery.urlParam('post_type');
    	if(post_type=='property' && taxonomy==null){
	    	if(jQuery(this).is(":checked")) {
			    jQuery("input:checkbox[name^='post']:checked").each(function () {
					var data = {
						'action': 'setPropertyExportList',		
						'p_id': jQuery(this).val(),
						'is_checked': 1
					};
					jQuery.post(ajaxurl, data, function(response) {
						//alert(response.properties);
					})
			    });
		    } else {
		    	if(!jQuery(this).is(":checked")) {
		    		jQuery("input:checkbox[name^='post']:not(:checked)").each(function () {
		    			var data = {
							'action': 'setPropertyExportList',
							'p_id': jQuery(this).val(),	
							'is_checked': 0
						};
						jQuery.post(ajaxurl, data, function(response) {
							//alert('uncheck all =>> '+response);
						})
		    		});
		    	}
		    }
    	}
	});

	jQuery("#export_btn").click(function(){
		if(confirm("Are you sure export all selected properties?")){
			var data = {'action': 'getSessionProperties'};
			jQuery.post(ajaxurl, data, function(response) {
				var obj = jQuery.parseJSON(response);
				if(obj){
					jQuery.each( obj, function( key, value ) {
					  jQuery('#cb-select-'+value).prop('checked', false);
					});
				}
			});
			jQuery('#export_btn_box').hide();
			jQuery('#msg_box').html('<div id="message" class="notice notice-warning below-h2"><p>If you want to export below listed properties again then please select one or more properties from below property list!<br></p></div>');
			
		}else{
			return false;
		}
	});

//end document ready
});

//global 
var total = 0;

function calculatePercentage(virtualElem) {
    var calculatedVal = 0;    
    var virtualElemVal = parseFloat(jQuery("#"+virtualElem).val());    
    var virtualElemDataMin = jQuery("#"+virtualElem).attr('data_min');
    var virtualRuleCheck = jQuery('#buildType').val();
      
    if (virtualElem != 'salesPrice' && virtualElem != 'utilitiesConnectionCost') {

        percentOff = parseFloat(jQuery('#salesPrice').val());
        calculatedVal = parseFloat(percentOff * (virtualElemVal / 100))

        if (typeof virtualElemDataMin != "undefined") {
            if (calculatedVal < virtualElemDataMin) {
                calculatedVal = virtualElemDataMin;
            }
        }

    }

    return calculatedVal;
}

function calculateSum(elem) {
   
    var ruleCheck = jQuery('#buildType').val();
    var ruleName = 'rule'+ruleCheck;
    
   
    
    //alert(elemDataId + '_salePrice');
    var total = parseFloat(jQuery('#salesPrice').val());
   
    
    if (jQuery('#utilitiesConnectionCost').hasClass(ruleName)) {
        total += parseFloat(jQuery('#utilitiesConnectionCost').val());
    }
    

    jQuery("#finance_override").find('input[type=text]').css({"background-color": "#f0f0f0"});
    jQuery("#finance_override").find('input[type=text]').css({"color": "#f0f0f0"});
    jQuery("."+ruleName).css({"background-color": "#fff"});
    jQuery("."+ruleName).css({"color": "#000"});
    jQuery("#finance_total").css({"color": "#000"});
    
    //calculate percentage of sale price

    jQuery("#finance_override").find('input[type=text]').each(function(currInput) {
        currVal=jQuery("#"+this.id).val();
       
        if (jQuery("#"+this.id).hasClass(ruleName)) {
	   
            total = parseFloat(total) + parseFloat(calculatePercentage(this.id));
        }
        
    });

  
     
    //console.log(total)
    if (total > 0) {
        jQuery('#finance_total').val(parseFloat(total).toFixed(0));
    }
}


jQuery(document).ready(function() {
    
    
                /* Dispaly featured images respected to propery Id
				   * Date:- 19-May-2016 
				*/
				//var label = jQuery('#refid');
				//var text = label.text();
				   var text=jQuery("#nrealid").val();  
				    jQuery('#media-search-input').val(text);
				    jQuery("#postimagediv").on('click',".thickbox",function(){
					
					jQuery("#media-search-input").val(text);
					jQuery("#media-search-input").keyup();
					setTimeout(function() {
					    jQuery("#media-search-input").val(text);
					    jQuery("#media-search-input").keyup();
					}, 2000);
				     
				});
                
                /* Dispaly error message for property region
				   * Date:- 18-Jan-2017 
				*/
                jQuery('#publish').click(function(){
				    var regVal=jQuery("#property_meta_region").val();
				    var postType=jQuery("#post_type").val();
				    if(postType =='property'){
                        if(regVal=='--' || regVal==''){
                          jQuery("#rgnMsg").html('Please select region!');
                          alert('Please select region!');
                          return false;
                        }
				    }
				});



				jQuery('#region-add').click(function(){
				    jQuery("#carasoleBlock ul").append('<li taxonomy="region" term="'+jQuery('#property_meta_region option:selected').val()+'"> Country : '+jQuery('#property_meta_country option:selected').text()+' <br>Region : '+jQuery('#property_meta_region option:selected').text()+'<span >-</span></li>');
				    updateCarasoleBlock();
				});
				
				jQuery('#province-add').click(function(){
				    jQuery("#carasoleBlock ul").append('<li taxonomy="provinces" term="'+jQuery('#property_meta_province option:selected').val()+'"> Country : '+jQuery('#property_meta_country option:selected').text()+' <br>Region : '+jQuery('#property_meta_region option:selected').text()+'<br>Provinces : '+jQuery('#property_meta_province option:selected').text()+'<span >-</span></li>');
				    updateCarasoleBlock();
				});
				
				jQuery('#place-add').click(function(){
				    jQuery("#carasoleBlock ul").append('<li taxonomy="place" term="'+jQuery('#property_meta_place option:selected').val()+'"> Country : '+jQuery('#property_meta_country option:selected').text()+' <br>Region : '+jQuery('#property_meta_region option:selected').text()+' <br>Provinces : '+jQuery('#property_meta_province option:selected').text()+'<br>Place : '+jQuery('#property_meta_place option:selected').text()+'<span >-</span></li>');
				    updateCarasoleBlock();
				});
				
				jQuery(document).on('click','#carasoleBlock ul li span',function(){
				        jQuery(this).closest('#carasoleBlock ul li').remove();
					updateCarasoleBlock();
				});
							
			    });			    
			    
			    function updateCarasoleBlock(){
				    var carasoleBlock=[];
				    var id='';
				    jQuery( "#carasoleBlock ul li" ).each(function( index ) {
					var data = {};
					data.term = jQuery( this ).attr('term');
					data.taxonomy = jQuery( this ).attr('taxonomy');;
					carasoleBlock.push(data);
					id = jQuery( this ).parent().attr('data-id');
				    });
				    
				    var data = {
				       'action': 'carasoleBlockUpdate',		
				       'data': carasoleBlock,
				       'id':id
				    
			       }
				// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
				 jQuery.post(ajaxurl, data, function(response) {
				    
				 });
				  
				}
// Reset all search fields

jQuery(document).ready(function () {
   window.asd =  jQuery('.SlectBox').SumoSelect({ okCancelInMulti: false ,triggerChangeCombined: true,forceCustomRendering: true });
   window.test =  jQuery('.testsel').SumoSelect({okCancelInMulti:false });
   jQuery(".toplevel_page_t-location").removeAttr("href").css("cursor","pointer");

   jQuery('#post-query-reset').click(function(){
   	 
   	jQuery("#activate_proprietor_click").trigger("click");
   	jQuery("select#activate_proprietor").prop('selectedIndex', 0);
   	jQuery("#activate_proprietor_click").trigger("click");

   			  var obj = [];
   jQuery('.selectwebsites option').each(function () {
        obj.push(jQuery(this).index());
    });

    for (var i = 0; i < obj.length; i++) {
       jQuery('.selectwebsites')[0].sumo.unSelectItem(obj[i]);
    }

    		  var obj1 = [];
   jQuery('.Selectfin option').each(function () {
        obj1.push(jQuery(this).index());
    });

    for (var i = 0; i < obj1.length; i++) {
       jQuery('.Selectfin')[0].sumo.unSelectItem(obj1[i]);
    }

     var obj2 = [];
   jQuery('.Selectfin option').each(function () {
        obj2.push(jQuery(this).index());
    });

    for (var i = 0; i < obj2.length; i++) {
       jQuery('.Selectfin')[0].sumo.unSelectItem(obj2[i]);
    }
    

       var obj3 = [];
   jQuery('.SlectBank option').each(function () {
        obj3.push(jQuery(this).index());
    });

    for (var i = 0; i < obj3.length; i++) {
       jQuery('.SlectBank')[0].sumo.unSelectItem(obj3[i]);
    }

     var obj4 = [];
   jQuery('.Slectpenthouse option').each(function () {
        obj4.push(jQuery(this).index());
    });

    for (var i = 0; i < obj4.length; i++) {
       jQuery('.Slectpenthouse')[0].sumo.unSelectItem(obj4[i]);
    }

       var obj5 = [];
   jQuery('.Slectbuildtype option').each(function () {
        obj5.push(jQuery(this).index());
    });

    for (var i = 0; i < obj5.length; i++) {
       jQuery('.Slectbuildtype')[0].sumo.unSelectItem(obj5[i]);
    }

        var obj6 = [];
   jQuery('.Slectcat option').each(function () {
        obj6.push(jQuery(this).index());
    });

    for (var i = 0; i < obj6.length; i++) {
       jQuery('.Slectcat')[0].sumo.unSelectItem(obj6[i]);
    }

     var obj7 = [];
    jQuery('.Slectcat option').each(function () {
        obj7.push(jQuery(this).index());
    });

    for (var i = 0; i < obj7.length; i++) {
       jQuery('.Slectcat')[0].sumo.unSelectItem(obj7[i]);
    }

       var obj8 = [];
    jQuery('.SlectPlace option').each(function () {
        obj8.push(jQuery(this).index());
    });

    for (var i = 0; i < obj8.length; i++) {
       jQuery('.SlectPlace')[0].sumo.unSelectItem(obj8[i]); 
    }

     var obj9 = [];
    jQuery('.SlectRegion option').each(function () {
        obj9.push(jQuery(this).index());
    });

    for (var i = 0; i < obj9.length; i++) {
       jQuery('.SlectRegion')[0].sumo.unSelectItem(obj9[i]);
    }


       var obj10 = [];
    jQuery('.selecIntr option').each(function () {
        obj10.push(jQuery(this).index()); 
    });

    for (var i = 0; i < obj10.length; i++) {
       jQuery('.selecIntr')[0].sumo.unSelectItem(obj10[i]);
    }

     var obj11 = [];
    jQuery('.selecExtr option').each(function () {
        obj11.push(jQuery(this).index()); 
    });

    for (var i = 0; i < obj11.length; i++) {
       jQuery('.selecExtr')[0].sumo.unSelectItem(obj11[i]);
    }

       var obj12 = [];
    jQuery('.selecFeatre option').each(function () {
        obj12.push(jQuery(this).index()); 
    });

    for (var i = 0; i < obj12.length; i++) {
       jQuery('.selecFeatre')[0].sumo.unSelectItem(obj12[i]);
    }

        var obj13 = [];
    jQuery('.selecView option').each(function () {
        obj13.push(jQuery(this).index()); 
    });

    for (var i = 0; i < obj13.length; i++) {
       jQuery('.selecView')[0].sumo.unSelectItem(obj13[i]);
    }
  
    jQuery('#activate_proprietor').selectator('refresh');
    
 	jQuery(this).closest('form').find("input[type=text], textarea").val("");
	
   });
   


});
(function ($) {
// Default settings
var DEFAULT_SETTINGS = {
	// Search settings
    method: "GET",
    contentType: "json",
    queryParam: "q",
    searchDelay: 300,
    minChars: 1,
    propertyToSearch: "name",
    jsonContainer: null,

	// Display settings
    hintText: "Type in a search term",
    noResultsText: "No results",
    searchingText: "Searching...",
    deleteText: "&times;",
    animateDropdown: true,

	// Tokenization settings
    tokenLimit: null,
    tokenDelimiter: ",",
    preventDuplicates: false,

	// Output settings
    tokenValue: "id",

	// Prepopulation settings
    prePopulate: null,
    processPrePopulate: false,

	// Manipulation settings
    idPrefix: "token-input-",

	// Formatters
    resultsFormatter: function(item){ return "<li>" + item[this.propertyToSearch]+ "</li>" },
    tokenFormatter: function(item) { return "<li><p>" + item[this.propertyToSearch] + "</p></li>" },

	// Callbacks
    onResult: null,
    onAdd: null,
    onDelete: null,
    onReady: null
};

// Default classes to use when theming
var DEFAULT_CLASSES = {
    tokenList: "token-input-list",
    token: "token-input-token",
    tokenDelete: "token-input-delete-token",
    selectedToken: "token-input-selected-token",
    highlightedToken: "token-input-highlighted-token",
    dropdown: "token-input-dropdown",
    dropdownItem: "token-input-dropdown-item",
    dropdownItem2: "token-input-dropdown-item2",
    selectedDropdownItem: "token-input-selected-dropdown-item",
    inputToken: "token-input-input-token"
};

// Input box position "enum"
var POSITION = {
    BEFORE: 0,
    AFTER: 1,
    END: 2
};

// Keys "enum"
var KEY = {
    BACKSPACE: 8,
    TAB: 9,
    ENTER: 13,
    ESCAPE: 27,
    SPACE: 32,
    PAGE_UP: 33,
    PAGE_DOWN: 34,
    END: 35,
    HOME: 36,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40,
    NUMPAD_ENTER: 108,
    COMMA: 188
};

// Additional public (exposed) methods
var methods = {
    init: function(url_or_data_or_function, options) {
        var settings = $.extend({}, DEFAULT_SETTINGS, options || {});

        return this.each(function () {
            $(this).data("tokenInputObject", new $.TokenList(this, url_or_data_or_function, settings));
        });
    },
    clear: function() {
        this.data("tokenInputObject").clear();
        return this;
    },
    add: function(item) {
        this.data("tokenInputObject").add(item);
        return this;
    },
    remove: function(item) {
        this.data("tokenInputObject").remove(item);
        return this;
    },
    get: function() {
    	return this.data("tokenInputObject").getTokens();
   	}
}

// Expose the .tokenInput function to jQuery as a plugin
$.fn.tokenInput = function (method) {
    // Method calling and initialization logic
    if(methods[method]) {
        return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
    } else {
        return methods.init.apply(this, arguments);
    }
};

// TokenList class for each input
$.TokenList = function (input, url_or_data, settings) {
    //
    // Initialization
    //

    // Configure the data source
    if($.type(url_or_data) === "string" || $.type(url_or_data) === "function") {
        // Set the url to query against
        settings.url = url_or_data;

        // If the URL is a function, evaluate it here to do our initalization work
        var url = computeURL();

        // Make a smart guess about cross-domain if it wasn't explicitly specified
        if(settings.crossDomain === undefined) {
            if(url.indexOf("://") === -1) {
                settings.crossDomain = false;
            } else {
                settings.crossDomain = (location.href.split(/\/+/g)[1] !== url.split(/\/+/g)[1]);
            }
        }
    } else if(typeof(url_or_data) === "object") {
        // Set the local data to search through
        settings.local_data = url_or_data;
    }

    // Build class names
    if(settings.classes) {
        // Use custom class names
        settings.classes = $.extend({}, DEFAULT_CLASSES, settings.classes);
    } else if(settings.theme) {
        // Use theme-suffixed default class names
        settings.classes = {};
        $.each(DEFAULT_CLASSES, function(key, value) {
            settings.classes[key] = value + "-" + settings.theme;
        });
    } else {
        settings.classes = DEFAULT_CLASSES;
    }


    // Save the tokens
    var saved_tokens = [];

    // Keep track of the number of tokens in the list
    var token_count = 0;

    // Basic cache to save on db hits
    var cache = new $.TokenList.Cache();

    // Keep track of the timeout, old vals
    var timeout;
    var input_val;

    // Create a new text input an attach keyup events
    var input_box = $("<input type=\"text\"  autocomplete=\"off\">")
        .css({
            outline: "none"
        })
        .attr("id", settings.idPrefix + input.id)
        .focus(function () {
            if (settings.tokenLimit === null || settings.tokenLimit !== token_count) {
                show_dropdown_hint();
            }
        })
        .blur(function () {
            hide_dropdown();
            $(this).val("");
        })
        .bind("keyup keydown blur update", resize_input)
        .keydown(function (event) {
            var previous_token;
            var next_token;

            switch(event.keyCode) {
                case KEY.LEFT:
                case KEY.RIGHT:
                case KEY.UP:
                case KEY.DOWN:
                    if(!$(this).val()) {
                        previous_token = input_token.prev();
                        next_token = input_token.next();

                        if((previous_token.length && previous_token.get(0) === selected_token) || (next_token.length && next_token.get(0) === selected_token)) {
                            // Check if there is a previous/next token and it is selected
                            if(event.keyCode === KEY.LEFT || event.keyCode === KEY.UP) {
                                deselect_token($(selected_token), POSITION.BEFORE);
                            } else {
                                deselect_token($(selected_token), POSITION.AFTER);
                            }
                        } else if((event.keyCode === KEY.LEFT || event.keyCode === KEY.UP) && previous_token.length) {
                            // We are moving left, select the previous token if it exists
                            select_token($(previous_token.get(0)));
                        } else if((event.keyCode === KEY.RIGHT || event.keyCode === KEY.DOWN) && next_token.length) {
                            // We are moving right, select the next token if it exists
                            select_token($(next_token.get(0)));
                        }
                    } else {
                        var dropdown_item = null;

                        if(event.keyCode === KEY.DOWN || event.keyCode === KEY.RIGHT) {
                            dropdown_item = $(selected_dropdown_item).next();
                        } else {
                            dropdown_item = $(selected_dropdown_item).prev();
                        }

                        if(dropdown_item.length) {
                            select_dropdown_item(dropdown_item);
                        }
                        return false;
                    }
                    break;

                case KEY.BACKSPACE:
                    previous_token = input_token.prev();

                    if(!$(this).val().length) {
                        if(selected_token) {
                            delete_token($(selected_token));
                            hidden_input.change();
                        } else if(previous_token.length) {
                            select_token($(previous_token.get(0)));
                        }

                        return false;
                    } else if($(this).val().length === 1) {
                        hide_dropdown();
                    } else {
                        // set a timeout just long enough to let this function finish.
                        setTimeout(function(){do_search();}, 5);
                    }
                    break;

                case KEY.TAB:
                case KEY.ENTER:
                case KEY.NUMPAD_ENTER:
                case KEY.COMMA:
                  if(selected_dropdown_item) {
                    add_token($(selected_dropdown_item).data("tokeninput"));
                    hidden_input.change();
                    return false;
                  }
                  break;

                case KEY.ESCAPE:
                  hide_dropdown();
                  return true;

                default:
                    if(String.fromCharCode(event.which)) {
                        // set a timeout just long enough to let this function finish.
                        setTimeout(function(){do_search();}, 5);
                    }
                    break;
            }
        });

    // Keep a reference to the original input box
    var hidden_input = $(input)
                           .hide()
                           .val("")
                           .focus(function () {
                               input_box.focus();
                           })
                           .blur(function () {
                               input_box.blur();
                           });

    // Keep a reference to the selected token and dropdown item
    var selected_token = null;
    var selected_token_index = 0;
    var selected_dropdown_item = null;

    // The list to store the token items in
    var token_list = $("<ul />")
        .addClass(settings.classes.tokenList)
        .click(function (event) {
            var li = $(event.target).closest("li");
            if(li && li.get(0) && $.data(li.get(0), "tokeninput")) {
                toggle_select_token(li);
            } else {
                // Deselect selected token
                if(selected_token) {
                    deselect_token($(selected_token), POSITION.END);
                }

                // Focus input box
                input_box.focus();
            }
        })
        .mouseover(function (event) {
            var li = $(event.target).closest("li");
            if(li && selected_token !== this) {
                li.addClass(settings.classes.highlightedToken);
            }
        })
        .mouseout(function (event) {
            var li = $(event.target).closest("li");
            if(li && selected_token !== this) {
                li.removeClass(settings.classes.highlightedToken);
            }
        })
        .insertBefore(hidden_input);

    // The token holding the input box
    var input_token = $("<li />")
        .addClass(settings.classes.inputToken)
        .appendTo(token_list)
        .append(input_box);

    // The list to store the dropdown items in
    var dropdown = $("<div>")
        .addClass(settings.classes.dropdown)
        .appendTo("body")
        .hide();

    // Magic element to help us resize the text input
    var input_resizer = $("<tester/>")
        .insertAfter(input_box)
        .css({
            position: "absolute",
            top: -9999,
            left: -9999,
            width: "auto",
            fontSize: input_box.css("fontSize"),
            fontFamily: input_box.css("fontFamily"),
            fontWeight: input_box.css("fontWeight"),
            letterSpacing: input_box.css("letterSpacing"),
            whiteSpace: "nowrap"
        });

    // Pre-populate list if items exist
    hidden_input.val("");
    var li_data = settings.prePopulate || hidden_input.data("pre");
    if(settings.processPrePopulate && $.isFunction(settings.onResult)) {
        li_data = settings.onResult.call(hidden_input, li_data);
    }
    if(li_data && li_data.length) {
        $.each(li_data, function (index, value) {
            insert_token(value);
            checkTokenLimit();
        });
    }

    // Initialization is done
    if($.isFunction(settings.onReady)) {
        settings.onReady.call();
    }

    //
    // Public functions
    //

    this.clear = function() {
        token_list.children("li").each(function() {
            if ($(this).children("input").length === 0) {
                delete_token($(this));
            }
        });
    }

    this.add = function(item) {
        add_token(item);
    }

    this.remove = function(item) {
        token_list.children("li").each(function() {
            if ($(this).children("input").length === 0) {
                var currToken = $(this).data("tokeninput");
                var match = true;
                for (var prop in item) {
                    if (item[prop] !== currToken[prop]) {
                        match = false;
                        break;
                    }
                }
                if (match) {
                    delete_token($(this));
                }
            }
        });
    }
    
    this.getTokens = function() {
   		return saved_tokens;
   	}

    //
    // Private functions
    //

    function checkTokenLimit() {
        if(settings.tokenLimit !== null && token_count >= settings.tokenLimit) {
            input_box.hide();
            hide_dropdown();
            return;
        }
    }

    function resize_input() {
        if(input_val === (input_val = input_box.val())) {return;}

        // Enter new content into resizer and resize input accordingly
        var escaped = input_val.replace(/&/g, '&amp;').replace(/\s/g,' ').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        input_resizer.html(escaped);
        input_box.width(input_resizer.width() + 30);
    }

    function is_printable_character(keycode) {
        return ((keycode >= 48 && keycode <= 90) ||     // 0-1a-z
                (keycode >= 96 && keycode <= 111) ||    // numpad 0-9 + - / * .
                (keycode >= 186 && keycode <= 192) ||   // ; = , - . / ^
                (keycode >= 219 && keycode <= 222));    // ( \ ) '
    }

    // Inner function to a token to the list
    function insert_token(item) {
        var this_token = settings.tokenFormatter(item);
        this_token = $(this_token)
          .addClass(settings.classes.token)
          .insertBefore(input_token);

        // The 'delete token' button
        $("<span>" + settings.deleteText + "</span>")
            .addClass(settings.classes.tokenDelete)
            .appendTo(this_token)
            .click(function () {
                delete_token($(this).parent());
                hidden_input.change();
                return false;
            });

        // Store data on the token
        var token_data = {"id": item.id};
        token_data[settings.propertyToSearch] = item[settings.propertyToSearch];
        $.data(this_token.get(0), "tokeninput", item);

        // Save this token for duplicate checking
        saved_tokens = saved_tokens.slice(0,selected_token_index).concat([token_data]).concat(saved_tokens.slice(selected_token_index));
        selected_token_index++;

        // Update the hidden input
        update_hidden_input(saved_tokens, hidden_input);

        token_count += 1;

        // Check the token limit
        if(settings.tokenLimit !== null && token_count >= settings.tokenLimit) {
            input_box.hide();
            hide_dropdown();
        }

        return this_token;
    }

    // Add a token to the token list based on user input
    function add_token (item) {
        var callback = settings.onAdd;

        // See if the token already exists and select it if we don't want duplicates
        if(token_count > 0 && settings.preventDuplicates) {
            var found_existing_token = null;
            token_list.children().each(function () {
                var existing_token = $(this);
                var existing_data = $.data(existing_token.get(0), "tokeninput");
                if(existing_data && existing_data.id === item.id) {
                    found_existing_token = existing_token;
                    return false;
                }
            });

            if(found_existing_token) {
                select_token(found_existing_token);
                input_token.insertAfter(found_existing_token);
                input_box.focus();
                return;
            }
        }

        // Insert the new tokens
        if(settings.tokenLimit == null || token_count < settings.tokenLimit) {
            insert_token(item);
            checkTokenLimit();
        }

        // Clear input box
        input_box.val("");

        // Don't show the help dropdown, they've got the idea
        hide_dropdown();

        // Execute the onAdd callback if defined
        if($.isFunction(callback)) {
            callback.call(hidden_input,item);
        }
    }

    // Select a token in the token list
    function select_token (token) {
        token.addClass(settings.classes.selectedToken);
        selected_token = token.get(0);

        // Hide input box
        input_box.val("");

        // Hide dropdown if it is visible (eg if we clicked to select token)
        hide_dropdown();
    }

    // Deselect a token in the token list
    function deselect_token (token, position) {
        token.removeClass(settings.classes.selectedToken);
        selected_token = null;

        if(position === POSITION.BEFORE) {
            input_token.insertBefore(token);
            selected_token_index--;
        } else if(position === POSITION.AFTER) {
            input_token.insertAfter(token);
            selected_token_index++;
        } else {
            input_token.appendTo(token_list);
            selected_token_index = token_count;
        }

        // Show the input box and give it focus again
        input_box.focus();
    }

    // Toggle selection of a token in the token list
    function toggle_select_token(token) {
        var previous_selected_token = selected_token;

        if(selected_token) {
            deselect_token($(selected_token), POSITION.END);
        }

        if(previous_selected_token === token.get(0)) {
            deselect_token(token, POSITION.END);
        } else {
            select_token(token);
        }
    }

    // Delete a token from the token list
    function delete_token (token) {
        // Remove the id from the saved list
        var token_data = $.data(token.get(0), "tokeninput");
        var callback = settings.onDelete;

        var index = token.prevAll().length;
        if(index > selected_token_index) index--;

        // Delete the token
        token.remove();
        selected_token = null;

        // Show the input box and give it focus again
        input_box.focus();

        // Remove this token from the saved list
        saved_tokens = saved_tokens.slice(0,index).concat(saved_tokens.slice(index+1));
        if(index < selected_token_index) selected_token_index--;

        // Update the hidden input
        update_hidden_input(saved_tokens, hidden_input);

        token_count -= 1;

        if(settings.tokenLimit !== null) {
            input_box
                .show()
                .val("")
                .focus();
        }

        // Execute the onDelete callback if defined
        if($.isFunction(callback)) {
            callback.call(hidden_input,token_data);
        }
    }

    // Update the hidden input box value
    function update_hidden_input(saved_tokens, hidden_input) {
        var token_values = $.map(saved_tokens, function (el) {
            return el[settings.tokenValue];
        });
        hidden_input.val(token_values.join(settings.tokenDelimiter));

    }

    // Hide and clear the results dropdown
    function hide_dropdown () {
        dropdown.hide().empty();
        selected_dropdown_item = null;
    }

    function show_dropdown() {
        dropdown
            .css({
                position: "absolute",
                top: $(token_list).offset().top + $(token_list).outerHeight(),
                left: $(token_list).offset().left,
                zindex: 999
            })
            .show();
    }

    function show_dropdown_searching () {
        if(settings.searchingText) {
            dropdown.html("<p>"+settings.searchingText+"</p>");
            show_dropdown();
        }
    }

    function show_dropdown_hint () {
        if(settings.hintText) {
            dropdown.html("<p>"+settings.hintText+"</p>");
            show_dropdown();
        }
    }

    // Highlight the query part of the search term
    function highlight_term(value, term) {
        return value.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + term + ")(?![^<>]*>)(?![^&;]+;)", "gi"), "<b>$1</b>");
    }
    
    function find_value_and_highlight_term(template, value, term) {
        return template.replace(new RegExp("(?![^&;]+;)(?!<[^<>]*)(" + value + ")(?![^<>]*>)(?![^&;]+;)", "g"), highlight_term(value, term));
    }

    // Populate the results dropdown with some results
    function populate_dropdown (query, results) {
        if(results && results.length) {
            dropdown.empty();
            var dropdown_ul = $("<ul>")
                .appendTo(dropdown)
                .mouseover(function (event) {
                    select_dropdown_item($(event.target).closest("li"));
                })
                .mousedown(function (event) {
                    add_token($(event.target).closest("li").data("tokeninput"));
                    hidden_input.change();
                    return false;
                })
                .hide();

            $.each(results, function(index, value) {
                var this_li = settings.resultsFormatter(value);
                
                this_li = find_value_and_highlight_term(this_li ,value[settings.propertyToSearch], query);            
                
                this_li = $(this_li).appendTo(dropdown_ul);
                
                if(index % 2) {
                    this_li.addClass(settings.classes.dropdownItem);
                } else {
                    this_li.addClass(settings.classes.dropdownItem2);
                }

                if(index === 0) {
                    select_dropdown_item(this_li);
                }

                $.data(this_li.get(0), "tokeninput", value);
            });

            show_dropdown();

            if(settings.animateDropdown) {
                dropdown_ul.slideDown("fast");
            } else {
                dropdown_ul.show();
            }
        } else {
            if(settings.noResultsText) {
                dropdown.html("<p>"+settings.noResultsText+"</p>");
                show_dropdown();
            }
        }
    }

    // Highlight an item in the results dropdown
    function select_dropdown_item (item) {
        if(item) {
            if(selected_dropdown_item) {
                deselect_dropdown_item($(selected_dropdown_item));
            }

            item.addClass(settings.classes.selectedDropdownItem);
            selected_dropdown_item = item.get(0);
        }
    }

    // Remove highlighting from an item in the results dropdown
    function deselect_dropdown_item (item) {
        item.removeClass(settings.classes.selectedDropdownItem);
        selected_dropdown_item = null;
    }

    // Do a search and show the "searching" dropdown if the input is longer
    // than settings.minChars
    function do_search() {
        var query = input_box.val().toLowerCase();

        if(query && query.length) {
            if(selected_token) {
                deselect_token($(selected_token), POSITION.AFTER);
            }

            if(query.length >= settings.minChars) {
                show_dropdown_searching();
                clearTimeout(timeout);

                timeout = setTimeout(function(){
                    run_search(query);
                }, settings.searchDelay);
            } else {
                hide_dropdown();
            }
        }
    }

    // Do the actual search
    function run_search(query) {
        var cache_key = query + computeURL();
        var cached_results = cache.get(cache_key);
        if(cached_results) {
            populate_dropdown(query, cached_results);
        } else {
            // Are we doing an ajax search or local data search?
            if(settings.url) {
                var url = computeURL();
                // Extract exisiting get params
                var ajax_params = {};
                ajax_params.data = {};
                if(url.indexOf("?") > -1) {
                    var parts = url.split("?");
                    ajax_params.url = parts[0];

                    var param_array = parts[1].split("&");
                    $.each(param_array, function (index, value) {
                        var kv = value.split("=");
                        ajax_params.data[kv[0]] = kv[1];
                    });
                } else {
                    ajax_params.url = url;
                }

                // Prepare the request
                ajax_params.data[settings.queryParam] = query;
                ajax_params.type = settings.method;
                ajax_params.dataType = settings.contentType;
                if(settings.crossDomain) {
                    ajax_params.dataType = "jsonp";
                }

                // Attach the success callback
                ajax_params.success = function(results) {
                  if($.isFunction(settings.onResult)) {
                      results = settings.onResult.call(hidden_input, results);
                  }
                  cache.add(cache_key, settings.jsonContainer ? results[settings.jsonContainer] : results);

                  // only populate the dropdown if the results are associated with the active search query
                  if(input_box.val().toLowerCase() === query) {
                      populate_dropdown(query, settings.jsonContainer ? results[settings.jsonContainer] : results);
                  }
                };

                // Make the request
                $.ajax(ajax_params);
            } else if(settings.local_data) {
                // Do the search through local data
                var results = $.grep(settings.local_data, function (row) {
                    return row[settings.propertyToSearch].toLowerCase().indexOf(query.toLowerCase()) > -1;
                });

                if($.isFunction(settings.onResult)) {
                    results = settings.onResult.call(hidden_input, results);
                }
                cache.add(cache_key, results);
                populate_dropdown(query, results);
            }
        }
    }

    // compute the dynamic URL
    function computeURL() {
        var url = settings.url;
        if(typeof settings.url == 'function') {
            url = settings.url.call();
        }
        return url;
    }
};

// Really basic cache for the results
$.TokenList.Cache = function (options) {
    var settings = $.extend({
        max_size: 500
    }, options);

    var data = {};
    var size = 0;

    var flush = function () {
        data = {};
        size = 0;
    };

    this.add = function (query, results) {
        if(size > settings.max_size) {
            flush();
        }

        if(!data[query]) {
            size += 1;
        }

        data[query] = results;
    };

    this.get = function (query) {
        return data[query];
    };
};
}(jQuery));

setTimeout(function() {
    var len = jQuery("#post-body-content > ul.qtranxs-lang-switch-wrap").length;
    if (len == 2) {
        jQuery("#post-body-content > ul.qtranxs-lang-switch-wrap:last").hide();
        
    }
    jQuery("#postbox-container-2 > div#normal-sortables > div#qtranxs-meta-box-lsb").hide();
}, 3000);
/*
* Date: 20-Oct-2016
* Method: function for get page list by client id
*/
function getClientPages(){
	var client_id = jQuery('#client').val();
	if(client_id){
	    var data = {
			'action': 'getClientPageList',		
			'client_id': client_id
		};
		jQuery.post(ajaxurl, data, function(response) {
	        var obj = jQuery.parseJSON(response);
	        jQuery('#page_box').html(obj.pages);
	        tinyMCE.get('page_text_en').setContent('');
		    tinyMCE.get('page_text_fr').setContent('');
		    tinyMCE.get('page_text_nl').setContent('');
		    jQuery("#track_code_en").val('');
		    jQuery("#track_code_fr").val('');
		    jQuery("#track_code_nl").val('');
	        /*select = document.getElementById('page_id');  
            if (select) {
			    select.options.length = 0;
			    jQuery('option', select).remove();
			    jQuery.each(obj.pages, function(idx, obj) {
	                select.options.add(new Option(obj.p_name,obj.p_id), true);               
			    });
			}*/
		})
    }
}
/*
* Date: 12-Oct-2016
* Method: function for get thank you page information
*/
function getThkPageInfo(){
    var id_val = jQuery("#page_id").val();
    var client = jQuery("#client").val();
    jQuery("#load").show();  
 	if(id_val!='' && client!=''){
        var data = {
			'action': 'getThkPageInfor',		
			'page_id' :id_val,
			'client':client
		};
		jQuery.post(ajaxurl, data, function(response) {
	        var obj = jQuery.parseJSON(response);
			if(obj.error==0){
	            if(obj.data.page_txt.en && obj.data.page_txt.en!='undefined'){
	            	tinyMCE.get('page_text_en').setContent(obj.data.page_txt.en);
	            }else{
	            	tinyMCE.get('page_text_en').setContent('');
	            }
	            if(obj.data.page_txt.fr && obj.data.page_txt.fr!='undefined'){
	            	tinyMCE.get('page_text_fr').setContent(obj.data.page_txt.fr);
	            }else{
	            	tinyMCE.get('page_text_fr').setContent('');
	            }
	            if(obj.data.page_txt.nl && obj.data.page_txt.nl!='undefined'){
	            	tinyMCE.get('page_text_nl').setContent(obj.data.page_txt.nl);
	            }else{
	            	tinyMCE.get('page_text_nl').setContent('');
	            }
	            if(obj.data.track_code.en && obj.data.track_code.en!='undefined'){
	            	jQuery("#track_code_en").val(obj.data.track_code.en);
	            }else{
	            	jQuery("#track_code_en").val('');
	            }
	            if(obj.data.track_code.fr && obj.data.track_code.fr!='undefined'){
	            	jQuery("#track_code_fr").val(obj.data.track_code.fr);
	            }else{
	            	jQuery("#track_code_fr").val('');
	            }
	            if(obj.data.track_code.nl && obj.data.track_code.nl!='undefined'){
	            	jQuery("#track_code_nl").val(obj.data.track_code.nl);
	            }else{
	            	jQuery("#track_code_nl").val('');
	            }
	            /*if(obj.data.track_code.en && obj.data.track_code.en!='undefined'){
	            	tinyMCE.get('track_code_en').setContent(obj.data.track_code.en);
	            }else{
	            	tinyMCE.get('track_code_en').setContent('');
	            }
	            if(obj.data.track_code.fr && obj.data.track_code.fr!='undefined'){
	            	tinyMCE.get('track_code_fr').setContent(obj.data.track_code.fr);
	            }else{
	            	tinyMCE.get('track_code_fr').setContent('');
	            }
	            if(obj.data.track_code.nl && obj.data.track_code.nl!='undefined'){
	            	tinyMCE.get('track_code_nl').setContent(obj.data.track_code.nl);
	            }else{
	            	tinyMCE.get('track_code_nl').setContent('');
	            }*/
	       }
		});
    }
    jQuery("#load").hide();
    tinyMCE.get('page_text_en').setContent('');
    tinyMCE.get('page_text_fr').setContent('');
    tinyMCE.get('page_text_nl').setContent('');
    jQuery("#track_code_en").val('');
    jQuery("#track_code_fr").val('');
    jQuery("#track_code_nl").val('');
    jQuery("#msg").text("").hide();
    /*tinyMCE.get('track_code_en').setContent('');
    tinyMCE.get('track_code_fr').setContent('');
    tinyMCE.get('track_code_nl').setContent('');*/
    jQuery("#msg").text("").hide();
  }
/*
* Date: 12-Oct-2016
* Method: function for save thank you page information
*/
function saveThkPageInfo(){
	tinyMCE.triggerSave(false, true);
	var id_val = jQuery("#page_id").val();
	var client = jQuery("#client").val();
    var str = jQuery("#thanku_form" ).serialize();
	jQuery("#load").show();
    var data = {
		'action': 'saveThkPageInfor',
		'id' :id_val,
		'fdata' :str
	};
	jQuery.post(ajaxurl, data, function(response) {
	  jQuery("#load").hide();
	  var obj = jQuery.parseJSON(response);
	  if(obj.error==0 && obj.msg!=''){
	  	jQuery( "#msg" ).removeClass( 'error' ).addClass('updated' ).show(); 
      	jQuery("#msg").html(obj.msg).show();
	  	
	  }else{
		    jQuery( "#msg" ).removeClass( 'updated' ).addClass('error' ).show();
	        jQuery("#msg").html(obj.msg).show();
	    }
	});
}
/* add get thank you page content */ 
/*function chaeckPageText (){
       var id_val=jQuery("#page_id").val();
       jQuery("#load").show();  
 if(id_val!=''){
        var data = {
		'action': 'addThankuPageText',		
		'id' :id_val,
		'check' :'check'
	};
	jQuery.post(ajaxurl, data, function(response) {
        var obj = jQuery.parseJSON(response);
        if(response){
            if(obj.en && obj.en!='undefined'){
            	tinyMCE.get('page_text_en').setContent(obj.en);
                //jQuery("#page_text_en").val(obj.en);
            }else{
            	tinyMCE.get('page_text_en').setContent('');
            }
            if(obj.fr && obj.fr!='undefined'){
            	tinyMCE.get('page_text_fr').setContent(obj.fr);
                //jQuery("#page_text_fr").val(obj.fr);
            }else{
            	tinyMCE.get('page_text_fr').setContent('');
            }
            if(obj.nl && obj.nl!='undefined'){
            	tinyMCE.get('page_text_nl').setContent(obj.nl);
                //jQuery("#page_text_nl").val(obj.nl);
            }else{
            	tinyMCE.get('page_text_nl').setContent('');
            }
	        jQuery("#load").hide(); 
       } 
	});
    }
    jQuery("#msg").hide();
    tinyMCE.get('page_text_en').setContent('');
    tinyMCE.get('page_text_fr').setContent('');
    tinyMCE.get('page_text_nl').setContent('');
    //jQuery("#page_text_en").val("");
    //jQuery("#page_text_fr").val("");
    //jQuery("#page_text_nl").val("");
    jQuery("#msg").text("");
  }*/
 /* add thank you page content */  
/*function addThankuPageText(){
	var id_val=jQuery("#page_id").val();
    var str = jQuery("#thanku_form" ).serialize();
    tinyMCE.triggerSave(false, true);
    var en = jQuery("#page_text_en").val();
    var fr = jQuery("#page_text_fr").val();
    var nl = jQuery("#page_text_nl").val();
    if((id_val!='') && (en!='' || fr!='' || nl!='')){
    	jQuery("#load").show();
        var data = {
		'action': 'addThankuPageText',		
		'id' :id_val,
		'fdata' :str
	};
	jQuery.post(ajaxurl, data, function(response) { 
	  jQuery( "#msg" ).removeClass( 'error' ).addClass('updated' ).show(); 
      jQuery("#msg").html("<p>Thank you page text save successfully.</p>");
	  jQuery("#load").hide();  
	});
    }else{
	     //jQuery("#msg").show(); 
	     jQuery( "#msg" ).removeClass( 'updated' ).addClass('error' ).show();
         jQuery("#msg").html("<p>Please enter text.</p>");
    }
}*/

/* function to get page/block list 
  * date: 25/july/2016
 */
function loadpages(id,siteid){
	var layout= jQuery('input[name=layout]:checked', '#post').val()
    var data = {
      'action': 'loadPageDropDown',     
      'ID' : id,
      'site_id':siteid,
      'layout':layout
   };
   
   jQuery.post(ajaxurl, data, function(response) {                
      jQuery("#display_id").html(response);
  }); 
}

function getpageType(val){
	jQuery("div.mce-btn > button i.mce-ico").removeClass("mce-ico");
  if(val == 11 && val!=0){
  	jQuery("#post_slider_text").show();
  }else{
  	jQuery("#post_slider_text").hide();
  }
}
/*
* Date: 09-Sep-2016
* Method: function for show/hide page or post drop-down list for office meta data
*/
function loadpagepost(val){
	if(val == '1'){
		jQuery(".post_div").hide();
		jQuery(".page_div").show();
	}
	if(val == '2'){
		jQuery(".page_div").hide();
		jQuery(".post_div").show();
	}
}
/*
* Date: 05-Nov-2016
* Method: function for get project list by proprietor id
*/
function get_projects(proprietor_id){
	if(proprietor_id){
		//jQuery("#load").show();
	    var data = {
			'action': 'getProjectList',		
			'p_id': proprietor_id
		};
		jQuery.post(ajaxurl, data, function(response) {
			//jQuery("#load").hide();
	        var obj = jQuery.parseJSON(response);
	        //console.log(obj);
	        jQuery('#project_box').html(obj.project);
		})
    }
}