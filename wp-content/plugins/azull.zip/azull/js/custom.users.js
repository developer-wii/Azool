/*

jQuery('document').ready(function(){

 $name = jQuery('#user_regions_row').height();

	if( > 0){

		alert("hiiii");

		jQuery('#your-profile').AddClass("meghaaaaaaaa");

		jQuery('#user_regions_row').appendTo('.user-city-wrap');
	} 

//alert('hiii');

}); */