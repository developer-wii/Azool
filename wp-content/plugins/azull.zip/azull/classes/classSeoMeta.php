<?php
/* The class handles property,page,post seo metabox. The class is used to manage keywords and description in multiple langage and must be loaded properly
 * while rendering page,post,property.
 * Tags: azull_meta_keywords, azull_meta_description 
 * @package:wordpress
 * @subpackage:azull
 */

class Azull_Seo_Meta {

	var $field_names; //Set hook_init in below
	private static $instance;    
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self;
			self::$instance->init();

		}
		return self::$instance;
	}  
	
	
	function init() {
		//Register hooks
		global $post;
		add_action('init', array($this, 'hook_init'));
		add_action('admin_menu', array($this, 'hook_admin_menu'));
		add_action('save_post', array($this, 'hook_save_post'), 1);
		//Hooks defined in config
		add_action('wp_head', array($this, 'hook_head'));

		// Get title hook from options, or default to wp_title
		$title_hook = get_option('property_meta_title_hook');
		if (!$title_hook) $title_hook = "single_post_title"; // wp_title
		add_filter($title_hook, array(&$this, 'hook_title'));
	}	

	
	/* Init Hook */
	function hook_init() {		

		$title =  __('Browser Title', 'azull');
		$keywords = __('Keywords', 'azull');
		$description =  __('Description', 'azull');
		
		//Fields initialization
		$this->field_names = array(
			'title'       => $title,
			'keywords'    => $keywords,
			'description' => $description,
			);
	}

	/* Add menu page */
	function hook_admin_menu() {

		
		//Add META box (for both pages and posts)
		add_meta_box(
			'property_meta_seo', //HTML id
			__('Page SEO meta', 'azull'), //title
			array($this, 'meta_box_generate'), //callback
			'page', //type
			'normal', //context - normal, advanced, side
			'high' //priority - high, low
			);
		
		//Add META box (for both pages and posts)
		add_meta_box(
			'property_meta_meta_box', //HTML id
			__('Property SEO meta', 'azull'), //title
			array($this, 'meta_box_generate'), //callback
			'property', //type
			'normal', //context - normal, advanced, side
			'high' //priority - high, low
			);
		
		add_meta_box(
			'property_meta_meta_box', //HTML id
			__('Post SEO meta', 'azull'), //title
			array($this, 'meta_box_generate'), //callback
			'post', //type
			'normal', //context - normal, advanced, side
			'high' //priority - high, low
			);

		add_meta_box(
			'property_meta_meta_box', //HTML id
			__('Office SEO meta', 'azull'), //title
			array($this, 'meta_box_generate'), //callback
			'azulloffice', //type
			'normal', //context - normal, advanced, side
			'high' //priority - high, low
			);

		add_meta_box(
			'property_meta_meta_box', //HTML id
			__('Infodays SEO meta', 'azull'), //title
			array($this, 'meta_box_generate'), //callback
			'infodays', //type
			'normal', //context - normal, advanced, side
			'high' //priority - high, low
			);

		add_meta_box(
			'property_meta_meta_box', //HTML id
			__('Testimonial SEO meta', 'azull'), //title
			array($this, 'meta_box_generate'), //callback
			'testimonial', //type
			'normal', //context - normal, advanced, side
			'high' //priority - high, low
			);
	}
	
	/* Load & split META tags */
	function load_meta($post_id) { 
		/**if SEO data not available should use property desc***/
		$post_data = get_post($post_id, ARRAY_A); 
	    //print_r($post_data);
	    //die;
		$post_meta = get_post_meta($post_id);
	    //print('<pre>');print_r($post_data['post_category'][0]);die;// && $post_data['post_type']!='page'
		if(isset($post_data) && $post_data['post_status']!='auto-draft' && $post_data['post_type']=='property' ){
			$ref_no = (isset($post_meta['_nreal_id'][0]) && !empty($post_meta['_nreal_id'][0]))?$post_meta['_nreal_id'][0]:'';
			if(isset($post_meta['_place'][0]) && !empty($post_meta['_place'][0])){
				$place_term = get_term($post_meta['_place'][0],'place');
				$place = (isset($place_term->name) && !empty($place_term->name))?ucwords($place_term->name):'';
			}
			if(isset($post_meta['_region'][0]) && !empty($post_meta['_region'][0])){
				$region_term = get_term($post_meta['_region'][0],'region');
				$region = (isset($region_term->name) && !empty($region_term->name))?ucwords($region_term->name):'';
			}
			if(isset($post_meta['_country'][0]) && !empty($post_meta['_country'][0])){
				$country_term = get_term($post_meta['_country'][0],'country');
				$country = (isset($country_term->name) && !empty($country_term->name))?ucwords($country_term->name):'';
			}
			if(isset($post_data['post_category'][0]) && !empty($post_data['post_category'][0])){
				$category_term = get_term($post_data['post_category'][0],'category');
				$category = (isset($category_term->name) && !empty($category_term->name))?ucwords($category_term->name):'';
			}
			$languages = qtranxf_getSortedLanguages();
			foreach ($languages as $lang) {
				$t_place[$lang] = ucwords($this->getTranslatedTerm($lang,$place));
				$t_region[$lang] = ucwords($this->getTranslatedTerm($lang,$region));
				$t_country[$lang] = ucwords($this->getTranslatedTerm($lang,$country));
				$t_category[$lang] = ucwords($this->getTranslatedTerm($lang,$category));
				$t_title[$lang] = ucfirst(qtranxf_use($lang, $post_data['post_title']));
			}
			
			$desc_arr = array(
				'en'=>'Azull leader in sales of apartments and villas in Spain.',
				'fr'=>'Leader Azull des ventes d appartements et de villas en Espagne.',
				'nl'=>'Azull marktleider in verkoop van appartementen en villa’s in Spanje.'
				);
		    /*$te_koop_in_arr = array(
		    	'en'=>'for sale',
		    	'fr'=>'te koop dans',
		    	'nl'=>'te koop in'
		    	);*/
		    	$te_koop_in_arr = array(
		    		'en'=>' for sale in',
		    		'fr'=>' à vendre à',
		    		'nl'=>' te koop in'
		    		);
		    	$te_koop_in_arr1 = array(
		    		'en'=>'for sale',
		    		'fr'=>'à vendre',
		    		'nl'=>'te koop'
		    		);
		    	$postData=qtranxf_split($post_data['post_title']);


		    //print('<pre>');print_r($t_place);die;
		    	foreach($this->field_names as $field => $field_label) {
		    		$field_id = "property_meta:{$field}";
		    		$field_data1 = get_post_meta( $post_id, $field_id, true );
		    		$postMetaData=qtranxf_split($field_data1);
		    		$field_data = get_post_meta( $post_id, $field_id, true );
		    		if(empty($field_data) || $field_data ==''){
		    			switch ($field){
		    				case 'title':
		    				foreach ($languages as $lang) {

		    					if($postData[$lang]==''){
		    						$meta[$field][$lang]=$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' - Ref.'.$ref_no;
		    					}else{
		    						$meta[$field][$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].'Ref.'.$ref_no;
		    					}

								//$meta[$field][$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' Ref.'.$ref_no;
		    				}
		    				break;
		    				case 'keywords':
		    				foreach ($languages as $lang) {

		    					if($postData[$lang]==''){
		    						$meta[$field][$lang]=$t_category[$lang].$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_region[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_country[$lang];
		    					}else{
		    						$meta[$field][$lang] = $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].' '.$t_region[$lang].' '.$t_country[$lang];
		    					}

								//
		    				}
		    				break;  
		    				case 'description':
		    				foreach ($languages as $lang) {
		    					if($postData[$lang]==''){
		    						$meta[$field][$lang]= $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang];
		    					}else{
		    						$meta[$field][$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];
		    					}
 							//$meta[$field][$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];
		    				}
		    				break;			
		    			}
		    		}else{

		    			switch ($field){
		    				case 'title':
		    				foreach ($languages as $lang) {

		    					if($postMetaData[$lang]==''){	
		    						if($postData[$lang]==''){
		    							$meta[$field][$lang]=$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' - Ref.'.$ref_no;
		    						}else{
		    							$meta[$field][$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].'Ref.'.$ref_no;
		    						}
		    					}else{
		    						$meta[$field][$lang]=$postMetaData[$lang];
		    					}	

		    				}
		    				break;
		    				case 'keywords':
		    				foreach ($languages as $lang) {
		    					if($postMetaData[$lang]==''){	  
		    						if($postData[$lang]==''){
		    							$meta[$field][$lang]=$t_category[$lang].$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_region[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_country[$lang];
		    						}else{
		    							$meta[$field][$lang] = $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].' '.$t_region[$lang].' '.$t_country[$lang];
		    						}

								//
		    					}else{
		    						$meta[$field][$lang]=$postMetaData[$lang];
		    					}
		    				}
		    				break;  
		    				case 'description':
		    				foreach ($languages as $lang) {
		    					if($postMetaData[$lang]==''){			
		    						if($postData[$lang]==''){
		    							$meta[$field][$lang]= $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang];
		    						}else{
		    							$meta[$field][$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];
		    						}
		    					}else{
		    						$meta[$field][$lang]=$postMetaData[$lang];
		    					}
		    				}
		    				break;		

					//$meta[$field] = qtranxf_split( $field_data );	  
		    			}

		    		} 
				//$meta[$field] = qtranxf_split( $field_data ); 
		    	}
		    	return $meta;
		    }else if( isset($post_data) && $post_data['post_status']=='auto-draft' && $post_data['post_type']=='post' ){
		    	return false;
		    }else{
		    	$field_data='';
		    	foreach($this->field_names as $field => $field_label) {
		    		$field_id = "property_meta:{$field}";
		    		$field_data = get_post_meta( $post_id, $field_id, true );
		    		$meta[$field] = qtranxf_split( $field_data );
		    	}
		    	return $meta;	  
		    }
		    return false;
		}
	/*Date: 16-Sep-2016
	 *Method: function for get translated taxonomy 
	*/    
	function getTranslatedTerm($lang,$str){
		$allstring=get_option('qtranslate_term_name');
		$strArray=array();
	    //print('<pre>');print_r($allstring);die;
		foreach ($allstring as $key => $value) {
			if($key == $str){
				return $value[$lang];
			}
		}
		return $str;
	}
		/*function load_meta($post_id) { 
		//if SEO data not available should use property desc
	   $post_data = get_post($post_id, ARRAY_A); 
		foreach($this->field_names as $field => $field_label) {
			$field_id = "property_meta:{$field}";
			$field_data = get_post_meta( $post_id, $field_id, true );
			if(empty($field_data) || $field_data ==''){
					switch ($field){
						case 'title':  
							$meta[$field]['en'] = str_replace('-',' ',$post_data['post_name']);
							$meta[$field]['fr'] = str_replace('-',' ',$post_data['post_name']);
							$meta[$field]['nl'] = str_replace('-',' ',$post_data['post_name']);
						case 'keywords':
							$meta[$field]['en'] = str_replace('-',' ',$post_data['post_name']);
						$meta[$field]['fr'] = str_replace('-',' ',$post_data['post_name']);
							$meta[$field]['nl'] = str_replace('-',' ',$post_data['post_name']); 
							break;  
						case 'description': 
							$meta[$field] = qtranxf_split($post_data['post_content']);	
						foreach ($meta[$field] as $key => $value) {
							  	$meta[$field][$key] =  strip_tags(wpautop(substr($meta[$field][$key], 0, 160)));      
							  }       
							break;			
					}
			}else{
				$meta[$field] = qtranxf_split( $field_data );	  
			}  
		} 
		return $meta;
	}*/
	
	/* Filter which runs to save META details as post meta fields on page save */
	function hook_save_post($post_id) {
		// Fix bug when auto-saving revisions
		$revision_id = wp_is_post_revision($post_id);
		if ($revision_id !== false && $revision_id !== $post_id )
			return;
		
		/**if SEO data not available should use property desc***/
		$post_data = get_post($post_id, ARRAY_A); 

		$post_meta = get_post_meta($post_id);

		if ($post_data['post_type'] == 'property') {
			$ref_no = (isset($_POST['_nreal_id']) && !empty($_POST['_nreal_id']))?$_POST['_nreal_id']:'';
			if(isset($_POST['property_meta_essential']['place']) && $_POST['property_meta_essential']['place']!='--'){
				$place_term = get_term($_POST['property_meta_essential']['place'],'place');
				$place = (isset($place_term->name) && !empty($place_term->name))?ucwords($place_term->name):'';
			}
			if(isset($_POST['property_meta_essential']['region']) && $_POST['property_meta_essential']['region']!='--'){
				$region_term = get_term($_POST['property_meta_essential']['region'],'region');
				$region = (isset($region_term->name) && !empty($region_term->name))?ucwords($region_term->name):'';
			}
			if(isset($_POST['property_meta_essential']['country']) && $_POST['property_meta_essential']['country']!='--'){
				$country_term = get_term($_POST['property_meta_essential']['country'],'country');
				$country = (isset($country_term->name) && !empty($country_term->name))?ucwords($country_term->name):'';
			}
			if(isset($_POST['property_meta_essential']['category']) && !empty($_POST['property_meta_essential']['category'])){
				$category_term = get_term($_POST['property_meta_essential']['category'],'category');
				$category = (isset($category_term->name) && !empty($category_term->name))?ucwords($category_term->name):'';
			}

			$languages = qtranxf_getSortedLanguages();
			$desc_arr = array(
				'en'=>'Azull leader in sales of apartments and villas in Spain.',
				'fr'=>'Leader Azull des ventes d appartements et de villas en Espagne.',
				'nl'=>'Azull marktleider in verkoop van appartementen en villa’s in Spanje.'
				);

		    	/*$te_koop_in_arr = array(
		    	'en'=>'for sale',
		    	'fr'=>'te koop dans',
		    	'nl'=>'te koop in'
		    	);*/

		    	$te_koop_in_arr = array(
		    		'en'=>' for sale in',
		    		'fr'=>' à vendre à',
		    		'nl'=>' te koop in'
		    		);
		    	$te_koop_in_arr1 = array(
		    		'en'=>'for sale',
		    		'fr'=>'à vendre',
		    		'nl'=>'te koop'
		    		);

		    	$postDataTitle=qtranxf_split($post_data['post_title']);
		    	foreach ($languages as $lang) {
		    		$t_place[$lang] = ucwords($this->getTranslatedTerm($lang,$place));
		    		$t_region[$lang] = ucwords($this->getTranslatedTerm($lang,$region));
		    		$t_country[$lang] = ucwords($this->getTranslatedTerm($lang,$country));
		    		$t_category[$lang] = ucwords($this->getTranslatedTerm($lang,$category));
		    		$t_title[$lang] = ucfirst(qtranxf_use($lang, $post_data['post_title']));
		    		$t_field = 'property_meta_title';
		    		$k_field = 'property_meta_keywords';
		    		$d_field = 'property_meta_description';


		    		if($postDataTitle[$lang]==''){

		    			$custom_meta[$t_field.'_'.$lang]= $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' - Ref.'.$ref_no;

		    			$custom_meta[$k_field.'_'.$lang] =$t_category[$lang].$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_region[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_country[$lang];

		    			$custom_meta[$d_field.'_'.$lang]= $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang];

		    		}else{

		    			$custom_meta[$t_field.'_'.$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' Ref.'.$ref_no;
		    			$custom_meta[$k_field.'_'.$lang] = $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].' '.$t_region[$lang].' '.$t_country[$lang];

		    			$custom_meta[$d_field.'_'.$lang] = $t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];
		    		}

		    	}
			    //print('<pre>');print_r($custom_meta);die;
				//Iterate over field names and languages and copile into array
		    	$languages = qtranxf_getSortedLanguages();
		    	$meta = array();
		    	foreach($languages as $lang){
		    		foreach($this->field_names as $field => $field_label) {
					//Get field data
		    			$field_id = "property_meta_{$field}_{$lang}";
		    			$field_data = trim(str_replace('"', '', $_POST[$field_id]));
		    			$meta[$field][$lang] = (isset($field_data) && !empty($field_data))?$field_data:$custom_meta[$field_id];
				} //end of iterating over field names
			} //end of iterating over langauges

		} else {
			//This is for everything not property
			$languages = qtranxf_getSortedLanguages();
			foreach($languages as $lang){
				foreach($this->field_names as $field => $field_label) {
					//Get field data
					$field_id = "property_meta_{$field}_{$lang}";
					$meta[$field][$lang] = $_POST[$field_id];
				} //end of iterating over field names
		    } //end of iterating over langauges
		}
		foreach($meta as $field=>$data) {
			$field_id = "property_meta:{$field}";
			$field_data = $this->qtrans_join( $data );
			update_post_meta( $post_id, $field_id, $field_data );
		}
		
		return;		

	}
	/*function hook_save_post($post_id) {
		// Fix bug when auto-saving revisions
		$revision_id = wp_is_post_revision($post_id);
		if ($revision_id !== false && $revision_id !== $post_id )
			return;
	
		//Iterate over field names and languages and copile into array
		$languages = qtranxf_getSortedLanguages();
		$meta = array();
		foreach($languages as $lang){
			foreach($this->field_names as $field => $field_label) {
				//Get field data
				$field_id = "property_meta_{$field}_{$lang}";
				$field_data = trim(str_replace('"', '', $_POST[$field_id]));
				$meta[$field][$lang] = $field_data;
			} //end of iterating over field names
		} //end of iterating over langauges
		// Join and save
		foreach($meta as $field=>$data) {
			$field_id = "property_meta:{$field}";
			$field_data = $this->qtrans_join( $data );
			update_post_meta( $post_id, $field_id, $field_data );
		}
		return;		
	}*/

	function qtrans_join($texts) {
		if(!is_array($texts)) $texts = qtranxf_split($texts);
		return qtranxf_join_b($texts);
	}

	/* Filter which runs to update any over-ridden titles */
	function hook_title($title) {
		global $post;
		
		//See if post has an alternate title in current language
		$lang = qtranxf_getLanguage();
		$meta = $this->load_meta($post->ID);
		
		//Override title?
		$new_title = ($meta['title'][$lang]) ? $meta['title'][$lang] : $title;

		//Add suffix?
		if ($title_suffix = get_option('property_meta_title_suffix'))
			$new_title .= ' '.$title_suffix;

		//Return it
		return $new_title;
	}
	
	/* Action which runs dump the localised META tags */
	function hook_head(){

		if (!(is_single() || is_page())) return;
		global $post;
		$lang = qtranxf_getLanguage();
		$meta = $this->load_meta($post->ID);

		foreach($meta as $field=>$all_data) {

			if ($field == 'title') {
				continue;
			}elseif ($data = $all_data[$lang]){
				echo "<meta name=\"{$field}\" content=\"{$data}\" />\n";
			}
		}
		return;
	}
	
	/* Callback function for creating meta box */
	function meta_box_generate() {
		global $q_config, $post;
		$languages = qtranxf_getSortedLanguages();
		$meta = $this->load_meta($post->ID);
		?>
		<script type="text/javascript">
		//<![CDATA[
		function property_meta_switch_lang(lang) {
				//Hide all
				<?php foreach($languages as $lang): echo "jQuery('#property_meta_language_{$lang}').hide();"; endforeach; ?>
				
				//Show selected, recount chars
				jQuery('#property_meta_language_'+lang).show();
				property_meta_count_chars(lang);
			}
			
			//Count chars & paste into respective box
			function property_meta_count_chars(lang) {
				var chars = jQuery('#property_meta_description_'+lang).val().length;
				jQuery('#property_meta_description-length_'+lang).val(chars);
				jQuery(".property_meta_language-switcher a").css("font-weight", "normal");
				jQuery('#active_lang_' + lang).css("font-weight", "bold");
			}
		//]]>
	</script>
	<div class="property_meta_language-switcher">
		<?php
		echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a id='active_lang_".$lang."' href=\"javascript:property_meta_switch_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
	</div>

	<?php foreach($languages as $lang): ?>
		<table style="width:100%;" id="property_meta_language_<?php echo $lang ?>" class="property_meta_table" >
			<tr><td colspan="2" class="heading">
				<img src="<?php echo WP_PLUGIN_URL ?>/azull/flags/<?php echo $q_config['flag'][$lang] ?>" alt=""/>
				<strong><?php echo qtranxf_getLanguageName($lang) ?></strong>
			</td></tr>
			<tr>
				<th><label for="property_meta_title_<?php echo $lang ?>"><?php _e('Browser Title:', 'azull'); ?></label> </th>
				<td><input type="text" name="property_meta_title_<?php echo $lang ?>" id="property_meta_title_<?php echo $lang ?>" value="<?php echo (isset($meta['title'][$lang]) && !empty($meta['title'][$lang]))?$meta['title'][$lang]:''; ?>" style="width:100%;" /></td>
			</tr>
			<tr>
				<th><label for="property_meta_keywords_<?php echo $lang ?>"><?php _e('Keywords:', 'azull'); ?></label> </th>
				<td><input type="text" name="property_meta_keywords_<?php echo $lang ?>" id="property_meta_keywords_<?php echo $lang ?>" value="<?php echo (isset($meta['keywords'][$lang]) && !empty($meta['keywords'][$lang]))?$meta['keywords'][$lang]:''; ?>" style="width:100%;" /></td>
			</tr>
			<tr>
				<th><label for="property_meta_description_<?php echo $lang ?>"><?php _e('Description:', 'azull'); ?></label> </th>
				<td>
					<textarea name="property_meta_description_<?php echo $lang ?>" id="property_meta_description_<?php echo $lang ?>" style="width:100%;" rows="3" onkeyup="property_meta_count_chars('<?php echo $lang ?>')" onkeydown="property_meta_count_chars('<?php echo $lang ?>')"><?php echo (isset($meta['description'][$lang]) && !empty($meta['description'][$lang]))?$meta['description'][$lang]:''; ?></textarea>
					<br/>
					<input type="text" maxlength="3" size="3" id="property_meta_description-length_<?php echo $lang ?>" readonly="readonly"/>
					<?php _e('characters. Most search engines use a maximum of 160 chars for the description.', 'azull'); ?>
				</td>
			</tr>
		</table>
	<?php endforeach; 

    /* q_config['default_language']
       this value pass in property_meta_switch_lang() function if you want to set default language in englis 
    */

       ?>

       <script type="text/javascript">
		//<![CDATA[
		property_meta_switch_lang('nl');

	</script>

	<?php
}

/* Get all post/page meta */
function get_post_meta($post_type) {
		//Sort out the args
	$post_type = ($post_type == 'page') ? 'page' : 'post';
	
		//Function to get POSTS
	function qtm_get_posts(&$post_array) {
			//Get posts
		$post_array = get_posts(array(
			'post_parent' => $parent_id,
			'post_type' => 'post',
			'numberposts' => -1,
				'post_status' => '', //all statuses
				'orderby' => 'parent menu_order',
				'order' => 'ASC',
				));
	}

		//Recursive function to get hierarchical PAGES
	function qtm_get_pages_hierarchical(&$page_array, $parent_id, $depth=0) {
			//Get pages at this level
		$posts = get_posts(array(
			'post_parent' => $parent_id,
			'post_type' => 'page',
			'numberposts' => -1,
				'post_status' => '', //all statuses
				'orderby' => 'parent menu_order',
				'order' => 'ASC',
				));

			//For each page, add to page array and recurse into children
		foreach ($posts as $post) {
			$post->qtm_depth = $depth;
			$page_array[] = $post;
			qtm_get_pages_hierarchical($page_array, $post->ID, $depth+1);
		}
	}

	$posts = array();
	switch ($post_type) {
		case 'page':
				//Start the recursion
		qtm_get_pages_hierarchical($posts, 0);
		break;
		case 'post' || 'property':
				//Get all posts
		qtm_get_posts($posts);
		break;
		
	}
	return $posts;

}

/* function to get property seo meta and display in seo fields when add 
    new property 24/jan/2016
*/

    function azull_add_get_seometa(){

    	$ref_no='';



    	if(isset($_POST['nrealid']) && $_POST['nrealid']!=''){
    		$ref_no = $_POST['nrealid'];
    	}

    	if(isset($_POST['place']) && $_POST['place']!='--'){
    		$place_term = get_term($_POST['place'],'place');
    		$place = (isset($place_term->name) && !empty($place_term->name))?ucwords($place_term->name):'';
    	}
    	if(isset($_POST['region']) && $_POST['region']!='--'){
    		$region_term = get_term($_POST['region'],'region');
    		$region = (isset($region_term->name) && !empty($region_term->name))?ucwords($region_term->name):'';
    	}
    	if(isset($_POST['country']) && $_POST['country']!='--'){
    		$country_term = get_term($_POST['country'],'country');
    		$country = (isset($country_term->name) && !empty($country_term->name))?ucwords($country_term->name):'';
    	}
    	if(isset($_POST['category']) && !empty($_POST['category'])){
    		$category_term = get_term($_POST['category'],'category');
    		$category = (isset($category_term->name) && !empty($category_term->name))?ucwords($category_term->name):'';
    	}

    	$languages = qtranxf_getSortedLanguages();
    	function getTranslatedTerm11($lang,$str){
    		$allstring=get_option('qtranslate_term_name');
    		$strArray=array();
    		foreach ($allstring as $key => $value) {
    			if($key == $str){
    				return $value[$lang];
    			}
    		}
    		return $str;
    	}     
    	foreach ($languages as $lang) {
    		$t_place[$lang] = ucwords(getTranslatedTerm11($lang,$place));
    		$t_region[$lang] = ucwords(getTranslatedTerm11($lang,$region));
    		$t_country[$lang] = ucwords(getTranslatedTerm11($lang,$country));
    		$t_category[$lang] = ucwords(getTranslatedTerm11($lang,$category));

    	}
		//$languages = qtranxf_getSortedLanguages();
    	$desc_arr = array(
    		'en'=>'Azull leader in sales of apartments and villas in Spain.',
    		'fr'=>'Leader Azull des ventes d appartements et de villas en Espagne.',
    		'nl'=>'Azull marktleider in verkoop van appartementen en villa’s in Spanje.'
    		);

    	$te_koop_in_arr = array(
    		'en'=>' for sale in',
    		'fr'=>' à vendre à',
    		'nl'=>' te koop in'
    		);
    	$te_koop_in_arr1 = array(
    		'en'=>'for sale',
    		'fr'=>'à vendre',
    		'nl'=>'te koop'
    		);

    	$fields = array(
    		'1'=>'title',
    		'2'=>'keywords',
    		'3'=>'description'
    		);

    	foreach ($fields as $field) {
    		if($field=='title'){
    			foreach ($languages as $lang) {
    				$title_name= $lang.'_tname';
    				$titlename=$_POST[$title_name];
    				if(isset($titlename) && $titlename !=''){
    					$meta[$field][$lang]=$titlename.' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' Ref.'.$ref_no;
    				}else{
    					$meta[$field][$lang]=$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' - Ref.'.$ref_no;

    				}	
    			}
    		}
    		if($field=='keywords'){
    			foreach ($languages as $lang) {
    				$meta[$field][$lang]=$t_category[$lang].$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_region[$lang].', '.$t_category[$lang].' '.$te_koop_in_arr1[$lang].' '.$t_country[$lang];
    			}
    		}
    		if($field=='description'){
    			foreach ($languages as $lang) {
    				$title_name= $lang.'_tname';
    				$titlename=$_POST[$title_name];
    				if(isset($titlename) && $titlename !=''){
    					$meta[$field][$lang]= $titlename.' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];
    				}else{
    					$meta[$field][$lang]= $t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang];
    				}	
    			}
    		}
    	}	
    	echo json_encode($meta);
    	die();	   
    }


} //end of class
