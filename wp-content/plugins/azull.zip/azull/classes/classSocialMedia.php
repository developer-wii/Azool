<?php
/* The class used to define to share post on social media
 * @package:wordpress
 * @subpackage:azull
 */
defined('ABSPATH') or die("No script kiddies please!");

if ( !class_exists( 'Social_Media_Sharing' ) ) :

class Social_Media_Sharing{

     private static $instance;
    	/**
	 * Main Instance for Media_Attachment class
	 * @staticvar 	array 	$instance
	 * @return the one true instance
	 */    
    public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self;
			self::$instance->init();
		  }
	    return self::$instance;
	}
      
    function init(){

    		echo "meghaaa";
    		die();

		 //global $wp_taxonomies;	
    	 //add_action( 'init', array($this,'media_taxonomies') );        	 
 		 //add_action( 'admin_menu', array($this,'custom_menu_page_removing') ); 
 	}

 }//Class Ends 

 endif;
