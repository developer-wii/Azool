<?php
/* The class used to restrict resource on azullserver
 * @package:wordpress
 * @subpackage:azull
 */
defined('ABSPATH') or die("No script kiddies please!");

if ( !class_exists( 'Azull_Role' ) ) :
class Azull_Role{
         private static $instance;    

    	/**
	 * Main Instance for Azull_Role class
	 * @staticvar 	array 	$instance
	 * @return the one true instance
	 */    
    	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self;
			self::$instance->init();
		  }
	    return self::$instance;
	}
        function init(){	
         
        } 
}//end of 
