<?php
/* The class used to define custom post type for testimonials and info days
 * @package:wordpress
 * @subpackage:azull
 */

defined('ABSPATH') or die("No script kiddies please!");

if (!class_exists('Ajull_CustomPosts')) :

    class Ajull_CustomPosts {

        private static $instance;

        /**
         * Main Instance for CustomPosts class
         * @staticvar 	array 	$instance
         * @return the one true instance
         */
        public static function instance() {
            if (!isset(self::$instance)) {
                self::$instance = new self;
                self::$instance->init();
            }
            return self::$instance;
        }

        function init() {
            add_action('init', array($this, 'register_office'));
            add_action('init', array($this, 'register_testimonials'));
            add_action('init', array($this, 'register_adds'));
            add_action('init', array($this, 'register_infoDays'));
            add_action('init', array($this, 'register_xmls'));
            add_action('save_post', array('Ajull_CustomPosts', 'TestimonialMetaSave'));
            add_action('save_post', array('Ajull_CustomPosts', 'XMLMetaSave'));
            add_action('save_post', array('Ajull_CustomPosts', 'officeMetaSave'));
            add_action('save_post', array('Ajull_CustomPosts', 'azullinfoMetaSave'));
        }

        /* =============================New testimonial code Start======================================== */

        function register_testimonials() {
            register_post_type('testimonial', array(
                'labels' => array(
                    'name' => __('Testimonials', 'azull'),
                    'singular_name' => __('Testimonial', 'azull'),
                    'add_new' => __('Add New', 'azull'),
                    'add_new_item' => __('Add New Testimonial', 'azull'),
                    'edit' => __('Edit', 'azull'),
                    'edit_item' => __('Edit Testimonial', 'azull'),
                    'new_item' => __('New Testimonial', 'azull'),
                    'view' => __('View Testimonial', 'azull'),
                    'view_item' => __('View Testimonial', 'azull'),
                    'search_items' => __('Search Testimonial', 'azull'),
                    'not_found' => __('No testimonials found', 'azull'),
                    'not_found_in_trash' => __('No testimonials found in Trash', 'azull'),
                    'parent' => __('Parent Testimonial', 'azull'),
                ),
                'public' => true,
                'publicly_queryable' => true,
                'show_ui' => true,
                'menu_icon' => 'dashicons-format-quote',
                'exclude_from_search' => true,
                'query_var' => true,
                'rewrite' => true,
                'capability_type' => 'post',
                'has_archive' => true,
                'hierarchical' => false,
                'menu_position' => 10,
                'supports' => array('title', 'editor', 'thumbnail', 'author', 'excerpt'),
                'register_meta_box_cb' => array($this, 'testimonialMeta'), // Callback function for custom metaboxes
                    )
            );
        }

        function testimonialMeta() {
            add_meta_box('testimonialMeta', __('Testimonial Details', 'azull'), array($this, 'testimonialMetaBoxe'), 'testimonial', 'normal', 'high');
        }

        function testimonialMetaBoxe($post) {

            //$post_id = get_the_ID();
            $post_id = $post->ID; //m-code	
            $testimonial_data = get_post_meta($post_id, '_testimonial', true);
            
        //    print_r($testimonial_data);
            $default_lang = "nl";
           
            // $testimonial_data = json_decode($testimonial_data);
            // comment by manoj patel 08-02-2016 for special charactors save

            wp_nonce_field('testimonials', 'testimonials');

            $languages = qtranxf_getSortedLanguages();  // for get all languages 
            echo '<div style="margin: 5px;text-align: right;" class="epc_language-switcher">';
            echo "&nbsp;|&nbsp;";
            foreach ($languages as $lang) {
                echo "<a href=\"javascript:testimonial_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
            }
            echo "</div>";



            foreach ($languages as $lang):
                ?>

                <div id="testimonial_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
                    <p>
                        <label><?php _e("Client's Name (optional)", "azull") ?></label><br />
                        <input type="text" name="testimonial[<?php echo $lang; ?>][client_name]" value="<?php echo (isset($testimonial_data[$lang]["client_name"])) ? $testimonial_data[$lang]["client_name"] : '' ?>"/><br />
                    </p>
                    <p>
                        <label><?php _e("Business/Site Name (optional)", "azull") ?></label><br />
                        <input type="text"  style="width: 100%;" name="testimonial[<?php echo $lang; ?>][source]" value="<?php echo (isset($testimonial_data[$lang]["source"])) ? $testimonial_data[$lang]["source"] : '' ?>"/><br />
                    </p>
                    <p>
                        <label><?php _e("Link (optional)", "azull") ?></label><br />
                        <input type="text"  style="width: 100%;" name="testimonial[<?php echo $lang; ?>][link]" value="<?php echo (isset($testimonial_data[$lang]["link"])) ? $testimonial_data[$lang]["link"] : '' ?>"/><br />
                    </p>
                </div>
            <?php endforeach; ?>
            <script type="text/javascript">//<![CDATA[
                var default_lang = '<?php echo $default_lang; ?>';
                testimonial_switch_lang(default_lang);
                function testimonial_switch_lang(lang) {
                    //Hide all
            <?php
            foreach ($languages as $lang): echo "jQuery('#testimonial_language_{$lang}').hide();";
            endforeach;
            ?>
                    jQuery('#testimonial_language_' + lang).show();
                    jQuery(".epc_language-switcher a").css("font-weight", "normal");
                    jQuery('#active_lang_' + lang).css("font-weight", "bold");
                }
                //]]>
            </script>
            <?php
        }

        static function TestimonialMetaSave() {
            $post_id = get_the_ID();
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
                return;

            if (!wp_verify_nonce($_POST['testimonials'], 'testimonials'))
                return;

            // update_post_meta($post_id, '_testimonial', json_encode($_POST['testimonial'])); 
            // comment by manoj patel 08-02-2016 for special charactors save
            update_post_meta($post_id, '_testimonial', $_POST['testimonial']);
            return;
        }

        /* =============================New testimonial code End======================================== */

        /**
         * Registers Info Days custom post type and its taxonomies.
         * @since 1.0
         *
         */
        function register_infoDays() {
            register_post_type('infodays', array(
                'labels' => array(
                    'name' => __('Info days', 'azull'),
                    'singular_name' => __('Info days', 'azull'),
                    'add_new' => __('Add New', 'azull'),
                    'add_new_item' => __('Add New Info days', 'azull'),
                    'edit' => __('Edit'),
                    'edit_item' => __('Edit Info days', 'azull'),
                    'new_item' => __('New Info days', 'azull'),
                    'view' => __('View Info days', 'azull'),
                    'view_item' => __('View Info days', 'azull'),
                    'search_items' => __('Search Info day', 'azull'),
                    'not_found' => __('No info day found', 'azull'),
                    'not_found_in_trash' => __('No info day found in Trash', 'azull'),
                    'parent' => __('Parent Info day', 'azull'),
                ),
                'public' => true,
                'publicly_queryable' => true,
                'show_ui' => true,
                'exclude_from_search' => true,
                'menu_icon' => 'dashicons-calendar',
                'query_var' => true,
                'rewrite' => array('slug' => 'info-days'),
                'capability_type' => 'post',
                'has_archive' => true,
                'hierarchical' => false,
                'menu_position' => 10,
                'register_meta_box_cb' => array($this, 'azullinfoMeta'), // Callback function for custom metaboxes
                'supports' => array('title', 'editor', 'thumbnail'),
                    )
            );
        }

        /**
         * Registers Info Days custom post type and its taxonomies.
         * @since 1.0
         *
         */
        function register_adds() {
            register_post_type('azulladds', array(
                'labels' => array(
                    'name' => __('Azull adds', 'azull'),
                    'singular_name' => __('Azull adds', 'azull'),
                    'add_new' => __('Add adds', 'azull'),
                    'add_new_item' => __('Add New adds', 'azull'),
                    'edit' => __('Edit', 'azull'),
                    'edit_item' => __('Edit adds', 'azull'),
                    'new_item' => __('New adds', 'azull'),
                    'view' => __('View adds', 'azull'),
                    'view_item' => __('View adds', 'azull'),
                    'search_items' => __('Search adds', 'azull'),
                    'not_found' => __('No adds found', 'azull'),
                    'not_found_in_trash' => __('No adds found in Trash', 'azull'),
                    'parent' => __('Parent adds', 'azull'),
                ),
                'public' => true,
                'publicly_queryable' => true,
                'show_ui' => true,
                'exclude_from_search' => true,
                'menu_icon' => 'dashicons-megaphone',
                'query_var' => true,
                'rewrite' => array('slug' => 'adds'),
                'capability_type' => 'post',
                'has_archive' => true,
                'hierarchical' => false,
                'menu_position' => 10,
                'supports' => array('title', 'editor', 'thumbnail'),
                    )
            );
        }

        /**
         * Registers Info Days custom post type and its taxonomies.
         * @since 1.0
         *
         */
        function register_office() {
            register_post_type('azulloffice', array(
                'labels' => array(
                    'name' => __('Azull offices', 'azull'),
                    'singular_name' => __('Azull office', 'azull'),
                    'add_new' => __('Add new office', 'azull'),
                    'add_new_item' => __('Add New office', 'azull'),
                    'edit' => __('Edit', 'azull'),
                    'edit_item' => __('Edit office', 'azull'),
                    'new_item' => __('New office', 'azull'),
                    'view' => __('View add', 'azull'),
                    'view_item' => __('View office', 'azull'),
                    'search_items' => __('Search office', 'azull'),
                    'not_found' => __('No office found', 'azull'),
                    'not_found_in_trash' => __('No office found in Trash', 'azull'),
                    'parent' => __('Parent office', 'azull'),
                ),
                'public' => true,
                'publicly_queryable' => true,
                'show_ui' => true,
                'exclude_from_search' => true,
                'menu_icon' => 'dashicons-index-card',
                'query_var' => true,
                'rewrite' => array('slug' => 'office'),
                'capability_type' => 'post',
                'has_archive' => true,
                'hierarchical' => false,
                'menu_position' => 10,
                'register_meta_box_cb' => array($this, 'azullofficeMeta'), // Callback function for custom metaboxes
                'supports' => array('title', 'editor', 'thumbnail'),
                    )
            );
        }

        function azullofficeMeta() {
            add_meta_box('OfficeMeta', __('Office Meta', 'azull'), array($this, 'azullofficeMetaBoxe'), 'azulloffice', 'normal', 'high');
            if (class_exists('MultiPostThumbnails')) {

                new MultiPostThumbnails(array(
                    'label' => 'Secondary Image',
                    'id' => 'office-image',
                    'post_type' => 'azulloffice'
                ));
            }
        }

        function azullinfoMeta() {
            add_meta_box('inofMeta', __('Info Meta', 'azull'), array($this, 'azullinfoMetaBoxe'), 'infodays', 'normal', 'high');
        }

        function azullofficeMetaBoxe() {

            $post_id = get_the_ID();
            $azulloffice_data = get_post_meta($post_id, '_azulloffice', true);
            $default_lang = "nl";
            //   $azulloffice_data = json_decode($azulloffice_data, true);

            wp_nonce_field('azulloffices', 'azulloffices');

            $languages = qtranxf_getSortedLanguages();

            echo '<div style="margin: 5px;     text-align: right;" class="epc_language-switcher">';

            echo "&nbsp;|&nbsp;";
            foreach ($languages as $lang) {
                echo "<a href=\"javascript:office_switch_lang('$lang')\" id=\"active_lang_$lang\" title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
            }
            echo "</div>";
            foreach ($languages as $lang):
                ?>

                <div id="office_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
                    <p>
                        <label><?php _e("Office address (optional)", "azull") ?></label><br />
                        <textarea  style="width: 100%;" name="azulloffice[<?php echo $lang; ?>][address]"  /><?php echo (isset($azulloffice_data[$lang]['address'])) ? str_replace("rn", "\n", $azulloffice_data[$lang]['address']) : '' ?></textarea><br />
                        <span class="description">Enter office Address</span>
                    </p>
                    <p>
                        <label><?php _e("Phone Numbers (optional)", 'azull') ?></label><br />
                        <input style="width: 100%;" type="text" value="<?php echo (isset($azulloffice_data[$lang]['phone'])) ? $azulloffice_data[$lang]['phone'] : '' ?>" name="azulloffice[<?php echo $lang; ?>][phone]"  /><br />
                        <span class="description">Enter Office contact numbers (you can add multiple numbers each should be seperated by comma")</span>
                    </p>
                    <p>
                        <label><?php _e("email adress (optional)", 'azull') ?></label><br />
                        <input style="width: 100%;" type="text" value="<?php echo (isset($azulloffice_data[$lang]['email'])) ? $azulloffice_data[$lang]['email'] : '' ?>" name="azulloffice[<?php echo $lang; ?>][email]" size="40" /><br />
                        <span class="description">Enter office email (you can add multiple emails each should be seperated by comma)</span>
                    </p>
                    <p>
                        <label><?php _e("Opening hours (optional)", 'azull') ?></label><br />
                        <textarea  style="width: 100%;" name="azulloffice[<?php echo $lang; ?>][openingHours]"  /><?php echo (isset($azulloffice_data[$lang]['openingHours'])) ? str_replace("rn", "\n", $azulloffice_data[$lang]['openingHours']) : '' ?></textarea><br />
                        <span class="description">Enter office opening hours details</span>
                    </p>
                </div>
            <?php endforeach; $lang='nl';?>
            <div class="margin-b20">
            <p>
            <?php 
/*$page_ids=get_all_page_ids();
foreach($page_ids as $page_id){
    $page = get_page($page_id);
print('<pre>');print_r($page);die;
                                    $page_title = (!empty($page->post_title))?qtranxf_split($page->post_title):'';
                                    $page_title =  (!empty($page_title[$lang]))?$page_title[$lang]:$page_title['nl']; 
                                    $pageArr[$page->ID] = $page_title;
                                }*/
                               
            ?>
                        <label><?php _e("URL Type (optional)", 'azull') ?></label><br />
                        <ul>
                     <li class="office-url-type">
                     <input type="radio" name="url_type" value="1" checked onchange="return loadpagepost(this.value);"/><?php _e("Pages", 'azull'); ?></li>
                     <li class="office-url-type">
                     <input type="radio" name="url_type" value="2" <?php echo (isset($azulloffice_data['url_type']) && ($azulloffice_data['url_type']==2)  ? "checked" : ""); ?> onchange="return loadpagepost(this.value);"/><?php _e("Blog Posts", 'azull') ?></li>
                    </ul>
                        <span class="description">Select office url type</span>
                    </p>
                    <p>
                        <label><?php _e("URL (optional)", 'azull') ?></label><br>
                        <div class="page_div">
                        <select name="wp_page_id" id="wp_page_id" class="SlectBox">
                           <option class="selectator_group_header" value="">Please select page</option>
                           <?php
                               /*$my_wp_query = new WP_Query();
                               $all_wp_pages = $my_wp_query->query( array( 'post_type' => 'page', 'orderby' => 'post_title','order' => 'ASC','post_status'=>'publish'));
                               print_r($all_wp_pages);die;*/
                               $page_ids = get_all_page_ids();
                               if(isset($page_ids) && !empty($page_ids)){
                                $pageArr = '';
                                foreach($page_ids as $page_id){
                                    $page = get_page($page_id);
                                    $page_title = (!empty($page->post_title))?qtranxf_split($page->post_title):'';
                                    $page_title =  (!empty($page_title[$lang]))?$page_title[$lang]:$page_title['nl'];
                                    if($page->post_status == 'publish'){
                                        $pageArr[$page->ID] = $page_title;
                                    }
                                }
                                asort($pageArr);
                                if(isset($pageArr) && !empty($pageArr)){
                                   foreach($pageArr as $page_id=>$page_title){
                                    $page_id = (!empty($page_id))?$page_id:'';
                                    $page_title =  (!empty($page_title))?$page_title:''; 
                            ?>
                            <option value="<?php echo $page_id; ?>" class="selectator_option" <?php echo (isset($azulloffice_data['url']) && ($azulloffice_data['url']==$page_id)  ? "selected" : ""); ?> ><?php echo $page_title; ?></option>
                            <?php }}} ?>
                        </select>
                        <br><br>
                        <span class="description">Please select page as office url.</span>
                       </div>
                       <div class="dnone post_div">
                        <select name="wp_post_id" id="wp_post_id" class="SlectBox">
                           <option class="selectator_group_header" value="">Please select post</option>
                           <?php
                               $args = array('numberposts' => -1,'orderby' => 'post_title','order' => 'ASC','post_status'=>'publish'); 
                               $postsArr = get_posts($args);
                               if(isset($postsArr) && !empty($postsArr)){
                                foreach($postsArr as $post){
                                    $post_id = (!empty($post->ID))?$post->ID:'';
                                    $post_title = (!empty($post->post_title))?qtranxf_split($post->post_title):'';
                                    $post_title =  (!empty($post_title[$lang]))?$post_title[$lang]:$post_title['nl']; 
                            ?>
                            <option value="<?php echo $post_id; ?>" class="selectator_option" <?php echo (isset($azulloffice_data['url']) && ($azulloffice_data['url']==$post_id)  ? "selected" : ""); ?>><?php echo $post_title; ?></option>
                            <?php }} ?>
                        </select>
                        <br><br>
                        <span class="description">Please select post as office url.</span>
                       </div>
                    </p>
                    </div>
            <script type="text/javascript">//<![CDATA[
                var default_lang = '<?php echo $default_lang; ?>';
                office_switch_lang(default_lang);
                function office_switch_lang(lang) {
                    //Hide all
            <?php foreach ($languages as $lang): echo "jQuery('#office_language_{$lang}').hide();";
            endforeach;
            ?>
                    jQuery('#office_language_' + lang).show();
                    jQuery(".epc_language-switcher a").css("font-weight", "normal");
                    jQuery('#active_lang_' + lang).css("font-weight", "bold");
                }
                //]]>
                var url_type = '<?php echo $azulloffice_data['url_type']; ?>';
                //alert(url_type);
                if(url_type){
                    loadpagepost(url_type);
                }
            </script>
            <?php
        }

        static function officeMetaSave($post_id) {

            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
                return;

            if (!wp_verify_nonce($_POST['azulloffices'], 'azulloffices'))
                return;
            
            if(isset($_POST['url_type']) && $_POST['url_type']!=0){
                $_POST['azulloffice']['url_type'] = $_POST['url_type'];
                switch ($_POST['url_type']) {
                    case 1://page
                        $_POST['azulloffice']['url'] = $_POST['wp_page_id'];
                    break;
                    case 2://post
                        $_POST['azulloffice']['url'] = $_POST['wp_post_id'];
                    break;
                }
            }
            //print('<pre>');print_r($_POST['azulloffice']);die('post');
            //  update_post_meta( $post_id, '_azulloffice', json_encode($_POST['azulloffice']) );
            // update_post_meta($post_id, '_azulloffice', json_encode($_POST['azulloffice']));
            update_post_meta($post_id, '_azulloffice', $_POST['azulloffice']);
            return;
        }

        /* =============================New xml code Start======================================== */

        function register_xmls() {
            register_post_type('xml', array(
                'labels' => array(
                    'name' => __('XML', 'azull'),
                    'singular_name' => __('XML', 'azull'),
                    'add_new' => __('Add New', 'azull'),
                    'add_new_item' => __('Add New XML', 'azull'),
                    'edit' => __('Edit', 'azull'),
                    'edit_item' => __('Edit XML', 'azull'),
                    'new_item' => __('New XML', 'azull'),
                    'view' => __('View XML', 'azull'),
                    'view_item' => __('View XML', 'azull'),
                    'search_items' => __('Search XML', 'azull'),
                    'not_found' => __('No xmls found', 'azull'),
                    'not_found_in_trash' => __('No xmls found in Trash', 'azull'),
                    'parent' => __('Parent XML', 'azull'),
                ),
                'public' => false,
                'publicly_queryable' => false,
                'show_ui' => true,
                'menu_icon' => 'dashicons-format-quote',
                'exclude_from_search' => true,
                'query_var' => true,
                'rewrite' => true,
                'capability_type' => 'post',
                'has_archive' => false,
                'hierarchical' => false,
                'menu_position' => 10,
                'supports' => array('title'),
                'register_meta_box_cb' => array($this, 'xmlMeta'), // Callback function for custom metaboxes
                    )
            );
        }

        function xmlMeta() {
            add_meta_box('xmlMeta', __('XML Details', 'azull'), array($this, 'xmlMetaBoxe'), 'xml', 'normal', 'high');
        }

        function xmlMetaBoxe($post) {

            //$post_id = get_the_ID();
            $post_id = $post->ID; //m-code  
            $xml_data = get_post_meta($post_id, '_xml', true);
            // $xml_data = json_decode($xml_data);
            // comment by manoj patel 08-02-2016 for special charactors save

            wp_nonce_field('xmls', 'xmls');
            $all_proprietors = get_terms( 'proprietor', array(
                'hide_empty' => false,
            ) );      
            $all_weekdays = array("0" => "Sunday", "1" => "Monday", "2" => "Tuesday", "3" => "Wednesday", "4" => "Thursday", "5" => "Friday", "6" => "Saturday");
            $all_newbuilds = array("0" => "Not Allowed", "1" => "Allowed");
            ?>
            <p>
                <label><?php _e("XML Proprietor", "azull") ?></label><br />
                <select name="xml[id]">
                    <?php 
                    foreach ($all_proprietors as $key => $proprietor) {
                        echo '<option value="'.$proprietor->term_id.'"';
                        if (isset($xml_data["id"]) && $proprietor->term_id == $xml_data["id"]) {
                            echo " selected";
                        }
                        echo '>'.$proprietor->name;
                        echo '</option>';
                    }
                    ?>
                </select>
                <br />
            </p>
            <p>
                <label><?php _e("XML Link(s) (separate by line break)", "azull") ?></label><br />
                <textarea style="width: 100%;" name="xml[link]" rows="3"><?php echo (isset($xml_data["link"])) ? $xml_data["link"] : '' ?></textarea><br />
            </p>
            <p>
                <label><?php _e("XML Time Selection: Weekday", "azull") ?></label><br />
                <select name="xml[weekday]">
                    <?php 
                    foreach ($all_weekdays as $weekdaykey => $weekday) {
                        echo '<option value="'.$weekdaykey.'"';
                        if (isset($xml_data["weekday"]) && $weekdaykey == $xml_data["weekday"]) {
                            echo " selected";
                        }
                        echo '>'.$weekday;
                        echo '</option>';
                    }
                    ?>
                </select><br />
            </p>
            <p>
                <label><?php _e("XML Time Selection: Hour", "azull") ?></label><br />
                <select name="xml[hour]">
                    <?php 
                    for ($hour = 0; $hour < 24; $hour++) {
                        echo '<option value="'.$hour.'"';
                        if (isset($xml_data["hour"]) && $hour == $xml_data["hour"]) {
                            echo " selected";
                        }
                        echo '>'.$hour;
                        echo '</option>';
                    }
                    ?>
                </select><br />
            </p>
            <p>
                <label><?php _e("XML New Build Allowance", "azull") ?></label><br />
                <select name="xml[newbuild]">
                    <?php 
                    foreach ($all_newbuilds as $newbuildkey => $newbuild) {
                        echo '<option value="'.$newbuildkey.'"';
                        if (isset($xml_data["newbuild"]) && $newbuildkey == $xml_data["newbuild"]) {
                            echo " selected";
                        }
                        echo '>'.$newbuild;
                        echo '</option>';
                    }
                    ?>
                </select><br />
            </p>
            <p>
                <label><?php _e("XML Keywords (separate by line break)", "azull") ?></label><br />
                <textarea style="width: 100%;" name="xml[keywords]" rows="10"><?php echo (isset($xml_data["keywords"])) ? $xml_data["keywords"] : '' ?></textarea><br />
            </p>
            <p>
                <label><?php _e("XML Minimum Sales Price", "azull") ?></label><br />
                <input type="text"  style="width: 100%;" name="xml[minimum_sales_price]" value="<?php echo (isset($xml_data["minimum_sales_price"])) ? $xml_data["minimum_sales_price"] : '' ?>"/><br />
            </p>
            <input type="hidden" name="process_right_away" id="process_right_away" value="0" />
            <p>
                <label><?php _e("Process this agent XML right now", "azull") ?></label><br />
                <input type="button" onclick="jQuery('#process_button').val('Processing...');jQuery('#process_button').attr('disabled','disabled');jQuery('#process_right_away').val(1);jQuery('#publish').click();" value="Process" id="process_button" /><br />
            </p>
            <?php
        }

        static function XMLMetaSave() {
            $post_id = get_the_ID();
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
                return;

            if (!wp_verify_nonce($_POST['xmls'], 'xmls'))
                return;

            // update_post_meta($post_id, '_xml', json_encode($_POST['xml'])); 
            // comment by manoj patel 08-02-2016 for special charactors save
            update_post_meta($post_id, '_xml', $_POST['xml']);
            if ($_POST['process_right_away'] == 1) {
                //This needs to be processed right away
                global $wpdb;
                $wpdb->insert('wp_xml_record',array('path' => $_POST['xml']['link'],'agentId' => $_POST['xml']['id'],'status' => 0,'type' => 1, 'newbuild' => $_POST['xml']['newbuild'] , 'minimum_sales_price' => $_POST['xml']['minimum_sales_price'], 'keywords' => $$_POST['xml']['keywords']));
            }
            return;
        }

        function azullinfoMetaBoxe() {
            $post_id = get_the_ID();
            $azullinfo = get_post_meta($post_id, '_azullinfo', true);
            // $azullinfo = json_decode($azullinfo, true);
            $default_lang = "nl";

            wp_nonce_field('azullinfo_noun', 'azullinfo_noun');

            $languages = qtranxf_getSortedLanguages();

            echo '<div style="margin: 5px;     text-align: right;" class="epc_language-switcher">';

            echo "&nbsp;|&nbsp;";
            foreach ($languages as $lang) {
                echo "<a href=\"javascript:info_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
            }
            echo "</div>";
            foreach ($languages as $lang):
                ?>

                <div id="info_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
                    <p>
                        <label><?php _e("Date (optional)", "azull") ?></label><br />
                        <textarea  style="width: 100%;" name="azullinfo[<?php echo $lang; ?>][date]"  /><?php echo (isset($azullinfo[$lang]['date'])) ? str_replace("rn", "\n", $azullinfo[$lang]['date']) : '' ?></textarea><br />
                        <span class="description"><?php _e('Please enter date(string) eg. Dinsdag 28 april om 19u00', 'azull'); ?></span>
                    </p>
                    <p>
                        <label><?php _e("Location(optional)", "azull") ?></label><br />
                        <textarea  style="width: 100%;" name="azullinfo[<?php echo $lang; ?>][location]"  /><?php echo (isset($azullinfo[$lang]['location'])) ? str_replace("rn", "\n", $azullinfo[$lang]['location']) : '' ?></textarea><br />
                        <span class="description"><?php _e('Please enter location associated with info days', 'azull') ?></span>
                    </p>
                    <p>
                        <label><?php _e("Speaker(optional)", "azull") ?></label><br />
                        <textarea  style="width: 100%;" name="azullinfo[<?php echo $lang; ?>][speaker]"  /><?php echo (isset($azullinfo[$lang]['speaker'])) ? str_replace("rn", "\n", $azullinfo[$lang]['speaker']) : '' ?></textarea><br />
                        <span class="description"><?php _e('Please enter name and short description about speaker', 'azull') ?></span>
                    </p>
                    <p>
                        <label><?php _e("URL(optional)", "azull") ?></label><br />
                        <textarea  style="width: 100%;" name="azullinfo[<?php echo $lang; ?>][url]"  /><?php echo (isset($azullinfo[$lang]['url'])) ? str_replace("rn", "\n", $azullinfo[$lang]['url']) : '' ?></textarea><br />
                        <span class="description"><?php _e('Please enter url', 'azull') ?></span>
                    </p>
                    <p>
                        <label><?php _e("Additional Information(optional)", "azull") ?></label><br />
                        <textarea  style="width: 100%;" name="azullinfo[<?php echo $lang; ?>][information]"  /><?php echo (isset($azullinfo[$lang]['information'])) ? str_replace("rn", "\n", $azullinfo[$lang]['information']) : '' ?></textarea><br />
                        <span class="description"><?php _e('Please enter additional information', 'azull') ?></span>
                    </p>

                </div>
            <?php endforeach; ?>
            <script type="text/javascript">//<![CDATA[
                var default_lang = '<?php echo $default_lang; ?>';
                info_switch_lang(default_lang);
                function info_switch_lang(lang) {
                    //Hide all
            <?php foreach ($languages as $lang): echo "jQuery('#info_language_{$lang}').hide();";
            endforeach;
            ?>
                    jQuery('#info_language_' + lang).show();
                    jQuery(".epc_language-switcher a").css("font-weight", "normal");
                    jQuery('#active_lang_' + lang).css("font-weight", "bold");
                }
                //]]>
            </script>
            <?php
        }

        static function azullinfoMetaSave() {

            $post_id = get_the_ID();
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
                return;

            if (!wp_verify_nonce($_POST['azullinfo_noun'], 'azullinfo_noun'))
                return;


            update_post_meta($post_id, '_azullinfo', $_POST['azullinfo']);
            return;
        }

    }

    

    
endif;


