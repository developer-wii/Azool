<?php

/* class to handle azull server and client xmlrpc data synchronization and added xmrpc ap methods.
 * class Xmlrpc_Server contains all the methods to serve request comming from azull client
 * Xmlrpc_Client sends xmlrpc request to client website.
 * 
 * @author:Dhananjay Pandey
 * @since:1.0
 * @package:wordpress
 * @subpackage:azull
 */

//todo: enhance public and private key concept for implementing secure synchronization between client and server
//make enhancement in second and third phase

defined('ABSPATH') or die("No script kiddies please!");

include_once( ABSPATH . 'wp-includes/class-IXR.php' );
include_once( ABSPATH . 'wp-includes/class-wp-xmlrpc-server.php' );
include_once( ABSPATH . 'wp-includes/class-wp-http-ixr-client.php' );

/*
 * defines all methods to push conten on all client website.
 * class to be used on azull server.
 */

class Xmlrpc_Client extends WP_HTTP_IXR_Client {

    private $username;
    private $password;
    private $accesskey;
    var $currentrequest = 0;
    var $currentdate = true; // option to update target/remote date with now !
    var $siteid = null;

    public function __construct($site_ID = false) {
        //increase timeout for inmo-espana.com
        $this->timeout = 120;
        $acess = get_post_meta($site_ID, 'access', true);

        if (!isset($site_ID))
            return;

        $this->siteid = $site_ID;
        $server = untrailingslashit($acess['url']);
        $server = esc_url_raw($server . '/xmlrpc.php'); 
        parent::__construct($server);
        $this->username = $acess['name'];
        $this->password = $acess['pass'];
        $this->accesskey = $acess['key'];
    }

    /*
     * function fired when a post is published 
     * @param post ID
     * @param blog ID 
     */

    function send_post_to($post_id, $blog_id = 0) {

        $this->updateLatLong($post_id);
        // delete_post_meta_by_key( '_ext_'.$this->siteid );
        $to_post_id = get_post_meta($post_id, '_ext_' . $this->siteid, true);
        $status = $this->query('wp.getPost', array(0, $this->username, $this->password, $to_post_id));
        if (isset($to_post_id) && $to_post_id != '' && !$status)
            $to_post_id = 0;
        $remote_id = false;
        //check for attachement and add it on client webiste...
        // $attachments = get_posts(array('post_type' => 'attachment', 'posts_per_page' => -1, 'post_parent' => $post_id, 'exclude' => get_post_thumbnail_id($post_id)));
        // if ($attachments) {
        //     foreach ($attachments as $attachment) {
        //         if (!get_post_meta($attachment->ID, '_remote_' . $this->siteid))
        //             $this->add_attachment($attachment->ID);
        //         if (!$this->is_post_exists(get_post_meta($attachment->ID, '_remote_' . $this->siteid))) {
        //           $this->add_attachment($attachment->ID);
        //         }
        //     }
        // }

        if ($to_post_id > 0) {
            $remote_id = $this->edit_post_to($post_id);
            $remote_id = $to_post_id;
        } else {
            $v = $this->new_post_to($post_id);
            $remote_id = $this->currentrequest;
        }

        if ($attachments && $this->currentrequest > 0) {
            foreach ($attachments as $attachment) {
                $attachement_id_remote = get_post_meta($attachment->ID, '_remote_' . $this->siteid, true);
                if (!$this->is_post_exists($attachement_id_remote)) {
                  $this->add_attachment($attachment->ID);
                  $attachement_id_remote = get_post_meta($attachment->ID, '_remote_' . $this->siteid, true);
                }
                $params = array($blog_id, $this->username, $this->password, $attachement_id_remote, array('post_parent' => $this->currentrequest), 'publish');
                $status = $this->query('wp.editPost', $params);
            }
        }
        if ($this->currentrequest > 0)
        {
           update_post_meta($post_id, '_ext_' . $this->siteid, $this->currentrequest);
           update_post_meta($postId, '_client', array($this->siteid));
           //for update property map data at client website
           $this->set_option('mapdata',$this->currentrequest,'azull_mapdata');
        }   
        return $remote_id;
    }

    //delete post on remote website
  /*  static function delete_post($new_status, $old_status, $post) {
        if ($old_status == 'publish' && $new_status != 'publish') {
            foreach (azull::get_sites() as $site) {
                $obj = new Xmlrpc_Client($site);
                if (!$obj->test_connection())
                    continue;

                // A function to perform actions when a post status changes from publish to any non-public status.
                $remote_post_id = get_post_meta($post->ID, '_ext_' . $obj->siteid, true);

                if (!$remote_post_id)
                    continue;

                $result = $obj->query('wp.deletePost', 0, $obj->username, $obj->password, $remote_post_id);
                if ($obj->get_response()) {
                    delete_post_meta($post->ID, '_ext_' . $obj->siteid);
                    //delete_post_meta($post->ID,'_client'.$obj->siteid);
                    //handle media associationt
                    $attachments = get_posts(array('post_type' => 'attachment', 'posts_per_page' => -1, 'post_parent' => $post->ID));
                    foreach ($attachments as $attachment) {
                        delete_post_meta($attachment->ID, '_remote_' . $this->siteid);
                    }
                    return;
                }
            }
        }
        return;
    } */

      static function delete_post($new_status, $old_status, $post) {
        if ($old_status == 'publish' && $new_status != 'publish') {
            foreach (azull::get_sites() as $site) {
                $obj = new Xmlrpc_Client($site);
                if (!$obj->test_connection())
                    continue;

                // A function to perform actions when a post status changes from publish to any non-public status.
                $remote_post_id = get_post_meta($post->ID, '_ext_' . $obj->siteid, true);

                if (!$remote_post_id)
                    continue;

                $result = $obj->query('wp.deletePost', 0, $obj->username, $obj->password, $remote_post_id);
                if ($obj->get_response()) {
                    delete_post_meta($post->ID, '_ext_' . $obj->siteid);
                    //delete_post_meta($post->ID,'_client'.$obj->siteid);
                    //handle media associationt
                    $attachments = get_posts(array('post_type' => 'attachment', 'posts_per_page' => -1, 'post_parent' => $post->ID));
                    foreach ($attachments as $attachment) {
                        delete_post_meta($attachment->ID, '_remote_' . $this->siteid);
                        //unlink($attachment->guid);
                    }
                    return;
                }
            }
        }
        return;
    }


    public function delete_post_single($post_id = false) {
        global $wpdb;
        $remote_post_id = get_post_meta((integer) $post_id, '_ext_' . $this->siteid, true);
        if ($remote_post_id){
             $result = $this->query('wp.deletePost', 0, $this->username, $this->password, $remote_post_id);
             //for update property map data at client website
            $this->set_option('mapdata',$remote_post_id,'azull_mapdata');
        }
        if ($post_id) {    
              delete_post_meta($post_id, '_ext_' . $this->siteid);
              delete_post_meta($post_id, '_client' . $obj->siteid);
            //handle media associationt
            $attachments = $wpdb->get_results('SELECT * FROM wp_posts WHERE post_type ="attachment" AND  post_parent = '.$post_id);
            foreach ($attachments as $attachment) {
                delete_post_meta($attachment->ID, '_remote_' . $this->siteid);
                //for delete post attachments
                wp_delete_attachment($attachment->ID);
                 //unlink($attachment->guid);
                wp_delete_post($attachment->ID);
            }
            wp_delete_post($post_id);

            return true;
        }

        return false;
    }
 

     public function unpublish_post_single($post_id = false) { 
        global $wpdb;
        $remote_post_id = get_post_meta((integer) $post_id, '_ext_' . $this->siteid, true);
        if ($remote_post_id){
            if(get_post_type($post_id) == 'property'){
                //for remove all post of property which are unpublished from client website
                $this->set_option('post_property_attachment',$remote_post_id,'remove_property_attachments');
            }
            $result = $this->query('wp.deletePost', 0, $this->username, $this->password, $remote_post_id);
            if(get_post_type($post_id) == 'property'){
                //for update property map data at client website
                $this->set_option('mapdata',$remote_post_id,'azull_mapdata');
            }
            delete_post_meta($post_id, '_ext_' . $this->siteid); 
        }
        $attachments = $wpdb->get_results('SELECT * FROM wp_posts WHERE post_type ="attachment" AND  post_parent = '.$post_id);
            foreach ($attachments as $attachment) {   
                delete_post_meta($attachment->ID, '_remote_' . $this->siteid);
            }
        //delete_post_meta($post_id, '_ext_' . $this->siteid);
        //delete_post_meta($post_id, '_client' . $obj->siteid);
        return false;
    } 


    /* public function delete_post_single($post_id = false) {
        $remote_post_id = get_post_meta((integer) $post_id, '_ext_' . $this->siteid, true);
        
        if (!$remote_post_id || !$post_id)
            return;

        $result = $this->query('wp.deletePost', 0, $this->username, $this->password, $remote_post_id);
        if ($this->get_response()) {
            delete_post_meta($post_id, '_ext_' . $this->siteid);
            delete_post_meta($post_id, '_client' . $obj->siteid);
            //handle media associationt
            $attachments = get_posts(array('post_type' => 'attachment', 'posts_per_page' => -1, 'post_parent' => $post_id));
            foreach ($attachments as $attachment) {
                delete_post_meta($attachment->ID, '_remote_' . $this->siteid);
            }
            return true;
        }
        wp_delete_post($post_id);
        return false;
    }*/

 /* function to get term name by id*/
  function get_termName($termId) {
    global $wpdb;
    $terms = $wpdb->get_results('SELECT name FROM wp_terms WHERE term_id =' . $termId, ARRAY_A);
    if (isset($terms[0]['name']))
        return $terms[0]['name'];
    return false;
    }

    /**
     * Create a new remote post from a local one
     *
     * @param local post ID
     *
     */
    private function new_post_to($post_id, $blog_id = 0) {
        $attachement_id_remote = null;
        $attachment_id = null;
        $attachment_id = get_post_thumbnail_id($post_id);
        $attachement_id_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
        if (!$attachement_id_remote) {
            $this->add_attachment($attachment_id);
        } else {
          if (!$this->is_post_exists($attachement_id_remote)) {
            $this->add_attachment($attachment_id);
          }
        }

        $attachment_id = get_post_thumbnail_id($post_id);
        $attachement_id_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
        $original_post = get_post($post_id);
        $post_content = '';
        $site_dflt_lang='';

         /*code for add custom title on client site if title is empty*/
         $site_language_setting=get_post_meta($this->siteid, 'language', true);
         $site_dflt_lang=$site_language_setting['d'];
         
         $title=$original_post->post_title;
         $content=$original_post->post_content;
         $newContent=$original_post->post_content;
         $newTitle=$original_post->post_title;
         $customTitleContent='';
         $def_property_title='';
         $def_property_content='';
         //echo $newContent."<br>";
         //echo $newContent."<br>";
       
        if($original_post->post_type == 'property'){ 
            //echo 'ddd';
            //die('test');
           $cat=get_the_category($post_id);
           $cat_name=$cat[0]->cat_name;
           $countryName = $regionName = $country= $region='';
           $country=get_post_meta($post_id,'_country');  
           $region=get_post_meta($post_id,'_region');
           $place=get_post_meta($post_id,'_place');
           $country=$country[0];
           $place=$place[0];
           $region=$region[0];

           $countryName = $this->get_termName($country);
           $place = $this->get_termName($place);
           $regionName = $this->get_termName($region);
           
            $all_terms = get_option('qtranslate_term_name');
                foreach ($all_terms as $key => $value) {
                if($countryName && $countryName==$key) $countryName = $value[$site_dflt_lang];
                if($regionName && $key==$regionName) $regionName = $value[$site_dflt_lang];
                if($cat_name==$key) $cat_name = $value[$site_dflt_lang];
                if($place==$key) $place = $value[$site_dflt_lang];
            }


           /*echo $countryName."<br>";
           echo $place."<br>";
           echo $regionName."<br>";
           echo $cat_name ;*/

            if($site_dflt_lang=='en'){
              $customTitleContent =  ucwords($cat_name).' for sale in '.ucwords($place).', '.ucwords($regionName).', '.ucwords($countryName);
            }
            if($site_dflt_lang=='nl'){
              $customTitleContent =  ucwords($cat_name).' te koop in '.ucwords($place).', '.ucwords($regionName).', '.ucwords($countryName);
            }
            if($site_dflt_lang=='fr'){
              $customTitleContent =  ucwords($cat_name).' a vendre à '.ucwords($place).', '.ucwords($regionName).', '.ucwords($countryName);
            }
  

         //echo $title."<br>";
            $title_array = qtranxf_split($title); 
            $content_array = qtranxf_split($content);
            
            $def_property_title=$title_array[$site_dflt_lang];
            $def_property_content=$content_array[$site_dflt_lang];


            if(!empty($def_property_content)){
              $newContent = $content;
            }else{
             $customContent=$customTitleContent;
             $newContent = '[:'.$site_dflt_lang.']'.$customContent.". ".$content;
            }

            if(!empty($def_property_title)){
              $newTitle = $title;
            }else{
             $customTitle=$customTitleContent;
             $newTitle = trim('[:'.$site_dflt_lang.']'.$customTitle." ".$title);
            }
        }///end check post type    
         /*===End code=====*/

        //change all server url to corresponding client url...
        $server_url = get_site_url();
        $remote_site = get_post_meta($this->siteid, 'access', true);
        //preg_match_all('/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i', $original_post->post_content, $result, PREG_PATTERN_ORDER);
        //$result = $result[0];
        //print_r($result); die;
        //ToDo: filter all url from the local content and get corespongn url for the client website.
        //ToDo: this would work only when links has been addein througn media. Orther wisle just replace the  url...server with client
        //Set parent page
        $parent = 0;
        if (isset($original_post->post_parent) && $original_post->post_parent != 0)
            $parent = get_post_meta($original_post->post_parent, '_ext_' . $this->siteid, true);
        //$post_content = str_replace($server_url, $remote_site['url'], $original_post->post_content);
        $post_content = str_replace($server_url, $remote_site['url'], $newContent);

        $post = array(
            'post_type' => get_post_type($post_id),
            'post_status' => "publish",
            //'post_title' => $original_post->post_title,
            'post_title' => $newTitle,
            'post_author' => '',
            'post_excerpt' => $original_post->post_excerpt,
            'post_content' => $post_content,
            'post_date' => new IXR_Date(strtotime($original_post->post_date)),
            'post_date_gmt' => new IXR_Date(strtotime($original_post->post_date_gmt)),
            'post_format' => get_post_format($post_id),
            //'post_name' => $original_post->post_name,
            //'post_name' => $this->client_slug($original_post->post_title),
            'post_name' => $this->client_slug($original_post->post_title,$post_id),
            'post_password' => $original_post->post_password,
            'comment_status' => $original_post->comment_status,
            'ping_status' => $original_post->ping_status,
            'sticky' => is_sticky($post_id),
            'post_parent' => ($parent > 0) ? $parent : '',
            'to_ping' => $original_post->to_ping,
            'pinged' => $original_post->pinged,
            'post_modified' => new IXR_Date(strtotime($original_post->post_modified)),
            'post_modified_gmt' => new IXR_Date(strtotime($original_post->post_modified_gmt)),
            'menu_order' => $original_post->menu_order,
        );
        if($original_post->post_type != 'property'){
            $post['post_name'] = $this->client_page_slug($original_post->post_title);
        }
        if (get_post_type($post_id) == 'property' || get_post_type($post_id) == 'post'){
            $post['terms'] = $this->assign_terms($post_id);
        }

        if ($attachement_id_remote != ''){
            $post['post_thumbnail'] = $attachement_id_remote;
        }

        $params = array(0, $this->username, $this->password, $post, true);
        $status = $this->query('wp.newPost', $params);
        $this->currentrequest = $this->get_response();
        $to_post_id = $this->currentrequest;
        if ($status) {
            update_post_meta($post_id, '_ext_' . $this->siteid, $to_post_id);
            $this->xmrpc_update_post_meta($post_id, $to_post_id,0,$post);
            return $status;
        } else {
            $this->currentrequest = 0;
            return false;
        }
    }

    /**
     * edit the local post clone content before to edit the remote one
     * @param guids of local images or attachments
     * @param array of local - remote src or url inside content to proceed search and replace
     */
    private function edit_post_to($post_id, $guids = array(), $search_replace = array(), $blog_id = 0) {
        //if post status is not publish thne transition_post_status will handle it. it will remove it from all azull client
        if (get_post_status($post_id) != 'publish')
            return;

        // $attachement_id_remote = null;
        // $attachment_id = null;
        // $attachment_id = get_post_thumbnail_id($post_id);
        // $attachement_id_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
        // if (!$attachement_id_remote)
        //     $this->add_attachment($attachment_id);
        // if (!$this->is_post_exists($attachement_id_remote)) {
        //   $this->add_attachment($attachment_id);
        //   $attachement_id_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
        // }

        // $attachment_id = get_post_thumbnail_id($post_id);
        // $attachement_id_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
        $original_post = get_post($post_id);


        /*code for add custom title on client site if title is empty*/
        $post_content = '';
        $site_dflt_lang= '';
        $customTitleContent='';

/*code for add custom title on client site if title is empty*/
        $site_language_setting=get_post_meta($this->siteid, 'language', true);
        $site_dflt_lang=$site_language_setting['d'];
        $title=$original_post->post_title;
        $content=$original_post->post_content;
        $newContent=$original_post->post_content;
        $newTitle=$original_post->post_title;
        $def_property_title='';
        $def_property_content='';
          
    if($original_post->post_type == 'property'){
          $cat=get_the_category($post_id);
          $cat_name=$cat[0]->cat_name;
          $countryName = $regionName = $country= $region='';
          $country=get_post_meta($post_id,'_country');  
          $region=get_post_meta($post_id,'_region');
          $place=get_post_meta($post_id,'_place');
          $country=$country[0];
          $place=$place[0];
          $region=$region[0];
          $countryName = $this->get_termName($country);
          $place = $this->get_termName($place);
          $regionName = $this->get_termName($region);

        $all_terms = get_option('qtranslate_term_name');
                foreach ($all_terms as $key => $value) {
                if($countryName && $countryName==$key) $countryName = $value[$site_dflt_lang];
                if($regionName && $key==$regionName) $regionName = $value[$site_dflt_lang];
                if($cat_name==$key) $cat_name = $value[$site_dflt_lang];
                if($place==$key) $place = $value[$site_dflt_lang];
        }

        if($site_dflt_lang=='en'){
          $customTitleContent =  ucwords($cat_name).' for sale in '.ucwords($place).', '.ucwords($regionName).', '.ucwords($countryName);
        }
        if($site_dflt_lang=='nl'){
          $customTitleContent =  ucwords($cat_name).' te koop in '.ucwords($place).', '.ucwords($regionName).', '.ucwords($countryName);
        }
        if($site_dflt_lang=='fr'){
          $customTitleContent =  ucwords($cat_name).' a vendre à '.ucwords($place).', '.ucwords($regionName).', '.ucwords($countryName);
        }
        
        $def_property_title='';
        $def_property_content='';
        //echo $title;
        $title_array = qtranxf_split($title);     

        ///echo "xxx";//print_r($title_array);
            //print_r($site_dflt_lang);
            $def_property_title=$title_array[$site_dflt_lang];
        //print_r($def_property_title);
          //  die;

        $content_array = qtranxf_split($content);     
        $def_property_content=$content_array[$site_dflt_lang];

       
       if(!empty($def_property_content)){
          $newContent = $content;
       }else{
         $customContent=$customTitleContent;
         $newContent = '[:'.$site_dflt_lang.']'.$customContent.". ".$content;
       }

       if(!empty($def_property_title)){
          $newTitle = $title;
       }else{
         $customTitle=$customTitleContent;
         $newTitle = '[:'.$site_dflt_lang.']'.$customTitle." ".$title;
       }
    }
    //end check post type
       /*====end code custom title===*/




        //change all server url to corresponding client url...
        $server_url = get_site_url();
        $remote_site = get_post_meta($this->siteid, 'access', true);
        //$post_content = str_replace($server_url, $remote_site['url'], $original_post->post_content);
        $post_content = str_replace($server_url, $remote_site['url'], $newContent);

        //Set parent page
        $parent = 0;
        if (isset($original_post->post_parent) && $original_post->post_parent != 0)
            $parent = get_post_meta($original_post->post_parent, '_ext_' . $this->siteid, true);

        $post = array(
            'post_type' => get_post_type($post_id),
            'post_status' => "publish",
            //'post_title' => $original_post->post_title,
            'post_title' => $newTitle,
            'post_author' => '',
            'post_excerpt' => $original_post->post_excerpt,
            'post_content' => $post_content,
            'post_date' => new IXR_Date(strtotime($original_post->post_date)),
            'post_date_gmt' => new IXR_Date(strtotime($original_post->post_date_gmt)),
            'post_format' => get_post_format($post_id),
            'post_name' => $this->client_slug($original_post->post_title,$post_id),
            //'post_name' => $this->client_slug($original_post->post_title),
            'post_password' => $original_post->post_password,
            'comment_status' => $original_post->comment_status,
            'ping_status' => $original_post->ping_status,
            'sticky' => is_sticky($post_id),
            'post_parent' => ($parent > 0) ? $parent : '',
            'to_ping' => $original_post->to_ping,
            'pinged' => $original_post->pinged,
            'post_modified' => new IXR_Date(strtotime($original_post->post_modified)),
            'post_modified_gmt' => new IXR_Date(strtotime($original_post->post_modified_gmt)),
            'menu_order' => $original_post->menu_order,
        );
        if($original_post->post_type != 'property'){
            $post['post_name'] = $this->client_page_slug($original_post->post_title);
        }
        if (get_post_type($post_id) == 'property' || get_post_type($post_id) == 'post'){
            $post['terms'] = $this->assign_terms($post_id);
        }

        if ($attachement_id_remote != ''){
            $post['post_thumbnail'] = $attachement_id_remote;
        }

        $to_post_id = get_post_meta($post_id, '_ext_' . $this->siteid, true);
        $this->currentrequest = $to_post_id;
        if ($to_post_id > 0) {
            $params = array($blog_id, $this->username, $this->password, $to_post_id, $post);
            $status = $this->query('wp.editPost ', $params);
            $this->xmrpc_update_post_meta($post_id, $to_post_id,0,$post);
            return $status; // ID or false
        } else {
            $this->currentrequest = 0;
            return false;
        }
    }

    private function xmrpc_update_post_meta($post_id, $rpost_id = NULL, $blog_id = 0,$remote_post) {
        global $wpdb;
        //for post/page/property
        $custom_fields = array(
            'property_meta:title' => get_post_meta($post_id, 'property_meta:title', true),
            'property_meta:keywords' => get_post_meta($post_id, 'property_meta:keywords', true),
            'property_meta:description' => get_post_meta($post_id, 'property_meta:description', true),
        );
        if (get_post_type($post_id) == 'post') {
            $custom_fields['_featured'] = (get_post_meta($post_id, '_featured', true)) ? get_post_meta($post_id, '_featured', true) : 0;
            $custom_fields['_layout'] = (get_post_meta($post_id, 'layout', true)) ? get_post_meta($post_id, '_layout', true) : '';
            /*  Date:16-July-2016-
              *  this code for remove featrue image
              */
             $attachment_id = get_post_thumbnail_id($post_id);
             $attachement_id_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
             if (!$this->is_post_exists($attachement_id_remote)) {
                $this->add_attachment($attachment_id);
                $attachement_id_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
             }
             if($attachement_id_remote==''){
                $custom_fields['_thumbnail_id']='';
             }
        }
        if (get_post_type($post_id) == 'page') {
            $custom_fields['_page'] = (get_post_meta($post_id, '_page', true)) ? get_post_meta($post_id, '_page', true) : 0;
            $custom_fields['_layout'] = (get_post_meta($post_id, '_layout', true)) ? get_post_meta($post_id, '_layout', true) : 0;
            $custom_fields['_external_link'] = (get_post_meta($post_id, '_external_link', true)) ? get_post_meta($post_id, '_external_link', true) : '';

            if (class_exists('MultiPostThumbnails')) {
                $languages = qtranxf_getSortedLanguages();
                foreach ($languages as $lang) {

                    $thumbnail_featured_id = get_post_meta($post_id, 'page_feature_image_' . $lang . '_thumbnail_id', true);


                    $thumbnail_featured_title_id = get_post_meta($post_id, 'page_feature_title_image_' . $lang . '_thumbnail_id', true);

                    if ($thumbnail_featured_id && $thumbnail_featured_id != '') {
                        $thumbnail_featured_id_remote = get_post_meta($thumbnail_featured_id, '_remote_' . $this->siteid, true);
                        $custom_fields['page_feature_image_' . $lang . '_thumbnail_id'] = $thumbnail_featured_id_remote;
                    }

                    if ($thumbnail_featured_title_id && $thumbnail_featured_title_id != '') {
                        $thumbnail_featured_title_id_remote = get_post_meta($thumbnail_featured_title_id, '_remote_' . $this->siteid, true);
                        $custom_fields['page_feature_title_image_' . $lang . '_thumbnail_id'] = $thumbnail_featured_title_id_remote;
                    }
                }
            }
        }

        if (get_post_type($post_id) == 'testimonial') {
            $_testimonial = get_post_meta($post_id);
            $custom_fields['_page'] = (get_post_meta($post_id, '_page', true)) ? get_post_meta($post_id, '_page', true) : 0;
            $custom_fields['_layout'] = (get_post_meta($post_id, '_layout', true)) ? get_post_meta($post_id, '_layout', true) : 0;
            //  $custom_fields['_testimonial'] = ($_testimonial) ? $_testimonial : 0;
            $custom_fields['_testimonial'] = (get_post_meta($post_id, '_testimonial', true)) ? get_post_meta($post_id, '_testimonial', true) : 0;
            //    $custom_fields['_testimonial'] = (get_post_meta($post_id, '_testimonial', true)) ? get_post_meta($post_id, '_testimonial', true) : 0;
        }

        if (get_post_type($post_id) == 'infodays') {
            $_infodays = get_post_meta($post_id);
            $custom_fields['_page'] = (get_post_meta($post_id, '_page', true)) ? get_post_meta($post_id, '_page', true) : 0;
            $custom_fields['_layout'] = (get_post_meta($post_id, '_layout', true)) ? get_post_meta($post_id, '_layout', true) : 0;
            $custom_fields['_azullinfo'] = (get_post_meta($post_id, '_azullinfo', true)) ? get_post_meta($post_id, '_azullinfo', true) : 0;
            //           $custom_fields['_azullinfo'] = (get_post_meta($post_id, '_azullinfo', true)) ? get_post_meta($post_id, '_azullinfo', true) : 0;
        }

        if (get_post_type($post_id) == 'azulladds') {
            $custom_fields['_type'] = (get_post_meta($post_id, '_type', true)) ? get_post_meta($post_id, '_type', true) : 0;
            $custom_fields['_layout'] = (get_post_meta($post_id, '_layout', true)) ? get_post_meta($post_id, '_layout', true) : '';
            $custom_fields['_external_link'] = (get_post_meta($post_id, '_external_link', true)) ? get_post_meta($post_id, '_external_link', true) : '';
        }

        if (get_post_type($post_id) == 'azulloffice') {
            //$custom_fields['_page']=(get_post_meta($post_id,'page',true)) ? get_post_meta($post_id,'page',true): 0;
            $custom_fields['_layout'] = (get_post_meta($post_id, '_layout', true)) ? get_post_meta($post_id, '_layout', true) : 0;
            $custom_fields['_lat'] = (get_post_meta($post_id, '_lat', true)) ? get_post_meta($post_id, '_lat', true) : '';
            $custom_fields['_lng'] = (get_post_meta($post_id, '_lng', true)) ? get_post_meta($post_id, '_lng', true) : '';
            $custom_fields['_azulloffice'] = (get_post_meta($post_id, '_azulloffice', true)) ? get_post_meta($post_id, '_azulloffice', true) : '';
            if (class_exists('MultiPostThumbnails')) {
                //handle secondery image.. check multiple thumnail...
                $thumbnail_id = get_post_meta($post_id, 'azulloffice_office-image_thumbnail_id', true);
                if ($thumbnail_id && $thumbnail_id != '') {
                    $attachement_id_remote = get_post_meta($thumbnail_id, '_remote_' . $this->siteid, true);
                    $custom_fields['azulloffice_office-image_thumbnail_id'] = $attachement_id_remote;
                }
            }
        }
        if (get_post_type($post_id) == 'property') {
          
          /*code to add tag line on client sites*/
            $clientMetaDesc='';
            $en=''; $fr=''; $nl='';
            $sirteUrl=get_post_meta($this->siteid, 'access', true);
            $urlName=explode('www.',$sirteUrl['url']);
            $metaDesc=get_post_meta($post_id, 'property_meta:description', true);
            $meta_array = qtranxf_split($metaDesc);
            $siteUrl=str_replace('/','', $urlName[1]);
            switch ($siteUrl) {

            case 'azull.be':
               $tagline='Azull marktleider in verkoop van appartementen en villa’s in Spanje.';
                if($meta_array['nl']!=''){
                    $pos=strpos($meta_array['fr'],'Azull marktleider in verkoop van appartementen en villa’s in Spanje');
                    if($pos){
                     $nl = str_replace('Azull marktleider in verkoop van appartementen en villa’s in Spanje', $tagline, $meta_array['nl']);
                    }else{
                        $nl = $meta_array['nl'].".".$tagline;
                    }
                    
                 }
                if($meta_array['fr']!=''){
                   $fr = $meta_array['fr'];
                }
                if($meta_array['en']!=''){
                   $en = $meta_array['en'];
                }
                $clientMetaDesc='[:en]'.$en.'[:fr]'.$fr.'[:nl]'.$nl.'[:]';

               break;

            case 'azull.fr':
               $tagline='Azull, leader du marché de la vente d’appartements et de villas en Espagne.';
        
                if($meta_array['nl']!=''){
                   $nl = $meta_array['nl'];
                }
                if($meta_array['fr']!=''){
                   
                   $pos=strpos($meta_array['fr'],'Azull marktleider in verkoop van appartementen en villa’s in Spanje');
                  if($pos){
                    $fr=str_replace('Azull marktleider in verkoop van appartementen en villa’s in Spanje', $tagline, $meta_array['nl']);
                  }else{
                    $fr = $meta_array['fr'].".".$tagline;
                  }  
                }
                if($meta_array['en']!=''){
                   $en = $meta_array['en'];
                }
                $clientMetaDesc='[:en]'.$en.'[:fr]'.$fr.'[:nl]'.$nl.'[:]';

               break;

            case 'inmo-espana.com':
                $tagline='Inmo España is de Expert in verkoop van appartementen en villa’s in Spanje';
                if($meta_array['nl']!=''){
                   $pos=strpos($meta_array['nl'],'Inmo España is de Expert in verkoop van appartementen en villa’s in Spanje');
                    if($pos){
                         $nl = str_replace('Inmo España is de Expert in verkoop van appartementen en villa’s in Spanje', $tagline, $meta_array['nl']);
                    }else{
                         $nl = $meta_array['nl'].".".$tagline;
                    }
                  
                 }
                 if($meta_array['fr']!=''){
                   $fr = $meta_array['fr'];
                 }
                 if($meta_array['en']!=''){
                  $en = $meta_array['en'];
                 }
                $clientMetaDesc='[:en]'.$en.'[:fr]'.$fr.'[:nl]'.$nl.'[:]';
                  break;
            }

            //update property gallery
            $gallery = get_post_meta($post_id, 'property_gallery');

            if ($gallery = get_post_meta($post_id, 'property_gallery', true)) {
                $ids = json_decode(base64_decode($gallery));
                foreach ($ids as $id) {
                     $rcof = get_post_meta($id, '_remote_' . $this->siteid);
                    if (!get_post_meta($id, '_remote_' . $this->siteid))
                        $this->add_attachment($id);

                      if (!$this->is_post_exists(get_post_meta($id, '_remote_' . $this->siteid))) {
                        $this->add_attachment($id);
                      }

                    $rids[] = get_post_meta($id, '_remote_' . $this->siteid, true);
                }
                $rgallery = base64_encode(json_encode($rids));
            }

            $agent_id_local = get_post_meta($post_id, '_agent', true);

            //$agent = get_term_by('id', $agent_id_local, 'agent');
            $agent_slug = $this->get_termsname_slug($agent_id_local);
            $agent_id_remote = $this->has_taxonomy('agent', $agent_slug);

            $proprietor_id_local = get_post_meta($post_id, '_proprietor', true);
            //$proprietor = get_term_by('id', $proprietor_id_local, 'proprietor');
            $proprietor_slug = $this->get_termsname_slug($proprietor_id_local);
            $proprietor_id_remote = $this->has_taxonomy('proprietor', $proprietor_slug);

            $country_id_local = get_post_meta($post_id, '_country', true);
            //$country = get_term_by('id', $country_id_local, 'country');
            $country_slug = $this->get_termsname_slug($country_id_local);
            $country_id_remote = $this->has_taxonomy('country', $country_slug);

            $region_id_local = get_post_meta($post_id, '_region', true);
            //$region = get_term_by('id', $region_id_local, 'region');
            $region_slug = $this->get_termsname_slug($region_id_local);
            $region_id_remote = $this->has_taxonomy('region', $region_slug);

            $province_id_local = get_post_meta($post_id, '_province', true);
            //$province = get_term_by('id', $province_id_local, 'province');
            $province_slug = $this->get_termsname_slug($province_id_local);
            $province_id_remote = $this->has_taxonomy('province', $province_slug);

            $place_id_local = get_post_meta($post_id, '_place', true);
            $place_slug = $this->get_termsname_slug($place_id_local);
            $place_id_remote = $this->has_taxonomy('place', $place_slug);
            $project_id_local = get_post_meta($post_id, '_project', true);
            $project_slug = $this->get_termsname_slug($project_id_local);
            $project_id_remote = $this->has_taxonomy('project', $project_slug);
            $nreal_id = get_post_meta($post_id, '_nreal_id', true); //fix to accomodate old property id

            $custom_fields = array(
                '_propertyRef' => (isset($nreal_id) ) ? $nreal_id : $post_id,
                'property_meta:title' => get_post_meta($post_id, 'property_meta:title', true),
                'property_meta:keywords' => get_post_meta($post_id, 'property_meta:keywords', true),
                //'property_meta:description' => get_post_meta($post_id, 'property_meta:description', true),
                'property_meta:description' => $clientMetaDesc,
                '_propertyName' => get_post_meta($post_id, '_propertyName', true),
                '_agent' => ($agent_id_remote) ? $agent_id_remote : '',
                '_proprietor' => ($proprietor_id_remote) ? $proprietor_id_remote : '',
                '_country' => ($country_id_remote) ? $country_id_remote : '',
                '_region' => ($region_id_remote) ? $region_id_remote : '',
                '_province' => ($province_id_remote) ? $province_id_remote : '',
                '_place' => ($place_id_remote) ? $place_id_remote : '',
                '_lat' => get_post_meta($post_id, '_lat', true), 
                '_lng' => get_post_meta($post_id, '_lng', true),
                '_zip' => get_post_meta($post_id, '_zip', true),
                '_buildType' => get_post_meta($post_id, '_buildType', true),
                '_finance' => get_post_meta($post_id, '_finance', true),
                '_oldPrice' => get_post_meta($post_id, '_oldPrice', true),
                '_totalPrice' => azull_price('Total Price', $post_id),
                '_salesPrice' => get_post_meta($post_id, '_salesPrice', true),
                '_reservationAmount' => get_post_meta($post_id, '_reservationAmount', true),
                '_moreInformation' => get_post_meta($post_id, '_moreInformation', true),
                '_monthlyCharges' => get_post_meta($post_id, '_monthlyCharges', true),
                '_proprietorRef' => get_post_meta($post_id, '_proprietorRef', true),
                '_penthouse' => get_post_meta($post_id, '_penthouse', true),
                '_bank' => get_post_meta($post_id, '_bank', true),
                '_year' => get_post_meta($post_id, '_year', true),
                '_status' => get_post_meta($post_id, '_status', true),
                '_energyCurrent' => get_post_meta($post_id, '_energyCurrent', true),
                '_energyPotential' => get_post_meta($post_id, '_energyPotential', true),
                '_co2Current' => get_post_meta($post_id, '_co2Current', true),
                '_co2Potential' => get_post_meta($post_id, '_co2Potential', true),
                '_epc_e' => get_post_meta($post_id, '_epc_e', true),
                '_agentCheck' => get_post_meta($post_id, '_agentCheck', true),
                '_project'=>(isset($project_id_remote) && !empty($project_id_remote))?$project_id_remote:'',
                'property_gallery' => ($rgallery) ? $rgallery : array(),

                '_qts_slug_en' => get_post_meta($post_id, '_qts_slug_en', true),
                '_qts_slug_fr' => get_post_meta($post_id, '_qts_slug_fr', true),
                '_qts_slug_nl' => get_post_meta($post_id, '_qts_slug_nl', true),

                '_yoast_wpseo_title' => get_post_meta($post_id, '_yoast_wpseo_title', true),
                '_yoast_wpseo_metadesc' => get_post_meta($post_id, '_yoast_wpseo_metadesc', true),
                '_yoast_wpseo_focuskw' => get_post_meta($post_id, '_yoast_wpseo_focuskw', true),
            );

            $dimensions = $this->get_terms_custom('dimensions');
            if ($dimensions) {
                foreach ($dimensions as $dimension) {
                    if ($id_remote = $this->has_taxonomy('dimensions', $dimension->slug))
                        ;
                    $custom_fields['_dimensions_' . $id_remote] = get_post_meta($post_id, '_dimensions_' . $dimension->term_id, true);
                }
            }
            $scores = $this->get_terms_custom('walkscores');
            if ($scores) {
                foreach ($scores as $score) {
                    if ($id_remote = $this->has_taxonomy('walkscores', $score->slug))
                        ;
                    $custom_fields['_scores_' . $id_remote] = get_post_meta($post_id, '_scores_' . $score->term_id, true);
                }
            }
            $terms = $this->get_terms_custom('feature');
            if (!empty($terms) && !is_wp_error($terms)) {
                $taxonomy_meta['type'] = 1;
                foreach ($terms as $term) {
                    $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
                    if ($taxonomy_meta['type'] == 2) {
                        $feature_id_remote = $this->has_taxonomy('feature', $term->slug);
                        $custom_fields['_feature_' . $feature_id_remote] = get_post_meta($post_id, '_feature_' . $term->term_id, true);
                    }
                }
            }
        }
        $language = get_post_meta((int) $this->siteid, 'language', true);
        //$languages = qtranxf_getSortedLanguages();
        //save custom permalink in post meta
        $post_types = array('post','page','property');
        //$post_types = array('post');
        if (in_array(get_post_type($post_id), $post_types)) {
            $site_access = get_post_meta($this->siteid, 'access', true);
            $site_url = rtrim($site_access['url'],"/");
            if($this->siteid == 7933){
                $client_site_url = $site_url;
            }else{
                $client_site_url = str_replace('http://','https://',$site_url);
            }
            if(isset($language['a']) && !empty($language['a']) && is_array($language['a']) && count($language['a'])>0){
                foreach ($language['a'] as $key => $val) {
                    $meta_key = '_custom_permalink_'.strtolower($val);
                    $lang_permalink = get_post_meta($post_id, $meta_key, true);
                    if(isset($lang_permalink) && !empty($lang_permalink)){
                        $custom_fields[$meta_key] = str_replace('http://azull.biz/cisin',$client_site_url.'/'.$val,$lang_permalink);
                    }else if(isset($remote_post['post_name']) && !empty($remote_post['post_name']) && get_post_type($post_id) == 'property'){
                        update_post_meta($post_id, '_custom_permalink_'.$val, get_site_url().'/'.rtrim($remote_post['post_name'],"-"));
                        $custom_fields[$meta_key] = $client_site_url.'/'.$val.'/'.rtrim($remote_post['post_name'],"-");
                    }
                }
            }
        }

        //get main website access url
        $canonical_reference = '';
        $canonical_ref_site = '';
        $main_site = get_post_meta($post_id, '_main_site', true);
        if(isset($main_site) && !empty($main_site) && $main_site!=0 && $main_site!=$this->siteid){
            $all_clients = get_post_meta($post_id, '_client', true);
            if(isset($all_clients) && !empty($all_clients) && count($all_clients)>0 && in_array($main_site, $all_clients)){

                //get client website meta
                $client_site = $this->siteid;
                $client_site_access = get_post_meta($client_site, 'access', true);
                $client_site_url = $client_site_access['url'];
                $cw_url_arr = explode('.', $client_site_url);
                $cw_domain = (isset($cw_url_arr[1]) && !empty($cw_url_arr[1]))?strtolower($cw_url_arr[1]):'';
                $client_language = get_post_meta((int) $client_site, 'language', true);
                $client_default_lang = (isset($client_language['d']) && !empty($client_language['d']))?strtolower($client_language['d']):'';
                //get main website meta
                $main_site_access = get_post_meta($main_site, 'access', true);
                $main_site_url = $main_site_access['url'];
                $mw_url_arr = explode('.', $main_site_url);
                if(isset($mw_url_arr[1]) && !empty($mw_url_arr[1])){
                  //5-3-2017 Johan: If main website is not set, you can consider azull.be as main website for Dutch, azull.fr as main website for French and azull.eu as main website for English. 
                  //logic implemented by Tien
                  //This case is for main website is set
                  $mainsite_language = get_post_meta((int) $main_site, 'language', true);
                  $mainsite_default_lang = (isset($mainsite_language['d']) && !empty($mainsite_language['d']))?strtolower($mainsite_language['d']):'';
                  //If the client site language is not the same as main site language, then set to fall back, azull.be as main website for Dutch, azull.fr as main website for French and azull.eu as main website for English
                  if ($client_default_lang != $mainsite_default_lang) {
                    switch ($client_default_lang) {
                      case 'nl':
                        $canonical_ref_site = 50913;
                        break;
                      case 'fr':
                        $canonical_ref_site = 335455;
                        break;
                      case 'en':
                        $canonical_ref_site = 571562;
                        break;
                      
                      default:
                        $canonical_ref_site = '';
                        break;
                    }
                  } else {
                  //If the client site language is the same with main site language, use it
                    $canonical_ref_site = $main_site;
                  }
                }

                /*$access = get_post_meta($main_site, 'access', true);
                $main_site_url = $access['url'];*/
                $postArr = get_post($post_id);
                $post_type = get_post_type($post_id);
                if(isset($canonical_ref_site) && !empty($canonical_ref_site) && isset($remote_post['post_title']) && !empty($remote_post['post_title']) && isset($post_type) && !empty($post_type)){

                    $main_site_access = get_post_meta($canonical_ref_site, 'access', true);
                    $main_site_url = rtrim($main_site_access['url'],'/');

                    switch ($post_type) {
                        case 'property':
                            $main_site_slug = $this->client_slug($remote_post['post_title'],$post_id,$canonical_ref_site);
                            $canonical_reference = 'property/'.strtolower($main_site_slug);
                            //$canonical_reference = 'property/'.strtolower($remote_post['post_name']);
                        break;
                        case 'azulloffice':
                            //$canonical_reference = $main_site_url.'/property/'.$post_url;
                        break;
                        case 'infodays':
                            //$canonical_reference = $main_site_url.'/property/'.$post_url;
                        break;
                        case 'testimonial':
                            //$canonical_reference = $main_site_url.'/property/'.$post_url;
                        break;
                        case 'azulladds':
                            //$canonical_reference = $main_site_url.'/property/'.$post_url;
                        break;
                        case 'post':
                            $post_date = date('Y/m/d',strtotime($postArr->post_date));
                            $main_site_slug = $this->client_page_slug($remote_post['post_title'],$canonical_ref_site);
                            $canonical_reference = $post_date.'/'.strtolower($main_site_slug);
                            //$canonical_reference = $post_date.'/'.strtolower($remote_post['post_name']);
                        break;
                        case 'page':
                            $main_site_slug = $this->client_page_slug($remote_post['post_title'],$canonical_ref_site);
                            $canonical_reference = strtolower($main_site_slug);
                        break;
                    }
                }
            }
        } else {
          //5-3-2017 Johan: If main website is not set, you can consider azull.be as main website for Dutch, azull.fr as main website for French and azull.eu as main website for English. 
          //logic implemented by Tien
          //This case is for main website is NOT set (blank)
          $client_site = $this->siteid;                
          $client_language = get_post_meta((int) $client_site, 'language', true);
          $client_default_lang = (isset($client_language['d']) && !empty($client_language['d']))?strtolower($client_language['d']):'';
          //If the main website is not set, then set to fall back, azull.be as main website for Dutch, azull.fr as main website for French and azull.eu as main website for English
          switch ($client_default_lang) {
            case 'nl':
              $canonical_ref_site = 50913;
              break;
            case 'fr':
              $canonical_ref_site = 335455;
              break;
            case 'en':
              $canonical_ref_site = 571562;
              break;
            
            default:
              $canonical_ref_site = '';
              break;
          }

          $postArr = get_post($post_id);
          $post_type = get_post_type($post_id);
          if(isset($canonical_ref_site) && !empty($canonical_ref_site) && isset($remote_post['post_title']) && !empty($remote_post['post_title']) && isset($post_type) && !empty($post_type)){
            $main_site_access = get_post_meta($canonical_ref_site, 'access', true);
            $main_site_url = rtrim($main_site_access['url'],'/');

            switch ($post_type) {
              case 'property':
                  $main_site_slug = $this->client_slug($remote_post['post_title'],$post_id,$canonical_ref_site);
                  $canonical_reference = 'property/'.strtolower($main_site_slug);
                  //$canonical_reference = 'property/'.strtolower($remote_post['post_name']);
              break;
              case 'azulloffice':
                  //$canonical_reference = $main_site_url.'/property/'.$post_url;
              break;
              case 'infodays':
                  //$canonical_reference = $main_site_url.'/property/'.$post_url;
              break;
              case 'testimonial':
                  //$canonical_reference = $main_site_url.'/property/'.$post_url;
              break;
              case 'azulladds':
                  //$canonical_reference = $main_site_url.'/property/'.$post_url;
              break;
              case 'post':
                  $post_date = date('Y/m/d',strtotime($postArr->post_date));
                  $main_site_slug = $this->client_page_slug($remote_post['post_title'],$canonical_ref_site);
                  $canonical_reference = $post_date.'/'.strtolower($main_site_slug);
                  //$canonical_reference = $post_date.'/'.strtolower($remote_post['post_name']);
              break;
              case 'page':
                  $main_site_slug = $this->client_page_slug($remote_post['post_title'],$canonical_ref_site);
                  $canonical_reference = strtolower($main_site_slug);
              break;
            }
          }
        }

        if(isset($canonical_reference) && !empty($canonical_reference)){
            $main_website_cr_url = '';
            //$languages = qtranxf_getSortedLanguages();
            if(isset($language['a']) && !empty($language['a']) && is_array($language['a']) && count($language['a'])>0){
                foreach ($language['a'] as $key => $val) {
                    if(isset($val) && !empty($val)){
                        $main_website_cr_url[$val] = str_replace('http://','https://',$main_site_url.'/'.rtrim($canonical_reference,'-'));
                    }
                }
                $custom_fields['canonical_reference'] = $main_website_cr_url;
            }
        }else{
            $custom_fields['canonical_reference'] = '';
        }


        //print('<pre>');print_r($custom_fields);die('hmmmm');
        $this->query('azull.meta', $this->accesskey, $rpost_id, $custom_fields);
        /*print_r($this->get_response());
        exit;*/
        return;
    }

    private function assign_terms($post_id, $blog_id = 0) {
        $terms = array();
        global $wpdb;
        if (get_post_type($post_id) == 'post') {
            $property_taxonomy = array(
                'post_tag',
                'category'
            );
            foreach ($property_taxonomy as $key => $taxonomy_name) {
                $taxonomy_terms = wp_get_post_terms($post_id, $taxonomy_name, array("fields" => "all"));
                $term_ids = array();
                foreach ($taxonomy_terms as $term) {
                    if ($remote_id = $this->has_taxonomy($taxonomy_name, $term->slug))
                    $term_ids[] = $remote_id;
                }
                $terms[$taxonomy_name] = $term_ids;
            }
        }
        //nav_menu
        if (get_post_type($post_id) == 'property') {
            $property_taxonomy = array(
                'category',
                'locality',
                'status',
                'banner',
                'feature',
                'orientation',
                'view',
                'exterior',
                'interior',
                'agent',
                'proprietor',
                'country',
                'region',
                'provinces',
                'place',
                'walkscores',
                'dimensions'
            );
            $term_add = 0;
            foreach ($property_taxonomy as $key => $taxonomy_name) {
             //   $taxonomy_terms = wp_get_post_terms($post_id, $taxonomy_name, array("fields" => "all"));
                 $taxonomy_terms = $wpdb->get_results("SELECT t.*, tt.* FROM wp_terms AS t INNER JOIN wp_term_taxonomy AS tt ON tt.term_id = t.term_id INNER JOIN wp_term_relationships AS tr ON tr.term_taxonomy_id = tt.term_taxonomy_id WHERE tt.taxonomy IN ('$taxonomy_name') AND tr.object_id IN ($post_id) ORDER BY t.name ASC");
                $term_ids = array();
                foreach ($taxonomy_terms as $term) {
                        
                     if($remote_id = $this->has_taxonomy($taxonomy_name, $term->slug)){
                           $term_ids[] = $remote_id;
                     }else{//if terms not available on client's websites
                      
                    $taxonomy = $taxonomy_name;
                        $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
                        $this->set_taxonomy($taxonomy, $term->slug);
                        $remote_term_id = $this->has_taxonomy($taxonomy, $term->slug);
                    
                    if (get_option('z_taxonomy_image' . $term->term_id, true)) {
                            $attachment_id = $this->z_get_attachment_id_by_url(get_option('z_taxonomy_image' . $term->term_id, true));
                            if (!get_post_meta($attachment_id, '_remote_' . $this->siteid, true))
                                $this->add_attachment($attachment_id);
                            if (!$this->is_post_exists(get_post_meta($attachment_id, '_remote_' . $this->siteid, true))) {
                              $this->add_attachment($attachment_id);
                            }

                            if (get_post_meta($attachment_id, '_remote_' . $this->siteid, true)) {
                                $remote_attachment_id = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
                                $this->set_option('z_taxonomy_image' . $remote_term_id, $remote_attachment_id, 'taxonomyimg');
                            }
                    }
                    if (get_option('azull_taxonomy_meta_' . $term->term_id) && $remote_term_id) {
                            if ($taxonomy == 'country' ||$taxonomy == 'region' || $taxonomy == 'provinces' || $taxonomy == 'place') {
                                $option_locals = get_option('azull_taxonomy_meta_' . $term->term_id);
                                $option_remote = array();
                                foreach ($option_locals as $k => $v) {
                                    $options_term = get_term_by('id', (int) $v, $k);
                                    $options_term_id = $this->has_taxonomy($k, $options_term->slug);
                                    $option_remote[$k] = $options_term_id;
                                }

                                if (!empty($option_remote))
                                    $this->set_option('azull_taxonomy_meta_' . $remote_term_id, $option_remote, 'taxonomymeta');
                            }else {
                                $this->set_option('azull_taxonomy_meta_' . $remote_term_id, get_option('azull_taxonomy_meta_' . $term->term_id), 'taxonomymeta');
                            }
                     }
                    }//end else
                    /*if ($remote_id = $this->has_taxonomy($taxonomy_name, $term->slug))
                    $term_ids[] = $remote_id;*/
                }
                $terms[$taxonomy_name] = $term_ids;
            }
        }//end property 
        if(isset($term_add) && $term_add==1){
            //call and update taxonomy translation
            $qtrans_name = get_option('qtranslate_term_name');
            if (isset($qtrans_name) && !empty($qtrans_name)){
                $this->set_option('qtranslate_term_name', $qtrans_name, 'taxonomytranslation');
            }
            $azull_string = get_option('azullString');
            if (isset($azull_string) && !empty($azull_string)){
                $this->set_option('azullString', $azull_string, 'azullString');
            }
        }
        return $terms;
    }
    // get attachment ID by image url
public function z_get_attachment_id_by_url($image_src) {
    global $wpdb;
    $query = "SELECT ID FROM {$wpdb->posts} WHERE guid = '$image_src'";
    $id = $wpdb->get_var($query);
    return (!empty($id)) ? $id : NULL;
}

    public function test_connection() {
        // @TODO find a better suitable function
        $result = $this->query('wp.getPostTypes', '0', $this->username, $this->password);


        if (!$result) {
            $error_code = absint($this->get_error_code());

            switch ($error_code) {
                case 32301:
                    add_filter('redirect_post_location', create_function('$location', 'return add_query_arg("message", 305, $location);'));
                    break;
                case 401:
                    add_filter('redirect_post_location', create_function('$location', 'return add_query_arg("message", 302, $location);'));
                    break;
                case 403:
                    add_filter('redirect_post_location', create_function('$location', 'return add_query_arg("message", 303, $location);'));
                    break;
                case 405:
                    add_filter('redirect_post_location', create_function('$location', 'return add_query_arg("message", 304, $location);'));
                    break;
                default:
                    add_filter('redirect_post_location', create_function('$location', 'return add_query_arg("message", 306, $location);'));
                    break;
            }
            return false;
        }
        return true;
    }

    public function is_post_exists($ext_ID) {

        $result = $this->query('wp.getPost', '1', $this->username, $this->password, $ext_ID);
        if (!$result) {
            return false;
        }
        $post = $this->getResponse();
        if ($ext_ID != $post['post_id']) {
            return false;
        }
        return true;
    }

    public static function display_settings($args) {
        global $hits_count_arr;
        $site_ID = $args[0]->ID;
        $hits_count_arr = $args[1];

        $access = get_post_meta($site_ID, 'access', true);
        $general = get_post_meta($site_ID, 'general', true);
        $financial = get_post_meta($site_ID, 'financial', true);
        $lng = get_post_meta($site_ID, 'language', true);
        require_once( AZULL_DIR . 'template/site.php' );
    }

    /*
     * Update navigation menu on client side
     * Params : server menu id, menutype(Primary,Footer,Sidebar, etc...)
     */

    function xmlrpc_nav_menu($menu_id, $menue_type) {
        $menue_obj = wp_get_nav_menu_items($menu_id);
        $menue_name_obj = get_term_by('id', $menu_id, 'nav_menu');
        $menue_remote = array();
        $menue_parent = '';

        $sub_page_id_remote = 0;
        $page_id_remote = 0;
        foreach ($menue_obj as $menue) {
            if ($menue->menu_item_parent > 0) {
                foreach ($menue_obj as $menue_sub) {
                    if ($menue_sub->ID == $menue->menu_item_parent) {
                        $sub_page_id = get_post_meta($menue_sub->ID, '_menu_item_object_id', true);
                        $sub_page = get_page_by_path(get_the_title($sub_page_id));
                        $sub_page_id_remote = get_post_meta($sub_page_id, '_ext_' . $this->siteid, true);
                    }
                }
            }
            $page_id = get_post_meta($menue->ID, '_menu_item_object_id', true);
            $page = get_page_by_path(get_the_title($page_id));
            //print_r($page);
            $page_id_remote = get_post_meta($page_id, '_ext_' . $this->siteid, true);

            $menue_remote[] = array($page_id_remote, $menue->menu_order, $sub_page_id_remote);
            $page_id_remote = 0;
            $sub_page_id_remote = 0;
        }



        $result = $this->query('azull.nav', array($this->accesskey, $menue_name_obj->name, $menue_remote, $menue_type));
        return;
        //todo: err handling
    }

    /* @abstract: save server url and access value as an option on client webste.
     * @param $site_ID: client website id, it post id for azull_sites on server
     * @todo:handle returned data
     */

    public function set_key($site_ID, $blog_id = 0) {
        ini_set('max_execution_time', 0); //300 seconds = 5 minutes  
        $access = get_post_meta($site_ID, 'access', true);
        $this->query('azull.apikey', $this->username, $this->password, array('access_key' => esc_html($access['key']), 'access_url' => site_url()));
        //return; // comment on 01-03-2016 so taxonimies loop not run when any website update it is run only one time when any website created
        
        // 16-02-02016 for not showing properties
        //synchronize all post and property taxonomy and its translation
        if ($this->getResponse()) {
             //ini_set('max_execution_time', -1);
            //support only category,post_tag and property taxonomy only		
            $taxonomies = array(
                'post_tag',
                'nav_menu'
                /*'category',
                'type',
                'status',
                'banner',
                'feature',
                'orientation',
                'view',
                'locality',
                'exterior',
                'interior',
                'walkscores',
                'dimensions',*/
                /*'country',
                'region',
                'provinces',*/
                /*'agent',
                'post_tag',
                'nav_menu'*/
                //'proprietor',
                //'place',
            );

            foreach ($taxonomies as $taxonomy) {
                $remote_term_id = false;
                $terms = get_terms($taxonomy, array('hide_empty' => false));
                if (!empty($terms) && !is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
                        $this->set_taxonomy($taxonomy, $term->slug);
                        $remote_term_id = $this->has_taxonomy($taxonomy, $term->slug);
                        
                        if (get_option('z_taxonomy_image' . $term->term_id, true)) {

                            $attachment_id = z_get_attachment_id_by_url(get_option('z_taxonomy_image' . $term->term_id, true));
                            if (!get_post_meta($attachment_id, '_remote_' . $this->siteid, true))
                                $this->add_attachment($attachment_id);
                            if (!$this->is_post_exists(get_post_meta($attachment_id, '_remote_' . $this->siteid, true))) {
                              $this->add_attachment($attachment_id);
                            }

                            if (get_post_meta($attachment_id, '_remote_' . $this->siteid, true)) {
                                $remote_attachment_id = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);
                                $this->set_option('z_taxonomy_image' . $remote_term_id, $remote_attachment_id, 'taxonomyimg');
                            }
                        }
                        if (get_option('azull_taxonomy_meta_' . $term->term_id) && $remote_term_id) {

                            if ($taxonomy == 'country' ||$taxonomy == 'region' || $taxonomy == 'provinces' || $taxonomy == 'place') {
                                $option_locals = get_option('azull_taxonomy_meta_' . $term->term_id);
                                $option_remote = array();
                                foreach ($option_locals as $k => $v) {
                                    $options_term = get_term_by('id', (int) $v, $k);
                                    $options_term_id = $this->has_taxonomy($k, $options_term->slug);
                                    $option_remote[$k] = $options_term_id;
                                }

                                if (!empty($option_remote))
                                    $this->set_option('azull_taxonomy_meta_' . $remote_term_id, $option_remote, 'taxonomymeta');
                            }else {
                                $this->set_option('azull_taxonomy_meta_' . $remote_term_id, get_option('azull_taxonomy_meta_' . $term->term_id), 'taxonomymeta');
                            }
                        }
                    }
                }
                $remote_term_id = false;
            }

            //call and update taxonomy translation
        //    if (get_option('qtranslate_term_name'))
          //      $this->set_option('qtranslate_term_name', get_option('qtranslate_term_name'), 'taxonomytranslation');
        }

        $this->set_option('_site_id', $site_ID, 'siteoptions');
        //TODO:save, logo,site title,site tagline etc....
    }

    function set_option($key, $val, $action) {
        $this->query('azull.option', $this->accesskey, $key, $val, $action);
      
    }

    /* @abstract: saves server url and access value as an option on client webste. the function is defined azull.settings in azull client.
     * @param $site_ID: client website id, it post id for azull_sites on server
     * @todo:handle returned data
     */

    public function save_settings($site_ID) {
        if (!$this->test_connection())
            return;

        $access = get_post_meta($site_ID, 'access', true);
        $result = $this->query('azull.settings', $this->username, $this->password, array('access_key' => esc_html($access['key']), 'access_url' => site_url()));
        return $result;
    }

    /* @abstract: handle all the media associated with post,page and property, so we  can have all the media loaded simultaneously on client while uploading and store corresponding attachement id, we just need to to deal with attachement id on clients
     * @param:$post_id
     * @param:$attachement_id
     * @return: arry of metadata for remote meida
     */

    function remote_media($post_id, $attachement_id, $blog_id = 0) {

        // remote post id...
        $to_post_id = get_post_meta($post_id, '_ext_' . $this->siteid, true);

        //get all local attached media........
        $medias = $this->get_attached_medias($post_id, 'image');
        $remote_images = array();
        if ($medias) { //print_r( $medias );
            // create remote links of medias images
            foreach ($medias as $oneimage) {
                $remote_images[] = array(
                    'link' => $oneimage['link'],
                    'file' => $oneimage['metadata']['file'],
                    'thumbnail' => array('link' => $oneimage['thumbnail'],
                        'file' => $oneimage['metadata']['sizes']['thumbnail']['file']),
                    'medium' => array('file' => $oneimage['metadata']['sizes']['medium']['file']),
                    'post-thumbnail' => array('file' => $oneimage['metadata']['sizes']['post-thumbnail']['file'])
                );
            }
            // synchronize 
            $search = array(); //local remaining link
            $replace = array();
            foreach ($guids as $one_id => $one_attachment) {

                foreach ($remote_images as $oneimage) {
                    if ($one_attachment['remote'] == $oneimage['link']) { //error_log ( '----> '.$oneimage['link'] );
                        $remote_folder = str_replace($oneimage['thumbnail']['file'], "", $oneimage['thumbnail']['link']);

                        $replace[] = $remote_folder . $oneimage['medium']['file']; //error_log ( '---med replace-> '.$remote_folder.$oneimage['medium']['file'] );
                        $src_m = wp_get_attachment_image_src($one_id, 'medium');
                        $search[] = $src_m[0]; // error_log ( '---med search-> '.$src_m[0] );
                        $replace[] = $oneimage['thumbnail']['link'];
                        $src = wp_get_attachment_image_src($one_id, 'thumbnail');
                        $search[] = $src[0];
                    }
                }
            }
            if ($replace) {
                // error_log ( '- array replace -');
                $remote_id = $this->edit_post_to($post_id, $guids, array('search' => $search, 'replace' => $replace));
            }
        }
    }

    /* @abstract:create a remote attachment
     * @param:$post id
     * $params:$ext_ID, equivalent post id on remote client
     * @use: metaWeblog.newMediaObject
     */

    function send_attachments($post_id) {

        $args = array(
            'post_type' => 'attachment',
            'numberposts' => -1,
            'post_status' => 'any',
            'post_parent' => $post_id,
            'exclude' => get_post_thumbnail_id($post_id)
        );
        $attachments = get_posts($args);


        if ($attachments != array()) {

            $to_post_id = get_post_meta($post_id, '_ext_' . $this->siteid, true);

            // 
            $guids = array();
            foreach ($attachments as $attachment_id => $attachment) {
                $params = array(
                    0,
                    $this->username,
                    $this->password,
                    array(
                        'name' => basename(get_attached_file($attachment_id)), //$attachment->post_title,
                        'type' => $attachment->post_mime_type,
                        'bits' => new IXR_Base64(file_get_contents(get_attached_file($attachment_id)))  // get_attached_file( $attachment_id)
                    )
                );


                $status = $this->query('metaWeblog.newMediaObject', $params);

                if (!$status) {
                    error_log('Error [' . $this->getErrorCode() . ']: ' . $this->getErrorMessage());
                }
                if ($status) {
                    $request = $this->getResponse(); //error_log( print_r( $request ) );
                    $guids[$attachment_id] = array('local' => $attachment->guid, 'remote' => $request['url']);
                    error_log($request['url']);
                }
            }

            return $guids;
        }

        return array();
    }

    /* @abstract: get attached medias from remote client.
     * @param:$post id
     * @params:$ext_ID, equivalent post id on remote client
     * @params:$mime_type 
     */

    function get_attached_medias($post_ID = 0, $mime_type = '') {

        $remote_post_id = get_post_meta($post_id, '_ext_' . $this->siteid, true);
        // get recent
        $params = array(0, $this->username, $this->password, array('mime_type' => $mime_type, 'parent_id' => $remote_post_id));

        $status = $this->query('wp.getMediaLibrary', $params);
        if ($status) {
            $requestattach = $this->getResponse();
            return $requestattach;
            error_log($requestattach[0]['link']);
        }
        if (!$status) {
            error_log('Error [' . $this->getErrorCode() . ']: ' . $this->getErrorMessage());
        }
        return array();
    }

    /* @abstract: add new taxonomy term on client */

    function add_taxonomy($taxonomy, $slug, $name) {
        $status = false;
        //get taxonom details from local
        $taxonomybyslug = get_term_by('slug', $slug, $taxonomy);
        $parent = $this->has_parent($taxonomy, $slug);

        if ($slug == '')
            $slug = str_replace(" ", "-", $name);

        if ($slug == '')
            return false;


        if (!$parent)
            $status = $this->query('wp.newTerm', 0, $this->username, $this->password, array("name" => (($name == '') ? $taxonomybyslug->name : $name), "taxonomy" => $taxonomy, "slug" => $slug));

        //taxonomy has parent
        if ($parent && is_numeric($parent))
            $status = $this->query('wp.newTerm', 0, $this->username, $this->password, array("name" => (($name == '') ? $taxonomybyslug->name : $name), "taxonomy" => $taxonomy, "slug" => $slug, "parent" => $parent));


        if ($status) {
            return $this->get_response();
        } else {
            return false;
        }
    }

    /* @abstract: update existing taxonomy or add if does not exist */

    function set_taxonomy($taxonomy, $slug) {

        $status = false;
        $parent = false;
        $taxonomybyslug = get_term_by('slug', $slug, $taxonomy);
        $hastaxonomy = $this->has_taxonomy($taxonomy, $slug);

        //check and get the parent Id for client website.
        $parent = $this->has_parent($taxonomy, $slug);

        if (!$hastaxonomy)
            $status = $this->add_taxonomy($taxonomy, $slug, '');

        if ($hastaxonomy && !$parent)
            $status = $this->query('wp.editTerm', 0, $this->username, $this->password, $hastaxonomy, array("name" => $taxonomybyslug->name, "taxonomy" => $taxonomy, "slug" => $slug));


        if ($hastaxonomy && $parent) {
            $status = $this->query('wp.editTerm', 0, $this->username, $this->password, $hastaxonomy, array("name" => $taxonomybyslug->name, "taxonomy" => $taxonomy, "slug" => $slug, "parent" => $parent));
        }

        if ($status) {
            return $status;
        } else {
            return false;
        }
    }

    /* @abstract: delete existing taxonomy  and returned the deleted id to unset translation and taxonomy image */

    function delete_taxonomy($taxonomy, $slug) {

        $hastaxonomy = $this->has_taxonomy($taxonomy, $slug);

        if ($hastaxonomy && is_numeric($hastaxonomy))
            $status = $this->query('wp.deleteTerm ', 0, $this->username, $this->password, $taxonomy, $hastaxonomy);

        if ($status) {
            return $this->get_response();
        } else {
            return false;
        }
    }

    /* @abstract: set/unset option value on client website need for taxonomy translation,taxonomy image, and language on all clients
     * @param:$key, option key on client
     * @param:$val, option value
     * @param:$action: the task to perforeme...
     */

    function manage_client_option($key, $val, $action) {
        $result = $this->query('azull.option', array($this->accesskey, $key, $val, $action));
        return;
    }

    /* @abstract: check if client website has taxonomy
     * @param:$taxonomy
     * @param:$slug
     * @return: client taxonomy id if it exists otherwise false
     */

    function has_taxonomy($taxonomy, $slug) {
        $status = $this->query('wp.getTerms', '1', $this->username, $this->password, $taxonomy);
        if ($status) {
            $request = $this->getResponse();
            $remotecatsslug = array();
            foreach ($request as $remotecategory) {
                if ($remotecategory ['slug'] === $slug && is_numeric($remotecategory ['term_id']))
                    return $remotecategory['term_id'];
            }
        }
        return false;
    }

    /* @abstract: check if taxonomy beeing added has parent
     * @param:$taxonomy
     * @param:$slug
     * @return: client taxonomy parent id if it exists otherwise false
     */

    function has_parent($taxonomy, $slug) {
        //get taxonom details from local
        $taxonomybyslug = get_term_by('slug', $slug, $taxonomy);
        if (!isset($taxonomybyslug))
            return false;

        if (isset($taxonomybyslug) && $taxonomybyslug->parent == 0)
            return false;

        $taxonomybyid = get_term_by('id', $taxonomybyslug->parent, $taxonomy);
        $this->query('wp.getTerms', '1', $this->username, $this->password, $taxonomy, array('search' => $taxonomybyid->slug));

        if ($this->getResponse()) {
            foreach ($this->getResponse() as $val) {
                if ($val['slug'] == $taxonomybyid->slug)
                    return $val['term_id'];
            }
        }

        return false;
    }

    function add_attachment($attachment_id) {

        error_reporting(0);

        $type = get_post_mime_type($attachment_id);

        if (!$type)
            return;

        $url =   get_attached_file($attachment_id);
     
        $url = str_replace("/wp-required/","/",$url);

        $params = array(
            0,
            $this->username,
            $this->password,
            array(
                'name' => basename(get_attached_file($attachment_id)), //$attachment->post_title,
                'type' => $type,
                'bits' => new IXR_Base64(file_get_contents( $url)) 
            )
        );

        $status = $this->query('metaWeblog.newMediaObject', $params);

        if ($status) {
            $remote_attachement = $this->get_response();
               
            update_post_meta($attachment_id, '_remote_' . $this->siteid, $remote_attachement['id']);
            return $status;
        } else {
            return false;
        }
    }

    function delete_attachment($attachment_id) {

        $attachement_remote = get_post_meta($attachment_id, '_remote_' . $this->siteid, true);

        $status = $this->query('azull.deleteFiles', 0, $this->username, $this->password, $attachement_remote); //delete existing fetured image on client website.

        if ($status) {

            return $status;
        } else {
            return false;
        }
    }

    /* @abstract: get all info_request from client
     * @param:$key, option key on client
     * @param:$val    
     */

    function get_client_infoRequest($type) {
        $result = $this->query('azull.infoget', array($this->accesskey, $type));
        if ($result)
            return json_decode($this->get_response());
        return false;
    }

    /* @abstract: get all info_request from client
     * @param:$key, option key on client
     * @param:$val    
     */

    function save_client_infoRequest($key) {

        $result = $this->query('azull.infosave', $this->username, $this->password, $key);

        if ($result)
            return $this->get_response();

        return false;
    }

    /* @abstract: get all search criteria
     * @param:remote user id       
     */

    function xmlrpc_searchCriteria($remote_user_id) {
        $result = $this->query('azull.criteria', array($this->accesskey, $remote_user_id));
        /// print_r($this->get_response());
        if ($result)
            return $this->get_response();

        return false;
    }

    /* @abstract: get various hits counts from remote client (Meghaaa).
     * @param:$post id
     * @params:$ext_ID, equivalent post id on remote client
     * @params:$mime_type 
     */

    Public function get_client_hits_counter() {

        $result = $this->query('azull.clienthits', array($this->accesskey));
        if ($result)

        // echo '<pre>'; print_r($this->get_response()); echo '</pre>'; 	
            return $this->get_response();
    }

    public function get_response() {
        return parent::getResponse();
    }

    public function get_error_code() {
        return parent::getErrorCode();
    }

    public function get_error_message() {
        return parent::getErrorMessage();
    }

//    private function azull_use($text) {
//        $text_new = '';
//        $language = get_post_meta((int) $this->siteid, 'language', true);
//        $text_array = qtranxf_split($text);
//
//        foreach ($language['a'] as $active_lng) {
//
//            if ($text_new != '')
//                $text_new .= '[:' . $active_lng . ']' . $text_array[$active_lng];
//
//            if ($text_new === '')
//                $text_new = '[:' . $active_lng . ']' . $text_array[$active_lng];
//        }
//
//        return $text_new . "[:]";
//    }


    private function azull_use($text) {
        $text_new = '';
        $language = get_post_meta((int) $this->siteid, 'language', true);
        $text_array = qtranxf_split($text);

        foreach ($language['a'] as $active_lng) {

            if ($text_new != '')
                $text_new .= '<!--:' . $active_lng . '-->' . $text_array[$active_lng] . '<!--:-->';

            if ($text_new === '')
                $text_new = '<!--:' . $active_lng . '-->' . $text_array[$active_lng] . '<!--:-->';
        }

        return $text_new;
    }

    private function client_slug($title,$post_id,$clientId = 0) {
        $client_site_id = (isset($clientId) && $clientId!=0)?$clientId:$this->siteid;
        $language = get_post_meta((int) $client_site_id, 'language', true);
        $default_lang = (isset($language['d']) && !empty($language['d']))?$language['d']:'nl';
        if(isset($post_id) && !empty($post_id) && $post_id!=0){
            $slug_txt_arr = array(
                'en'=>'for-sale',
                'fr'=>'a-vendre',
                'nl'=>'te-koop'
            );
            $option_lang = get_option('qtranslate_term_name');
            $category = wp_get_post_terms($post_id,'category');
            $post_category = (isset($option_lang[$category[0]->name][$default_lang]))?$option_lang[$category[0]->name][$default_lang]:$category[0]->name;
            $post_meta = get_post_meta($post_id);
            $ref = $post_meta['_nreal_id'][0];
            $cntry_term = $this->get_termsname_custom($post_meta['_country'][0]);
            $post_country = (isset($option_lang[$cntry_term][$default_lang]))?$option_lang[$cntry_term][$default_lang]:$cntry_term;
            $region_term =$this->get_termsname_custom($post_meta['_region'][0]);  
            $post_region = (isset($option_lang[$region_term][$default_lang]))?$option_lang[$region_term][$default_lang]:$region_term;
            $place_term = $this->get_termsname_custom($post_meta['_place'][0]); 
            $post_place = (isset($option_lang[$place_term][$default_lang]))?$option_lang[$place_term][$default_lang]:$place_term;
            $p_post_name = $ref.'-'.$post_category.'-'.$slug_txt_arr[strtolower($default_lang)].'-'.$post_place.'-'.$post_region.'-'.$post_country;
            //$p_post_name = $ref.'-'.$post_category.'-te-koop-'.$post_place.'-'.$post_region.'-'.$post_country;
            $p_post_name = str_replace(' ', '-', $p_post_name);
            $slug = str_replace('--', '-',str_replace(',', '', str_replace('.', '', $p_post_name)));
        }else{        
            $text_array = qtranxf_split($title);
            $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $text_array[$default_lang]);
        }
        return $slug;
    }
    private function client_page_slug($title,$clientId = 0) {
        $client_site_id = (isset($clientId) && $clientId!=0)?$clientId:$this->siteid;
        $language = get_post_meta((int) $client_site_id, 'language', true);
        $default_lang = (isset($language['d']) && !empty($language['d']))?$language['d']:'nl';
        $text_array = qtranxf_split($title);
        $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $text_array[$default_lang]);
        return $slug;
    }
    /*private function client_slug($title) {
        $language = get_post_meta((int) $this->siteid, 'language', true);
        $text_array = qtranxf_split($title);
        $slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $text_array[$language['d']]);
        return $slug;
    }*/
    
     /* Get the server ninja forms tables detail and call the client 
    * XMLRPC function
    */
   public function add_ninja_forms() {
      global $wpdb;
      $table_nf_objects = $wpdb->prefix . 'nf_objects';
      $table_nf_objectmeta = $wpdb->prefix . 'nf_objectmeta';
      $table_ninja_forms_fields = $wpdb->prefix . 'ninja_forms_fields';
      $server_nf_data['nf_objects'] = $wpdb->get_results("SELECT * FROM $table_nf_objects WHERE id=$_POST[form_id]");
      $server_nf_data['nf_objectmeta'] = $wpdb->get_results("SELECT * FROM $table_nf_objectmeta WHERE object_id=$_POST[form_id]");
      $server_nf_data['ninja_forms_fields'] = $wpdb->get_results("SELECT * FROM $table_ninja_forms_fields WHERE form_id=$_POST[form_id]");
      
      $server_nf_data['transient_nf_form'] = get_option('_transient_nf_form_'.$_POST['form_id']);
      $server_nf_data['transient_timeout_nf_form'] = get_option('_transient_timeout_nf_form_'.$_POST['form_id']);
      $server_nf_data['form_id'] = $_POST['form_id'];
      
      $result = $this->query('azull.ninjaformssave', array($this->accesskey,$server_nf_data));
      
      if ($result)
         return $this->get_response();

      return;
   }
   
   /*  Get the server ninja forms nf_objectmeta table detail and call the client XMLRPC function
    */
   public function update_ninja_forms_settings() {
      global $wpdb;
      $table_nf_objectmeta = $wpdb->prefix . 'nf_objectmeta';
      $nf_forms_settings['nf_objectmeta'] = $wpdb->get_results("SELECT * FROM $table_nf_objectmeta WHERE object_id=$_POST[_form_id]");
      $nf_forms_settings['form_id'] = $_POST['_form_id'];
      $result = $this->query('azull.ninjaformssettings', array($this->accesskey,$nf_forms_settings));
      if ($result)
         return $this->get_response();

      return;
   }
/*
* Date : 31-03-2016
* Method : Function for delete form from client website
*/
public function delete_ninja_forms() {
      $server_nf_data['form_id'] = $_POST['form_id'];
      $result = $this->query('azull.ninjaformsdelete', array($this->accesskey,$server_nf_data));
      //print_r($this->get_response());die('ookk');
      if ($result)
         return $this->get_response();

      return;
   }
/**************
Date: 25-apr-2016
method: customisation function because asynacronous was not working
**/
public function get_terms_custom($texonomy) {
      global $wpdb;
       $record = $wpdb->get_results("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_term_taxonomy.taxonomy = '$texonomy'");
       if(!empty($record)) return $record;
       return ;
   }

   public function get_termsname_custom($termId) {
      global $wpdb;
       $record = $wpdb->get_results("SELECT name FROM wp_terms where term_id ='".$termId."'",ARRAY_A);
       if(!empty($record[0]['name'])) return $record[0]['name'];
       return ;
   }

     public function get_termsname_slug($termId) {
      global $wpdb;
       $record = $wpdb->get_results("SELECT slug FROM wp_terms where term_id ='".$termId."'",ARRAY_A);
       if(!empty($record[0]['slug'])) return $record[0]['slug'];
       return ;
   }

public function findLatLong($address ='spain'){
    $url = "http://maps.google.com/maps/api/geocode/json?address=".$address."&sensor=false";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    $response = curl_exec($ch);
    curl_close($ch);
    $response = json_decode($response);
    $array['lat'] = $response->results[0]->geometry->location->lat;
    $array['long'] = $response->results[0]->geometry->location->lng;
    return $array;
}


 public function get_custom_term_by_id($term_id,$taxonomy) {
      global $wpdb;
      //echo "SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_terms.slug = '$taxonomy_slug' AND wp_term_taxonomy.taxonomy = '$taxonomy'";die;
       $record = $wpdb->get_row("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_terms.term_id = '$term_id' AND wp_term_taxonomy.taxonomy = '$taxonomy'");
       if(!empty($record)){
        return $record;
       }
   }


  public function updateLatLong($post_id){
        if(isset($post_id) && !empty($post_id) && $post_id!=0){
            $lat = get_post_meta($post_id, '_lat', true);
            $lng = get_post_meta($post_id, '_lng', true);
            if ((!$lat || !$lng)) {
                $country = $this->get_custom_term_by_id(get_post_meta($post_id, '_country', true), 'country', false);
                $place = $this->get_custom_term_by_id(get_post_meta($post_id, '_place', true), 'place', false);
                $regions = $this->get_custom_term_by_id(get_post_meta($post_id, '_region', true), 'region', false);
                $provinces = $this->get_custom_term_by_id(get_post_meta($post_id, '_province', true), 'provinces', false);
                $address = "";
                if (!is_wp_error($place)) {
                    $address = ($place->name) ? $place->name . "," : '';
                }
                if (!is_wp_error($provinces)) {
                    $address .= ($provinces->name) ? $provinces->name . ',' : '';
                }
                /*if (!is_wp_error($regions)) {
                    $address .= ($regions->name) ? $regions->name . ',' : '';
                }*/

                if (!is_wp_error($country)) {
                    $address .= ($country->name) ? $country->name : '';
                }
                $address = str_replace(" ", '+', $address);
                
                if ($country && $place) {
                    $geocode = file_get_contents('http://maps.google.com/maps/api/geocode/json?address=' . $address . '&sensor=false');
                    $output = json_decode($geocode);
                    if (isset($output->results) && !empty($output->results)) {
                        $lat = $output->results[0]->geometry->location->lat;
                        $lng = $output->results[0]->geometry->location->lng;
                    }
                }
                //to do update lat lng to reduce map api request...
                if (isset($lat) && $lat != '')
                    update_post_meta($post_id, '_lat', $lat);
                if (isset($lng) && $lng != '')
                    update_post_meta($post_id, '_lng', $lng);
            }
        }
    }
    
    public function addPageToClient() {
      
      $result = $this->query('azull.pages', array($this->accesskey,$server_nf_data));
      if ($result){
         return $this->get_response();
      }
      return;
 }

/*public function delete_unused_post_attachment($post_id = false) {
    global $wpdb;
    if (isset($post_id) && !empty($post_id)) {
        $values = get_post_custom($post_id);
        if (isset($values['property_gallery']))
           $ids = json_decode(base64_decode($values['property_gallery'][0]));
        else
           $ids = array();
        $f_img = get_post_thumbnail_id($post_id);
        $ids[] = $f_img;
        //print('<pre>');print_r($f_img);
        //print('<pre>');print_r($ids);
        //$sql = "SELECT * FROM wp_posts where post_type='attachment' AND post_parent= $post_id";
        //$attachment_data = $wpdb->get_results($sql, ARRAY_A);
        if(isset($ids) && !empty($ids)){
            $attachment_data = get_posts(array('post_type' => 'attachment', 'posts_per_page' => -1, 'post_parent' => $post_id, 'exclude' => get_post_thumbnail_id($post_id)));
            //print('<pre>');print_r($attachment_data);die;
            if(isset($attachment_data) && !empty($attachment_data)){
              $i=1;
               foreach ($attachment_data as $key => $val) {
                  if(!in_array($val->ID, $ids) && $val->post_type=='attachment'){
                     $attachment_path = get_post_meta($val->ID, '_wp_attached_file');
                     wp_delete_attachment($val->ID);
                     //echo $i.' ==> '.$val->ID.'<br>';
                     $i++;
                  }else{
                    //echo '<br>Helo';
                    //echo $i.' ==> '.$val->ID.'<br>';
                  }
                  
                }
              }
        }
        //die('hio');
    return true;
    }
    //die('hi');
    return false;
}*/

public function delete_unused_attachment($post_id = false) {
    if (isset($post_id) && !empty($post_id)) {
        wp_delete_attachment($post_id);
    }
}





}


