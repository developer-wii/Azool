<?php
class Azull_Meta{
    static function post_meta(){
	global $post,$wpdb;
	$val=array();		  
	$val=get_post_meta($post->ID,"_client",true);
	      
	$fetured = get_post_meta($post->ID,'_featured',true);	   
	$_page =get_post_meta($post->ID,'_page',true);	    
	$layout =get_post_meta($post->ID,'_layout',true);
	$_type = get_post_meta($post->ID,'_type',true);
	
	$postOrder = get_post( $post->ID ); 
    $postOrder->menu_order;
    $order = (isset($postOrder->menu_order) && $postOrder->menu_order!='')? $postOrder->menu_order:''; 
	    
	$datas = $wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");		
		
	    $html .= "<table class='form-table property_general'>";
		if(get_post_type( $post )=='post' || get_post_type( $post )=='page')	{
	    	$html .= get_main_sites_list();
		}
		  $html .= "<th  valign='top' scope='row'><label>".__('Client visibility:','azull')."</label></th>";
		  $html .= "<td>";
		  
          $html .= '<select style="min-height: 26px; width: 180px" class="SlectBox" name="client[]" multiple>';
		  $html .= '<option value="" disabled selected>'.__('Select site','azull').'</option>';
		 
		  foreach ($datas as $data){	
	  		$sitename = explode(']', $data->post_title);
	  		$sitename = explode('[', $sitename[1]);       
	  		$sitename =  $sitename[0];
		 	$html .= "<option value='".$data->ID."' ".(( is_array($val) && in_array($data->ID,$val)) ? 'selected' : '').">".qtranxf_use(qtranxf_getLanguage(), $data->post_title)."</option>";
		  }

		  $html .= "</select><br>";
		  $html .= "<span class='description'>".__('Select one or more clients website.','azull')."</span>";
		  $html .= "</td>";
		  $html .='</tr>';
            
	    if( get_post_type( $post )=='post')	{	  
	    $html .=self::category_generate();
	    
	    $html .= "<tr class='form-field'>";
            $html .= "<th  valign='top' scope='row'><label>".__('Type','azull').":</label></th>";
	    $html .= "<td>";
		  $html .= '<select style="float: left;min-height: 26px;width: 100%;" class="SlectBox" name="featured">';
		  $html .= '<option value="0" selected >--</option>';
		  $html .= '<option value="1" '.((isset($fetured) && $fetured==1) ?"selected":"").'>Slide</option>';
		  $html .= '<option value="2" '.((isset($fetured) && $fetured==2) ?"selected":"").'>Aside carousel</option>';
                  $html .= '</select><br>';
		  $html .= "<span class='description'>".__('Select post featured type.','azull')."</span>";
	    $html .= "</td>";
            $html .= "</tr>";	    

	    
	    }
            if(get_post_type( $post )=='page'){
		 
	    $html .= "<tr class='form-field'>";
            $html .= "<th  valign='top' scope='row'><label>".__('Parent','azull').":</label></th>";
	    $html .= "<td>";	    
		  $html .='<select id="parent_id" name="parent_id" class="SlectBox" >';
		  $html .= '<option value="">(no parent)</option>'; 
		
		   $pages = get_pages(); 
		   foreach ( $pages as $page ) {
			 $html .= '<option value="' .  $page->ID . '" '.((wp_get_post_parent_id( $post->ID ) && wp_get_post_parent_id( $post->ID )==$page->ID) ?"selected":"").'>';
			 $html .=  $page->post_title;
			 $html .= '</option>';
			 
		}		  
		 $html .='</select>';
	    $html .= "</td>";
            $html .= "</tr>";
	    
	    $html .= "<tr class='form-field'>";
            $html .= "<th  valign='top' scope='row'><label>".__('Order','azull').":</label></th>";
	    $html .= "<td>";
	    $html .= '<input id="menu_order" type="text" value="'.((isset($post->menu_order) && $post->menu_order!='')?$post->menu_order:0).'" size="4" name="menu_order">';
	    $html .= "</td>";
            $html .= "</tr>";
		  
	    $html .= "<tr class='form-field'>";
            $html .= "<th  valign='top' scope='row'><label>".__('Type','azull').":</label></th>";
	    $html .= "<td>";
	   
		  $html .= '<select onchange="return getpageType(this.value)"style="float: left;min-height: 26px;width: 100%;" class="SlectBox" name="page">';
		  $html .= '<option value="0" selected>--</option>';
		 

		  $html .= '<option value="3" '.((isset($_page) && $_page==3) ?"selected":"").'>'.__('Aside','azull').'</option>';		 
		  $html .= '<option value="5" '.((isset($_page) && $_page==5) ?"selected":"").'>'.__('Blog','azull').'</option>';
          $html .= '<option value="1" '.((isset($_page) && $_page==1) ?"selected":"").'>'.__('Featured block','azull').'</option>';
		  $html .= '<option value="2" '.((isset($_page) && $_page==2) ?"selected":"").'>'.__('Featured','azull').'</option>';
          $html .= '<option value="12" '.((isset($_page) && $_page==12) ?"selected":"").'>'.__('Form Page','azull').'</option>'; 
          $html .= '<option value="10" '.((isset($_page) && $_page==10) ?"selected":"").'>'.__('Front page','azull').'</option>';
		  $html .= '<option value="7" '.((isset($_page) && $_page==7) ?"selected":"").'>'.__('Info days','azull').'</option>'; 
          $html .= '<option value="4" '.((isset($_page) && $_page==4) ?"selected":"").'>'.__('Property','azull').'</option>';    
          $html .= '<option value="9" '.((isset($_page) && $_page==9) ?"selected":"").'>'.__('Quick message','azull').'</option>';   
          $html .= '<option value="8" '.((isset($_page) && $_page==8) ?"selected":"").'>'.__('Request info','azull').'</option>';
		  $html .= '<option value="11" '.((isset($_page) && $_page==11) ?"selected":"").'>'.__('Slide(Home slider)','azull').'</option>';
		  $html .= '<option value="6" '.((isset($_page) && $_page==6) ?"selected":"").'>'.__('Testimonial','azull').'</option>';
		  $html .= '<option value="13" '.((isset($_page) && $_page==13) ?"selected":"").'>'.__('Video','azull').'</option>';
		  $html .= '</select><br>';
		  $html .= "<span class='description'>".__('Select page type','azull').".</span>";
	    $html .= "</td>";
            $html .= "</tr>";
		  
			
	    }
            if(get_post_type( $post )=='azulloffice'){
                $html .= "<tr class='form-field'>";
                $html .= "<th  valign='top' scope='row'><label>".__('Latitude','azull').":</label></th>";
                $html .= "<td>";
                $lat =get_post_meta($post->ID,'_lat',true);
                $lng =get_post_meta($post->ID,'_lng',true);
                $html .= '<input id="menu_order" type="text" value="'.((isset($lat) && $lat!='')? $lat:'').'" size="12" name="_lat"><br/>';
                $html .= "<span class='description'>".__('Enter latitude for office','azull').".</span>";
                $html .= "</td>";
                
                $html .= "</tr>";
                
                $html .= "<tr class='form-field'>";
                $html .= "<th  valign='top' scope='row'><label>".__('Longitude','azull').":</label></th>";
                $html .= "<td>";
                $html .= '<input id="menu_order" type="text" value="'.((isset($lng) && $lng!='' ) ? $lng:'').'" size="12" name="_lng"><br/>';
                $html .= "<span class='description'>".__('Enter longitude for office','azull').".</span>";
                $html .= "</td>";
	   
	    
            $html .= "</tr>";
            }

            if(get_post_type( $post )=='infodays' || get_post_type( $post )=='azulloffice'){

               	$html .= "<tr class='form-field'>";
                $html .= "<th  valign='top' scope='row'><label>".__('Order','azull').":<label></th>";
                $html .= "<td>";
                $html .="<input type='text' name='menu_order' value=".$order.">";                      
                $html .= "</td>";
                $html .= "</tr>";
            } 

            if(get_post_type( $post )=='azulladds'){
                $html .= "<tr class='form-field'>";
                $html .= "<th  valign='top' scope='row'><label>".__('Add type','azull').":<label></th>";
                $html .= "<td>";
                      $html .= '<select style="float: left;min-height: 26px;width: 100%;" class="SlectBox" name="type">';
                      $html .= '<option value="0"  disabled selected>--</option>';
                      $html .= '<option value="1" '.((isset($_type) &&  $_type==1) ?"selected":"").'>'.__('Banner top','azull').'</option>';
                      $html .= '<option value="2" '.((isset($_type) &&  $_type==2) ?"selected":"").'>'.__('Banner bottom','azull').'</option>';
                      $html .= '<option value="3" '.((isset($_type) && $_type==3) ?"selected":"").'>'.__('Aside top','azull').'</option>';
                      $html .= '<option value="4" '.((isset($_type) &&  $_type==4) ?"selected":"").'>'.__('Aside bottom','azull').'</option>';
                      $html .= '<option value="5" '.((isset($_type) &&  $_type==5) ?"selected":"").'>'.__('Aside page','azull').'</option>';
                      $html .= '<option value="6" '.((isset($_type) &&  $_type==6) ?"selected":"").'>'.__('Page top','azull').'</option>';
                      $html .= '<option value="7" '.((isset($_type) &&  $_type==7) ?"selected":"").'>'.__('Page bottom','azull').'</option>';                      
                $html .= "</td>";
                $html .= "</tr>";
                
            }  
	    $html .= "<tr class='form-field'>";
            $html .= "<th  valign='top' scope='row'><label>".__('Layout','azull').":<label></th>";
	    $html .= "<td>";
		  $html .= '<select style="float: left;min-height: 26px;width: 100%;" class="SlectBox" name="layout">';
		  $html .= '<option value="0"  disabled selected>--</option>';
		  $html .= '<option value="1" '.((isset($layout) && $layout==1) ?"selected":"").'>'.__('Overlay','azull').'</option>';
		  $html .= '<option value="2" '.((isset($layout) &&  $layout==2) ?"selected":"").'>'.__('Left aligned','azull').'</option>';
		  $html .= '<option value="3" '.((isset($layout) &&  $layout==3) ?"selected":"").'>'.__('Right aligned','azull').'</option>';
		  if(get_post_type( $post )=='page')
		  $html .= '<option value="4" '.((isset($layout) && $layout==4) ?"selected":"").'>'.__('Home Appointment','azull').'</option>';
	  
		  $html .= '</select><br>';
		  $html .= "<span class='description'>".__('Select post display layout','azull').".</span>";
	      $html .= "</td>";
          $html .= "</tr>";
	    
	   	  $html .= "</table><style>.SumoSelect{width:96%;}</style>";
	   	  echo $html;
		   
	}
        private function category_generate(){
	    global $post; $html='';			
            $terms  = get_terms( 'category', 'orderby=id&hide_empty=0' );   
	    
            if ( !empty( $terms ) && !is_wp_error( $terms ) ){
				$assigned_terms = array();
				$assigned_terms = wp_get_post_terms($post->ID, 'category', array("fields" => "ids"));
                $html .= "<tr class='form-field'>";
                $html .= "<th  valign='top' scope='row'>".__('Category','azull')."</th>";
                $html .= "<td>";
                $html .= "<select name='category' class='SlectBox' style='width:180px'> ";
                $html .=  "<option value=''>--</option>";
		
                foreach ( $terms as $term ) {
			
		    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);		    
		     if(isset($taxonomy_meta['type']) && $taxonomy_meta['type']=='post'){
			$html .= "<option value='".$term->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id,$assigned_terms)) ? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$term->name)."</option>";
		     }
		 }
                $html .= "</select><br>";
                $html .= "<span class='description'>".__('Select post','azull')." <strong>".__('category','azull')."</strong>.</span>";
                $html .= "</td></tr>";                  
             }
	     
	     return $html;
	}

	static function post_external_link() {
	     # Get the globals:
		  global $post, $wp_meta_boxes;
	      
		  # Output the "advanced" meta boxes:
		  do_meta_boxes(get_current_screen(), 'advanced', $post);
	      
		  # Remove the initial "advanced" meta boxes:
		  unset($wp_meta_boxes['page']['advanced']);
		  unset($wp_meta_boxes['azulladds']['advanced']);
	 }
	 
	 
	static function external_link($post_type) {
		  # Allowed post types to show meta box:
		  $post_types = array('page','azulladds');
	      
		  if (in_array($post_type, $post_types)) {	      
		      # Add a meta box to the administrative interface:
		      add_meta_box('post_external_link', 'External link',  array('Azull_Meta','external_link_meta_box'), $post_type, 'advanced', 'high');	      
		  }
	      
	 }
	 static function external_link_meta_box(){
		  global $post;
		  
		  global $aj_config, $post;  $languages = qtranxf_getSortedLanguages();
		  $external_link='';
		  $external_link = get_post_meta($post->ID, '_external_link', true);
		  @$external_link=json_decode($external_link,true);		 
		  $html="";
		  $html .='<label class="screen-reader-text" for="foo_deck">External link</label>';		  
		  foreach($languages as $lang):
			   $class=((qtranxf_getLanguage()!=$lang) ? "external_hide ":"");
			   $html .='<input class="external_link external_'.$lang.'" style="width: 100%;" id="external_'.$lang.'" type="text" autocomplete="external_link" value="'.$external_link[$lang].'" name="external_link['.$lang.']" placeholder="External link">';
		  endforeach;
		  $html .="Enter valid external link.";
		  $html .='<style>.external_hide{display:none;}#post_external_link{margin: 5px 0;}#post_external_link .handlediv,#post_external_link h3.hndle{display: none;}#post_external_link div.inside{margin: 0px; padding: 6px;}</style>';
		  $html .="<script>
			          
				    jQuery( '.external_link' ).each(function( index ) {jQuery( this ).hide();});
				    jQuery( '.external_".qtranxf_getLanguage()."' ).each(function( index ) {jQuery( this ).show();});
				   
				    jQuery(document).on('click', '.qtranxf_title_lang', function(e){
				             var id = jQuery(this).attr('id');					     
					     jQuery( '.external_link' ).each(function( index ) {jQuery( this ).hide();});
					     id = '.external' + id;					    
					     jQuery(id).show();
				    });
				    
			   </script>";
		  
		  echo $html;
		 
	}
	

/*
 function to add/update slider text 
 Date:- 01-aug-2016 
*/

static function post_slider_text(){
          # Get the globals:
		  global $post, $wp_meta_boxes;
		  # Output the "advanced" meta boxes:
		  do_meta_boxes(get_current_screen(), 'advanced', $post);
		  # Remove the initial "advanced" meta boxes:
		  unset($wp_meta_boxes['page']['advanced']);
		  unset($wp_meta_boxes['azulladds']['advanced']);
 } 

 static function post_page_link(){
          # Get the globals:
		  global $post, $wp_meta_boxes;
		  # Output the "advanced" meta boxes:
		  do_meta_boxes(get_current_screen(), 'advanced', $post);
		  # Remove the initial "advanced" meta boxes:
		  unset($wp_meta_boxes['page']['advanced']);
		  unset($wp_meta_boxes['azulladds']['advanced']);
 }

static function add_slider_text($post_type){
$post_types = array('page','azulladds');
    if (in_array($post_type, $post_types)) {         
              # Add a meta box to the administrative interface:
              add_meta_box('post_slider_text', 'Slider Text',  array('Azull_Meta','slider_text_meta_box'), $post_type, 'normal');         
          }
    /*if($post_type=='post' ||  $post_type=='page' || $post_type=='property'){
    	add_meta_box('post_page_link', 'Meta data',  array('Azull_Meta','page_post_permalink'), $post_type, 'normal');
    } */
        
}
    
 
 /*static function page_post_permalink(){

global $post, $aj_config, $q_config;
$languages = qtranxf_getSortedLanguages();
$l = $q_config['default_language'];
$post_page_permalink = get_post_meta($post->ID, '_post_page_permalink', true);
?>
<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery('#plinkactive_lang_nl').css("font-weight", "bold");
});	
function pagePostLink_lang(lang) {
		<?php foreach($languages as $lang): echo "jQuery('#lang_plink_{$lang}').hide();"; endforeach; ?>
		jQuery('#lang_plink_'+lang).show();
        jQuery(".prlink_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#plinkactive_lang_' + lang).css("font-weight", "bold");
}
</script>
<div style="margin: 5px;text-align: right;" class="prlink_epc_language-switcher">	 
<?php   echo "&nbsp;|&nbsp;";
		foreach($languages as $lang) {
			echo "<a href=\"javascript:pagePostLink_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"plinkactive_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
		}
		?>
 </div> 
<?php
foreach($languages as $lang):
$addedLink = (isset($post_page_permalink[$lang]) && !empty($post_page_permalink[$lang]))?$post_page_permalink[$lang]:'';
?>
<div id="lang_plink_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
      <div class="wrap">
      <div class="meta-box-sortables ui-sortable">
      <div class="postbox" style="padding: 8px;">
      <table style="width: 80%;" id="" class="property_meta_table">
			<tbody>
			<tr>
				<th width="10%"><label for="meta_permalink">Permalink:</label> </th>
				<td width="90%"><input style="width: 100%;" type="text" name="post_page_permalink[<?php echo $lang;?>]" id="theEditor_<?php echo $lang;?>" value="<?php echo $addedLink;?>" placeholder="Permalink"></td>
			</tr>
		</tbody></table>
    </div></div></div>
 </div>

 <?php    
 endforeach;

}*/

static function slider_text_meta_box(){
    global $post;
    global $aj_config, $post;  
    $languages = qtranxf_getSortedLanguages();
    $slider_text = get_post_meta($post->ID, '_slider_text', true);
?>
<?php /*<script src="<?php //echo WP_PLUGIN_URL ?>/azull/js/tinymce/tinymce.min.js"></script>*/
?>
<script>

	jQuery(document).ready(function($) {
     tinymce.init({
    selector: "textarea.textareaEditor_slide", 
    /*  //textareaEditor_slide
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],*/
    });
	});

</script>
<link href="">
<div class="wrap">
    <div class="meta-box-sortables ui-sortable">
    <div id="" class="postbox" style="padding: 8px;">
        <?php
          $languages = qtranxf_getSortedLanguages();  // for get all languages 
            echo '<div style="margin-bottom: 20px;text-align: left;" class="epc_language-switcher">';
            echo "&nbsp;";
            foreach ($languages as $lang) {
                echo "<a href=\"javascript:frm_title_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
            }
            echo "</div>";
        $html.='<table class="form-table">';
              ?>  <tr>
                   <td></td>
                <td>
                <?php
               
foreach ($languages as $lang): 
				 ?>
                
 <div class="slider_text_language_<?php echo $lang ?>"  <?php echo (($lang!='en') ? 'style="display:none"' :'');?>>
			<textarea  class="textareaEditor_slide" id="textareaEditor_slide_<?php echo $lang ?>" style="width:100%;background: hsl(0, 0%, 95%);" rows="10" name="slider_text[<?php echo $lang;?>]">
			<?php echo ($slider_text)? $slider_text[$lang]:''?>
			</textarea>
		    </div> 
                <?php 
                endforeach; 
                ?>

                </td>
                </tr> 
                <?php 
        echo $html1;
       ?>
            <script type="text/javascript">
               jQuery('#active_lang_nl').css("font-weight", "bold");
                var default_lang = 'nl';
                frm_title_switch_lang(default_lang);
                function frm_title_switch_lang(lang) {
            <?php
            foreach ($languages as $lang): echo "jQuery('.slider_text_language_{$lang}').hide();";
            endforeach;
            ?>
                    jQuery('.slider_text_language_' + lang).show();
                    jQuery('#active_lang_' + lang).css("font-weight", "bold");
                     jQuery(".epc_language-switcher a").css("font-weight", "normal");
                }
            </script>

    </div>
    </div>
    </div>
<?php
  }  	
/*
* Date: 05-01-2017
* Method: Function for add custom permalink meta box
*/
static function add_permalink_metabox($post_type){
	$post_types = array('post','page','property');
    if (in_array($post_type, $post_types)) {         
    	add_meta_box('post_page_link', 'Meta Data',  array('Azull_Meta','add_custom_permalink'), $post_type, 'normal');
    } 
}

/*
* Date: 05-01-2017
* Method: Function for display custom permalink meta box content
*/
static function add_custom_permalink(){
	global $post, $aj_config, $q_config;
	$languages = qtranxf_getSortedLanguages();
	//$l = $q_config['default_language'];
	//$post_page_permalink = get_post_meta($post->ID, '_custom_permalink_', true);
	?>
	<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('#plinkactive_lang_nl').css("font-weight", "bold");
	});	
	function permalink_link_lang(lang) {
		<?php foreach($languages as $lang): echo "jQuery('#lang_plink_{$lang}').hide();"; endforeach; ?>
		jQuery('#lang_plink_'+lang).show();
        jQuery(".prlink_epc_language-switcher a").css("font-weight", "normal");
        jQuery('#plinkactive_lang_' + lang).css("font-weight", "bold");
	}
	</script>
	<div style="margin: 5px;text-align: right;" class="prlink_epc_language-switcher">	 
	<?php   echo "&nbsp;|&nbsp;";
			foreach($languages as $lang) {
				echo "<a href=\"javascript:permalink_link_lang('$lang')\" title=\"".qtranxf_getLanguageName($lang)."\" id=\"plinkactive_lang_$lang\">".qtranxf_getLanguageName($lang)."</a>&nbsp|&nbsp;";
			}
			?>
	 </div> 
	<?php
	foreach($languages as $lang):
		$addedLink = (!empty(get_post_meta($post->ID, '_custom_permalink_'.$lang, true)))?get_post_meta($post->ID, '_custom_permalink_'.$lang, true):'';
	//(isset($post_page_permalink[$lang]) && !empty($post_page_permalink[$lang]))?$post_page_permalink[$lang]:'';
	?>
	<div id="lang_plink_<?php echo $lang ?>"  <?php echo (($lang!='nl') ? 'style="display:none"' :'');?>>
	      <div class="wrap">
	      <div class="meta-box-sortables ui-sortable">
	      <div class="postbox" style="padding: 8px;">
	      <table style="width: 80%;" id="" class="property_meta_table">
				<tbody>
				<tr>
					<th width="10%"><label for="meta_permalink">Permalink:</label> </th>
					<td width="90%"><input style="width: 100%;" type="text" name="custom_permalink[<?php echo $lang;?>]" id="theEditor_<?php echo $lang;?>" value="<?php echo $addedLink;?>" placeholder="Permalink"></td>
				</tr>
			</tbody></table>
	    </div></div></div>
	 </div>
	 <?php    
	 endforeach;
}
 static function save_meta(){
	global $post, $wpdb;
	/* Code check featured image for property 
       Date:- 17-sep-2016 (abhi.p)
	*/
    if(get_post_type()=='property'){
        $thumnilId=get_post_thumbnail_id();
        if($thumnilId == '' && empty($thumnilId)){
           $url =get_admin_url()."post.php?post='".get_the_ID()."'&action=edit";
           $variable_to_send = '1';
           wp_redirect( $url.'&perror='.$variable_to_send );
     	   exit();
        }
    }
    /* Code check property region for property 
       Date:- 17-jan-2017(abhi.p)
	*/
     /*if(get_post_type() == 'property'){
         $regions=$_POST['property_meta_essential']['region'];
         if ($regions=='' || $regions=='--') {
            $url =get_admin_url()."post.php?post='".get_the_ID()."'&action=edit";
            $variable_to_send = '1';
            wp_redirect( $url.'&rerror='.$variable_to_send );
            exit();
         }
     }*/
    /* add/update infodays order */
    if(get_post_type()=='infodays'){
        //$infodaysOrder=($_POST['infodays_order']!='')?$_POST['infodays_order']:0;
        //if($infodaysOrder!='' || $infodaysOrder==0){
		  //$postId = get_the_ID();
		  //$wpdb->update('wp_posts',array('menu_order'=>$infodaysOrder),array('ID' => $postId));
          //$wpdb->query($wpdb->prepare("UPDATE wp_posts SET menu_order='$infodaysOrder' WHERE ID=$postId"));
		//}
		if(isset($_POST['azullinfo']) && !empty($_POST['azullinfo'])){
			update_post_meta($post->ID,'_azullinfo', $_POST['azullinfo']);
		}
	}

    /*===end code===*/
    if(!isset($post) || get_post_type($post->ID)=='azull_site' || (defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE))
   return;
	 
	//if(isset($_POST['post_page_permalink']))
	    //update_post_meta($post->ID, '_post_page_permalink', $_POST['post_page_permalink']);
	     
	if(isset($_POST['featured']))
	    update_post_meta($post->ID, '_featured', $_POST['featured']);
	  
	if(isset($_POST['page']))
	    update_post_meta($post->ID, '_page', $_POST['page']);
	  
	if(isset($_POST['layout']))
	    update_post_meta($post->ID, '_layout', $_POST['layout']);			   
	           
        if(isset($_POST['type']))
	    update_post_meta($post->ID,'_type', $_POST['type']);		    
	 
	if(isset($_POST['_lat']))
	    update_post_meta($post->ID,'_lat', $_POST['_lat']);
		   
	if(isset($_POST['_lng']))
	    update_post_meta($post->ID,'_lng', $_POST['_lng']);

	if(isset($_POST['external_link']))
	 update_post_meta($post->ID,'_external_link', json_encode($_POST['external_link']));	   

	if(isset($_POST['slider_text']) && $_POST['slider_text']!='')
	update_post_meta($post->ID,'_slider_text',$_POST['slider_text']);	   
           
	if(isset($_POST['category']) ){			
	  //property categories terms
		$categories_ids = array_map( 'intval',(array)$_POST['category']);		
		$categories_ids = array_unique( $categories_ids );
		wp_set_object_terms($post->ID, $categories_ids, 'category',false);
	}
	if(isset($_POST['azulloffice']) && !empty($_POST['azulloffice'])){
		if(isset($_POST['url_type']) && $_POST['url_type']!=0){
            $_POST['azulloffice']['url_type'] = $_POST['url_type'];
            switch ($_POST['url_type']) {
                case 1://page
                    $_POST['azulloffice']['url'] = $_POST['wp_page_id'];
                break;
                case 2://post
                    $_POST['azulloffice']['url'] = $_POST['wp_post_id'];
                break;
            }
        }
        //print('<pre>');print_r($_POST['azulloffice']);die('post');
        update_post_meta($post->ID, '_azulloffice', $_POST['azulloffice']);
	}

	if(isset($post) && get_post_type($post->ID)=='property'){
		//echo 'hehehe';die;

		$languages = qtranxf_getSortedLanguages();
		$title_data = '';
        $keywords_data = '';
        $description_data = '';
		if(isset($languages) && !empty($languages)){
			foreach($languages as $lang){
				$title_id = "property_meta_title_".$lang;
				$keywords_id = "property_meta_keywords_".$lang;
				$description_id = "property_meta_description_".$lang;
				$title_data .= "[:$lang]".trim(str_replace('"', '', $_POST[$title_id]));
				$keywords_data .= "[:$lang]".trim(str_replace('"', '', $_POST[$keywords_id]));
				$description_data .= "[:$lang]".trim(str_replace('"', '', $_POST[$description_id]));
			}
		}
		if(isset($title_data) && !empty($title_data)){
			update_post_meta($post->ID,'property_meta:title', $title_data.'[:]' );
		}
		if(isset($keywords_data) && !empty($keywords_data)){
			update_post_meta($post->ID,'property_meta:keywords', $keywords_data.'[:]' );
		}
		if(isset($description_data) && !empty($description_data)){
			update_post_meta($post->ID,'property_meta:description', $description_data.'[:]');
		}
		//add/update property custom permalink
		Azull_Meta::property_custom_permalink($post->ID);
	}
	if(isset($_POST['share_clientUrl']) && $_POST['share_clientUrl']!=''){
	    update_post_meta($post->ID,'_share_client_url', $_POST['share_clientUrl']);	
	    $val = get_post_meta($post->ID,"_share_client_url",true);	   
	}
	if(isset($post) && get_post_type($post->ID)=='post'){
		/*$languages = qtranxf_getSortedLanguages();
		$meta_desc_arr = array(
	    	"en"=>"Azull is the market leader in sales of apartments and villas in Spain. Before you buy a property on the Costa Blanca, Costa del Sol, Costa Calida (Murcia) or in Mallorca and Tenerife, please first contact Azull.",
	    	"fr"=>"Azull est le leader du marché des ventes d'appartements et de villas en Espagne. Avant d'acheter une propriété sur la Costa Blanca, Costa del Sol, Costa Calida (Murcia) ou à Majorque et Tenerife, s'il vous plaît d'abord contacter Azull.",
	    	"nl"=>"Azull is marktleider in verkoop van appartementen en villa's in Spanje. Vooraleer U een woning koopt aan de Costa Blanca, Costa del Sol, Costa Calida (Murcia) of in Mallorca en Tenerife, neem eerst contact op met Azull."
	    );
		$title_data = '';
        $keywords_data = '';
        $description_data = '';
        /*$tags = wp_get_post_tags($post->ID);
        $keyword_tag = '';
        if(isset($tags) && !empty($tags)){
        	$t_posts = count($tags);
        	$i=1;
        	foreach ($tags as $key => $val) {
        		$keyword_tag .= $val->name;
        		$keyword_tag .= (isset($t_posts) && $i < $t_posts)?', ':'';
        		$i++;
        	}
        }
		if(isset($languages) && !empty($languages)){
			foreach($languages as $lang){
				// if(isset($_POST['category']) && $_POST['category'] == 896){
				// 	$content = apply_filters('the_content', qtranxf_use($lang, $_POST['content']));
		  //       	$title_text = str_replace('&#8211;', '-', strip_tags(substr($content, 0, strpos( $content, '</p>' ) + 4 )));
				// }else{
				// 	$title_text = qtranxf_use($lang, strip_tags($_POST['post_title']));
	   //      	}
				// $content = apply_filters('the_content', qtranxf_use($lang, strip_tags($_POST['content'])));
	   //      	$title_text = strip_tags(substr($content, 0, strpos( $content, '</p>' ) + 4 ));
	   //      	$keywords_text = str_replace(',,', ',',str_replace('.,', ',',$title_text.', '.$keyword_tag));
	   //      	$desc_text = str_replace('..', '.',$title_text.'. '.$meta_desc_arr[$lang]);

				$title_text = (!empty($_POST["property_meta_title_".$lang]))?$_POST["property_meta_title_".$lang]:$title_text;
				$keywords_text = (!empty($_POST["property_meta_keywords_".$lang]))?$_POST["property_meta_keywords_".$lang]:$keywords_text;
				$desc_text = (!empty($_POST["property_meta_description_".$lang]))?$_POST["property_meta_description_".$lang]:$desc_text;

				$title_data .= "[:$lang]".str_replace('"', '', $title_text);
				$keywords_data .= "[:$lang]".str_replace('"', '', $keywords_text);
				$description_data .= "[:$lang]".str_replace('"', '', $desc_text);


				$_POST["property_meta_title_{$lang}"] = $title_text;
				$_POST["property_meta_keywords_{$lang}"] = $keywords_text;
				$_POST["property_meta_description_{$lang}"] = $desc_text;
			}
		}
		if(isset($title_data) && !empty($title_data)){
			update_post_meta($post->ID,'property_meta:title', $title_data.'[:]' );
		}
		if(isset($keywords_data) && !empty($keywords_data)){
			update_post_meta($post->ID,'property_meta:keywords', $keywords_data.'[:]' );
		}
		if(isset($description_data) && !empty($description_data)){
			update_post_meta($post->ID,'property_meta:description', $description_data.'[:]');
		}*/
	}
	update_post_meta($post->ID,'_main_site', $_POST['main_website']);
	//save custom permalink in post meta
	//print('<pre>');print_r(get_post_type());die();
	$post_types = array('post','page');
    if (in_array(get_post_type(), $post_types)) {
    	if(isset($_POST['post_title']) && !empty($_POST['post_title'])){
    		$existing_post = get_post($post->ID);
    		$existing_post_title = $existing_post->post_title;
    		$cust_perm = array();
    		$site_url = get_site_url();	
		    if(!empty($_POST['post_type'])){
		    	switch ($_POST['post_type']) {
		    		case 'post':
		    			$post_date = date('Y/m/d',strtotime($existing_post->post_date));
		    			$site_url = get_site_url().'/'.$post_date;	
	    			break;
		    		case 'page':
		    			$site_url = get_site_url();	
	    			break;
		    	}
		    }
		    $en_exist = strpos($existing_post_title,"[:en]");
		    if($en_exist !== false){
		    	$en_txt = qtranxf_use('en', $existing_post->post_title);
		    	$en_txt = str_replace('à', 'a', str_replace('é', 'e', $en_txt));
		    	$en_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($en_txt));
			    if(isset($en_slug) && !empty($en_slug)){
			       $cust_perm['en'] = $site_url.'/'.rtrim($en_slug,"-");
			    }
		    }
		    $fr_exist = strpos($existing_post_title,"[:fr]");
		    if($fr_exist !== false){
		    	$fr_txt = qtranxf_use('fr', $existing_post->post_title);
		    	$fr_txt = str_replace('à', 'a', str_replace('é', 'e', $fr_txt));
		    	$fr_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($fr_txt));
			    if(isset($fr_slug) && !empty($fr_slug)){
			      $cust_perm['fr'] = $site_url.'/'.rtrim($fr_slug,"-");
			    }
		    }
		    $nl_exist = strpos($existing_post_title,"[:nl]");
		    if($nl_exist !== false){
		    	$nl_txt = qtranxf_use('nl', $existing_post->post_title);
		    	$nl_txt = str_replace('à', 'a', str_replace('é', 'e', $nl_txt));
		    	$nl_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($nl_txt));
		      	if(isset($nl_slug) && !empty($nl_slug)){
		        	$cust_perm['nl'] = $site_url.'/'.rtrim($nl_slug,"-");
		      	}
		    }
		    //print('<pre>');print_r($fr_exist);die();
	      //print('<pre>');print_r($en_slug);//die();
	      //print('<pre>');print_r($fr_slug);
	      //print('<pre>');print_r($cust_perm);//die();
	  	}
		if(isset($_POST['custom_permalink']) && !empty($_POST['custom_permalink'])){
			//print('<pre>');print_r($_POST['custom_permalink']);die();
			foreach ($_POST['custom_permalink'] as $key => $plval) {
				if(!empty($plval)){
					$plval = str_replace('à', 'a', str_replace('é', 'e', $plval));
					update_post_meta($post->ID, '_custom_permalink_'.$key, $plval);
				}else if(isset($cust_perm[$key]) && !empty($cust_perm[$key])){
					update_post_meta($post->ID, '_custom_permalink_'.$key, $cust_perm[$key]);
				}else{
					update_post_meta($post->ID, '_custom_permalink_'.$key, '');
				}
			}	
		}
	}
    /*if (in_array(get_post_type(), $post_types)) {  
		if(isset($_POST['custom_permalink']) && !empty($_POST['custom_permalink'])){
			foreach ($_POST['custom_permalink'] as $key => $plval) {
				update_post_meta($post->ID, '_custom_permalink_'.$key,rtrim($plval,"/"));	
			}
		}
	}*/
	//get clients before update meta
	$before_clients = array();
	$before_clients = get_post_meta($post->ID,"_client",true);
	$after_clients=array();
	//update server meta value
	update_post_meta($post->ID,'_client', $_POST['client']);
	if(isset($_POST['client']) && $_POST['client']!='' && $_POST['post_status'] == 'publish'){
		//update server meta value
		//update_post_meta($post->ID,'_client', $_POST['client']);
	    //get clients after update meta
		$after_clients = get_post_meta($post->ID,"_client",true);
	    foreach($_POST['client'] as $clinet){
			if ($_SERVER['REMOTE_ADDR'] == '113.160.59.74' && false) {
				$obj = new Xmlrpc_Client($clinet);
				if(!$obj->test_connection())
				    continue;	
				    $obj->send_post_to($post->ID);
			}
			//Add to XML processing table
			else {
				$data = array(
					'path' => $post->ID,
					'type' => 2,
					'agentId' => $clinet,
					'status' => 0,
					'start_datetime' => date('Y-m-d h:i:s'),
					'slot' => 1,
					'slot_status' => 1,
					'total_records' => 0,
					'total_traverse_record' => 0,
					'total_updated_records' => 0,
					'total_added_records' => 0
				);
				$wpdb->insert('wp_xml_record',$data);
			}
	    }
	}
	if(isset($before_clients) && !empty($before_clients) && count($before_clients)>0){
		foreach ($before_clients as $key => $client) {
			if(!in_array($client,$after_clients)){
				//delete uncheck client post
				$obj = new Xmlrpc_Client($client);
				if(!$obj->test_connection())
				    continue;
					if(isset($_POST['post_status']) && $_POST['post_status']!='auto-draft'){
						$obj->delete_post_single($post->ID);
					    //for trac post un-publish action
					    /*if(isset($post) && get_post_type($post->ID)=='post'){
					    	self::email_post_unpublish($post->ID,$post,$client);
						}*/
					}
			}
		}
	}
	$location = admin_url("post.php?post=".$post->ID."&action=edit");
	if($_POST['post_status'] !='draft'){
	   if ( 'property' == get_post_type($post->ID)) {
	        if ( isset( $_POST['save'] ) || isset( $_POST['publish'] ) ){
	        $location=get_option('redirect_url');
	        } 
	    } 
	}
	wp_redirect($location);
	//return;	
}


	/*function email_post_unpublish( $post_id, $post, $client ) {
	  if(isset($post_id) && !empty($post_id) && isset($post) && !empty($post)){
	    if($post->post_status!='auto-draft' && $post->post_type=='post'){
	      $email = 'manoj.p@cisinlabs.com';
	      $subject = 'Blog post unpublished on azull.biz';
	      $message = 'A post was unpublished below is the post detail<br>';
	      
	      $message .= 'Client Id => '.$client.'<br>';
	      $message .= 'Post Id => '.$post->ID.'<br>';
	      $message .= 'Post Date => '.$post->post_date.'<br>';
	      $message .= 'Post Title => '.$post->post_title.'<br>';
	      //$message .= 'Post Content => '.$post->post_content.'<br>';

	      $message .= 'Post Name => '.$post->post_name.'<br>';
	      $ip = $_SERVER['REMOTE_ADDR'];
	      $user = wp_get_current_user();
	      $message .= 'User Ip => '.$ip.'<br>';
	      $message .= 'User ID => '.$user->ID.'<br>';
	      $message .= 'User Email => '.$user->user_email.'<br>';
	      $message .= 'User Role => '.$user->roles[0].'<br>';
	      if(isset($user) && !empty($user)){
	        $user_meta = get_user_meta($user->ID);
	        $f_name = (isset($user_meta['first_name'][0]))?$user_meta['first_name'][0]:'';
	        $l_name = (isset($user_meta['last_name'][0]))?$user_meta['last_name'][0]:'';
	        $message .= 'User First Name => '.$f_name.'<br>';
	        $message .= 'User Last Name => '.$l_name.'<br>';
	      }
	      $message .= date("l jS \of F Y h:i:s A");
	      $html = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
	      $html .='<html xmlns="http://www.w3.org/1999/xhtml">';
	      $html .='<head>';
	      $html .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
	      $html .='<title>' . $subject . '</title>';
	      $html .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
	      $html .='</head>';
	      $html .='<body style="margin: 0; padding: 0;font-size:12px;">';
	      $html .= $message;
	      $html .='</body>';
	      $html .='</html>';
	      wp_mail($email, $subject, $html);
	    }
	  }
	}*/



	static function add_multiple_page_thumbnails_from_plugin() {
	    $languages = qtranxf_getSortedLanguages();	 
	    if(class_exists('MultiPostThumbnails')){
		foreach($languages as $lang) {
		    new MultiPostThumbnails( array(  
			'label'     => __('Featured Image').' '.qtranxf_getLanguageName($lang), 
			'id'        => 'feature_image_'.$lang,
			'post_type' => 'page'  
		    ) ); 
		}
		
		foreach($languages as $lang) {
		    new MultiPostThumbnails( array(  
			'label'     => __('Featured Title Image').' '.qtranxf_getLanguageName($lang), 
			'id'        => 'feature_title_image_'.$lang,
			'post_type' => 'page'  
		    ) ); 
		}
	    }	     
	}	
/*
* Date: 12-Jan-2017
* Method: Function for add/update permalink for property
*/
static function property_custom_permalink($postId) {
	//print('<pre>');print_r($postId);//die('hi');
    if(isset($postId) && !empty($postId) && $postId != 0 && isset($_POST['custom_permalink']) && is_array($_POST['custom_permalink'])){
        $option_lang = get_option('qtranslate_term_name');
        $category = wp_get_post_terms($postId,'category');
        $post_meta = get_post_meta($postId);
        $ref = $post_meta['_nreal_id'][0];
        $cntry_term = Azull_Meta::get_termname_custom($post_meta['_country'][0]);
        $region_term =Azull_Meta::get_termname_custom($post_meta['_region'][0]);
        $place_term = Azull_Meta::get_termname_custom($post_meta['_place'][0]);
        $site_url = get_site_url();
        $slug_txt_arr = array(
            'en'=>'for-sale',
            'fr'=>'a-vendre',
            'nl'=>'te-koop'
        );
        foreach ($_POST['custom_permalink'] as $key => $plval) {
        	$post_category = (isset($option_lang[$category[0]->name][$key]))?$option_lang[$category[0]->name][$key]:$category[0]->name;
        	$post_country = (isset($option_lang[$cntry_term][$key]))?$option_lang[$cntry_term][$key]:$cntry_term;
        	$post_region = (isset($option_lang[$region_term][$key]))?$option_lang[$region_term][$key]:$region_term;
        	$post_place = (isset($option_lang[$place_term][$key]))?$option_lang[$place_term][$key]:$place_term;

        	$p_post_name = $ref.'-'.$post_category.'-'.$slug_txt_arr[strtolower($key)].'-'.$post_place.'-'.$post_region.'-'.$post_country;
        	$p_post_name = str_replace(' ', '-', strtolower($p_post_name));
        	$slug = str_replace('--', '-',str_replace(',', '', str_replace('.', '', $p_post_name)));
        	if(!empty($plval)){
				update_post_meta($postId, '_custom_permalink_'.$key, $plval);
			}else if(isset($slug) && !empty($slug)){
				update_post_meta($postId, '_custom_permalink_'.$key, $site_url.'/'.rtrim($slug,"-"));
			}else{
				update_post_meta($postId, '_custom_permalink_'.$key, '');
			}
        }
      //print('<pre>');print_r($_POST['custom_permalink']);die('hi');
    }
}
/*
* Date: 12-Jan-2017
* Method: Function for get term name
*/
public function get_termname_custom($termId) {
	if(isset($termId) && !empty($termId) && $termId!=0){
    	global $wpdb;
    	$record = $wpdb->get_results("SELECT name FROM wp_terms where term_id =".$termId,ARRAY_A);
    	if(!empty($record[0]['name'])) return $record[0]['name'];
	}
    return '';
}
//********** End Class ************//
}