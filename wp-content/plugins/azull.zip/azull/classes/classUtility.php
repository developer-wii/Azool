<?php
/* A utility class to contain all mis methods used globally in pluging.
 * @author:Dhananjay Pandey
 * @since:1.0
 * @package:wordpress
 * @subpackage:azull
 */
 
defined('ABSPATH') or die("No script kiddies please!");

class Azull_Utility{
    static function azull_features_pdf($post_id){
	    $html = array(); $val=array();
	    
	    $val=get_post_meta($post_id,'_dimensions',true );	
            $terms  = get_terms( 'dimensions', 'orderby=id&hide_empty=0' );
	    
	    	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){                        
			foreach ( $terms as $term ) {
			    
			    $s=((isset($val[$term->term_id]) && $val[$term->term_id]=='')? 'background:#ccc;':'background:#091C38;');
			    $distance="";
			    if(isset($val[$term->term_id]) && $val[$term->term_id]!=""){
				
				//$distance .= ((float)$val[$term->term_id]>500) ? number_format(((float)$val[$term->term_id]/1000),0,".","").'km²' : number_format((float)$val[$term->term_id],0,".","") .'m²';	
				$distance .= ((float)$val[$term->term_id]>500) ? number_format(((float)$val[$term->term_id]),0,".","").'m²' : number_format((float)$val[$term->term_id],0,".","") .'m²';					
				
			    }
			    
			if(isset($val[$term->term_id]) && $val[$term->term_id]!='')	
                    $html[] =  "<div style='float:left;background:#091C38;text-align:center;'>
					<img alt='".qtranxf_use($lng,$term->name)."' title='".qtranxf_use($lng,$term->name)."'  ".((!isset($val[$term->term_id]))? 'class="gray-image"':'')." src='".z_taxonomy_image_url($term->term_id)."' />".$distance."</div>";
		    	}
            }
            
            $val=get_post_meta($post_id,'_scores',true );	
            $terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );	    
	    
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
		
		    foreach ( $terms as $term ) {
			$s=((isset($val[$term->term_id]) && $val[$term->term_id]=='')? 'background:#ccc;':'background:#091C38;');
			$distance="";
			if(isset($val[$term->term_id]) && $val[$term->term_id]!=""){					
			    
			    $distance .= ((float)$val[$term->term_id]>500) ? number_format(((float)$val[$term->term_id]/1000),0,".","").'km' : number_format((float)$val[$term->term_id],0,".","") .'m';
			   
			}
			
			if(isset($val[$term->term_id]) && $val[$term->term_id]!='')	
			$html[]= "<div style='float:left;background:#091C38;text-align:center;'><img alt='".qtranxf_use($lng,$term->name)."' title='".qtranxf_use($lng,$term->name)."'  ".((!isset($val[$term->term_id]))? 'class="gray-image"':'')." src='".z_taxonomy_image_url($term->term_id)."' /><div style='color:hsl(209, 79%, 39%); background:#fff); border:1px solid hsl(209, 79%, 39%); dispay:block; width:100%;'>".$distance."</div></div>";
                    }
            }   
	return $html;    
            
    }


static  function azull_features_pdf_icons($post_id,$color="hsl(209, 79%, 39%)"){
    $html='<div style="margin-left:-15px;">';
	$terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	    $taxonomy_meta['type']=1;$taxonomy_meta['search']=0;
              foreach ( $terms as $term ) {
	       $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
	            if($taxonomy_meta['type']==2 && get_post_meta($post_id,'_feature_'.$term->term_id,true)!='' && z_taxonomy_image_url($term->term_id)!=''){
            $fnuber= get_post_meta($post_id,'_feature_'.$term->term_id,true);
			$fnuber =(isset($fnuber ) && is_numeric($fnuber)) ? $fnuber: $fnuber;					 
			$fnuber =(isset($fnuber ) && !is_numeric($fnuber)) ?__($fnuber,'azull'): $fnuber;
			if($fnuber && $fnuber!=0){
                 $html .="<div style='width:8%;margin-left:2%;margin-bottom: 15px;background:".$color.";float:left;text-align:center' ><img  src='".z_taxonomy_image_url($term->term_id)."'><div style='color:".$color."; background:#fff); border:1px solid ".$color."; dispay:block; width:100%;'>".$fnuber."</div></div>";
			}
			
		    }
		  $taxonomy_meta['search']=0;
               }
         }
        $terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );  
	if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	  foreach ( $terms as $term ) {	
	      $distance="";
	      $val=get_post_meta($post_id,'_scores_'.$term->term_id,true);
	      if(isset($val) && $val!="" && z_taxonomy_image_url($term->term_id)!='' && $val!= 0){
		$distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km' : number_format((float)$val,0,".","") .'m'; 	    
			$html .=  "<div style='width:8%;margin-left:2%;background:".$color.";float:left;text-align:center' ><img src='".z_taxonomy_image_url($term->term_id)."'/><div style='color:".$color."; background:#fff); border:1px solid ".$color."; dispay:block; width:100%;'>".$distance."</div></div>";
	      }
	    }
	}
	  /*$terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );
	  if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	    foreach ( $terms as $term ) {
	      $distance="";
	      $val=get_post_meta($post_id,'_scores_'.$term->term_id,true);
	      if(isset($val) && $val!="" && z_taxonomy_image_url($term->term_id)!='' && $val!= 0){
		    $distance .= ((float)$val>999) ? number_format(((float)$val/100),0,".","").'m²' : number_format((float)$val,0,".","") .'m'; 	    
		  $html .=  "<div style='width:8%;margin-left:2%;background:".$color.";float:left;text-align:center' ><img  src='".z_taxonomy_image_url($term->term_id)."' /><div style='color:#fff; background:#fff); border:1px solid ".$color."; dispay:block; width:100%;'>".$distance."</div></div>";
	      }
	  }  
	}*/
	$terms  = get_terms( 'dimensions', 'orderby=id&hide_empty=0' );
	if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	   foreach ( $terms as $term ) {
	       $distance="";
	       $val=get_post_meta($post_id,'_dimensions_'.$term->term_id,true);
	       if(isset($val) && $val!="" && z_taxonomy_image_url($term->term_id)!='' && $val!= 0){		
		   $distance .= ((float)$val>999) ? number_format(((float)$val),0,".","").'m²' : number_format((float)$val,0,".","") .'m²';	
		   $html .= "<div style=' margin-bottom: 5px; width:8%;margin-left:2%;background:".$color.";float:left;text-align:center' ><img  src='".z_taxonomy_image_url($term->term_id)."' /><div style='color:".$color."; background:#fff); border:1px solid ".$color."; dispay:block; width:100%;'>".$distance."</div></div>";
	       }
	   }           
	 }
	$taxonomys= array('locality','feature','interior','exterior');
	foreach($taxonomys as $taxonomy){
		$terms = wp_get_post_terms($post_id, $taxonomy);
		if ( !empty( $terms ) && !is_wp_error( $terms ) ){
		  foreach ( $terms as $term ) {	
		  	if(z_taxonomy_image_url($term->term_id)!=''){
			$html .=  "<div style='margin-bottom: 15px; width:8%;margin-left:2%;background:".$color.";float:left;text-align:center'><img  src='".z_taxonomy_image_url($term->term_id)."' /></div>";			     
		    }
		   }
		}
    }

	 /*$terms = wp_get_post_terms($post_id, 'locality');
	if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	   foreach ( $terms as $term ) {
	           if(z_taxonomy_image_url($term->term_id)!='')
		   $html .=  "<div style='width:8%;margin-left:2%;background:".$color.";float:left;text-align:center'><img  src='".z_taxonomy_image_url($term->term_id)."' /></div>";
	       }		   
	}*/

	    /*$terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );	
	    $val = wp_get_post_terms($post_id, 'feature', array("fields" => "ids"));
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {
		if(in_array($term->term_id,$val) && z_taxonomy_image_url($term->term_id)!=''){
		 $html .=  "<div style='width:8%;margin-left:2%;".$color.";float:left;text-align:center'><img    src='".z_taxonomy_image_url($term->term_id)."' /></div";
		}
	      }
	    }*/
	    /*$terms  = get_terms( 'interior', 'orderby=id&hide_empty=0' );	
	    $val = wp_get_post_terms($post_id, 'interior', array("fields" => "ids"));
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {
		if(in_array($term->term_id,$val) && z_taxonomy_image_url($term->term_id)!=''){
		 $html .=  "<div style='width:8%;margin-left:2%;background:".$color.";float:left;text-align:center'><img    src='".z_taxonomy_image_url($term->term_id)."' /></div";
		}
	      }
	    }
	    	
	    $terms  = get_terms( 'exterior', 'orderby=id&hide_empty=0' );	
	    $val = wp_get_post_terms($post_id, 'exterior', array("fields" => "ids"));
	    
	    if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	      foreach ( $terms as $term ) {
		if(in_array($term->term_id,$val) && z_taxonomy_image_url($term->term_id)!=''){
		 $html .=  "<div style='width:8%;margin-left:2%;background:".$color.";float:left;text-align:center'><img    src='".z_taxonomy_image_url($term->term_id)."' /></div";
		}
	      }
	    }*/
	 return "</div>".$html;
    }
    static function azull_gallery_pdf($post_id,$size='full'){    
		  $html = "<table autosize='1' repeat_header='1' style='margin-top:15px;'>";  
		  
		  $i=0;
                  $images = json_decode(base64_decode(get_post_meta($post_id, 'property_gallery', true)));
		         
			  foreach ($images as $id ) {
			     if(get_post_thumbnail_id( $post_id )!=$id && $id!='') {
			    
			       $url = wp_get_attachment_image_src( $id, 'pdf-small' );
			       if(($i)%8==0) {
			       		$html .="</table><table autosize='1' repeat_header='1' style='margin-top:15px;'>'";
			       }
			         if($i%2==0)
			         $html .='<tr>';
				 $html .= '<td><img style="width:100%;margin-bottom:15px;'.(($i%2==0) ? "margin-right:7.5px;":"margin-left:7.5pxpx;").'" src="'.$url[0].'"/></td>';
				  if($i%2==0 && $i!=0)			         
				 $html .='</tr>';
				 $i++;
			     }
			     
			    
			  }

			$html .="</table>";  
		  return $html;
		          
    }

 static function azull_meta_pdf($post_id,$color="#0E4F8B"){

    $obj = new Azull_Subscriber();  
	global $q_config;
	$term = wp_get_post_terms($post_id, 'category',true);
	$html .= "<table autosize='1' repeat_header='1' width='100%'>";
	$html .= "<tr>";
	    $html .= "<th width='33%' style='text-align:left;color:".$color.";text-transform:uppercase;font-size:10pt;'>";
	    //$html .= __('General Information','azull');
	    $html .= $obj->getTranslatedString('en','nl','General Information');
	     
	    $html .= "</th>";
	    
	    $html .= "<th width='33%' style='text-align:left;color:".$color.";text-transform:uppercase;font-size:10pt'>";
	    //$html .= __('Location Information','azull');
	    $html .= $obj->getTranslatedString('en','nl','Location Information');
	    $html .= "</th >";
	    
	    $html .= "<th width='33%' style='text-align:left;color:".$color.";text-transform:uppercase;font-size:10pt'>";
	    //$html .= __('Financial Information','azull');
	    $html .= $obj->getTranslatedString('en','nl','Financial Information');
	    $html .= "</th>";
	    
	$html .= "</tr>";
	
	$html .= "<tr>";
	
	    $html .= "<td width='33%' style='text-align:left;vertical-align:top;font-size:9pt;color:".$color.";'>";
	    

		
		    /*$html .='<strong style="font-size8pt;color:"'.$color.'";">'.__('Category','azull').':</strong> '.property_category($post_id).'<br/>';
		    if(property_status($post_id))
		    $html .='<strong>'.__('Status','azull').':</strong> '.property_status($post_id).'<br/>';
		    if(build_year($post_id)!='')
		    $html .='<strong>'.__('Build year','azull').':</strong> '.build_year($post_id).'<br/>';*/

            $html .='<strong style="font-size8pt;color:"'.$color.'";">'.$obj->getTranslatedString('en','nl','Category').':</strong> '.property_category($post_id).'<br/>';
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Status').':</strong> '.property_status($post_id).'<br/>';
		    if(build_year($post_id)!='')
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Build year').':</strong> '.build_year($post_id).'<br/>';

		    
		    $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
				if ( !empty( $terms ) && !is_wp_error( $terms ) ){
				
				   $taxonomy_meta['type']=1;$taxonomy_meta['search']=0;
				     foreach ( $terms as $term ) {
				      $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
					   if($taxonomy_meta['type']==2 && get_post_meta($post_id,'_feature_'.$term->term_id,true)!=''){
					    $fnuber= get_post_meta($post_id,'_feature_'.$term->term_id,true);
				            $fnuber =(isset($fnuber ) && is_numeric($fnuber)) ? $fnuber: $fnuber;					 
					    $fnuber =(isset($fnuber ) && !is_numeric($fnuber)) ?__($fnuber,'azull'): $fnuber;
				            //$html .='<strong>'.__('No.','azull').qtranxf_use(qtranxf_getLanguage(),$term->name).':</strong> '.$fnuber.'<br/>';
					    $html .='<strong>'.$obj->getTranslatedString('en','nl','No.').qtranxf_use(qtranxf_getLanguage(),$term->name).':</strong> '.$fnuber.'<br/>';
					   }
					 $taxonomy_meta['search']=0;  
				      }
				}
		    
		   
		   
		    $term = wp_get_post_terms($post_id, 'view');		  
		    if( $term[0]->name!='')
		    /*$html .='<strong>'.__('Property view','azull').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';		    
		    $html .='<br/>';*/
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Property view').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';		    
		    $html .='<br/>';
		    
		
	    $html .= "</td>";
	    
	    $html .= "<td width='33%' style='text-align:left;vertical-align:top;font-size:9pt;color:".$color.";'>";
	            
		    $term = wp_get_post_terms($post_id, 'place');
		    /*if($term)
	    	    $html .='<strong>'.__('Place','azull').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
		    $term = wp_get_post_terms($post_id, 'provinces');
		    if($term)
		    $html .='<strong>'.__('Provinces','azull').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
		    $term = wp_get_post_terms($post_id, 'region');
		    if($term)
		    $html .='<strong>'.__('Region','azull').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
		    $term = wp_get_post_terms($post_id, 'country');
		    if($term)
		    $html .='<strong>'.__('Country','azull').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
	            //todo:include google map...
	    	    $html .='<br/>';*/
            if($term)
	    	    $html .='<strong>'.$obj->getTranslatedString('en','nl','Place').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
		    $term = wp_get_post_terms($post_id, 'provinces');
		    if($term)
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Provinces').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
		    $term = wp_get_post_terms($post_id, 'region');
		    if($term)
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Region').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
		    $term = wp_get_post_terms($post_id, 'country');
		    if($term)
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Country').':</strong> '.qtranxf_use(qtranxf_getLanguage(),$term[0]->name).'<br/>';
	            //todo:include google map...
	    	    $html .='<br/>';

		    $html .='<br/>';
	    $html .= "</td>";

	    
	   /* $html .= "<td width='33%' style='text-align:left;vertical-align:top;font-size:9pt;color:".$color.";'>";
	            $settings=get_option('azullsettings');
		   
	            $finance=get_post_meta($post_id,'_finance',true);
		  
		    if(isset($finance['vat']) && get_post_meta($post_id,'_buildType',true)==1)
	    	    $html .='<strong>'.__('VAT','azull').':</strong> '.$finance['vat'].'%<br/>';
		    if(isset($finance['availability']))
		    $html .='<strong>'.__('For sale','azull').':</strong> '.(($finance['availability']==0) ? __('Yes','azull'):__('No','azull')).'<br/>';
		    
		    $html .='<strong>'.__('Sales Price','azull').':</strong> '.number_format ( (integer) azull_price('Sales price',$post_id) , 0 , "" , "." ).$settings['currency'].'<br/>';
		    $html .='<strong>'.__('Total Price','azull').':</strong> '.number_format ( (integer) azull_price('Total price',$post_id) , 0 , "" , "." ).$settings['currency'].'<br/>';
		    $html .="<span style='font-size:6.5pt;'>( ".__('Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.','azull')." )</span>";	
	    	    $html .='<br/>';
           */
            $html .= "<td width='33%' style='text-align:left;vertical-align:top;font-size:9pt;color:".$color.";'>";
	            $settings=get_option('azullsettings');
		   
	            $finance=get_post_meta($post_id,'_finance',true);
		  
		    if(isset($finance['vat']) && get_post_meta($post_id,'_buildType',true)==1)
	    	    $html .='<strong>'.$obj->getTranslatedString('en','nl','VAT').':</strong> '.$finance['vat'].'%<br/>';
		    if(isset($finance['availability']))
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','For sale').':</strong> '.(($finance['availability']==0) ? $obj->getTranslatedString('en','nl','Yes'):$obj->getTranslatedString('en','nl','No')).'<br/>';
		    
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Sales Price').':</strong> '.number_format ( (integer) azull_price('Sales price',$post_id) , 0 , "" , "." ).$settings['currency'].'<br/>';
		    $html .='<strong>'.$obj->getTranslatedString('en','nl','Total Price').':</strong> '.number_format ( (integer) azull_price('Total price',$post_id) , 0 , "" , "." ).$settings['currency'].'<br/>';
		    $html .="<span style='font-size:6.5pt;'>( ".$obj->getTranslatedString('en','nl','Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.')." )</span>";	
	    	    $html .='<br/>';
		   
	    $html .= "</td>";
	
	$html .= "</tr>";
	
	/*$html .= "<tr>";
	    $html .= "<th width='33%' style='text-align:left;vertical-align:top;color:#0E4F8B;text-transform:uppercase;font-size:10pt'>";
	    $html .= __('Features','azull');
	    $html .= "</th>";
	    
	    $html .= "<th width='33%' style='text-align:left;vertical-align:top;color:#0E4F8B;text-transform:uppercase;font-size:10pt'>";
	    $html .= __('Exterior','azull');
	    $html .= "</th >";
	    
	    $html .= "<th width='33%' style='text-align:left;vertical-align:top;color:#0E4F8B;text-transform:uppercase;font-size:10pt'>";
	    $html .= __('Interior','azull');
	    $html .= "</th>";
	    
	$html .= "</tr>"*/;
	
	/*$html .= "<tr>";
	
	    $html .= "<td width='33%' style='text-align:left;vertical-align:top;font-size:9pt;color:#0E4F8B;'>";
	    
            $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );	     
	    $assigned_terms = wp_get_post_terms($post_id, 'feature', array("fields" => "ids"));
            if ( !empty( $terms ) && !is_wp_error( $terms ) ){   
		foreach ( $terms as $term ) {	    
		    
		    if(in_array($term->term_id,$assigned_terms))    
			 $html .= $q_config['term_name'][$term->name][qtranxf_getLanguage()].'<br/>';
		    }
            }
	    $html .='<br/>';
	    $html .='<br/>';
	    $html .= "</td>";
	    
	    $html .= "<td width='33%' style='text-align:left;vertical-align:top; font-size:9pt;color:#0E4F8B;'>";
	    $terms  = get_terms( 'exterior', 'orderby=id&hide_empty=0' );
	    $assigned_terms = wp_get_post_terms($post_id, 'exterior', array("fields" => "ids"));
	    
            if ( !empty( $terms ) && !is_wp_error( $terms ) ){   
		foreach ( $terms as $term ) {
		    if(in_array($term->term_id,$assigned_terms))    
			 $html .= $q_config['term_name'][$term->name][qtranxf_getLanguage()].'<br/>';
		    }
            }
	    $html .='<br/>';
	    $html .='<br/>';
	    $html .= "</td>";
	    
	    $html .= "<td width='33%' style='text-align:left;vertical-align:top; font-size:9pt;color:#0E4F8B;'>";
	    $terms  = get_terms( 'interior', 'orderby=id&hide_empty=0' );
	    $assigned_terms = wp_get_post_terms($post_id, 'interior', array("fields" => "ids"));
            if ( !empty( $terms ) && !is_wp_error( $terms ) ){   
		foreach ( $terms as $term ) {
		    if(in_array($term->term_id,$assigned_terms))    
			 $html .= $q_config['term_name'][$term->name][qtranxf_getLanguage()].'<br/>';
		    }
            }
	    $html .='<br/>';
	    $html .='<br/>';
	    $html .= "</td>";
	
	$html .= "</tr>";*/
	
	$html .="</table>";  
	return $html;		          
    }
    
    /*
     *All ajax action call...
     */
    static function carasoleBlockUpdate(){
	$html ="";
	global $post;
	if(isset($_POST['data'])){
	    //foreach($_POST['data'] as $val){
		update_post_meta((integer)$_POST['id'],'_carasoleBlock',json_encode($_POST['data']));
	    //}
	}
	
	
    }

static function terms_region_provinces(){
	$regions = self::azull_region();
	$provinces = self::azull_provinces();
	$results = array(
			 'regions' =>$regions['regions'],
			 'provinces' =>$provinces['provinces']	
			);
	die(json_encode($results,JSON_FORCE_OBJECT));
    }
    static function loadaTax(){
	 $azullTax=false;
        
	if(isset($_POST['country'])  && $_POST['country']!='--'){
	    $azullTax=get_option('country_tax_'.$_POST['country']);

	}
	 if( isset($_POST['region'] ) && $_POST['region']!='' && $_POST['region']!='--'){
	    
	   $azullTax =get_option('region_tax_'.$_POST['region']);   	
	}	 
	if( isset($_POST['provinces'] ) && $_POST['provinces']!='' && $_POST['provinces']!='--'){
	   $azullTax =get_option('province_tax_'.$_POST['provinces']);   	
	}	 
	/* Date : 20-05-2016
	if( isset($_POST['province'] ) && $_POST['province']!='' && $_POST['province']!='--'){
	   $azullTax =get_option('province_tax_'.$_POST['province']);   	
	}*/	
	if($azullTax){
	   $azullTax = json_decode($azullTax,true);
	}
     

				    $html .='<tr>';
					$html .='<th></th>';
					$html .='<td><label style="width: 65px;display:inline-block">'.__('In','azull').'(%)</label><label style="width: 103px;display:inline-block">'.__('Min','azull').'</label></td>'; 		

                   //$html .='<td><label style="width: 65px;display:inline-block">'.$obj->getTranslatedString('en','nl','In').'(%)</label><label style="width: 103px;display:inline-block">'.$obj->getTranslatedString('en','nl','Min').'</label></td>';

				    $html .='</tr>';
				    
				    $html .='<tr>';
					$html .='<th><label>'.__('VAT','azull').'</label></th>';
					$html .='<td>';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="4" size="4" name="azullTax[vat][per]"  value="'.((isset($azullTax['vat']['per'])) ? $azullTax['vat']['per'] :'').'" />';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="10" size="10" name="azullTax[vat][min]"  value="'.((isset($azullTax['vat']['min'])) ? $azullTax['vat']['min'] :'').'" />'; 
					    $html .='<br><span class="description">'.__('Enter value added tax in','azull').' % (xx.xx).</span>';
					    //$html .='<br><span class="description">'.$obj->getTranslatedString('en','nl','Enter value added tax intdiv(dividend, divisor)').' % (xx.xx).</span>';

					$html .='</td>';
				    $html .='</tr>';
				    
				    $html .='<tr>';
					$html .='<th><label>'.__('Transmission tax','azull').'</label></th>';
					//$html .='<th><label>'.$obj->getTranslatedString('en','nl','Transmission tax').'</label></th>';

					$html .='<td>';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="4" size="4" name="azullTax[transmissionTax][per]"  value="'.((isset($azullTax['transmissionTax']['per'])) ? $azullTax['transmissionTax']['per'] :'').'" />';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="10" size="10" name="azullTax[transmissionTax][min]"  value="'.((isset($azullTax['transmissionTax']['min'])) ? $azullTax['transmissionTax']['min'] :'').'" />'; 
					    $html .='<br><span class="description">'.__('Enter transmission tax in','azull').' % (xx.xx).</span>';
					    //$html .='<br><span class="description">'.$obj->getTranslatedString('en','nl','Enter transmission tax in').' % (xx.xx).</span>';

					$html .='</td>';
				    $html .='</tr>';
				    
				    $html .='<tr>';
					$html .='<th><label>'.__('Stamp Duty','azull').'</label></th>';
					$html .='<td>';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="4" size="4" name="azullTax[stampDuty][per]"  value="'.((isset($azullTax['stampDuty']['per'])) ? $azullTax['stampDuty']['per'] :'').'" />';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="10" size="10" name="azullTax[stampDuty][min]"  value="'.((isset($azullTax['stampDuty']['min'])) ? $azullTax['stampDuty']['min'] :'').'" />'; 
					    $html .='<br><span class="description">'.__('Enter stamp duty in','azull').' % (xx.xx).</span>';
					$html .='</td>';
				    $html .='</tr>';
				    
				    $html .='<tr>';
					$html .='<th><label>'.__('Notary costs','azull').'</label></th>';
					$html .='<td>';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="4" size="4" name="azullTax[notaryCost][per]"  value="'.((isset($azullTax['notaryCost']['per'])) ? $azullTax['notaryCost']['per'] :'').'" />';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="10" size="10" name="azullTax[notaryCost][min]"  value="'.((isset($azullTax['notaryCost']['min'])) ? $azullTax['notaryCost']['min'] :'').'" />'; 
					    $html .='<br><span class="description">'.__('Enter notary costs in','azull').' % (xx.xx).</span>';
					$html .='</td>';
				    $html .='</tr>';
				    
				    $html .='<tr>';
					$html .='<th><label>'.__('Enter lawyer costs in','azull').'</label></th>';
					$html .='<td>';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="4" size="4" name="azullTax[lawyerCosts][per]"  value="'.((isset($azullTax['lawyerCosts']['per'])) ? $azullTax['lawyerCosts']['per'] :'').'" />';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="10" size="10" name="azullTax[lawyerCosts][min]"  value="'.((isset($azullTax['lawyerCosts']['min'])) ? $azullTax['lawyerCosts']['min'] :'').'" />'; 
					    $html .='<br><span class="description">'.__('Enter lawyer costs in','azull').' % (xx.xx).</span>';
					$html .='</td>';
				    $html .='</tr>';
				    
				    $html .='<tr>';
					$html .='<th><label>'.__('Utilities connection cost','azull').'</label></th>';
					$html .='<td>';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="4" size="4" name="azullTax[utilitiesConnectionCost][per]"  value="'.((isset($azullTax['utilitiesConnectionCost']['per'])) ? $azullTax['utilitiesConnectionCost']['per'] :'').'" />';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="10" size="10" name="azullTax[utilitiesConnectionCost][min]"  value="'.((isset($azullTax['utilitiesConnectionCost']['min'])) ? $azullTax['utilitiesConnectionCost']['min'] :'').'" />'; 
					    $html .='<br><span class="description">'.__('Utilities connection cost in','azull').' % (xx.xx).</span>';
					$html .='</td>';
				    $html .='</tr>';
				    
				    $html .='<tr>';
					$html .='<th><label>'.__('Buyer costs','azull').'</label></th>';
					$html .='<td>';
					
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="4" size="4" name="azullTax[buyerCosts][per]"  value="'.((isset($azullTax['buyerCosts']['per'])) ? $azullTax['buyerCosts']['per'] :'').'" />';
					    $html .='<input type="text" autocomplete="off" class="decimal" maxlength="10" size="10" name="azullTax[buyerCosts][min]"  value="'.((isset($azullTax['buyerCosts']['min'])) ? $azullTax['buyerCosts']['min'] :'').'" />'; 
					    $html .='<br><span class="description">'.__('Enter Buyer costs in','azull').' % (xx.xx).</span>';
					$html .='</td>';
				    $html .='</tr>';
				    
				    $html .='<tr style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);">';					
					$html .='<td colspan="2">';
					    $html .='<span class="description"><strong>'.__('Note','azull').':</strong>'.__('Field marked "*", % will be caculate aginst property cost and will be used as value. Min rule will apply as other fields.','azull').'</span><br/>';
					    $html .='<span class="description">'.__('Tax and overhead cost should be added for each country/region/provinces, depending on you want to apply it based on country, region or provinces.','azull').'</span>';
					$html .='</td>';
				    $html .='</tr>';

				    die($html);
    }
    static function terms_region_place(){
	$regions = self::region();
	$places = self::place();	
	
	
	$results = array(
			 'regions' =>$regions['regions'],
			 'places' =>$place['places']	
			);
	die(json_encode($results,JSON_FORCE_OBJECT));
    }
    
    
    static function azull_region(){
	$regions = self::region();
	$provinces = self::provinces();
	$place = self::place();

	$currentLang = qtrans_getLanguage();
	foreach($regions as $region) {
		$newregion = $region;
		if ($newregion['name'] != "--") $newregion['name'] = qtrans_use($currentLang, $newregion['name'],false);
		$newregions[] = $newregion;
	}
	$regions = $newregions;

	foreach($provinces as $province) {
		$newprovince = $province;
		if ($newprovince['name'] != "--") $newprovince['name'] = qtrans_use($currentLang, $newprovince['name'],false);
		$newprovinces[] = $newprovince;
	}
	$provinces = $newprovinces;

	foreach($places as $place) {
		$newplace = $place;
		if ($newplace['name'] != "--") $newplace['name'] = qtrans_use($currentLang, $newplace['name'],false);
		$newplaces[] = $newplace;
	}
	$places = $newplaces;


	$results = array(
			 'regions' =>$regions,
			 'provinces' =>$provinces,
			 'places' =>$place
			);
	die(json_encode($results,JSON_FORCE_OBJECT));
    }
    static function azull_province(){
	$result = array();	
	$provinces = self::provinces();
	$places = self::place();
	$results = array(			
			 'provinces' =>$provinces,
			 'places' =>$places
			);
	die(json_encode($results,JSON_FORCE_OBJECT));
    }
    static function azull_place(){
	$result = array();	
        $place = self::place();
	$results = array(
			 'places' =>$place
			);
	die(json_encode($results,JSON_FORCE_OBJECT));
    }
    private function region(){
	
	$result = array();	
	$result[0]['term_id'] ='';
	$result[0]['name']='--';
	
	$i=1;	
	$regions = get_terms('region', array('orderby' => 'name', 'hide_empty' => false));
	//$regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));  
	    foreach($regions as $region){
		$taxonomy_meta = get_option('azull_taxonomy_meta_'.$region->term_id);
		if(isset($taxonomy_meta['country']) && isset($_POST['country']) && $taxonomy_meta['country']==$_POST['country']){
		    
		    $result[$i]['term_id']=$region->term_id;
		    $result[$i]['name']=$region->name;
		     $i++;
		}    
		   
	    }
	    
	return $result;
	
    }
    private function provinces(){
	$result=array();
	
	$result[0]['term_id']='';
	$result[0]['name']='--';
	$i=1;
	
	    $provinces = get_terms('provinces', array( 'orderby' => 'name', 'hide_empty' => false));
	    //$provinces = get_terms('provinces', array( 'orderby' => 'slug', 'hide_empty' => false));
	       foreach($provinces as $province){
		    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$province->term_id);
		    if(isset($taxonomy_meta['country']) && $taxonomy_meta['country']==$_POST['country']){
			
			    if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$_POST['region']){
				$result[$i]['term_id']=$province->term_id;
				$result[$i]['name']=$province->name;
				 $i++;
			    }else{
				$result[$i]['term_id']=$province->term_id;
				$result[$i]['name']=$province->name;				
				$i++;
			    }
			    
			    
			}
		   
	    }
	   

	return $result;
    }
    private function place(){
	
	$result = array();
	$result[0]['term_id'] ='';
	$result[0]['name']='--';
	
	$i = 1;	
	    $places = get_terms('place', array('orderby' => 'name', 'hide_empty' => false));
	    //$places = get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));
	    foreach($places as $place){
		
		$taxonomy_meta = get_option('azull_taxonomy_meta_'.$place->term_id);
		if(isset($taxonomy_meta['country']) && isset($_POST['country']) && $taxonomy_meta['country']==$_POST['country']){
		    
		    if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$_POST['region']){			    
				
				if(isset($taxonomy_meta['provinces'])  && $taxonomy_meta['provinces']==$_POST['province']){
				    $result[$i]['term_id'] =$place->term_id;
				    $result[$i]['name']=$place->name;
				    $i++;
				}else{
				    
				    $result[$i]['term_id'] =$place->term_id;
				    $result[$i]['name']=$place->name;
				    $i++;
				}
		    }			
		}  
	    
	    }
	    return $result;
    }
    
    static function finincial_data($post_id){
	$post_id = (int)$_POST['post_id'];	
	global $aj_config;
	$azullTax=false;
	$currency = (isset($aj_config['currency']) ? $aj_config['currency'] :'');
	
	if(isset($_POST['country']) && $_POST['country']!='--'){
	    $azullTax=get_option('country_tax_'.$_POST['country']);
	}
	if( isset($_POST['region'] ) && $_POST['region']!='' && $_POST['region']!='--'){
	    
	    if(get_option('region_tax_'.$_POST['region']))
		$azullTax =get_option('region_tax_'.$_POST['region']);   	
	}	 
	if( isset($_POST['provinces'] ) && $_POST['provinces']!='' && $_POST['provinces']!='--'){
	    if(get_option('province_tax_'.$_POST['provinces']))
	   $azullTax =get_option('province_tax_'.$_POST['provinces']);   	
	}
	

	if($azullTax){
	   $default = json_decode($azullTax,true);
	  
	}else{
	    
	    $country=get_post_meta($post_id,'_country',true);
	    $region=get_post_meta($post_id,'_region',true);
	    $province=get_post_meta($post_id,'_province',true);
	    
	    if(isset($country)){
	     if(get_option('country_tax_'.$country)) 	
	     $azullTax=get_option('country_tax_'.$country);
	    }
	    if(isset($region)){
	       if(get_option('region_tax_'.$region))
	       $azullTax =get_option('region_tax_'.$region);   	
	    }	 
	    if( isset($province)){
	       if(get_option('province_tax_'.$region))	
	       $azullTax =get_option('province_tax_'.$province);
	    }
	    if($azullTax)
	    $default = json_decode($azullTax,true);	
	}
	
	
	$buildType=get_post_meta($post_id,'_buildType',true);
	$html .="<tr>";
	    $html .="<td><label>".__('Build Type','azull')."</label>";
		$html .="<select id='buildType'  name='property_meta_finance[buildType]' onchange='calculateSum(this);'>";
		    $html .="<option value='1' ".((isset($buildType) && 1==$buildType)? 'selected':'').">".__('New','azull')."</option>";
		    $html .="<option value='2' ".((isset($buildType) && 2 == $buildType) ? 'selected' : '').">".__('Resale','azull')."</option>";
		$html .="</select>";
	    $html .="<br><span class='description'>".__('Select Build type','azull')."</span>";
	    $html .="<td>";	
	 $html .="<tr>";
	
	$html .="<tr>";	
		$html .="<td><label>".__('Sales Price','azull')."</label>";
		$html .="<input onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' autocomplete='off' id='salesPrice' class='decimal meta_sale_price rule1 rule2' maxlength='12' type='text' name='property_meta_finance[salesPrice]' value='".((get_post_meta($post_id,"_salesPrice",true)) ? get_post_meta($post_id,"_salesPrice",true):"")."' />";
		$html .="<br><span class='description'>".__('Enter sales price','azull')." ".$currency ."(xxxxxx.xx)</span>";
		$html .="</td>";	
	$html .="</tr>";   
	
	$vat_min = ((isset($default["vat"]["min"]) && $default["vat"]["min"] != '') ? $default["vat"]["min"] : '');
	$vat_per = ((isset($default["vat"]["per"]) && $default["vat"]["per"] != '') ? $default["vat"]["per"] : '');	
	$vat_per = ((isset($val["vat"]) && $val["vat"] != '') ? max($val["vat"],$vat_per) : $vat_per);
	
	$html .="<tr>";    
	    $html .="<td><label>".__('VAT','azull')."</label>";
	    $html .="<input type='text' onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' id='vat'  data_min='".$vat_min."' autocomplete='off' class='decimal percent rule1 sum' maxlength='4' name='property_meta_finance[vat]'  value='".$vat_per."' />";
	    $html .="<br><span class='description'>".__('Enter value added tax in','azull')." %(xx).</span>";
	     $html .="</td>";
	$html .="</tr>";
	
	$transmissionTax_min = ((isset($default["transmissionTax"]["min"]) && $default["transmissionTax"]["min"] != '') ? $default["transmissionTax"]["min"] :'');
	$transmissionTax_per = ((isset($default["transmissionTax"]["per"]) && $default["transmissionTax"]["per"] != '') ? $default["transmissionTax"]["per"] : '');
	$transmissionTax_per = ((isset($val["transmissionTax"]) && $val["transmissionTax"] != '') ?  max($val["transmissionTax"],$transmissionTax_per) : $transmissionTax_per);
	
	$html .="<tr>";
	    $html .="<td><label>".__('Transmission tax','azull')."</label>";
	    $html .="<input onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' id='transmissionTax'   data_min='".$transmissionTax_min."' autocomplete='off' class='decimal percent rule2 sum' maxlength='4' type='text' name='property_meta_finance[transmissionTax]' value='".$transmissionTax_per."' />"; 
	    $html .="<br><span class='description'>".__('Enter transmission tax in','azull')." %(xx).</span>";
	    $html .="<td>";
	$html .="<tr>";
	
	$stampDuty_min = ((isset($default["stampDuty"]["min"]) && $default["stampDuty"]["min"] != '') ? $default["stampDuty"]["min"] : '');
	$stampDuty_per = ((isset($default["stampDuty"]["per"]) && $default["stampDuty"]["per"] != '') ? $default["stampDuty"]["per"] : '');
	$stampDuty_per = ((isset($val["stampDuty"]) && $val["stampDuty"] != '') ?  max($val["stampDuty"],$stampDuty_per) : $stampDuty_per);
	
	$html .="<tr>";
	    $html .="<td><label>".__('Stamp Duty','azull')."</label>";
	    $html .="<input onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' autocomplete='off' id='stampDuty'  data_min='".$stampDuty_min."' class='decimal percent rule1 sum' maxlength='4' type='text' name='property_meta_finance[stampDuty]'  value='".$stampDuty_per."' />";
	    $html .="<br><span class='description'>".__('Enter stamp duty in','azull')." %(xx).</span>";
	    $html .="<td>";
	$html .="</tr>";
	
	$notaryCost_min = ((isset($default["notaryCost"]["min"]) && $default["notaryCost"]["min"] != '') ? $default["notaryCost"]["min"] : '');
	$notaryCost_per = ((isset($default["notaryCost"]["per"]) && $default["notaryCost"]["per"] != '') ? $default["notaryCost"]["per"] : '');
	$notaryCost_per = ((isset($val["notaryCost"]) && $val["notaryCost"] != '') ? max($val["notaryCost"],$notaryCost_per) : $notaryCost_per);
	
	$html .="<tr>";
	    $html .="<td><label>".__('Notary costs','azull')."</label>";
	    $html .="<input onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' autocomplete='off' id='notaryCost'  data_min='".$notaryCost_min."' class='decimal percent rule1 rule2 sum' maxlength='4' type='text' name='property_meta_finance[notaryCost]'  value='".$notaryCost_per."' />";
	    $html .="<br><span class='description'>".__('Enter notary costs in','azull')." %(xx).</span>";
	    $html .="<td>";
	$html .="</tr>";
	
	$lawyerCost_min = ((isset($default["lawyerCosts"]["min"]) && $default["lawyerCosts"]["min"] != '') ? $default["tlawyerCosts"]["min"] : '');
	$lawyerCost_per = ((isset($default["lawyerCosts"]["per"]) && $default["lawyerCosts"]["per"] != '') ? $default["lawyerCosts"]["per"] : '');
	$lawyerCost_per = ((isset($val["lawyerCosts"]) && $val["lawyerCosts"] != '') ? max($val["lawyerCosts"],$lawyerCost_per) : $lawyerCost_per);
	
	$html .="<tr>";
	    $html .="<td><label>".__('Lawyer costs','azull')."</label>";
	    $html .="<input onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' autocomplete='off' id='lawyerCost'  data_min='".$lawyerCost_min."' class='decimal percent rule1 rule2 sum' maxlength='4' type='text' name='property_meta_finance[lawyerCost]'  value='".$lawyerCost_per."' />";
	    $html .="<br><span class='description'>".__('Enter lawyer costs in','azull')." %(xx).</span>";
	    $html .="<td>";
	$html .="</tr>";
	
	
	$v=0;
	$utilitiesConnectionCost_min = ((isset($default["utilitiesConnectionCost"]["min"]) && $default["utilitiesConnectionCost"]["min"] != '') ? $default["utilitiesConnectionCost"]["min"] : '');
	
	
	$utilitiesConnectionCost_per = ((isset($default["utilitiesConnectionCost"]["per"]) && $default["utilitiesConnectionCost"]["per"] != '') ? $default["utilitiesConnectionCost"]["per"] : '');
	if(get_post_meta($post_id,"_salesPrice",true) && $utilitiesConnectionCost_per!='')
	$v = ($utilitiesConnectionCost_per/100) * get_post_meta($post_id,"_salesPrice",true); 	
	$v = max($utilitiesConnectionCost_min,$v);	
	$utilitiesConnectionCost_per = ((isset($val["utilitiesConnectionCost"]) && $val["utilitiesConnectionCost"] != '') ? max($val["utilitiesConnectionCost"],$v) : $v);
	
	$html .="<tr>";
	    $html .="<td><label>".__('Utilities connection cost','azull')."</label>";
	    $html .="<input onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' autocomplete='off' id='utilitiesConnectionCost'  data_min='".$utilitiesConnectionCost_min."' class='decimal rule1 rule2 sum' maxlength='10' type='text' name='property_meta_finance[utilitiesConnectionCost]' value='".$utilitiesConnectionCost_per."' />";
	    $html .="<br><span class='description'>".__('Utilities connection cost','azull')." ".$currency ."(xxxxxx.xx).</span>";
	    $html .="<td>";
	$html .="</tr>";
	
	$buyerCost_min = ((isset($default["buyerCosts"]["min"]) && $default["buyerCosts"]["min"] != '') ? $default["buyerCosts"]["min"] : '');
	$buyerCost_per = ((isset($default["buyerCosts"]["per"]) && $default["buyerCosts"]["per"] != '') ? $default["buyerCosts"]["per"] : '');
	$buyerCost_per = ((isset($val["buyerCost"]) && $val["buyerCost"] != '') ? max($val["buyerCost"],$buyerCost_per) : $buyerCost_per);
	
	$html .="<tr>";
	    $html .="<td><label>".__('Buyer costs','azull')."</label>";
	    $html .="<input onkeyup='calculateSum(this);' onkeydown='calculateSum(this);' class='decimal percent rule2 sum' id='buyerCost'   data_min='".$buyerCost_min."' maxlength='4' type='text' name='property_meta_finance[buyerCost]'  value='".$buyerCost_per."' />";
	    $html .="<br><span class='description'>".__('Enter Buyer costs in','azull')." %(xx.xx).</span>";
	    $html .="<td>";
	$html .="</tr>";
	
	$html .="<tr>";
	    $html .="<td><label>".__('Total price','azull')."</label>";
	    $html .="<input style='color: #000!important;' id='finance_total' autocomplete='off' class='decimal' readonly maxlength='12' type='text' name='property_meta_finance[totalPrice]'  value='".((isset($val["totalPrice"]) && $val["totalPrice"] != '') ? $val["totalPrice"] : '')."' />";
	    $html .="<br><span class='description'>".__('Total price in','azull')." ".$currency.".</span>";
	    $html .="<td>";
	$html .="</tr>";
	
	die($html);
 }
    //cutomizing location taxonomy...
    
    static function region_columns($theme_columns) {
	$new_columns = array(
	    'cb' => '<input type="checkbox" />',
	    'name' => __('Name'),
	    'country' => __('Country','azull'),
	    'slug' => __('Slug'),
	    'posts' => __('Properties','azull')
	    );
	return $new_columns;
    }
    static function manage_region_columns($out, $column_name, $term_id) {
	
	$taxonomy_meta = get_option('azull_taxonomy_meta_'.$term_id);
	
		switch ($column_name) {
		    case 'country':
			
			if(isset($taxonomy_meta['country'])){		   
			    $term=get_term( (int)$taxonomy_meta['country'], 'country');		  
			    $out .= qtranxf_use(qtranxf_getLanguage(),$term->name);
			}
			
			break;
	     
		    default:
			break;
		}

		return $out;  

    }
    
    static function provinces_columns($theme_columns) {
	$new_columns = array(
	    'cb' => '<input type="checkbox" />',
	    'name' => __('Name'),
	    'country' => __('Country','azull'),
	    'region' => __('Region','azull'),
	    'slug' => __('Slug'),
	    'posts' => __('Properties','azull')
	    );
	return $new_columns;
    }
    static function manage_provinces_columns($out, $column_name, $term_id) {
	$taxonomy_meta = get_option('azull_taxonomy_meta_'.$term_id);
	 
	switch ($column_name) {
	    case 'country':
		if(isset($taxonomy_meta['country'])){		   
		    $term=get_term( (int)$taxonomy_meta['country'], 'country');		  
		    $out .= qtranxf_use(qtranxf_getLanguage(),$term->name);
		}
		break;
	    case 'region':
		if(isset($taxonomy_meta['region'])){		   
		    $term=get_term( (int)$taxonomy_meta['region'], 'region');		  
		    $out .= qtranxf_use(qtranxf_getLanguage(),$term->name);
		}
		break;
     
	    default:
		break;
	}
	return $out;   
    }
    
    static function place_columns($theme_columns) {
	$new_columns = array(
	    'cb' => '<input type="checkbox" />',
	    'name' => __('Name'),
	    'country' => __('Country','azull'),
	    'region' => __('Region','azull'),
	    'provinces' => __('Provinces','azull'),
	    'slug' => __('Slug'),
	    'posts' => __('Properties','azull')
	    );
	return $new_columns;
    }
    static function manage_place_columns($out, $column_name, $term_id) {
	$taxonomy_meta = get_option('azull_taxonomy_meta_'.$term_id);
	
	switch ($column_name) {
	    case 'country':
		if(isset($taxonomy_meta['country'])){		   
		    $term=get_term( (int)$taxonomy_meta['country'], 'country');		  
		    $out .= qtranxf_use(qtranxf_getLanguage(),$term->name);
		}
		break;
	    case 'region':
		if(isset($taxonomy_meta['region'])){		   
		    $term=get_term( (int)$taxonomy_meta['region'], 'region');		  
		    $out .= qtranxf_use(qtranxf_getLanguage(),$term->name);
		}
		break;
	case 'provinces':
		if(isset($taxonomy_meta['provinces'])){		   
		    $term=get_term( (int)$taxonomy_meta['provinces'], 'provinces');		  
		    $out .= qtranxf_use(qtranxf_getLanguage(),$term->name);
		}
		break;
     
	    default:
		break;
	}
	return $out;   
    }

/* function to add new column in project list
   date: 07/12/2016, Manoj(ab)
*/
function project_columns(){
	$new_columns = array(
	    'cb' => '<input type="checkbox" />',
	    'name' => __('Name'),
	    'pro_name' => __('Proprietor Name','azull'),
	    'slug' => __('Slug'),
	    'posts' => __('Properties','azull')
	    );
	return $new_columns;
}
/* function to display new column value in project list
   date: 07/12/2016, Manoj(ab)
*/
static function manage_project_columns($out, $column_name, $term_id) {
	$taxonomy_meta = get_option('azull_taxonomy_meta_'.$term_id);
	$id=$taxonomy_meta['proprietor'];
	switch ($column_name) {
		case 'pro_name':
			$term = get_term_by( 'id', absint( $id ), 'proprietor' );
			$out  .=qtranxf_use(qtranxf_getLanguage(), $term->name);
			break;
		}
	return $out;   
}




    static function proprietor_columns($theme_columns) {
	$new_columns = array(
	    'cb' => '<input type="checkbox" />',
	    'name' => __('Name'),
	    //'proprietorship' => __('proprietorship','azull'),
        'proprietorship' => __('Proprietor Type','azull'),
	    'vat' => __('BTW'),
	    'slug' => __('Slug'),
	    'posts' => __('Properties','azull')
	    );
	return $new_columns;
    }
    static function manage_proprietor_columns($out, $column_name, $term_id) {
	$taxonomy_meta = get_option('azull_taxonomy_meta_'.$term_id);
	switch ($column_name) {
	    case 'proprietorship':
		
		/*if(isset($taxonomy_meta['type'])){		   
		    if($taxonomy_meta['type']==1)		  
		    $out .= __("Agent",'azull');
		    
		    if($taxonomy_meta['type']==2)		  
		    $out .= __("Owner",'azull');
		    
		    if($taxonomy_meta['type']==3)		  
		    $out .= __("Builder",'azull');
		}*/

if(isset($taxonomy_meta['type'])&& is_array($taxonomy_meta['type'])){		   

  if((in_array(1, $taxonomy_meta["type"])) && (in_array(2, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
        $out .="Builder, Agent, Owner";
    }else if((in_array(1, $taxonomy_meta["type"])) && (in_array(2, $taxonomy_meta["type"]))){
              $out .= "Agent, Owner";
    }
    else if((in_array(2, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
              $out .= "Builder, Owner";
    }
    else if((in_array(1, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
              $$out .= "Agent, Builder";
    }else if(in_array(1, $taxonomy_meta["type"])){
        $out .= "Agent";
    }
    else if(in_array(2, $taxonomy_meta["type"])){
        $out .= "Owner";
    }
    else if(in_array(3, $taxonomy_meta["type"])){
        $out .= "Builder";
    }
}else{

    if($taxonomy_meta['type']==1)		  
    $out .= __("Agent",'azull');
    
    if($taxonomy_meta['type']==2)		  
    $out .= __("Owner",'azull');
    
    if($taxonomy_meta['type']==3)		  
    $out .= __("Builder",'azull');
		}
		
		break;
     case 'vat':
      if(isset($taxonomy_meta['vat_no']) && $taxonomy_meta['vat_no']!=''){	
        echo $taxonomy_meta['vat_no'];
      }
     break;
	    default:
		break;
	}
	return $out;   
    }
    /**
	* filter for providing translation based on saved options get_option( 'azullString')
	* @param : string to be translated
	* @param : domain should be alwasy azull
	* todo: 
	*/
   static function azull_gettext_filter($trans_string,$string, $domain ) {
   	 return $string;   
	    global $q_config, $azullString,$azullString_s;
		 	$lng = $q_config['language'];
 		  
        if($domain=='azull' || $domain=='wp'){
	      	if(isset($azullString)){
	      		foreach ($azullString as $key =>  $val){			
			     if (isset($val[en]) && ($val[en] === $string)) {
			       return $azullString[$key][$lng];
			     }
		       }    
	      	}	       
	    if(isset($azullString_s)){	       
		        foreach ($azullString_s as $key => $val){			
				    if (isset($val[en]) && ($val[en] === $string)) {
				       return $azullString_s[$key][$lng];
				    }
			   }
			}  
       	}
	       return $trans_string ;
	 }
//***** import property data from azull.info to azull.biz ****//
function send_import_properties_request() {
   
   global $wpdb, $current_user;
      $err = false;
      if ($_POST['step'] == '')
         $err .=__("Please enter your first name!", 'azull') . "<br/>";

      $data['html'] = "<p id='ajaxmsg' class='error'>" . $err . "</p>";
      if ($err)
         die(json_encode($data));

if (isset($_POST["step"])) {
	$azull_utility_object = new Azull_Utility();
    $step = $_POST["step"];
    switch ($step) {
        case '1':
        	echo 'step1';exit();
            //$azull_utility_object->azull_db_import_step_1();
            break;
        case '2':
        	echo 'step2';exit();
            //$azull_utility_object->azull_db_import_step_2();
            break;
        case '3':
        	echo 'step3';exit();
            //$azull_utility_object->azull_db_import_step_3();
            break;
        //case '4':
        	//echo 'step4';exit();
            //$azull_utility_object->azull_db_import_step_4();
            //break;
    }
}
echo 'Nothing';exit();
      
      die(json_encode($data));
   }

/*
* Date : 22-03-2016
* Method : To download image to local
*/

 static function download($url, $path)
{
  # open file to write
  $fp = fopen ($path, 'w+');
  # start curl
  $ch = curl_init();
  curl_setopt( $ch, CURLOPT_URL, $url );
  # set return transfer to false
  curl_setopt( $ch, CURLOPT_RETURNTRANSFER, false );
  curl_setopt( $ch, CURLOPT_BINARYTRANSFER, true );
  curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
  # increase timeout to download big file
  curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, 10 );
  # write data to local file
  curl_setopt( $ch, CURLOPT_FILE, $fp );
  # execute curl
  curl_exec( $ch );
  # close curl
  curl_close( $ch );
  # close local file
  fclose( $fp );

  if (filesize($path) > 0) return true;
}

function get_azull_info_property_data($sql_queries){
	if(isset($sql_queries) && !empty($sql_queries)){
		$ch = curl_init();
		$url = 'http://www.azull.info/getInfo.php';
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		$postData = array('user' => 'cis', 'pass' => 'cis','sql_qry'=>$sql_queries);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);   
		$output = curl_exec($ch);
		if (!curl_errno($ch)) {
		  //print curl_error($ch);
			curl_close($ch);
			//$outputData = json_decode($output,true);
			$outputData = unserialize($output);
			if ($outputData['status'] == 1) {
			  return $outputData['data'];
			} else {
			  return false;
			  //echo $outputData['msg'];
			}
		}
	}
}


function import_azull_info_properties($params) {
	//print_r($params);die('$params');
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    require_once(ABSPATH . "wp-admin" . '/includes/image.php');
    $gt_nl_var = new translate("auto","nl");
    $gt_var = new translate("auto","en");
    $gt_es_nl = new translate("es","nl");
    global $wpdb;
    //ini_set('max_execution_time', 0); //300 seconds = 5 minutes     
    // get all properties data from azull.info
    $property_tbl = 'p35p6_nbreal_properties';
    $location_tbl = 'p35p6_nbreal_locations';
    $region_tbl = 'p35p6_nbreal_regions';
    $builder_tbl = 'p35p6_nbreal_builders';
    $country_tbl = 'p35p6_nbreal_countries';
    $city_tbl = 'p35p6_nbreal_cities';
    $category_tbl = 'p35p6_nbreal_categories';
    $t_available_record = 0;
    $limit = (isset($params['limit']) && !empty($params['limit']))?$params['limit']:'';
    $t_property_sql = "SELECT $property_tbl.*,$builder_tbl.title as p_builder_title,$builder_tbl.phone as p_builder_phone,$builder_tbl.email as p_builder_email,$builder_tbl.website as p_builder_website,$region_tbl.title as p_region_title,$country_tbl.title as p_location_country_title,$city_tbl.title as p_location_city_title,$category_tbl.title as p_category_title
                FROM $property_tbl
                LEFT JOIN $builder_tbl ON $builder_tbl.nbreal_builder_id=$property_tbl.nbreal_builder_id 
                LEFT JOIN $location_tbl ON $location_tbl.nbreal_location_id=$property_tbl.nbreal_location_id
                LEFT JOIN $country_tbl ON $country_tbl.nbreal_country_id=$location_tbl.nbreal_country_id 
                LEFT JOIN $region_tbl ON $region_tbl.nbreal_region_id=$location_tbl.nbreal_region_id 
                LEFT JOIN $city_tbl ON $city_tbl.nbreal_city_id=$location_tbl.nbreal_city_id 
                LEFT JOIN $category_tbl ON $category_tbl.nbreal_category_id=$property_tbl.nbreal_category_id where $property_tbl.website = 1 AND $property_tbl.enabled = 1 order by $property_tbl.nbreal_property_id";
    $t_properties = $this->get_azull_info_property_data($t_property_sql);
    if(isset($params['filter_remove_property']) && $params['filter_remove_property']==1){
    	$this->filter_and_remove_properties();
    }
    $t_available_record = count($t_properties);
    //print('<pre>');print_r($t_properties);die('ok');
   // get all properties  AND $property_tbl.enabled = 1
    $property_sql = "SELECT $property_tbl.*,$builder_tbl.title as p_builder_title,$builder_tbl.phone as p_builder_phone,$builder_tbl.email as p_builder_email,$builder_tbl.website as p_builder_website,$region_tbl.title as p_region_title,$country_tbl.title as p_location_country_title,$city_tbl.title as p_location_city_title,$category_tbl.title as p_category_title
                FROM $property_tbl
                LEFT JOIN $builder_tbl ON $builder_tbl.nbreal_builder_id=$property_tbl.nbreal_builder_id 
                LEFT JOIN $location_tbl ON $location_tbl.nbreal_location_id=$property_tbl.nbreal_location_id
                LEFT JOIN $country_tbl ON $country_tbl.nbreal_country_id=$location_tbl.nbreal_country_id 
                LEFT JOIN $region_tbl ON $region_tbl.nbreal_region_id=$location_tbl.nbreal_region_id 
                LEFT JOIN $city_tbl ON $city_tbl.nbreal_city_id=$location_tbl.nbreal_city_id 
                LEFT JOIN $category_tbl ON $category_tbl.nbreal_category_id=$property_tbl.nbreal_category_id where $property_tbl.website = 1 AND $property_tbl.enabled = 1 order by $property_tbl.nbreal_property_id $limit";// AND $property_tbl.enabled = 1 
                //print_r($property_sql);die('$property_sql');
    $nbreal_Properties = $this->get_azull_info_property_data($property_sql);
    //print('<pre>');print_r($nbreal_Properties);die('helo');
    //print_r($gt_es_nl->get('Costa Blanca Sur'));die('chk');
    if(isset($nbreal_Properties) && !empty($nbreal_Properties)){
    	$t_record_added = (isset($params['total_added_records']) && !empty($params['total_added_records']))?$params['total_added_records']:0;
    	$t_record_updated = (isset($params['total_updated_records']) && !empty($params['total_updated_records']))?$params['total_updated_records']:0;
    	$t_record_travesed = (isset($params['total_traverse_record']) && !empty($params['total_traverse_record']))?$params['total_traverse_record']:0;
	    foreach ($nbreal_Properties as $j_property) {
	        //Main property id in joomla
	        $property_ref_id = $j_property['nbreal_property_id'];
	        //Check above posts exists or not in wp db posts and postmeta tables
	        $querystr = "SELECT $wpdb->postmeta.post_id,$wpdb->posts.post_modified,count($wpdb->postmeta.post_id)
	                    FROM $wpdb->postmeta
	                    join $wpdb->posts on $wpdb->posts.ID = $wpdb->postmeta.post_id
	                    WHERE
	                    (meta_key = '_nreal_id' AND meta_value = '" . $property_ref_id . "')
	                    GROUP BY post_id;";
	        $postid = $wpdb->get_results($querystr, ARRAY_A);
	        //Fetch posts contents part in different languages  
	        $en_t = $j_property['title'];
	        $en_d = $j_property['description'];

	        $table = 'p35p6_falang_content';
	        $fr_t_sql = "SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=2";
	        $fr_t = $this->get_azull_info_property_data($fr_t_sql);
	        $fr_d_sql = "SELECT * FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=2";
	        $fr_d = $this->get_azull_info_property_data($fr_d_sql);
	        $nl_t_sql = "SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=4";
	        $nl_t = $this->get_azull_info_property_data($nl_t_sql);
	        $nl_d_sql = "SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=4";
	        $nl_d = $this->get_azull_info_property_data($nl_d_sql);

	        /*$table = 'p35p6_falang_content'; // get posts details excluding english language like in french and in netherland                 
	        $fr_t = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=2", ARRAY_A);
	        $fr_d = $wpdb->get_results("SELECT * FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=2", ARRAY_A);
	        $nl_t = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=4", ARRAY_A);
	        $nl_d = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=4", ARRAY_A);*/

	        // create title and content for multilingual format
	        $title = "[:en]" . ucwords($en_t);
	        $title .="[:fr]" . $fr_t[0]['value'];
	        $title .="[:nl]" . $nl_t[0]['value'] . "[:]";
	        $content = "[:en]" . $en_d;
	        $content .="[:fr]" . $fr_d[0]['value'];
	        $content .="[:nl]" . $nl_d[0]['value'] . "[:]";
	        
	        $p_cate_title=(isset($j_property['p_category_title']) && !empty($j_property['p_category_title']))?ucwords($gt_nl_var->get($j_property['p_category_title'])):$j_property['p_category_title'];
	        $p_city_title=(isset($j_property['p_location_city_title']) && !empty($j_property['p_location_city_title']))?ucwords($gt_nl_var->get($j_property['p_location_city_title'])):$j_property['p_location_city_title'];
	        $p_region_title=(isset($j_property['p_region_title']) && !empty($j_property['p_region_title']))?ucwords($gt_es_nl->get($j_property['p_region_title'])):$j_property['p_region_title'];
	        $p_country_title=(isset($j_property['p_location_country_title']) && !empty($j_property['p_location_country_title']))?ucwords($gt_nl_var->get($j_property['p_location_country_title'])):$j_property['p_location_country_title'];
			$property_post_name=$property_ref_id.'-'.$p_cate_title.'-te-koop-'.$p_city_title.'-'.$p_region_title.'-'.$p_country_title;
			$p_post_name = str_replace(' ', '-', $property_post_name);
		    $post_name = str_replace('--', '-',str_replace(',', '', str_replace('.', '', $p_post_name)));
		    $post_name = str_replace('--', '-',$post_name);
	        //Create array for insert it in wp_posts table
	        $property = array(
	            'post_author' => 1,
	            'post_title' => iconv('ISO-8859-1','UTF-8', $title),
	            'post_content' => iconv('ISO-8859-1','UTF-8', $content),
	            'post_status' => 'publish',
	            'post_type' => 'property',
	            'post_name' => iconv('ISO-8859-1','UTF-8', $post_name),//str_replace(" ", "-", $en_t),
	            //'post_name' => str_replace(" ", "-", $en_t),
	            'post_modified' => $j_property["modified_on"]);
	        $post_parent = 0;
	        $is_new = 0;
	        $add_update_gallery = 0;
	        $wp_post_id = 0;
	        //print('<pre>');print_r($property);die('kk2');
	        // check if posts already exists in azull.biz
	        if (isset($postid[0]['post_id']) && !empty($postid[0]['post_id']) && $postid[0]['post_id'] != 0) {
	        	$post_parent = $postid[0]['post_id'];
	        	$wp_post_id = $postid[0]['post_id'];
	        	$p_import_date = get_post_meta($postid[0]['post_id'], '_import_date', true );
				$date1=strtotime($p_import_date);
				$date2=strtotime($j_property['modified_on']);
				$diff=$date2-$date1;
	            if ($diff > 0) {
	                //update post
	                $property['ID'] = $postid[0]['post_id'];
	                $post_parent = wp_update_post($property, false);
	                update_post_meta($postid[0]['post_id'], '_import_date',$j_property['modified_on']);
	                //$add_update_gallery = 1;
	                $t_record_updated = $t_record_updated + 1;
	            }
	        } else {
	            //add new post in azull.biz for property post type
	            $post_parent = wp_insert_post($property, false);
	            $wp_post_id = $post_parent;
	            update_post_meta($post_parent, '_import_date',$j_property['modified_on']);
	            $is_new = 1;
	            $add_update_gallery = 1;
	            $t_record_added = $t_record_added + 1;
	        }
	        if (isset($post_parent) && $post_parent!=0) {
	        	$t_record_travesed++;
	            //handle meta keyword start
	            $en_kt = $j_property['metakey'];  // from properties table
	            $en_kd = $j_property['metadesc'];   // from properties table

	            $table = 'p35p6_falang_content';
	            $fr_kt_sql = "SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=2";
	        	$fr_kt = $this->get_azull_info_property_data($fr_kt_sql);
	        	$fr_kd_sql = "SELECT * FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metadesc' AND language_id=2";
	        	$fr_kd = $this->get_azull_info_property_data($fr_kd_sql);
	        	$nl_kt_sql = "SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=4";
	        	$nl_kt = $this->get_azull_info_property_data($nl_kt_sql);
	        	$nl_kd_sql = "SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metadesc' AND language_id=4";
	        	$nl_kd = $this->get_azull_info_property_data($nl_kd_sql);


	            /*$table = 'p35p6_falang_content'; // get posts details excluding english language like in french and in netherland (language_id=1 english, 2= fr, 4=nl)   
	            $fr_kt = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=2", ARRAY_A);
	            $fr_kd = $wpdb->get_results("SELECT * FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metadesc' AND language_id=2", ARRAY_A);
	            $nl_kt = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=4", ARRAY_A);
	            $nl_kd = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metadesc' AND language_id=4", ARRAY_A);*/
	            //create key and description for multilingual format
	            $ktitle = "[:en]" . $en_kt;
	            $ktitle .="[:fr]" . $fr_kt[0]['value'];
	            $ktitle .="[:nl]" . $nl_kt[0]['value'] . "[:]";
	            $kcontent = "[:en]" . $en_kd;
	            $kcontent .="[:fr]" . $fr_kd[0]['value'];
	            $kcontent .="[:nl]" . $nl_kd[0]['value'] . "[:]";
	            update_post_meta($post_parent, 'property_meta:title', $title);//get from above as we fetch it already  for title 
	            update_post_meta($post_parent, 'property_meta:keywords', $ktitle);
	            update_post_meta($post_parent, 'property_meta:description', $kcontent);
	            //add/update post meta for uniqqely identify that properties are imported from azull.info
	            update_post_meta($post_parent,'_azullinfo_import', 1);
	            //$add_update_gallery=1;
	            if (isset($add_update_gallery) && $add_update_gallery == 1) {
		            //get attachments files for property  
		            $gallery_table = 'p35p6_nbreal_files';
		            $gallery_sql = "SELECT * FROM " . $gallery_table . " where nbreal_property_id=" . $property_ref_id . " ORDER BY ordering ASC";
	        		$gallerys_nbreal = $this->get_azull_info_property_data($gallery_sql);

		            //$gallerys_nbreal = $wpdb->get_results("SELECT * FROM " . $gallery_table . " where nbreal_property_id=" . $property_ref_id . ' ORDER BY ordering ASC', ARRAY_A);
		            $uploads = wp_upload_dir();
		            $i = 0;
		            $gallery = array();
					$base_path = str_replace("/wp-required","",$uploads['basedir']);
		            foreach ($gallerys_nbreal as $gallery_nbreal) {
		               // code to check image exist in remote server
		            	$gallery_nbreal_file_title = $gallery_nbreal['file_title'];
			            $remote_image_url = 'http://www.azull.info/media/com_nbreal/files/properties/original/'.$gallery_nbreal['nbreal_property_id'].'/'.$gallery_nbreal_file_title;
			            if(isset($remote_image_url) && !is_array($remote_image_url)) { // check should not array
				            $ch = curl_init($remote_image_url);
				                  curl_setopt($ch, CURLOPT_NOBODY, true);
				                  curl_exec($ch);
				            $retcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				            if($retcode==200){
				                //$file_name = $base_path . '/original/' . $property_ref_id . "/" . $gallery_nbreal_file_title;
								$j_title=$post_name.'-'.$i;//$gallery_nbreal['nbreal_property_id'].'-'.$p_cate_title.'-te-koop-'.$p_city_title.'-'.$p_region_title.'-'.$p_country_title.'-'.$i;
					            $imgtitle = str_replace(' ', '-', $j_title);
					            $name = str_replace('--', '-',str_replace(',', '', str_replace('.', '', $imgtitle)));
								//$wp_filetype = wp_check_filetype( basename( $file_name ), null );
					            $wp_filetype = wp_check_filetype( basename($remote_image_url), null );


						        $file_name_new = $base_path.$uploads['subdir'].'/'.$name.'.'.$wp_filetype['ext'];
						        if($this->download($remote_image_url, $file_name_new)){
	              					chmod($filename,0777);
					                /*if (!file_exists($file_name_new) && file_exists($file_name)) {
					                    copy($file_name, $file_name_new);
					                }*/
					                $title=preg_replace('/\.[^.]+$/', '', $name);
					                $attachment = array(
					                    'guid' => $uploads['url']."/".basename($filename),
					                    'post_mime_type' => $wp_filetype['type'],
					                    'post_title' =>$title,
					                    'post_name' => $title,
					                    'post_content' => '',
					                    'post_parent' => $post_parent,
					                    'post_status' => 'inherit'
					                );
					                $attachment_id = wp_insert_attachment($attachment, $file_name_new, $post_parent);
					                $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_name_new);
					                if (isset($attachment_data) && !empty($attachment_data) && count($attachment_data) > 0) {
					                    wp_update_attachment_metadata($attachment_id, $attachment_data);
					                }
					                if ($attachment_id && $i == 0):
					                    update_post_meta($post_parent, '_thumbnail_id', $attachment_id);
					                else:
					                    $gallery[] = $attachment_id;
					                endif;
					            }
			                }
		          		curl_close($ch);
		            	}
		                $i++;
		            }
		            if (!empty($gallery)) {
		                $encode = base64_encode(json_encode($gallery));
		                update_post_meta((integer) $post_parent, 'property_gallery', $encode);
		            }
	        	}
	            // insert property reference id from joomla to azull.biz 
	            update_post_meta($post_parent, '_nreal_id', (integer) $property_ref_id);
	            //end handle post image
	        }//end if $post_parent
	        if(isset($wp_post_id) && !empty($wp_post_id) && $wp_post_id!=0){
//step 2 for add/update property's taxomomy
	    $nbreal = $j_property;
        $wp_property_post_id = $wp_post_id; // azull.biz property post id
            if (isset($nbreal['n_floors']) && $nbreal['n_floors'] != '') {
                update_post_meta($wp_property_post_id, '_feature_40', $nbreal['n_floors']); //Floors term id = 40 in wp_terms
            }
            if (isset($nbreal['floor_n']) && $nbreal['floor_n'] != '') {
                update_post_meta($wp_property_post_id, '_feature_39', $nbreal['floor_n']); //Floor term id = 39 in wp_terms
            }
            if (isset($nbreal['n_bedrooms']) && $nbreal['n_bedrooms'] != '') {
                update_post_meta($wp_property_post_id, '_feature_37', $nbreal['n_bedrooms']); //Bedrooms term id 37 in wp_terms
            }
            if (isset($nbreal['n_bathrooms']) && $nbreal['n_bathrooms'] != '') {
                update_post_meta($wp_property_post_id, '_feature_36', $nbreal['n_bathrooms']); //Bathrooms term id 36 in wp_terms
            }
            if (isset($nbreal['plus_info']) && $nbreal['plus_info'] != "") {
                update_post_meta($wp_property_post_id, '_moreInformation', $nbreal['plus_info']);
            }
            //add property construction year and project name in postmeta table 
            update_post_meta($wp_property_post_id, '_year', $nbreal['construction_year']);
            update_post_meta($wp_property_post_id, '_propertyName', $nbreal['project_name']);
            /* ========= Room Informations End ====== */
            /* Add financial information of properties Start 
             * get financial information from joomla table p35p6_nbreal_financials
             * get information from joomla in this format
             * [sales_price] => 120400
             * [total_price] => 135540
             * [old_price] => 244000
             * [comission] => 0
             * [reservation_amount] => 3000
             * [monthly_community_fee] => 0
             */
            $f_sql = "SELECT * FROM p35p6_nbreal_financials WHERE nbreal_financial_id=" . (int) $nbreal['nbreal_financial_id'];
	        $f_nbreal = $this->get_azull_info_property_data($f_sql);
            //$f_nbreal = $wpdb->get_results("SELECT * FROM p35p6_nbreal_financials WHERE nbreal_financial_id=" . (int) $nbreal['nbreal_financial_id'], ARRAY_A);
            if (isset($f_nbreal[0]['sales_price']) && $f_nbreal[0]['sales_price'] != '') {
                update_post_meta($wp_property_post_id, '_salesPrice', $f_nbreal[0]['sales_price']);
            }
            if (isset($f_nbreal[0]['total_price']) && $f_nbreal[0]['total_price'] != '') {
                update_post_meta($wp_property_post_id, '_totalPrice', $f_nbreal[0]['total_price']);
            }
            if (isset($f_nbreal[0]['old_price']) && $f_nbreal[0]['old_price'] != '') {
                update_post_meta($wp_property_post_id, '_oldPrice', $f_nbreal[0]['old_price']);
            }
            if (isset($f_nbreal[0]['comission']) && $f_nbreal[0]['comission'] != '') {
                update_post_meta($wp_property_post_id, '_commissionPer', $f_nbreal[0]['comission']);
            }
            if (isset($f_nbreal[0]['reservation_amount']) && $f_nbreal[0]['reservation_amount'] != '') {
                update_post_meta($wp_property_post_id, '_reservationAmount', $f_nbreal[0]['reservation_amount']);
            }
            if (isset($f_nbreal[0]['monthly_community_fee']) && $f_nbreal[0]['monthly_community_fee'] != '') {
                update_post_meta($wp_property_post_id, '_monthlyCharges', $f_nbreal[0]['monthly_community_fee']);
            }
            /* ===== Add financial information of properties End */
            /* ====== Add location related details of properties Start
              get location related information from joomla table p35p6_nbreal_locations
              get information from joomla in this format
             * [latitude] => 22
             * [longitude] => 55
             * [zipcode] => 30153
             */
            $l_sql = "SELECT * FROM p35p6_nbreal_locations WHERE nbreal_location_id=" . $nbreal['nbreal_location_id'];
	        $location_nbreal = $this->get_azull_info_property_data($l_sql);
            //$location_nbreal = $wpdb->get_results("SELECT * FROM p35p6_nbreal_locations WHERE nbreal_location_id=" . $nbreal['nbreal_location_id'], ARRAY_A);
            if (isset($location_nbreal[0]['latitude']) && $location_nbreal[0]['latitude'] != '') {
                update_post_meta($wp_property_post_id, '_lat', $location_nbreal[0]['latitude']);
            }
            if (isset($location_nbreal[0]['longitude']) && $location_nbreal[0]['longitude'] != '') {
                update_post_meta($wp_property_post_id, '_lng', $location_nbreal[0]['longitude']);
            }
            if (isset($location_nbreal[0]['zipcode']) && $location_nbreal[0]['zipcode'] != '') {
                update_post_meta($wp_property_post_id, '_zip', $location_nbreal[0]['zipcode']);
            }
            /*== Add location related details of properties End ==*/
            /*======= Get property relations from p35p6_nbreal_frelations table of joomla Start
             * get relations of property from p35p6_nbreal_frelations table and update it in wp postmeta table according to property id
             * [nbreal_frelation_id] => 54
              [nbreal_property_id] => 169
              [nbreal_feature_id] => 30
              [value] =>
             */
            $frelations_sql = "SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=" . (int) $nbreal['nbreal_property_id'];
	        $nbreal_frelations = $this->get_azull_info_property_data($frelations_sql);
            //$nbreal_frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=" . (int) $nbreal['nbreal_property_id'], ARRAY_A);
            //Todo: hand translation for these taxnomy manually....
            // dimensions has two value form nb_realpropety table, and rest in nbreal_relation table.
            update_post_meta($wp_property_post_id, '_dimensions_81', $nbreal['construction_area']); //Build size
            update_post_meta($wp_property_post_id, '_dimensions_110', $nbreal['total_area']); //Plot size
            foreach ($nbreal_frelations as $nbreal_frelation) {
                if (isset($nbreal_frelation['nbreal_feature_id'])) {
                    switch ($nbreal_frelation['nbreal_feature_id']) {
                        // Dimensions
                        case 72://(guest house)Useful area
                            update_post_meta($wp_property_post_id, '_dimensions_113', $nbreal_frelation['value']);
                            break;
                        case 26://garden
                            update_post_meta($wp_property_post_id, '_dimensions_82', $nbreal_frelation['value']);
                            break;
                        case 43://Terrace
                            update_post_meta($wp_property_post_id, '_dimensions_112', $nbreal_frelation['value']);
                            break;
                        case ''://Roof terrace
                            update_post_meta($wp_property_post_id, '_dimensions_111', $nbreal_frelation['value']);
                            break;
                        // Walkscores
                        // add post meta values for property walkscores (Distance from different places)
                        case 54://airport
                            update_post_meta($wp_property_post_id, '_scores_103', $nbreal_frelation['value']);
                            break;
                        case 55://golf
                            update_post_meta($wp_property_post_id, '_scores_104', $nbreal_frelation['value']);
                            break;
                        case 60://Main Road
                            update_post_meta($wp_property_post_id, '_scores_105', $nbreal_frelation['value']);
                            break;
                        case 57://Resturant
                            update_post_meta($wp_property_post_id, '_scores_106', $nbreal_frelation['value']);
                            break;
                        case 53://sea
                            update_post_meta($wp_property_post_id, '_scores_107', $nbreal_frelation['value']);
                            break;
                        case 56://Shop
                            update_post_meta($wp_property_post_id, '_scores_108', $nbreal_frelation['value']);
                            break;
                        case 72://Solarium
                            update_post_meta($wp_property_post_id, '_scores_109', $nbreal_frelation['value']);
                            break;
                    }
                }
            }
            /* wp_set_object_terms use for relate property and taxonomies
             * like property id @$wp_property_post_id(Like 8042 from wp_posts table)
             * & taxonomy view (Like 62 from wp_terms table in wp)
             * & so we have 62 view taxonomy in property 8042 
             */
            $view = $this->getSystematicTermIds("view", false);// for taxonomy array
            // 60 => castle, 61 => city-center, 62 => golf, 63 => golf-mountain, 64 => golf-zee, 65 => mountains, 66 => partial-seaview, 67 => seaview, 68 => seaview-mountains
            $view_sql = "SELECT title FROM p35p6_nbreal_tviews WHERE nbreal_tview_id=" . (int) $nbreal['nbreal_tview_id'];
	        $view_nbreal = $this->get_azull_info_property_data($view_sql);
            //$view_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_tviews WHERE nbreal_tview_id=" . (int) $nbreal['nbreal_tview_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $view_nbreal_title=(isset($view_nbreal[0]['title']) && !empty($view_nbreal[0]['title']))?$gt_var->get($view_nbreal[0]['title']):$view_nbreal[0]['title'];
            $v_title_slug = str_replace("&", "", strtolower($view_nbreal_title));
            $v_title_slug = str_replace("+", "", strtolower($v_title_slug));
            $view_title_slug = str_replace("  ", "-", strtolower($v_title_slug));
            $view_title_slug = str_replace(" ", "-", strtolower($view_title_slug));
            $vid = $this->get_custom_term_by_slug($view_title_slug, 'view');
            if (in_array($vid->term_id, $view)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $vid->term_id);
            } elseif (isset($view_nbreal_title) && !empty($view_nbreal_title)) {
            	/*
                 * add view if not available for fetched view name in taxonomy and terms tables
                 */
                $added_view_id = $this->add_new_term($view_nbreal_title, "view");
                if (isset($added_view_id) && $added_view_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_view_id);
                }
            }
            // from wp_terms table slugs
            $localty = $this->getSystematicTermIds("locality", false);
            // 21 => Beach, 22 => Country, 23 => Golf
            $locality_sql = "SELECT title FROM p35p6_nbreal_tareas WHERE nbreal_tarea_id=" . (int) $nbreal['nbreal_tarea_id'];
	        $locality_nbreal = $this->get_azull_info_property_data($locality_sql);
            //$locality_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_tareas WHERE nbreal_tarea_id=" . (int) $nbreal['nbreal_tarea_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $locality_nbreal_title=(isset($locality_nbreal[0]['title']) && !empty($locality_nbreal[0]['title']))?$gt_var->get($locality_nbreal[0]['title']):$locality_nbreal[0]['title'];
            $locality_title_slug = str_replace(" ", "-", strtolower($locality_nbreal_title));
            $lid = $this->get_custom_term_by_slug($locality_title_slug, 'locality');
            if (in_array($lid->term_id, $localty)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $lid->term_id);
            } elseif (isset($locality_nbreal_title) && !empty($locality_nbreal_title)) {
            	$added_locality_id = $this->add_new_term($locality_nbreal_title, "locality");
                if (isset($added_locality_id) && $added_locality_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_locality_id);
                }
            }
            // from wp_terms table slugs
            $banner = $this->getSystematicTermIds("banner", false);
            // 32 => featured, 33 => new, 34 => reduced, 35=> sold
            $banner_sql = "SELECT title FROM p35p6_nbreal_ribbons WHERE nbreal_ribbon_id=" . (int) $nbreal['nbreal_ribbon_id'];
	        $banner_nbreal = $this->get_azull_info_property_data($banner_sql);
            //$banner_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_ribbons WHERE nbreal_ribbon_id=" . (int) $nbreal['nbreal_ribbon_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $banner_nbreal_title=(isset($banner_nbreal[0]['title']) && !empty($banner_nbreal[0]['title']))?$gt_var->get($banner_nbreal[0]['title']):$banner_nbreal[0]['title'];
            $banner_title_slug = str_replace(" ", "-", strtolower($banner_nbreal_title));
            $bid = $this->get_custom_term_by_slug($banner_title_slug, 'banner');
            if (in_array($bid->term_id, $banner)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $bid->term_id);
            } elseif (isset($banner_nbreal_title) && !empty($banner_nbreal_title)) {
            	$added_banner_id = $this->add_new_term($banner_nbreal_title, "banner");
                if (isset($added_banner_id) && $added_banner_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_banner_id);
                }
            }
            // from wp_terms table slugs
            $orientation = $this->getSystematicTermIds("orientation", false); // for taxonomy array
            // 51 => east, 52 => east-west, 53 => north, 54 => north-east
            // 55 => north-west, 56 => south-east, 57 => south-west, 58 => south, 59 => west
            $orientation_sql = "SELECT title FROM p35p6_nbreal_facings WHERE nbreal_facing_id=" . (int) $nbreal['nbreal_facing_id'];
	        $orientation_nbreal = $this->get_azull_info_property_data($orientation_sql);
            //$orientation_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_facings WHERE nbreal_facing_id=" . (int) $nbreal['nbreal_facing_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $orientation_nbreal_title=(isset($orientation_nbreal[0]['title']) && !empty($orientation_nbreal[0]['title']))?$gt_var->get($orientation_nbreal[0]['title']):$orientation_nbreal[0]['title'];
            $orientation_title_slug = str_replace(" ", "-", strtolower($orientation_nbreal_title));
            $oid = $this->get_custom_term_by_slug($orientation_title_slug, 'orientation');
            if (in_array($oid->term_id, $orientation)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $oid->term_id);
            } elseif (isset($orientation_nbreal_title) && !empty($orientation_nbreal_title)) {
            	$added_orientation_id = $this->add_new_term($orientation_nbreal_title, "orientation");
                if (isset($added_orientation_id) && $added_orientation_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_orientation_id);
                }
            }
            // from wp_terms table slugs
            $categories = $this->getSystematicTermIds("category", false); // for taxonomy array
            $category_sql = "SELECT title FROM p35p6_nbreal_categories WHERE nbreal_category_id=" . (int) $nbreal['nbreal_category_id'];
	        $category_nbreal = $this->get_azull_info_property_data($category_sql);
            //$category_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_categories WHERE nbreal_category_id=" . (int) $nbreal['nbreal_category_id'], ARRAY_A);
            // 12 => Townhouse, 13 => Villa, 514 => Land, 515 => Apartment
            //translate taxonomy title to english using google translate library
            $category_nbreal_title=(isset($category_nbreal[0]['title']) && !empty($category_nbreal[0]['title']))?$gt_var->get($category_nbreal[0]['title']):$category_nbreal[0]['title'];
            $category_title_slug = str_replace(" ", "-", strtolower($category_nbreal_title));
            $cid = $this->get_custom_term_by_slug($category_title_slug, 'category');
            if (in_array($cid->term_id, $categories)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $cid->term_id);
            } elseif (isset($category_nbreal_title) && !empty($category_nbreal_title)) {
            	$added_category_id = $this->add_new_term($category_nbreal_title, "category");
                if (isset($added_category_id) && $added_category_id != 0) {
                	//manage category-property relation in options
                	$cate_property_arr=array('type'=>'property');
		        	update_option('azull_taxonomy_meta_' . $added_category_id, $cate_property_arr);
		        	$this->add_term_relation((int) $wp_property_post_id, (int) $added_category_id);
                }
            }            
            // from wp_terms table slugs 
            $status = $this->getSystematicTermIds("status", false);// for taxonomy array
            // 24 => bank, 25 => needs-construction-work, 26 => new, 27 => refurbished, 28 => resale, 29 => ruin, 30 => sold, 31 => under-construction
            $status_sql = "SELECT title FROM p35p6_nbreal_conditions WHERE nbreal_condition_id=" . (int) $nbreal['nbreal_condition_id'];
	        $status_nbreal = $this->get_azull_info_property_data($status_sql);
            //$status_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_conditions WHERE nbreal_condition_id=" . (int) $nbreal['nbreal_condition_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $status_nbreal_title=(isset($status_nbreal[0]['title']) && !empty($status_nbreal[0]['title']))?$gt_var->get($status_nbreal[0]['title']):$status_nbreal[0]['title'];
            $status_title_slug = str_replace(" ", "-", strtolower($status_nbreal_title));
            $satausid = $this->get_custom_term_by_slug($status_title_slug, 'status');
            if (in_array($satausid->term_id, $status)) {
            	update_post_meta($wp_property_post_id, '_status', (int) $satausid->term_id);
            	$this->add_term_relation((int) $wp_property_post_id, (int) $satausid->term_id);
            } elseif (isset($status_nbreal_title) && !empty($status_nbreal_title)) {
            	$added_status_id = $this->add_new_term($status_nbreal_title, "status");
                if (isset($added_status_id) && $added_status_id != 0) {
                	update_post_meta($wp_property_post_id, '_status', (int) $added_status_id);
                    $this->add_term_relation((int) $wp_property_post_id, (int) $added_status_id);
                    //bank...
                    if ($nbreal['nbreal_condition_id'] == 3) {
                        update_post_meta($wp_property_post_id, '_bank', 1);
                    }
                }
            }
            if ($nbreal['nbreal_condition_id'] == 1) { // New
                update_post_meta($wp_property_post_id, '_buildType', 1);
            } else {
                update_post_meta($wp_property_post_id, '_buildType', 2);
            }
            if ($nbreal['enabled'] == 0) { // if these property not enabled on joomla we are stored it as draft
                $ppost_data = array("post_status" => 'draft');
                $where_ppost = array("ID" => $wp_property_post_id);
                $wpdb->update($wpdb->posts, $ppost_data, $where_ppost);
            }
    //step 3 for add/update country, region,city and properito...
            $nbreal_property_id = $nbreal['nbreal_property_id']; // joomla property id
            $property_wp_postid = (isset($wp_post_id) && !empty($wp_post_id))?$wp_post_id:'';
            $features = $this->getSystematicTermIds("feature", false); // get term array for taxonomy feature
		    $exteriors = $this->getSystematicTermIds("exterior", false); // get term array for taxonomy exterior
		    $interiors = $this->getSystematicTermIds("interior", false); // get term array for taxonomy interior
		    $table_name_features = 'p35p6_nbreal_features';
		    $feature_sql = "SELECT * FROM " . $table_name_features;
	        $frelations = $this->get_azull_info_property_data($feature_sql);
		    //$frelations = $wpdb->get_results("SELECT * FROM " . $table_name_features, ARRAY_A);
            // get properties relations with features, interiors and exteriors 
	        $relation_sql = "SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=" . (int) $nbreal_property_id;
	        $nbreal_frelations = $this->get_azull_info_property_data($relation_sql);
            //$nbreal_frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=" . (int) $nbreal_property_id, ARRAY_A);
            $property_features = array();
            $property_exterior = array();
            $property_interior = array();
            if (isset($nbreal_frelations) && !empty($nbreal_frelations)) {
                foreach ($nbreal_frelations as $nbreal_frelation) {
                    $nbreal_feature_id = $nbreal_frelation['nbreal_feature_id'];
                    $relate_sql = "SELECT * FROM p35p6_nbreal_features where nbreal_feature_id=" . (int) $nbreal_feature_id;
	        		$frelations = $this->get_azull_info_property_data($relate_sql);
                    //$frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_features where nbreal_feature_id=" . (int) $nbreal_feature_id, ARRAY_A);
                    $frelations_title_slug = str_replace(" ", "-", strtolower($frelations[0]['title']));
                    $fid = $this->get_custom_term_by_slug($frelations_title_slug, 'feature');
                    $eid = $this->get_custom_term_by_slug($frelations_title_slug, 'exterior');
                    $iid = $this->get_custom_term_by_slug($frelations_title_slug, 'interior');
                    if (in_array($fid->term_id, $features)) {
                    	$this->add_term_relation((int) $property_wp_postid, (int) $fid->term_id);
                    }
                    if (in_array($eid->term_id, $exteriors)) {
                    	$this->add_term_relation((int) $property_wp_postid, (int) $eid->term_id);
                    }
                    if (in_array($iid->term_id, $interiors)) {
                    	$this->add_term_relation((int) $property_wp_postid, (int) $iid->term_id);
                    }
                } // End foreach
            } // End if
            $builder_title=$nbreal["p_builder_title"];//(isset($nbreal["p_builder_title"]) && !empty($nbreal["p_builder_title"]))?$gt_var->get($nbreal["p_builder_title"]):$nbreal["p_builder_title"];
	        if (isset($builder_title) && $builder_title != '') {
		        //$terms = get_term_by('slug', $builder_title_slug, 'proprietor');
		        $builder_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($builder_title))));
            	$terms = $this->get_custom_term_by_slug($builder_title_slug, 'proprietor');
		        $taxonomy_meta['type'] = 3;
		        if ($terms->term_id != '') {
		        	$this->add_term_relation((int) $property_wp_postid, (int) $terms->term_id);
		            update_post_meta($property_wp_postid, '_proprietor', $terms->term_id);
		            $term_id=$terms->term_id;
		        }else{
		        	//add new proprietor as term
		    		$added_proprietor_id = $this->add_new_term($builder_title, "proprietor");
		            if (isset($added_proprietor_id) && $added_proprietor_id != 0) {
		            	update_post_meta($property_wp_postid, '_proprietor', $added_proprietor_id);
		            	$this->add_term_relation((int) $property_wp_postid, (int) $added_proprietor_id);
		                //manage country-region-place relation in options
		            	$place_taxonomy_meta['country'] = $cntry_id;
		            	$place_taxonomy_meta['region'] = $region_id;
		            	$place_taxonomy_meta['provinces'] = $t;
			        	update_option('azull_taxonomy_meta_' . $added_proprietor_id, $place_taxonomy_meta);
			        	$term_id=$added_proprietor_id;
		            }
		        }
		        $taxonomy_meta['phone'] = $nbreal['p_builder_phone'];
		        $taxonomy_meta['email'] = $nbreal['p_builder_email'];
		        $taxonomy_meta['web'] = $nbreal['p_builder_website'];
		        update_option('azull_taxonomy_meta_' . $term_id, $taxonomy_meta);
	    	}
            $cntry_id = '';
            //translate taxonomy title to english using google translate library
            $country_title = (isset($nbreal["p_location_country_title"]) && !empty($nbreal["p_location_country_title"]))?$gt_var->get($nbreal["p_location_country_title"]):$nbreal["p_location_country_title"];
            if (isset($country_title) && $country_title != '') {
            	$country_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($country_title))));
            	$term = $this->get_custom_term_by_slug($country_title_slug, 'country');
                if(isset($term->term_id) && !empty($term->term_id) && $term->term_id!=''){
                	$cntry_id=$term->term_id;
                	$this->add_term_relation((int) $property_wp_postid, (int) $term->term_id);
	                update_post_meta($property_wp_postid, '_country', $term->term_id);
            	}else{
            		//add new country as term
            		$added_country_id = $this->add_new_term($country_title, "country");
                    if (isset($added_country_id) && $added_country_id != 0) {
                    	update_post_meta($property_wp_postid, '_country', $added_country_id);
                    	$this->add_term_relation((int) $property_wp_postid, (int) $added_country_id);
                    }
            	}
            }
            $region_id='';
            //translate taxonomy title to english using google translate library
            $region_title=(isset($nbreal["p_region_title"]) && !empty($nbreal["p_region_title"]))?$gt_var->get($nbreal["p_region_title"]):$nbreal["p_region_title"];
            //$region_title=(isset($nbreal["p_region_title"]) && !empty($nbreal["p_region_title"]))?$gt_es_nl->get($nbreal["p_region_title"]):$nbreal["p_region_title"];
            if (isset($region_title) && $region_title != '') {
            	$region_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($region_title))));
            	if($region_title_slug=='costa-blanca-norte' || $region_title_slug=='costa-blanca-north'){
            		$region_title_slug = 'costa-blanca-norte';
            	}
		        $term = $this->get_custom_term_by_slug($region_title_slug, 'region');
                if(isset($term->term_id) && !empty($term->term_id) && $term->term_id!=''){
                	$region_id = $term->term_id;
                	$this->add_term_relation((int) $property_wp_postid,(int)$region_id);
                	update_post_meta((int) $property_wp_postid, '_region',(int)$region_id);
            	}else{
            		//add new region as term
            		$added_region_id = $this->add_new_term($region_title, "region");
                    if (isset($added_region_id) && $added_region_id != 0) {
                    	$region_id = $added_region_id;
                    	update_post_meta($property_wp_postid, '_region', $added_region_id);
                    	$this->add_term_relation((int) $property_wp_postid, (int) $added_region_id);
                        //manage country-region relation in options
                    	$region_taxonomy_meta['country'] = $cntry_id;
			        	update_option('azull_taxonomy_meta_' . $added_region_id, $region_taxonomy_meta);
                    }
            	}
            }
            
            $city_title = $nbreal["p_location_city_title"];
            //translate taxonomy title to english using google translate library
            //$city_title=(isset($nbreal["p_location_city_title"]) && !empty($nbreal["p_location_city_title"]))?$gt_var->get($nbreal["p_location_city_title"]):$nbreal["p_location_city_title"];
            if (isset($city_title) && $city_title != '') {
            	$city_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($city_title))));
		        $term = $this->get_custom_term_by_slug($city_title_slug, 'place');
                if(isset($term) && !empty($term) && $term!=''){
                	$this->add_term_relation((int) $property_wp_postid, (int) $term->term_id);
                	update_post_meta($property_wp_postid, '_place', $term->term_id);
            	}else{
            		//add new place as term
            		$added_place_id = $this->add_new_term($city_title, "place");
                    if (isset($added_place_id) && $added_place_id != 0) {
                    	update_post_meta($property_wp_postid, '_place', $added_place_id);
                    	$this->add_term_relation((int) $property_wp_postid, (int) $added_place_id);
                        //manage country-region-place relation in options
                    	$place_taxonomy_meta['country'] = $cntry_id;
                    	$place_taxonomy_meta['region'] = $region_id;
                    	$place_taxonomy_meta['provinces'] = $t;
			        	update_option('azull_taxonomy_meta_' . $added_place_id, $place_taxonomy_meta);
                    }
            	}
            }
			$place_term_id = get_post_meta($property_wp_postid,'_place',true );
            $taxonomy_m = get_option('azull_taxonomy_meta_' . (int) $place_term_id);
            $t = '';
            $provinces = $this->get_all_terms('provinces');
            foreach ($provinces as $province) {
                $taxonomy_metap = get_option('azull_taxonomy_meta_' . (int) $province->term_id);
                if ($taxonomy_metap['region'] == $taxonomy_m['region']) {
                    $t = $province->term_id;
                }
            }
            if ($t != '') {
            	$this->add_term_relation((int) $property_wp_postid, (int) $t);
                update_post_meta((int) $property_wp_postid, '_province', (int) $t);
            }

        }
	    }//end foreach $data_nbreal
	    return array('t_record_updated'=>$t_record_updated,'t_record_added'=>$t_record_added,'t_record_travesed'=>$t_record_travesed,'t_available_record'=>$t_available_record);
    }//end if $nbreal_Properties
}
/*
 * Method : import_azull_info_properties
 * Params : Null
 * @get all properties details from azull.info(Joomla DB) and insert it in azull.biz(Wordpress DB) if not available 
 * if already available update that property basic details and meta information with _nbreal_id in meta(it is ref id or property id in joomla)
 * return : Perform insert and update operation on WP DB for property basic details
 */
function import_azull_info_properties_old_26052016($params) {
	//echo $limit.' => '.$total_traverse_record;die('yes');
    //Todo :drop this fuction after making it live.
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    require_once(ABSPATH . "wp-admin" . '/includes/image.php');
    $gt_nl_var = new translate("auto","nl");
    $gt_var = new translate("auto","en");
    global $wpdb;
    //ini_set('max_execution_time', 0); //300 seconds = 5 minutes     
    // get all properties data from azull.info
    $property_tbl = 'p35p6_nbreal_properties';
    $location_tbl = 'p35p6_nbreal_locations';
    $region_tbl = 'p35p6_nbreal_regions';
    $builder_tbl = 'p35p6_nbreal_builders';
    $country_tbl = 'p35p6_nbreal_countries';
    $city_tbl = 'p35p6_nbreal_cities';
    $category_tbl = 'p35p6_nbreal_categories';
    $t_available_record = 0;
    $limit = (isset($params['limit']) && !empty($params['limit']))?$params['limit']:'';
	//if(!$total_traverse_record){
	    $t_properties = $wpdb->get_results("SELECT $property_tbl.*,$builder_tbl.title as p_builder_title,$builder_tbl.phone as p_builder_phone,$builder_tbl.email as p_builder_email,$builder_tbl.website as p_builder_website,$region_tbl.title as p_region_title,$country_tbl.title as p_location_country_title,$city_tbl.title as p_location_city_title,$category_tbl.title as p_category_title
	                FROM $property_tbl
	                LEFT JOIN $builder_tbl ON $builder_tbl.nbreal_builder_id=$property_tbl.nbreal_builder_id 
	                LEFT JOIN $location_tbl ON $location_tbl.nbreal_location_id=$property_tbl.nbreal_location_id
	                LEFT JOIN $country_tbl ON $country_tbl.nbreal_country_id=$location_tbl.nbreal_country_id 
	                LEFT JOIN $region_tbl ON $region_tbl.nbreal_region_id=$location_tbl.nbreal_region_id 
	                LEFT JOIN $city_tbl ON $city_tbl.nbreal_city_id=$location_tbl.nbreal_city_id 
	                LEFT JOIN $category_tbl ON $category_tbl.nbreal_category_id=$property_tbl.nbreal_category_id where $property_tbl.website = 1 order by $property_tbl.nbreal_property_id", ARRAY_A);// AND $property_tbl.enabled = 1
	    $t_available_record = count($t_properties);
	//}
	//echo $limit.' => '.$t_available_record;die('yes1');
    $nbreal_Properties = $wpdb->get_results("SELECT $property_tbl.*,$builder_tbl.title as p_builder_title,$builder_tbl.phone as p_builder_phone,$builder_tbl.email as p_builder_email,$builder_tbl.website as p_builder_website,$region_tbl.title as p_region_title,$country_tbl.title as p_location_country_title,$city_tbl.title as p_location_city_title,$category_tbl.title as p_category_title
                FROM $property_tbl
                LEFT JOIN $builder_tbl ON $builder_tbl.nbreal_builder_id=$property_tbl.nbreal_builder_id 
                LEFT JOIN $location_tbl ON $location_tbl.nbreal_location_id=$property_tbl.nbreal_location_id
                LEFT JOIN $country_tbl ON $country_tbl.nbreal_country_id=$location_tbl.nbreal_country_id 
                LEFT JOIN $region_tbl ON $region_tbl.nbreal_region_id=$location_tbl.nbreal_region_id 
                LEFT JOIN $city_tbl ON $city_tbl.nbreal_city_id=$location_tbl.nbreal_city_id 
                LEFT JOIN $category_tbl ON $category_tbl.nbreal_category_id=$property_tbl.nbreal_category_id where $property_tbl.website = 1 order by $property_tbl.nbreal_property_id $limit", ARRAY_A); // get all properties  AND $property_tbl.enabled = 1
    //print('<pre>');print_r($nbreal_Properties);die;
    //print_r($gt_var->get('Pagina niet gevonden.'));die;
    if(isset($nbreal_Properties) && !empty($nbreal_Properties)){
    	$t_record_added = (isset($params['total_added_records']) && !empty($params['total_added_records']))?$params['total_added_records']:0;
    	$t_record_updated = (isset($params['total_updated_records']) && !empty($params['total_updated_records']))?$params['total_updated_records']:0;
    	$t_record_travesed = (isset($params['total_traverse_record']) && !empty($params['total_traverse_record']))?$params['total_traverse_record']:0;

	    foreach ($nbreal_Properties as $j_property) {
	        //Main property id in joomla
	        $property_ref_id = $j_property['nbreal_property_id'];
	        //Check above posts exists or not in wp db posts and postmeta tables
	        $querystr = "SELECT $wpdb->postmeta.post_id,$wpdb->posts.post_modified,count($wpdb->postmeta.post_id)
	                    FROM $wpdb->postmeta
	                    join $wpdb->posts on $wpdb->posts.ID = $wpdb->postmeta.post_id
	                    WHERE
	                    (meta_key = '_nreal_id' AND meta_value = '" . $property_ref_id . "')
	                    GROUP BY post_id;";
	        $postid = $wpdb->get_results($querystr, ARRAY_A);
	        //Fetch posts contents part in different languages  
	        $en_t = $j_property['title'];
	        $en_d = $j_property['description'];
	        $table = 'p35p6_falang_content'; // get posts details excluding english language like in french and in netherland                 
	        $fr_t = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=2", ARRAY_A);
	        $fr_d = $wpdb->get_results("SELECT * FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=2", ARRAY_A);
	        $nl_t = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=4", ARRAY_A);
	        $nl_d = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=4", ARRAY_A);
	        // create title and content for multilingual format
	        $title = "[:en]" . ucwords($en_t);
	        $title .="[:fr]" . $fr_t[0]['value'];
	        $title .="[:nl]" . $nl_t[0]['value'] . "[:]";
	        $content = "[:en]" . $en_d;
	        $content .="[:fr]" . $fr_d[0]['value'];
	        $content .="[:nl]" . $nl_d[0]['value'] . "[:]";
	        //translate category, city, region and country in Dutch
	        /*$p_cate_title=(isset($j_property['p_category_title']) && !empty($j_property['p_category_title']))?ucwords($this->get_translated_text($j_property['p_category_title'],"auto","nl")):$j_property['p_category_title'];
	        $p_city_title=(isset($j_property['p_location_city_title']) && !empty($j_property['p_location_city_title']))?ucwords($this->get_translated_text($j_property['p_location_city_title'],"auto","nl")):$j_property['p_location_city_title'];
	        $p_region_title=(isset($j_property['p_region_title']) && !empty($j_property['p_region_title']))?ucwords($this->get_translated_text($j_property['p_region_title'],"auto","nl")):$j_property['p_region_title'];
	        $p_country_title=(isset($j_property['p_location_country_title']) && !empty($j_property['p_location_country_title']))?ucwords($this->get_translated_text($j_property['p_location_country_title'],"auto","nl")):$j_property['p_location_country_title'];*/

	        $p_cate_title=(isset($j_property['p_category_title']) && !empty($j_property['p_category_title']))?ucwords($gt_nl_var->get($j_property['p_category_title'])):$j_property['p_category_title'];
	        $p_city_title=(isset($j_property['p_location_city_title']) && !empty($j_property['p_location_city_title']))?ucwords($gt_nl_var->get($j_property['p_location_city_title'])):$j_property['p_location_city_title'];
	        $p_region_title=(isset($j_property['p_region_title']) && !empty($j_property['p_region_title']))?ucwords($gt_nl_var->get($j_property['p_region_title'])):$j_property['p_region_title'];
	        $p_country_title=(isset($j_property['p_location_country_title']) && !empty($j_property['p_location_country_title']))?ucwords($gt_nl_var->get($j_property['p_location_country_title'])):$j_property['p_location_country_title'];

			$property_post_name=$property_ref_id.'-'.$p_cate_title.'-te-koop-'.$p_city_title.'-'.$p_region_title.'-'.$p_country_title;
			$p_post_name = str_replace(' ', '-', $property_post_name);
		    $post_name = str_replace('--', '-',str_replace(',', '', str_replace('.', '', $p_post_name)));
		    $post_name = str_replace('--', '-',$post_name);
	        //Create array for insert it in wp_posts table
	        $property = array(
	            'post_author' => 1,
	            'post_title' => $title,
	            'post_content' => $content,
	            'post_status' => 'publish',
	            'post_type' => 'property',
	            'post_name' => $post_name,//str_replace(" ", "-", $en_t),
	            //'post_name' => str_replace(" ", "-", $en_t),
	            'post_modified' => $j_property["modified_on"]);
	        $post_parent = 0;
	        $is_new = 0;
	        $add_update_gallery = 0;
	        $wp_post_id = 0;
	        // check if posts already exists in azull.biz
	        if (isset($postid[0]['post_id']) && !empty($postid[0]['post_id']) && $postid[0]['post_id'] != 0) {
	        	$post_parent = $postid[0]['post_id'];
	        	$wp_post_id = $postid[0]['post_id'];
	        	$p_import_date = get_post_meta($postid[0]['post_id'], '_import_date', true );
				$date1=strtotime($p_import_date);
				$date2=strtotime($j_property['modified_on']);
				$diff=$date2-$date1;
	            if ($diff > 0) {
	                //update post
	                $property['ID'] = $postid[0]['post_id'];
	                $post_parent = wp_update_post($property, false);
	                update_post_meta($postid[0]['post_id'], '_import_date',$j_property['modified_on']);
	                $add_update_gallery = 1;
	                $t_record_updated = $t_record_updated + 1;
	            }
	        } else {
	            //add new post in azull.biz for property post type
	            $post_parent = wp_insert_post($property, false);
	            $wp_post_id = $post_parent;
	            update_post_meta($post_parent, '_import_date',$j_property['modified_on']);
	            $is_new = 1;
	            $add_update_gallery = 1;
	            $t_record_added = $t_record_added + 1;
	        }
	        if (isset($post_parent) && $post_parent!=0) {
	        	$t_record_travesed++;
	            //handle meta keyword start
	            $en_kt = $j_property['metakey'];  // from properties table
	            $en_kd = $j_property['metadesc'];   // from properties table
	            $table = 'p35p6_falang_content'; // get posts details excluding english language like in french and in netherland (language_id=1 english, 2= fr, 4=nl)   
	            $fr_kt = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=2", ARRAY_A);
	            $fr_kd = $wpdb->get_results("SELECT * FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metadesc' AND language_id=2", ARRAY_A);
	            $nl_kt = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=4", ARRAY_A);
	            $nl_kd = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $property_ref_id . " AND reference_table='nbreal_properties' AND reference_field='metadesc' AND language_id=4", ARRAY_A);
	            //create key and description for multilingual format
	            $ktitle = "[:en]" . $en_kt;
	            $ktitle .="[:fr]" . $fr_kt[0]['value'];
	            $ktitle .="[:nl]" . $nl_kt[0]['value'] . "[:]";
	            $kcontent = "[:en]" . $en_kd;
	            $kcontent .="[:fr]" . $fr_kd[0]['value'];
	            $kcontent .="[:nl]" . $nl_kd[0]['value'] . "[:]";
	            update_post_meta($post_parent, 'property_meta:title', $title);//get from above as we fetch it already  for title 
	            update_post_meta($post_parent, 'property_meta:keywords', $ktitle);
	            update_post_meta($post_parent, 'property_meta:description', $kcontent);
	            //$add_update_gallery=1;
	            if (isset($add_update_gallery) && $add_update_gallery == 1) {
		            //get attachments files for property  
		            $gallery_table = 'p35p6_nbreal_files';
		            $gallerys_nbreal = $wpdb->get_results("SELECT * FROM " . $gallery_table . " where nbreal_property_id=" . $property_ref_id . ' ORDER BY ordering ASC', ARRAY_A);
		            $uploads = wp_upload_dir();
		            $i = 0;
		            $gallery = array();
					$base_path = str_replace("/wp-required","",$uploads['basedir']);
		            foreach ($gallerys_nbreal as $gallery_nbreal) {
		                $gallery_nbreal_file_title = $gallery_nbreal['file_title'];
		                $file_name = $base_path . '/original/' . $property_ref_id . "/" . $gallery_nbreal_file_title;
						$j_title=$gallery_nbreal['nbreal_property_id'].'-'.$p_cate_title.'-te-koop-'.$p_city_title.'-'.$p_region_title.'-'.$p_country_title.'-'.$i;
			            $imgtitle = str_replace(' ', '-', $j_title);
			            $name = str_replace('--', '-',str_replace(',', '', str_replace('.', '', $imgtitle)));
						$wp_filetype = wp_check_filetype( basename( $file_name ), null );
				        $file_name_new = $base_path.$uploads['subdir'].'/'.$name.'.'.$wp_filetype['ext'];
		                if (!file_exists($file_name_new) && file_exists($file_name)) {
		                    copy($file_name, $file_name_new);
		                }
		                $title=preg_replace('/\.[^.]+$/', '', $name);
		                $attachment = array(
		                    'guid' => $uploads['url']."/".basename($filename),
		                    'post_mime_type' => $wp_filetype['type'],
		                    'post_title' =>$title,
		                    'post_name' => $title,
		                    'post_content' => '',
		                    'post_parent' => $post_parent,
		                    'post_status' => 'inherit'
		                );
		                $attachment_id = wp_insert_attachment($attachment, $file_name_new, $post_parent);
		                $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_name_new);
		                if (isset($attachment_data) && !empty($attachment_data) && count($attachment_data) > 0) {
		                    wp_update_attachment_metadata($attachment_id, $attachment_data);
		                }
		                if ($attachment_id && $i == 0):
		                    update_post_meta($post_parent, '_thumbnail_id', $attachment_id);
		                else:
		                    $gallery[] = $attachment_id;
		                endif;
		                $i++;
		            }
		            if (!empty($gallery)) {
		                $encode = base64_encode(json_encode($gallery));
		                update_post_meta((integer) $post_parent, 'property_gallery', $encode);
		            }
	        	}
	            // insert property reference id from joomla to azull.biz 
	            update_post_meta($post_parent, '_nreal_id', (integer) $property_ref_id);
	            //end handle post image
	        }//end if $post_parent
	        if(isset($wp_post_id) && !empty($wp_post_id) && $wp_post_id!=0){
//step 2 for add/update property's taxomomy
	    $nbreal = $j_property;
        $wp_property_post_id = $wp_post_id; // azull.biz property post id
            if (isset($nbreal['n_floors']) && $nbreal['n_floors'] != '') {
                update_post_meta($wp_property_post_id, '_feature_40', $nbreal['n_floors']); //Floors term id = 40 in wp_terms
            }
            if (isset($nbreal['floor_n']) && $nbreal['floor_n'] != '') {
                update_post_meta($wp_property_post_id, '_feature_39', $nbreal['floor_n']); //Floor term id = 39 in wp_terms
            }
            if (isset($nbreal['n_bedrooms']) && $nbreal['n_bedrooms'] != '') {
                update_post_meta($wp_property_post_id, '_feature_37', $nbreal['n_bedrooms']); //Bedrooms term id 37 in wp_terms
            }
            if (isset($nbreal['n_bathrooms']) && $nbreal['n_bathrooms'] != '') {
                update_post_meta($wp_property_post_id, '_feature_36', $nbreal['n_bathrooms']); //Bathrooms term id 36 in wp_terms
            }
            if (isset($nbreal['plus_info']) && $nbreal['plus_info'] != "") {
                update_post_meta($wp_property_post_id, '_moreInformation', $nbreal['plus_info']);
            }
            //add property construction year and project name in postmeta table 
            update_post_meta($wp_property_post_id, '_year', $nbreal['construction_year']);
            update_post_meta($wp_property_post_id, '_propertyName', $nbreal['project_name']);
            /* ========= Room Informations End ====== */
            /* Add financial information of properties Start 
             * get financial information from joomla table p35p6_nbreal_financials
             * get information from joomla in this format
             * [sales_price] => 120400
             * [total_price] => 135540
             * [old_price] => 244000
             * [comission] => 0
             * [reservation_amount] => 3000
             * [monthly_community_fee] => 0
             */
            $f_nbreal = $wpdb->get_results("SELECT * FROM p35p6_nbreal_financials WHERE nbreal_financial_id=" . (int) $nbreal['nbreal_financial_id'], ARRAY_A);

            if (isset($f_nbreal[0]['sales_price']) && $f_nbreal[0]['sales_price'] != '') {
                update_post_meta($wp_property_post_id, '_salesPrice', $f_nbreal[0]['sales_price']);
            }
            if (isset($f_nbreal[0]['total_price']) && $f_nbreal[0]['total_price'] != '') {
                update_post_meta($wp_property_post_id, '_totalPrice', $f_nbreal[0]['total_price']);
            }
            if (isset($f_nbreal[0]['old_price']) && $f_nbreal[0]['old_price'] != '') {
                update_post_meta($wp_property_post_id, '_oldPrice', $f_nbreal[0]['old_price']);
            }
            if (isset($f_nbreal[0]['comission']) && $f_nbreal[0]['comission'] != '') {
                update_post_meta($wp_property_post_id, '_commissionPer', $f_nbreal[0]['comission']);
            }
            if (isset($f_nbreal[0]['reservation_amount']) && $f_nbreal[0]['reservation_amount'] != '') {
                update_post_meta($wp_property_post_id, '_reservationAmount', $f_nbreal[0]['reservation_amount']);
            }
            if (isset($f_nbreal[0]['monthly_community_fee']) && $f_nbreal[0]['monthly_community_fee'] != '') {
                update_post_meta($wp_property_post_id, '_monthlyCharges', $f_nbreal[0]['monthly_community_fee']);
            }
            /* ===== Add financial information of properties End */
            /* ====== Add location related details of properties Start
              get location related information from joomla table p35p6_nbreal_locations
              get information from joomla in this format
             * [latitude] => 22
             * [longitude] => 55
             * [zipcode] => 30153
             */
            $location_nbreal = $wpdb->get_results("SELECT * FROM p35p6_nbreal_locations WHERE nbreal_location_id=" . $nbreal['nbreal_location_id'], ARRAY_A);
            if (isset($location_nbreal[0]['latitude']) && $location_nbreal[0]['latitude'] != '') {
                update_post_meta($wp_property_post_id, '_lat', $location_nbreal[0]['latitude']);
            }
            if (isset($location_nbreal[0]['longitude']) && $location_nbreal[0]['longitude'] != '') {
                update_post_meta($wp_property_post_id, '_lng', $location_nbreal[0]['longitude']);
            }
            if (isset($location_nbreal[0]['zipcode']) && $location_nbreal[0]['zipcode'] != '') {
                update_post_meta($wp_property_post_id, '_zip', $location_nbreal[0]['zipcode']);
            }
            /*== Add location related details of properties End ==*/
            /*======= Get property relations from p35p6_nbreal_frelations table of joomla Start
             * get relations of property from p35p6_nbreal_frelations table and update it in wp postmeta table according to property id
             * [nbreal_frelation_id] => 54
              [nbreal_property_id] => 169
              [nbreal_feature_id] => 30
              [value] =>
             */
            $nbreal_frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=" . (int) $nbreal['nbreal_property_id'], ARRAY_A);
            //Todo: hand translation for these taxnomy manually....
            // dimensions has two value form nb_realpropety table, and rest in nbreal_relation table.
            update_post_meta($wp_property_post_id, '_dimensions_81', $nbreal['construction_area']); //Build size
            update_post_meta($wp_property_post_id, '_dimensions_110', $nbreal['total_area']); //Plot size
            foreach ($nbreal_frelations as $nbreal_frelation) {
                if (isset($nbreal_frelation['nbreal_feature_id'])) {
                    switch ($nbreal_frelation['nbreal_feature_id']) {
                        // Dimensions
                        case 72://(guest house)Useful area
                            update_post_meta($wp_property_post_id, '_dimensions_113', $nbreal_frelation['value']);
                            break;
                        case 26://garden
                            update_post_meta($wp_property_post_id, '_dimensions_82', $nbreal_frelation['value']);
                            break;
                        case 43://Terrace
                            update_post_meta($wp_property_post_id, '_dimensions_112', $nbreal_frelation['value']);
                            break;
                        case ''://Roof terrace
                            update_post_meta($wp_property_post_id, '_dimensions_111', $nbreal_frelation['value']);
                            break;
                        // Walkscores
                        // add post meta values for property walkscores (Distance from different places)
                        case 54://airport
                            update_post_meta($wp_property_post_id, '_scores_103', $nbreal_frelation['value']);
                            break;
                        case 55://golf
                            update_post_meta($wp_property_post_id, '_scores_104', $nbreal_frelation['value']);
                            break;
                        case 60://Main Road
                            update_post_meta($wp_property_post_id, '_scores_105', $nbreal_frelation['value']);
                            break;
                        case 57://Resturant
                            update_post_meta($wp_property_post_id, '_scores_106', $nbreal_frelation['value']);
                            break;
                        case 53://sea
                            update_post_meta($wp_property_post_id, '_scores_107', $nbreal_frelation['value']);
                            break;
                        case 56://Shop
                            update_post_meta($wp_property_post_id, '_scores_108', $nbreal_frelation['value']);
                            break;
                        case 72://Solarium
                            update_post_meta($wp_property_post_id, '_scores_109', $nbreal_frelation['value']);
                            break;
                    }
                }
            }
            /* wp_set_object_terms use for relate property and taxonomies
             * like property id @$wp_property_post_id(Like 8042 from wp_posts table)
             * & taxonomy view (Like 62 from wp_terms table in wp)
             * & so we have 62 view taxonomy in property 8042 
             */
            $view = $this->getSystematicTermIds("view", false);// for taxonomy array
            // 60 => castle, 61 => city-center, 62 => golf, 63 => golf-mountain, 64 => golf-zee, 65 => mountains, 66 => partial-seaview, 67 => seaview, 68 => seaview-mountains
            $view_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_tviews WHERE nbreal_tview_id=" . (int) $nbreal['nbreal_tview_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $view_nbreal_title=(isset($view_nbreal[0]['title']) && !empty($view_nbreal[0]['title']))?$gt_var->get($view_nbreal[0]['title']):$view_nbreal[0]['title'];
            $view_title_slug = str_replace(" ", "-", strtolower($view_nbreal_title));
            $vid = $this->get_custom_term_by_slug($view_title_slug, 'view');
            if (in_array($vid->term_id, $view)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $vid->term_id);
            } elseif (isset($view_nbreal_title) && !empty($view_nbreal_title)) {
            	/*
                 * add view if not available for fetched view name in taxonomy and terms tables
                 */
                $added_view_id = $this->add_new_term($view_nbreal_title, "view");
                if (isset($added_view_id) && $added_view_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_view_id);
                }
            }
            // from wp_terms table slugs
            $localty = $this->getSystematicTermIds("locality", false);
            // 21 => Beach, 22 => Country, 23 => Golf
            $locality_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_tareas WHERE nbreal_tarea_id=" . (int) $nbreal['nbreal_tarea_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $locality_nbreal_title=(isset($locality_nbreal[0]['title']) && !empty($locality_nbreal[0]['title']))?$gt_var->get($locality_nbreal[0]['title']):$locality_nbreal[0]['title'];
            $locality_title_slug = str_replace(" ", "-", strtolower($locality_nbreal_title));
            $lid = $this->get_custom_term_by_slug($locality_title_slug, 'locality');
            if (in_array($lid->term_id, $localty)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $lid->term_id);
            } elseif (isset($locality_nbreal_title) && !empty($locality_nbreal_title)) {
            	$added_locality_id = $this->add_new_term($locality_nbreal_title, "locality");
                if (isset($added_locality_id) && $added_locality_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_locality_id);
                }
            }
            // from wp_terms table slugs
            $banner = $this->getSystematicTermIds("banner", false);
            // 32 => featured, 33 => new, 34 => reduced, 35=> sold
            $banner_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_ribbons WHERE nbreal_ribbon_id=" . (int) $nbreal['nbreal_ribbon_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $banner_nbreal_title=(isset($banner_nbreal[0]['title']) && !empty($banner_nbreal[0]['title']))?$gt_var->get($banner_nbreal[0]['title']):$banner_nbreal[0]['title'];
            $banner_title_slug = str_replace(" ", "-", strtolower($banner_nbreal_title));
            $bid = $this->get_custom_term_by_slug($banner_title_slug, 'banner');
            if (in_array($bid->term_id, $banner)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $bid->term_id);
            } elseif (isset($banner_nbreal_title) && !empty($banner_nbreal_title)) {
            	$added_banner_id = $this->add_new_term($banner_nbreal_title, "banner");
                if (isset($added_banner_id) && $added_banner_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_banner_id);
                }
            }
            // from wp_terms table slugs
            $orientation = $this->getSystematicTermIds("orientation", false); // for taxonomy array
            // 51 => east, 52 => east-west, 53 => north, 54 => north-east
            // 55 => north-west, 56 => south-east, 57 => south-west, 58 => south, 59 => west
            $orientation_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_facings WHERE nbreal_facing_id=" . (int) $nbreal['nbreal_facing_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $orientation_nbreal_title=(isset($orientation_nbreal[0]['title']) && !empty($orientation_nbreal[0]['title']))?$gt_var->get($orientation_nbreal[0]['title']):$orientation_nbreal[0]['title'];
            $orientation_title_slug = str_replace(" ", "-", strtolower($orientation_nbreal_title));
            $oid = $this->get_custom_term_by_slug($orientation_title_slug, 'orientation');
            if (in_array($oid->term_id, $orientation)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $oid->term_id);
            } elseif (isset($orientation_nbreal_title) && !empty($orientation_nbreal_title)) {
            	$added_orientation_id = $this->add_new_term($orientation_nbreal_title, "orientation");
                if (isset($added_orientation_id) && $added_orientation_id != 0) {
                	$this->add_term_relation((int) $wp_property_post_id, (int) $added_orientation_id);
                }
            }
            // from wp_terms table slugs
            $categories = $this->getSystematicTermIds("category", false); // for taxonomy array
            $category_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_categories WHERE nbreal_category_id=" . (int) $nbreal['nbreal_category_id'], ARRAY_A);
            // 12 => Townhouse, 13 => Villa, 514 => Land, 515 => Apartment
            //translate taxonomy title to english using google translate library
            $category_nbreal_title=(isset($category_nbreal[0]['title']) && !empty($category_nbreal[0]['title']))?$gt_var->get($category_nbreal[0]['title']):$category_nbreal[0]['title'];
            $category_title_slug = str_replace(" ", "-", strtolower($category_nbreal_title));
            $cid = $this->get_custom_term_by_slug($category_title_slug, 'category');
            if (in_array($cid->term_id, $categories)) {
            	$this->add_term_relation((int) $wp_property_post_id, (int) $cid->term_id);
            } elseif (isset($category_nbreal_title) && !empty($category_nbreal_title)) {
            	$added_category_id = $this->add_new_term($category_nbreal_title, "category");
                if (!is_object($added_category_id) && isset($added_category_id) && $added_category_id != 0) {
                	//manage category-property relation in options
                	$cate_property_arr=array('type'=>'property');
		        	update_option('azull_taxonomy_meta_' . $added_category_id, $cate_property_arr);
		        	$this->add_term_relation((int) $wp_property_post_id, (int) $added_category_id);
                }
            }            
            // from wp_terms table slugs 
            $status = $this->getSystematicTermIds("status", false);// for taxonomy array
            // 24 => bank, 25 => needs-construction-work, 26 => new, 27 => refurbished, 28 => resale, 29 => ruin, 30 => sold, 31 => under-construction
            $status_nbreal = $wpdb->get_results("SELECT title FROM p35p6_nbreal_conditions WHERE nbreal_condition_id=" . (int) $nbreal['nbreal_condition_id'], ARRAY_A);
            //translate taxonomy title to english using google translate library
            $status_nbreal_title=(isset($status_nbreal[0]['title']) && !empty($status_nbreal[0]['title']))?$gt_var->get($status_nbreal[0]['title']):$status_nbreal[0]['title'];
            $status_title_slug = str_replace(" ", "-", strtolower($status_nbreal_title));
            $satausid = $this->get_custom_term_by_slug($status_title_slug, 'status');
            if (in_array($satausid->term_id, $status)) {
            	update_post_meta($wp_property_post_id, '_status', (int) $satausid->term_id);
            	$this->add_term_relation((int) $wp_property_post_id, (int) $satausid->term_id);
            } elseif (isset($status_nbreal_title) && !empty($status_nbreal_title)) {
            	$added_status_id = $this->add_new_term($status_nbreal_title, "status");
                if (!is_object($added_status_id) && isset($added_status_id) && $added_status_id != 0) {
                	update_post_meta($wp_property_post_id, '_status', (int) $added_status_id);
                    $this->add_term_relation((int) $wp_property_post_id, (int) $added_status_id);
                    //bank...
                    if ($nbreal['nbreal_condition_id'] == 3) {
                        update_post_meta($wp_property_post_id, '_bank', 1);
                    }
                }
            }
            if ($nbreal['nbreal_condition_id'] == 1) { // New
                update_post_meta($wp_property_post_id, '_buildType', 1);
            } else {
                update_post_meta($wp_property_post_id, '_buildType', 2);
            }
            if ($nbreal['enabled'] == 0) { // if these property not enabled on joomla we are stored it as draft
                $ppost_data = array("post_status" => 'draft');
                $where_ppost = array("ID" => $wp_property_post_id);
                $wpdb->update($wpdb->posts, $ppost_data, $where_ppost);
            }
    //step 3 for add/update country, region,city and properito...
            $nbreal_property_id = $nbreal['nbreal_property_id']; // joomla property id
            $property_wp_postid = (isset($wp_post_id) && !empty($wp_post_id))?$wp_post_id:'';
            $features = $this->getSystematicTermIds("feature", false); // get term array for taxonomy feature
		    $exteriors = $this->getSystematicTermIds("exterior", false); // get term array for taxonomy exterior
		    $interiors = $this->getSystematicTermIds("interior", false); // get term array for taxonomy interior
		    $table_name_features = 'p35p6_nbreal_features';
		    $frelations = $wpdb->get_results("SELECT * FROM " . $table_name_features, ARRAY_A);
            // get properties relations with features, interiors and exteriors 
            $nbreal_frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=" . (int) $nbreal_property_id, ARRAY_A);
            $property_features = array();
            $property_exterior = array();
            $property_interior = array();
            if (isset($nbreal_frelations) && !empty($nbreal_frelations)) {
                foreach ($nbreal_frelations as $nbreal_frelation) {
                    $nbreal_feature_id = $nbreal_frelation['nbreal_feature_id'];
                    $frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_features where nbreal_feature_id=" . (int) $nbreal_feature_id, ARRAY_A);
                    $frelations_title_slug = str_replace(" ", "-", strtolower($frelations[0]['title']));
                    $fid = $this->get_custom_term_by_slug($frelations_title_slug, 'feature');
                    $eid = $this->get_custom_term_by_slug($frelations_title_slug, 'exterior');
                    $iid = $this->get_custom_term_by_slug($frelations_title_slug, 'interior');
                    if (in_array($fid->term_id, $features)) {
                    	$this->add_term_relation((int) $property_wp_postid, (int) $fid->term_id);
                    }
                    if (in_array($eid->term_id, $exteriors)) {
                    	$this->add_term_relation((int) $property_wp_postid, (int) $eid->term_id);
                    }
                    if (in_array($iid->term_id, $interiors)) {
                    	$this->add_term_relation((int) $property_wp_postid, (int) $iid->term_id);
                    }
                } // End foreach
            } // End if
            

            $builder_title=$nbreal["p_builder_title"];//(isset($nbreal["p_builder_title"]) && !empty($nbreal["p_builder_title"]))?$gt_var->get($nbreal["p_builder_title"]):$nbreal["p_builder_title"];
	        if (isset($builder_title) && $builder_title != '') {
		        //$terms = get_term_by('slug', $builder_title_slug, 'proprietor');
		        $builder_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($builder_title))));
            	$terms = $this->get_custom_term_by_slug($builder_title_slug, 'proprietor');
		        $taxonomy_meta['type'] = 3;
		        if ($terms->term_id != '') {
		        	$this->add_term_relation((int) $property_wp_postid, (int) $terms->term_id);
		            update_post_meta($property_wp_postid, '_proprietor', $terms->term_id);
		            $term_id=$terms->term_id;
		        }else{
		        	//add new proprietor as term
		    		$added_proprietor_id = $this->add_new_term($builder_title, "proprietor");
		            if (!is_object($added_proprietor_id) && isset($added_proprietor_id) && $added_proprietor_id != 0) {
		            	update_post_meta($property_wp_postid, '_proprietor', $added_proprietor_id);
		            	$this->add_term_relation((int) $property_wp_postid, (int) $added_proprietor_id);
		                //manage country-region-place relation in options
		            	$place_taxonomy_meta['country'] = $cntry_id;
		            	$place_taxonomy_meta['region'] = $region_id;
		            	$place_taxonomy_meta['provinces'] = $t;
			        	update_option('azull_taxonomy_meta_' . $added_proprietor_id, $place_taxonomy_meta);
			        	$term_id=$added_proprietor_id;
		            }
		        }
		        $taxonomy_meta['phone'] = $nbreal['p_builder_phone'];
		        $taxonomy_meta['email'] = $nbreal['p_builder_email'];
		        $taxonomy_meta['web'] = $nbreal['p_builder_website'];
		        update_option('azull_taxonomy_meta_' . $term_id, $taxonomy_meta);
	    	}
            $cntry_id = '';
            //translate taxonomy title to english using google translate library
            $country_title = (isset($nbreal["p_location_country_title"]) && !empty($nbreal["p_location_country_title"]))?$gt_var->get($nbreal["p_location_country_title"]):$nbreal["p_location_country_title"];
            if (isset($country_title) && $country_title != '') {
            	$country_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($country_title))));
            	$term = $this->get_custom_term_by_slug($country_title_slug, 'country');
                if(isset($term->term_id) && !empty($term->term_id) && $term->term_id!=''){
                	$cntry_id=$term->term_id;
                	$this->add_term_relation((int) $property_wp_postid, (int) $term->term_id);
	                update_post_meta($property_wp_postid, '_country', $term->term_id);
            	}else{
            		//add new country as term
            		$added_country_id = $this->add_new_term($country_title, "country");
                    if (!is_object($added_country_id) && isset($added_country_id) && $added_country_id != 0) {
                    	update_post_meta($property_wp_postid, '_country', $added_country_id);
                    	$this->add_term_relation((int) $property_wp_postid, (int) $added_country_id);
                    }
            	}
            }
            $region_id='';
            //translate taxonomy title to english using google translate library
            $region_title=(isset($nbreal["p_region_title"]) && !empty($nbreal["p_region_title"]))?$gt_var->get($nbreal["p_region_title"]):$nbreal["p_region_title"];

            if (isset($region_title) && $region_title != '') {
            	$region_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($region_title))));
		        $term = $this->get_custom_term_by_slug($region_title_slug, 'region');
                if(isset($term->term_id) && !empty($term->term_id) && $term->term_id!=''){
                	$region_id = $term->term_id;
                	$this->add_term_relation((int) $property_wp_postid, (integer) $term->term_id);
                	update_post_meta($property_wp_postid, '_region', $term->term_id);
            	}else{
            		//add new region as term
            		$added_region_id = $this->add_new_term($region_title, "region");
                    if (!is_object($added_region_id) && isset($added_region_id) && $added_region_id != 0) {
                    	$region_id = $added_region_id;
                    	update_post_meta($property_wp_postid, '_region', $added_region_id);
                    	$this->add_term_relation((int) $property_wp_postid, (integer) $added_region_id);
                        //manage country-region relation in options
                    	$region_taxonomy_meta['country'] = $cntry_id;
			        	update_option('azull_taxonomy_meta_' . $added_region_id, $region_taxonomy_meta);
                    }
            	}
            }
            
            $city_title = $nbreal["p_location_city_title"];
            //translate taxonomy title to english using google translate library
            //$city_title=(isset($nbreal["p_location_city_title"]) && !empty($nbreal["p_location_city_title"]))?$gt_var->get($nbreal["p_location_city_title"]):$nbreal["p_location_city_title"];
            if (isset($city_title) && $city_title != '') {
            	$city_title_slug = str_replace("--", "-",str_replace("---", "-", str_replace(" ", "-", strtolower($city_title))));
		        $term = $this->get_custom_term_by_slug($city_title_slug, 'place');
                if(isset($term) && !empty($term) && $term!=''){
                	$this->add_term_relation((int) $property_wp_postid, (int) $term->term_id);
                	update_post_meta($property_wp_postid, '_place', $term->term_id);
            	}else{
            		//add new place as term
            		$added_place_id = $this->add_new_term($city_title, "place");
                    if (!is_object($added_place_id) && isset($added_place_id) && $added_place_id != 0) {
                    	update_post_meta($property_wp_postid, '_place', $added_place_id);
                    	$this->add_term_relation((int) $property_wp_postid, (int) $added_place_id);
                        //manage country-region-place relation in options
                    	$place_taxonomy_meta['country'] = $cntry_id;
                    	$place_taxonomy_meta['region'] = $region_id;
                    	$place_taxonomy_meta['provinces'] = $t;
			        	update_option('azull_taxonomy_meta_' . $added_place_id, $place_taxonomy_meta);
                    }
            	}
            }
			$place_term_id = get_post_meta($property_wp_postid,'_place',true );
            $taxonomy_m = get_option('azull_taxonomy_meta_' . (int) $place_term_id);
            $t = '';
            $provinces = $this->get_all_terms('provinces');
            foreach ($provinces as $province) {
                $taxonomy_metap = get_option('azull_taxonomy_meta_' . (int) $province->term_id);
                if ($taxonomy_metap['region'] == $taxonomy_m['region']) {
                    $t = $province->term_id;
                }
            }
            if ($t != '') {
            	$this->add_term_relation((int) $property_wp_postid, (integer) $t);
                update_post_meta((int) $property_wp_postid, '_province', (integer) $t);
            }

        }
	    }//end foreach $data_nbreal
	    return array('t_record_updated'=>$t_record_updated,'t_record_added'=>$t_record_added,'t_record_travesed'=>$t_record_travesed,'t_available_record'=>$t_available_record);
    }//end if $nbreal_Properties
}

/*
* Date : 05-03-2016
* Method : function for get taxonomy terms in systamatic order by name
* Params : taxonomy
* Return : array
*/

function getSystematicTerms($taxonomy = '') {
	global $wpdb;
    $terms_array = get_terms($taxonomy, 'orderby=id&hide_empty=0');
    //for filter property category and post category
    if(isset($taxonomy) && !empty($taxonomy) && $taxonomy=='category'){
    	if(isset($terms_array) && !empty($terms_array)){
    		$temp_array=array();
    		foreach ($terms_array as $term) {
    			if($term->term_id!=1){
	                $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
	                if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'property') {
	                    $temp_array[]=$term;
	                }
            	}
            }
    	}
    	$terms_array=$temp_array;
    }
    foreach ($terms_array as $val) {
        $taxonomy_terms[$val->term_id] = trim(strtolower($val->name));
    }
    return $taxonomy_terms;
}
/*
* Date : 05-03-2016
* Method : function for get taxonomy terms in systamatic order by ids
* Params : taxonomy
* Return : array
*/
function getSystematicTermIds($taxonomy = '', $type = "ASSOC") {
	global $wpdb;
	$terms_array = $this->get_custom_terms($taxonomy, 'orderby=id&hide_empty=0');
    //$terms_array = get_terms($taxonomy, 'orderby=id&hide_empty=0');
    //for filter property category and post category
    if(isset($taxonomy) && !empty($taxonomy) && $taxonomy=='category'){
    	if(isset($terms_array) && !empty($terms_array)){
    		$temp_array=array();
    		foreach ($terms_array as $term) {
    			if($term->term_id != 1){
	                $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
	                if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'property') {
	                    $temp_array[] = $term;
	                }
            	}
            }
    	}
    	$terms_array = $temp_array;
    }
    switch ($type) {
        case 'ASSOC' ://array index start with 1
            $taxonomy_terms = array();
            $i = 0;
            foreach ($terms_array as $val) {
                $i++;
                $taxonomy_terms[$i] = $val->term_id;
            }
            break;
        default ://array index start with 0
            $taxonomy_terms = array();
            foreach ($terms_array as $val) {
                $taxonomy_terms[] = $val->term_id;
            }
            $taxonomy_terms = array_values($taxonomy_terms);
            break;
    }
    return $taxonomy_terms;
}
/**************
Date: 25-apr-2016
method: customisation function because asynacronous was not working
**/
/**************
method: customisation function because asynacronous was not working
**/
public function get_custom_term_by_slug($taxonomy_slug,$taxonomy) {
      global $wpdb;
      //echo "SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_terms.slug = '$taxonomy_slug' AND wp_term_taxonomy.taxonomy = '$taxonomy'";die;
       $record = $wpdb->get_row("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_terms.slug = '$taxonomy_slug' AND wp_term_taxonomy.taxonomy = '$taxonomy'");
       if(!empty($record)){
       	return $record;
       }
   }
/*
* Date : 09-May-2016
* Method : function for get term 
*/
function get_custom_terms($taxonomy){
    global $wpdb;
    $record = $wpdb->get_results("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_term_taxonomy.taxonomy = '$taxonomy'");
    if(!empty($record)){
  	 return $record;
    }
    return '';
}
/*
* Date : 09-May-2016
* Method : function for add new term
*/
function add_new_term($term_title, $taxonomy){
   global $wpdb;
   $term_slug = str_replace(" ", "-", strtolower($term_title));
   $term = $this->get_custom_term_by_slug($term_slug,$taxonomy);
   if(isset($term) && !empty($term)){
		return false;
   }else{
   		$wpdb->insert('wp_terms',array('name' => $term_title,'slug' => $term_slug));
   		$added_term_id = $wpdb->insert_id;
		if(isset($added_term_id) && !empty($added_term_id) && $added_term_id!=0){
			$wpdb->insert('wp_term_taxonomy',array('term_id' => $added_term_id,'taxonomy' => $taxonomy,'parent'=>0));
			return $added_term_id;
		}
   }
return false;
}
/*
* Date : 09-May-2016
* Method : function for add term relationship
*/
function add_term_relation($post_id,$termId){
   global $wpdb;
   $wpdb->insert('wp_term_relationships',array('object_id' => $post_id,'term_taxonomy_id' => $termId)); 
}
/*
* Date : 09-May-2016
* Method : function for get al terms
*/
public function get_all_terms($texonomy) {
      global $wpdb;
       $record = $wpdb->get_results("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_term_taxonomy.taxonomy = '$texonomy'");
       if(!empty($record)){
       	return $record;
       }
       return ;
   }
/*============== Properties Import Steps End ===================*/
/*
* Date : 08-June-2016
* Method : function for define/set cron job for import properties from azull.info to azull.biz
* Params : NULL
* Return : success or error message
*/

function import_property_custom_cron_request() {
    global $wpdb;
	if (isset($_POST["cron_btn"])) {
		$set_cron = 0;
		$records = $wpdb->get_row('SELECT * FROM wp_xml_record WHERE type = 5 order by id desc', ARRAY_A);
		if(isset($records) && !empty($records)){
			if($records['status']==1){//cron is running, can't set custom cron now
				$err =__("Import property cron already working, please try after finish currently running cron process!", 'azull') . "<br/>";
			    
			    $response['html'] = '<div id="message" class="notice notice-error below-h2"><p>'.$err.'</p></div>';
			}elseif($records['status']==2){//cron competed, set custom cron
				$set_cron = 1;
			}
		}else{
			$set_cron = 1;
		}
		if(isset($set_cron) && $set_cron == 1){
			//add new cron job for data transfer from azull.info to azull.biz
			$data = array(
				'path' => '',
				'type' => 5,
				'agentId' => 0,
				'status' => 1,
				'start_datetime' => date('Y-m-d h:i:s'),
				'slot' => 1,
				'slot_status' => 1,
				'total_records' => 0,
				'total_traverse_record' => 0,
				'total_updated_records' => 0,
				'total_added_records' => 0
			);
			$wpdb->insert('wp_xml_record',$data);
			$succes =__("Import property cron job set successfully, property import start within few minutes.", 'azull') . "<br/>";

		    $response['html'] = '<div id="message" class="notice notice-success below-h2"><p>'.$succes.'</p></div>';
		}
	}
    die(json_encode($response));
   }
/*
* Date : 17-June-2016
* Method : function for filter and remove properties
* Params : NULL
* Return : NULL
*/

function filter_and_remove_properties() {
	$t_property_sql = "SELECT $property_tbl.*,$builder_tbl.title as p_builder_title,$builder_tbl.phone as p_builder_phone,$builder_tbl.email as p_builder_email,$builder_tbl.website as p_builder_website,$region_tbl.title as p_region_title,$country_tbl.title as p_location_country_title,$city_tbl.title as p_location_city_title,$category_tbl.title as p_category_title
                FROM $property_tbl
                LEFT JOIN $builder_tbl ON $builder_tbl.nbreal_builder_id=$property_tbl.nbreal_builder_id 
                LEFT JOIN $location_tbl ON $location_tbl.nbreal_location_id=$property_tbl.nbreal_location_id
                LEFT JOIN $country_tbl ON $country_tbl.nbreal_country_id=$location_tbl.nbreal_country_id 
                LEFT JOIN $region_tbl ON $region_tbl.nbreal_region_id=$location_tbl.nbreal_region_id 
                LEFT JOIN $city_tbl ON $city_tbl.nbreal_city_id=$location_tbl.nbreal_city_id 
                LEFT JOIN $category_tbl ON $category_tbl.nbreal_category_id=$property_tbl.nbreal_category_id where $property_tbl.website = 1 order by $property_tbl.nbreal_property_id";
    $properties = $this->get_azull_info_property_data($t_property_sql);
	if(isset($properties) && !empty($properties)){
		global $wpdb;
		$azullInfoProperty = array_column($properties,'nbreal_property_id');
		$querystr = "SELECT p.ID,pm1.meta_value AS _nreal_id,pm2.meta_value AS _azullinfo_import,pm3.meta_value AS _xmlref FROM $wpdb->posts p LEFT JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_nreal_id') LEFT JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_azullinfo_import'
        ) LEFT JOIN $wpdb->postmeta pm3 ON (pm3.post_id = p.ID  AND pm3.meta_key = '_xmlref') WHERE post_type = 'property'";
	                   
    	//$querystr = "SELECT p.ID,pm1.meta_value AS _nreal_id,pm2.meta_value AS _azullinfo_import FROM $wpdb->posts p LEFT JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_nreal_id') LEFT JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_azullinfo_import') WHERE post_type = 'property'";
	    $records = $wpdb->get_results($querystr, ARRAY_A);
	    $temp=array();
	    $remove_property=array();
	    if(isset($records) && !empty($records)){
	    	foreach ($records as $key => $val) {
	    		if(isset($val['_azullinfo_import']) && !empty($val['_azullinfo_import']) && $val['_azullinfo_import']==1 && isset($azullInfoProperty) && is_array($azullInfoProperty) && !in_array($val['_nreal_id'],$azullInfoProperty)){
	    			//$remove_property[] = array('ID'=>$val['ID'],'_nreal_id'=>$val['_nreal_id'],'_azullinfo_import'=>$val['_azullinfo_import'],'_xmlref'=>$val['_xmlref']);
	    			$wpdb->insert('wp_xml_record',array('path' => (integer) $val['ID'],'agentId' => 0,'status'=>0,'type'=>3));
	    		}
	    	}
	    	//print('<pre>');print_r($remove_property);die('helo');
	    }
	}
}
/*function remove_unpublished_properties() {
	die('hi');
	$property_tbl = 'p35p6_nbreal_properties';
    $location_tbl = 'p35p6_nbreal_locations';
    $region_tbl = 'p35p6_nbreal_regions';
    $builder_tbl = 'p35p6_nbreal_builders';
    $country_tbl = 'p35p6_nbreal_countries';
    $city_tbl = 'p35p6_nbreal_cities';
    $category_tbl = 'p35p6_nbreal_categories';
	$t_property_sql = "SELECT $property_tbl.*,$builder_tbl.title as p_builder_title,$builder_tbl.phone as p_builder_phone,$builder_tbl.email as p_builder_email,$builder_tbl.website as p_builder_website,$region_tbl.title as p_region_title,$country_tbl.title as p_location_country_title,$city_tbl.title as p_location_city_title,$category_tbl.title as p_category_title
                FROM $property_tbl
                LEFT JOIN $builder_tbl ON $builder_tbl.nbreal_builder_id=$property_tbl.nbreal_builder_id 
                LEFT JOIN $location_tbl ON $location_tbl.nbreal_location_id=$property_tbl.nbreal_location_id
                LEFT JOIN $country_tbl ON $country_tbl.nbreal_country_id=$location_tbl.nbreal_country_id 
                LEFT JOIN $region_tbl ON $region_tbl.nbreal_region_id=$location_tbl.nbreal_region_id 
                LEFT JOIN $city_tbl ON $city_tbl.nbreal_city_id=$location_tbl.nbreal_city_id 
                LEFT JOIN $category_tbl ON $category_tbl.nbreal_category_id=$property_tbl.nbreal_category_id where $property_tbl.website = 1 AND $property_tbl.enabled = 1 order by $property_tbl.nbreal_property_id";
    $properties = $this->get_azull_info_property_data($t_property_sql);
    
	if(isset($properties) && !empty($properties)){
		global $wpdb;
		$azullInfoProperty = array_column($properties,'nbreal_property_id');

		$querystr = "SELECT p.ID,pm1.meta_value AS _nreal_id,pm2.meta_value AS _azullinfo_import,pm3.meta_value AS _xmlref FROM $wpdb->posts p LEFT JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_nreal_id') LEFT JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_azullinfo_import'
        ) LEFT JOIN $wpdb->postmeta pm3 ON (pm3.post_id = p.ID  AND pm3.meta_key = '_xmlref') WHERE post_type = 'property'";
	                   
    	//$querystr = "SELECT p.ID,pm1.meta_value AS _nreal_id,pm2.meta_value AS _azullinfo_import FROM $wpdb->posts p LEFT JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_nreal_id') LEFT JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_azullinfo_import') WHERE post_type = 'property'";
	    $records = $wpdb->get_results($querystr, ARRAY_A);
	    //print('<pre>');print_r($azullInfoProperty);
	    print('<pre>');print_r($records);//die('helo');
	    $temp=array();
	    $remove_property=array();
	    if(isset($records) && !empty($records)){
	    	$i=0;
	    	foreach ($records as $key => $val) {
	    		if(isset($val['_azullinfo_import']) && !empty($val['_azullinfo_import']) && $val['_azullinfo_import']==1 && isset($azullInfoProperty) && is_array($azullInfoProperty) && in_array($val['_nreal_id'],$azullInfoProperty)){
	    			//$remove_property[] = array('ID'=>$val['ID'],'_nreal_id'=>$val['_nreal_id'],'_azullinfo_import'=>$val['_azullinfo_import'],'_xmlref'=>$val['_xmlref']);
	    			$biz_copied_properties[] = $val['_nreal_id'];
	    			//print_r($i);die('k=>>>>k');
	    			//if($i<50){
		    			//$wpdb->insert('wp_xml_record',array('path' => (integer) $val['ID'],'agentId' => 0,'status'=>0,'type'=>3));
		    		//}
		    		$i++;
	    		}
	    		
	    	}
	    	//print('<pre>');print_r($biz_copied_properties);die('helo again');
	    }
	    foreach ($azullInfoProperty as $ai_key => $ai_value) {
	    	if(!in_array($ai_value,$biz_copied_properties)){
	    		$biz_not_copied_properties[] = $ai_value;
	    	}
	    }
	    
	    print('<pre>');print_r($biz_not_copied_properties);die('helo again');
	}
}*/
/*function remove_unpublished_properties() {
	die('hi');
	$property_tbl = 'p35p6_nbreal_properties';
    $location_tbl = 'p35p6_nbreal_locations';
    $region_tbl = 'p35p6_nbreal_regions';
    $builder_tbl = 'p35p6_nbreal_builders';
    $country_tbl = 'p35p6_nbreal_countries';
    $city_tbl = 'p35p6_nbreal_cities';
    $category_tbl = 'p35p6_nbreal_categories';
	$t_property_sql = "SELECT $property_tbl.*,$builder_tbl.title as p_builder_title,$builder_tbl.phone as p_builder_phone,$builder_tbl.email as p_builder_email,$builder_tbl.website as p_builder_website,$region_tbl.title as p_region_title,$country_tbl.title as p_location_country_title,$city_tbl.title as p_location_city_title,$category_tbl.title as p_category_title
                FROM $property_tbl
                LEFT JOIN $builder_tbl ON $builder_tbl.nbreal_builder_id=$property_tbl.nbreal_builder_id 
                LEFT JOIN $location_tbl ON $location_tbl.nbreal_location_id=$property_tbl.nbreal_location_id
                LEFT JOIN $country_tbl ON $country_tbl.nbreal_country_id=$location_tbl.nbreal_country_id 
                LEFT JOIN $region_tbl ON $region_tbl.nbreal_region_id=$location_tbl.nbreal_region_id 
                LEFT JOIN $city_tbl ON $city_tbl.nbreal_city_id=$location_tbl.nbreal_city_id 
                LEFT JOIN $category_tbl ON $category_tbl.nbreal_category_id=$property_tbl.nbreal_category_id where $property_tbl.website = 1 AND $property_tbl.enabled = 0 order by $property_tbl.nbreal_property_id";
    $properties = $this->get_azull_info_property_data($t_property_sql);
    
	if(isset($properties) && !empty($properties)){
		global $wpdb;
		$azullInfoProperty = array_column($properties,'nbreal_property_id');

		$querystr = "SELECT p.ID,pm1.meta_value AS _nreal_id,pm2.meta_value AS _azullinfo_import,pm3.meta_value AS _xmlref FROM $wpdb->posts p LEFT JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_nreal_id') LEFT JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_azullinfo_import'
        ) LEFT JOIN $wpdb->postmeta pm3 ON (pm3.post_id = p.ID  AND pm3.meta_key = '_xmlref') WHERE post_type = 'property'";
	                   
    	//$querystr = "SELECT p.ID,pm1.meta_value AS _nreal_id,pm2.meta_value AS _azullinfo_import FROM $wpdb->posts p LEFT JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_nreal_id') LEFT JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_azullinfo_import') WHERE post_type = 'property'";
	    $records = $wpdb->get_results($querystr, ARRAY_A);
	    //print('<pre>');print_r($azullInfoProperty);
	    //print('<pre>');print_r($records);die('helo');
	    $temp=array();
	    $remove_property=array();
	    if(isset($records) && !empty($records)){
	    	$i=0;
	    	foreach ($records as $key => $val) {
	    		if(isset($val['_azullinfo_import']) && !empty($val['_azullinfo_import']) && $val['_azullinfo_import']==1 && isset($azullInfoProperty) && is_array($azullInfoProperty) && in_array($val['_nreal_id'],$azullInfoProperty)){
	    			$remove_property[] = array('ID'=>$val['ID'],'_nreal_id'=>$val['_nreal_id'],'_azullinfo_import'=>$val['_azullinfo_import'],'_xmlref'=>$val['_xmlref']);
	    			//print_r($i);die('k=>>>>k');
	    			if($i<50){
		    			//$wpdb->insert('wp_xml_record',array('path' => (integer) $val['ID'],'agentId' => 0,'status'=>0,'type'=>3));
		    		}
		    		$i++;
	    		}
	    		
	    	}
	    	print('<pre>');print_r($remove_property);die('helo again');
	    }
	}
}*/

/*function addThankuPageText(){
       $checkValue='';
        $parameters = array();
        parse_str($_POST['fdata'], $parameters);
        $pageText=serialize($parameters['page_text']);
        $optionId="thk_page_text_".$_POST['id'];
        $checkValue=$_POST['check'];
        
       if($checkValue && $checkValue!=''){
           $terms = unserialize(get_option($optionId));
           echo json_encode($terms);
           exit();
       }else{
           add_option( $optionId, $pageText, '', 'yes' );
           update_option($optionId, $pageText, '', 'yes' );
           die(true);
       }
       
}*/
/*
* Date : 04-Aug-2016
* Method : function for save weather info for each place/city to azull.biz
* Params : NULL
* Return : success or error message
*/
/*function save_weather_info_request() {
    global $wpdb;
    if(isset($_POST['place_id']) && $_POST['place_id']!=0){
    	$dataArr=array();
    	$error = 1;
    	$languages = qtranxf_getSortedLanguages();
    	if(isset($languages) && !empty($languages)){
    		foreach ($languages as $key => $val) {
    			if($_POST['vpn_val'][$val]){
    				$error=0;
    			}
    		}
    	}
    	$before_clients = array();
    	if(isset($_POST['vpn_val']) && $error==0){
    		$tmp=array('vpn'=>$_POST['vpn_val']);
    		if(isset($_POST['clients']) && !empty($_POST['clients'])){
    			$tmp['clients']=$_POST['clients'];
    		}
    		$weather_info = get_option('weather_info');
    		if(isset($weather_info) && !empty($weather_info) && count($weather_info)>0){
    			foreach ($weather_info as $key => $value) {
    				if($_POST['place_id']==$key){//echo $key;die('key');
    					$dataArr[$key] = $tmp;
    					$before_clients = $weather_info[$key]['clients'];
    				}else{
    					$dataArr[$key] = $value;
    				}
    			}
    		}
    		$dataArr[$_POST['place_id']]=$tmp;
			$after_clients=array();
			//update server meta value
			update_option('weather_info', $dataArr);
			if(isset($_POST['clients']) && $_POST['clients']!=''){
			    //get clients after update meta
				$after_clients = $_POST['clients'];
			    //add/update weather info at selected client's website
	    		foreach($_POST['clients'] as $client){
		            $obj = new Xmlrpc_Client($client);
		            if(!$obj->test_connection())
		               continue;
		               $obj->save_client_weatherinfo($client);
		         }
			}
			if(isset($before_clients) && !empty($before_clients) && count($before_clients)>0){
				foreach ($before_clients as $key => $client) {
					if(!in_array($client,$after_clients)){
						//delete uncheck client post
						$obj = new Xmlrpc_Client($client);
						if(!$obj->test_connection())
						    continue;
						    $obj->delete_weather_info($client,$_POST['place_id']);
					}
				}
			}
    		$succes =__("Weather info saved successfully..", 'azull') . "<br/>";
		    $response['html'] = '<div id="message" class="notice notice-success below-h2"><p>'.$succes.'</p></div>';
    	}else{
	    	$err =__("Please enter visible place name!", 'azull') . "<br/>";
			$response['html'] = '<div id="message" class="notice notice-error below-h2"><p>'.$err.'</p></div>';	
	    }
    }else{
    	$err =__("Please select place!", 'azull') . "<br/>";
		$response['html'] = '<div id="message" class="notice notice-error below-h2"><p>'.$err.'</p></div>';	
    }
    die(json_encode($response));
   }*/

 /*
* Date : 04-Aug-2016
* Method : function for get weather info for place/city to azull.biz
* Params : NULL
* Return : success or error message
*/
/*function get_place_weather_info_request(){
	if(isset($_POST['place_id']) && $_POST['place_id']!=0){
		$weather_info = get_option('weather_info');
    		if(isset($weather_info) && !empty($weather_info) && count($weather_info)>0){
    			foreach ($weather_info as $key => $value) {
    				if((int)$_POST['place_id'] === (int)$key){
    					$response['vpn'] = $value['vpn'];
    					$response['clients'] = $value['clients'];
    					die(json_encode($response));
    				}
    			}
    		}
	}
}*/

/*
* Date : 04-Aug-2016
* Method : function for save weather info for each place/city to azull.biz
* Params : NULL
* Return : success or error message
*/
function save_weather_info_request() {
    global $wpdb;
    if(isset($_POST['place_id']) && $_POST['place_id']!=0){
    	$dataArr=array();
    	$error = 1;
    	$languages = qtranxf_getSortedLanguages();
    	if(isset($languages) && !empty($languages)){
    		foreach ($languages as $key => $val) {
    			if($_POST['vpn_val'][$val]){
    				$error=0;
    				$t_name = $_POST['vpn_val'][$val];
    			}
    		}
    	}
    	$before_clients = array();
    	if(isset($_POST['vpn_val']) && $error==0){
    		$tmp = array(
    			'place' => $_POST['place_id'],
    			'vpn' => $_POST['vpn_val'],
    			'name' => (isset($_POST['vpn_val']['nl']) && !empty($_POST['vpn_val']['nl']))?$_POST['vpn_val']['nl']:$t_name,
    		);
    		if(isset($_POST['clients']) && !empty($_POST['clients'])){
    			$tmp['clients']=$_POST['clients'];
    		}
    		$weather_info = get_option('weather_info');
    		if(isset($weather_info) && !empty($weather_info) && count($weather_info)>0){
    			foreach ($weather_info as $key => $value) {
    				if($_POST['place_id']==$key){
    					$dataArr[$key] = $tmp;
    					$before_clients = $weather_info[$key]['clients'];
    				}else{
    					$dataArr[$key] = $value;
    				}
    			}
    		}
    		$dataArr[$_POST['place_id']]=$tmp;
			$after_clients=array();
			//update server meta value
			update_option('weather_info', $dataArr);
			if(isset($_POST['clients']) && $_POST['clients']!=''){
			    //get clients after update meta
				$after_clients = $_POST['clients'];
			    //add/update weather info at selected client's website
	    		foreach($_POST['clients'] as $client){
		            $obj = new Xmlrpc_Client($client);
		            if(!$obj->test_connection())
		               continue;
		               $obj->save_client_weatherinfo($client);
		         }
			}
			if(isset($before_clients) && !empty($before_clients) && count($before_clients)>0){
				foreach ($before_clients as $key => $client) {
					if(!in_array($client,$after_clients)){
						//delete uncheck client post
						$obj = new Xmlrpc_Client($client);
						if(!$obj->test_connection())
						    continue;
						    $obj->delete_weather_info($client,$_POST['place_id']);
					}
				}
			}
    		$succes =__("Weather info saved successfully..", 'azull') . "<br/>";
		    $msg = '<div id="message" class="notice notice-success below-h2"><p>'.$succes.'</p></div>';
		    $err_state = 0; 
    	}else{
	    	$err =__("Please enter visible place name!", 'azull') . "<br/>";
			$msg = '<div id="message" class="notice notice-error below-h2"><p>'.$err.'</p></div>';
			$err_state = 1; 
	    }
    }else{
    	$err =__("Please select place!", 'azull') . "<br/>";
		$msg = '<div id="message" class="notice notice-error below-h2"><p>'.$err.'</p></div>';
		$err_state = 1; 
    }
    $response = array('error'=>$err_state,'msg'=>$msg);
    die(json_encode($response));
   }

 /*
* Date : 04-Aug-2016
* Method : function for get weather info for place/city to azull.biz
* Params : NULL
* Return : success or error message
*/
function get_place_weather_info_request(){
	if(!empty($_POST['place_id'])){
		$place_id = base64_decode($_POST['place_id']);
		$weather_info = get_option('weather_info');
    		if(isset($weather_info) && !empty($weather_info) && count($weather_info)>0){
    			$obj_subsciber = new Azull_Subscriber();
    			foreach ($weather_info as $key => $value) {
    				if((int)$place_id === (int)$key){
    					$response['place'] = $place_id;
    					$response['vpn'] = $value['vpn'];
    					$response['clients'] = $value['clients'];
    					$response['place_meta'] = get_option('azull_taxonomy_meta_' . $place_id);
    					$response['edit_frm_title'] = $obj_subsciber->getTranslatedString('en','nl','Edit').' '.$obj_subsciber->getTranslatedString('en','nl','Weather Info');
    					die(json_encode($response));
    				}
    			}
    		}
	}
}
/*
* Date: 20-Dec-2016
* Method: function for delete weather info record
*/
function delete_weather_info() {
    if(!empty($_POST['place_id'])){
		$place_id = base64_decode($_POST['place_id']);
        $weather_info_data = get_option('weather_info');
        if(isset($weather_info_data) && !empty($weather_info_data) && count($weather_info_data)>0){
        	//print('<pre>');print_r($weather_info_data[$place_id]['clients']);die('chk');
        	if(isset($weather_info_data[$place_id]['clients']) && count($weather_info_data[$place_id]['clients'])>0){
        		foreach ($weather_info_data[$place_id]['clients'] as $key => $client) {
        			//delete uncheck client post
					$obj = new Xmlrpc_Client($client);
					if(!$obj->test_connection())
						continue;
						$obj->delete_weather_info($client,$place_id);
				}
        	}
            unset($weather_info_data[$place_id]);
            update_option('weather_info', $weather_info_data);
            $response['error'] = 0;
            $response['msg'] ='<div id="message" class="notice notice-success below-h2"><p>'.__("Record successfully deleted.", 'azull').'<br/></p></div>';
            die(json_encode($response));
        }
   }
   $response['error'] = 1;
   $response['msg'] ='<div id="message" class="notice notice-error below-h2"><p>'.__("Something goes wrong, please try again later.", 'azull').'<br/></p></div>';
   die(json_encode($response));
}


/* Function: display property price details.
   Date: 02/12/2016.
   Author: manoj(ab).
*/
function property_price_val(){
	$html='';
	
	if(isset($_POST['p_id']) && $_POST['p_id']!=''){

      $salesPrice=get_post_meta($_POST['p_id'], '_salesPrice', false);
      $vat=get_post_meta( $_POST['p_id'], '_vat', false);
      $transmissionTax=get_post_meta( $_POST['p_id'], '_transmissionTax', false);
      $stampDuty=get_post_meta( $_POST['p_id'], '_stampDuty', false);
      $buyerCost=get_post_meta( $_POST['p_id'], '_buyerCost', false);
      $notaryCost=get_post_meta( $_POST['p_id'], '_notaryCost', false);
      $totalPrice=get_post_meta( $_POST['p_id'], '_totalPrice', false);
      $lawyerCost=get_post_meta( $_POST['p_id'], '_lawyerCost', false);
      $buildType=get_post_meta( $_POST['p_id'],  '_buildType', false);
      $nreal_id=get_post_meta( $_POST['p_id'],  '_nreal_id', false);
      $proprietorRef = get_post_meta($_POST['p_id'], '_proprietorRef', true);
      $utilitiesConnectionCost=get_post_meta( $_POST['p_id'],  '_utilitiesConnectionCost', false);
      

	    $country=get_post_meta($_POST['p_id'],'_country',true);
	    $region=get_post_meta($_POST['p_id'],'_region',true);
	    $province=get_post_meta($_POST['p_id'],'_province',true);
	    
	    if(isset($country)){
	     if(get_option('country_tax_'.$country)) 	
	     $azullTax=get_option('country_tax_'.$country);
	    }
	    if(isset($region)){
	       if(get_option('region_tax_'.$region))
	       $azullTax =get_option('region_tax_'.$region);   	
	    }	 
	    if( isset($province)){
	       if(get_option('province_tax_'.$region))	
	       $azullTax =get_option('province_tax_'.$province);
	    }
	    if($azullTax)
	     $default = json_decode($azullTax,true);	

    $vat_min = ((isset($default["vat"]["min"]) && $default["vat"]["min"] != '') ? $default["vat"]["min"] : '');
	$vat_per = ((isset($default["vat"]["per"]) && $default["vat"]["per"] != '') ? $default["vat"]["per"] : '');	
	$vat_per = ((isset($val["vat"]) && $val["vat"] != '') ? max($val["vat"],$vat_per) : $vat_per);


    $transmissionTax_min = ((isset($default["transmissionTax"]["min"]) && $default["transmissionTax"]["min"] != '') ? $default["transmissionTax"]["min"] :'');
	$transmissionTax_per = ((isset($default["transmissionTax"]["per"]) && $default["transmissionTax"]["per"] != '') ? $default["transmissionTax"]["per"] : '');
	$transmissionTax_per = ((isset($val["transmissionTax"]) && $val["transmissionTax"] != '') ?  max($val["transmissionTax"],$transmissionTax_per) : $transmissionTax_per);

	$stampDuty_min = ((isset($default["stampDuty"]["min"]) && $default["stampDuty"]["min"] != '') ? $default["stampDuty"]["min"] : '');
	$stampDuty_per = ((isset($default["stampDuty"]["per"]) && $default["stampDuty"]["per"] != '') ? $default["stampDuty"]["per"] : '');
	$stampDuty_per = ((isset($val["stampDuty"]) && $val["stampDuty"] != '') ?  max($val["stampDuty"],$stampDuty_per) : $stampDuty_per);

    $notaryCost_min = ((isset($default["notaryCost"]["min"]) && $default["notaryCost"]["min"] != '') ? $default["notaryCost"]["min"] : '');
	$notaryCost_per = ((isset($default["notaryCost"]["per"]) && $default["notaryCost"]["per"] != '') ? $default["notaryCost"]["per"] : '');
	$notaryCost_per = ((isset($val["notaryCost"]) && $val["notaryCost"] != '') ? max($val["notaryCost"],$notaryCost_per) : $notaryCost_per);	

	$lawyerCost_min = ((isset($default["lawyerCosts"]["min"]) && $default["lawyerCosts"]["min"] != '') ? $default["tlawyerCosts"]["min"] : '');
	$lawyerCost_per = ((isset($default["lawyerCosts"]["per"]) && $default["lawyerCosts"]["per"] != '') ? $default["lawyerCosts"]["per"] : '');
	$lawyerCost_per = ((isset($val["lawyerCosts"]) && $val["lawyerCosts"] != '') ? max($val["lawyerCosts"],$lawyerCost_per) : $lawyerCost_per);

	$buyerCost_min = ((isset($default["buyerCosts"]["min"]) && $default["buyerCosts"]["min"] != '') ? $default["buyerCosts"]["min"] : '');
	$buyerCost_per = ((isset($default["buyerCosts"]["per"]) && $default["buyerCosts"]["per"] != '') ? $default["buyerCosts"]["per"] : '');
	$buyerCost_per = ((isset($val["buyerCost"]) && $val["buyerCost"] != '') ? max($val["buyerCost"],$buyerCost_per) : $buyerCost_per);

    $v=0;
	$utilitiesConnectionCost_min = ((isset($default["utilitiesConnectionCost"]["min"]) && $default["utilitiesConnectionCost"]["min"] != '') ? $default["utilitiesConnectionCost"]["min"] : '');
	
	$utilitiesConnectionCost_per = ((isset($default["utilitiesConnectionCost"]["per"]) && $default["utilitiesConnectionCost"]["per"] != '') ? $default["utilitiesConnectionCost"]["per"] : '');
	if(get_post_meta($_POST['p_id'],"_salesPrice",true) && $utilitiesConnectionCost_per!='')
	$v = ($utilitiesConnectionCost_per/100) * get_post_meta($_POST['p_id'],"_salesPrice",true); 	
	$v = max($utilitiesConnectionCost_min,$v);	
	///$utilitiesConnectionCost_per = ((isset($val["utilitiesConnectionCost"]) && $val["utilitiesConnectionCost"] != '') ? max($val["utilitiesConnectionCost"],$v) : $v);

    if($salesPrice[0]!=''){
      	$price=$salesPrice[0];
    }
     
$html .='<h2 style="margin-top: -70px;"><b>Property Detail</b></h2>';
$html .='<hr>';
$html .='<a id="popupclose" class="close" href="#">&times;</a>';
$html .='<div class="content_price">';
$html.='<table id="finance_override_pop_up" class="form-table financial_data" >';
$html.='<tr></tr><tr><td><label>Proprietor Ref</label><input id="prop_ref_no" maxlength="12" type="text" name="prop_ref_no" value="'.$proprietorRef.'" style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); margin-bottom: 5px;"><br></td></tr>';

$html.='<tr><td style="height: 25px;"><label>#Ref</label>'.$nreal_id[0].'</td></tr>';
$html.='<tr><td style="height: 25px;"><label>Title</label>'.get_the_title($_POST['p_id']).'</td></tr>';

$html.='<tr></tr><tr><td ><label>Build Type</label>';
	if($buildType[0]==1){
		$select="selected";
	}else{
		$select1="selected";
	}
$html.='<select id="buildTypePopUp" disabled name="property_meta_finance[buildType]" onchange="calculatePriceSumPopup(this);" style="margin-bottom: 5px;">
              <option value="1" '.$select.'>New</option>
              <option value="2" '.$select1.'>Resale</option>
              </select><br>
              </td><td></td></tr>';

$html.='<tr></tr><tr><td><label>Sales Price</label><input onkeyup="calculatePriceSumPopup(this);" onkeydown="calculatePriceSumPopup(this);" autocomplete="off" id="salesPricePopUp" class="decimal meta_sale_price rule1 rule2" maxlength="12" type="text" name="property_meta_finance[salesPrice]" value="'.$price.'" style="background-color: rgb(255, 255, 255); color: rgb(0, 0, 0); margin-bottom: 5px;"><br><span class="description">Enter sales price (xxxxxx.xx)</span></td></tr>';

$html.='<tr><td><label>VAT</label><input style="margin-bottom: 5px;" type="text" readonly  id="vatPopUp" autocomplete="off" class="decimal percent rule1 sum" data_min="'.$vat_min.'" maxlength="4" name="property_meta_finance[vat]" value="'.$vat[0].'" >
                   	<br></td></tr>';

$html.='<tr><td><label>Transmission tax</label><input  style="margin-bottom: 5px;" readonly data_min="0" autocomplete="off" id="transmissionTaxPopUp"class="decimal percent rule2 sum" maxlength="4" data_min="'.$transmissionTax_min.'" type="text" name="property_meta_finance[transmissionTax]" value="'.$transmissionTax[0].'"</td><td></td></tr>';

$html.='<tr></tr>';

$html.='<tr><td><label>Stamp Duty</label><input style="margin-bottom: 5px;"  readonly autocomplete="off" id="stampDutyPopUp"  class="decimal percent rule1 sum" maxlength="4" data_min="'.$stampDuty_min.'" type="text" name="property_meta_finance[stampDuty]" value="'.$stampDuty[0].'" ><br>
 	</td><td></td></tr>';

$html.='<tr><td><label>Notary costs</label><input readonly id="notaryCostPopUp" class="decimal percent rule1 rule2 sum" maxlength="4" data_min="'.$notaryCost_min.'" type="text" name="property_meta_finance[notaryCost]" value="'.$notaryCost[0].'" style="background-color: #eee; margin-bottom: 5px;"><br>
    </td><td></td></tr>';

$html.='<tr><td><label>Lawyer costs</label><input readonly autocomplete="off" id="lawyerCostPopUp"  class="decimal percent rule1 rule2 sum" maxlength="4" type="text" name="property_meta_finance[lawyerCost]" value="'.$lawyerCost[0].'" style="background-color: #eee; margin-bottom: 5px;"><br>
   </td><td></td></tr>';

$html.='<tr><td><label>Utilities connection cost</label><input readonly  autocomplete="off" id="utilitiesConnectionCostPopUp" data_min="'.$utilitiesConnectionCost_min.'" class="decimal rule1 rule2 sum" maxlength="10" type="text" name="property_meta_finance[utilitiesConnectionCost]" value="'.$utilitiesConnectionCost[0].'" style="background-color: #eee; margin-bottom: 5px;"><br>
   </td><td></td></tr>';

$html.='<tr><td><label>Buyer costs</label><input readonly class="decimal percent rule2 sum" id="buyerCostPopUp" data_min="'.$buyerCost_min.'" maxlength="4" type="text" name="property_meta_finance[buyerCost]" value="'.$buyerCost[0].'" style="background-color: #eee; margin-bottom: 5px;"><br>
    </td><td></td></tr>';

$html.='<tr><td><label>Total price</label><input readonly style="color: rgb(0, 0, 0); background-color: rgb(240, 240, 240); margin-bottom: 5px;" id="finance_total_pop_up" autocomplete="off" class="decimal" readonly="" maxlength="12" type="text" name="property_meta_finance[totalPrice]" value="'.$totalPrice[0].'">
    </td><td></td></tr>';

$html.='</table>';
$html.='<table width="70%"><tr><td width="50%"></td><td align="center"><input class="button" type="button" value="Update" onclick="return updateProperyPrice('.$_POST['p_id'].')" style="background: none repeat scroll 0 0 hsl(196, 63%, 49%);border-color: hsl(197, 100%, 32%);box-shadow: 0 1px 0 hsla(196, 69%, 69%, 0.5) inset, 0 1px 0 hsla(0, 0%, 0%, 0.15);color: hsl(0, 0%, 100%);margin: 5px 0 0 3px;text-decoration: none;">&nbsp;<span id="load" style="display:none;"><img src="http://azull.biz/cisin/wp-includes/images/spinner.gif"></span><br></td><td></td></tr></table>';
$html .='</div>';

	}
	?>

<script type="text/javascript">

var total = 0;

/* Function: calculate property price in percentage.
   Date: 02/12/2016.
   Author: manoj(ab).
*/
function calculatePercentagePricePopup(virtualElem) {
    var calculatedVal = 0;   

    var virtualElemVal = parseFloat(jQuery("#"+virtualElem).val());    
    var virtualElemDataMin = jQuery("#"+virtualElem).attr('data_min');
    var virtualRuleCheck = jQuery('#buildTypePopUp').val();
      
    if (virtualElem != 'salesPricePopUp' && virtualElem != 'utilitiesConnectionCostPopUp') {

        percentOff = parseFloat(jQuery('#salesPricePopUp').val());
        calculatedVal = parseFloat(percentOff * (virtualElemVal / 100))

        if (typeof virtualElemDataMin != "undefined") {
            if (calculatedVal < virtualElemDataMin) {
                calculatedVal = virtualElemDataMin;
            }
        }
    }
    return calculatedVal;
}


/* Function: calculate and display property sum price detail.
   Date: 02/12/2016.
   Author: manoj(ab).
*/
function calculatePriceSumPopup(elem) {

	    var ruleCheck = jQuery('#buildTypePopUp').val();
	    var ruleName = 'rule'+ruleCheck;
	    var total = parseFloat(jQuery('#salesPricePopUp').val());
	    if (jQuery('#utilitiesConnectionCostPopUp').hasClass(ruleName)) {
	        total += parseFloat(jQuery('#utilitiesConnectionCostPopUp').val());
	    }
	    jQuery("#finance_override_popUp").find('input[type=text]').css({"background-color": "#f0f0f0"});
	    jQuery("#finance_override_popUp").find('input[type=text]').css({"color": "#f0f0f0"});
	    jQuery("#finance_override_pop_up").css({"color": "#000"});

	    //calculate percentage of sale price
	    jQuery("#finance_override_pop_up").find('input[type=text]').each(function(currInput) {
	        currVal=jQuery("#"+this.id).val();
	        if (jQuery("#"+this.id).hasClass(ruleName)) {
	           total = parseFloat(total) + parseFloat(calculatePercentagePricePopup(this.id));
	        }
	    });
	    if (total > 0) {
	        jQuery('#finance_total_pop_up').val(parseFloat(total).toFixed(0));
	    }
	}

/* Function: update property price and proprietor ref no.
   Date: 02/12/2016.
   Author: manoj(ab).
*/
function updateProperyPrice(postId){
	jQuery("#load").show();
    var salesP =jQuery('#salesPricePopUp').val();
    var totalP =jQuery('#finance_total_pop_up').val();
    var prop_ref_no =jQuery('#prop_ref_no').val();
    jQuery.ajax({
        type: "POST",
        url: ajaxurl,
        data: {action: 'update_property_price',p_id:postId,salesP:salesP,totalP:totalP,prop_ref_no:prop_ref_no},
    }).done(function(response) {
	   	jQuery("#load").hide();
	   	var url =jQuery(location).attr('href'); 
	  	url = url.replace('#price','');
		window.location.href = url+'&suc=1';
    });
}	
//decimal validation
jQuery("input.decimal").bind("keypress", function(e) {
    var keyCode = e.which ? e.which : e.keyCode
    var ret = (((keyCode >= 48 && keyCode <= 57) || keyCode == 46) || specialKeys.indexOf(keyCode) != -1);
    if (ret) {
        jQuery(this).siblings(".description").removeClass("error");
    } else {
        jQuery(this).siblings(".description").addClass("error");
    }
    return ret;
});
jQuery("input.decimal").bind("paste", function(e) {
    return false;
});
jQuery("input.decimal").bind("drop", function(e) {
    return false;
});

</script>
	<?php
	echo $html;die();
}

/* Function: update property price details and  proprietor refrence no.
   Date: 02/12/2016.
   Author: manoj(ab).
*/
function update_property_price_val(){
	if(isset($_POST['p_id']) && $_POST['p_id']!=''){
	    $salesP=$_POST['salesP'];
	    $totalP=$_POST['totalP'];
	    $prop_r_no=$_POST['prop_ref_no'];
		update_post_meta($_POST['p_id'], '_salesPrice', $salesP);
		update_post_meta($_POST['p_id'], '_totalPrice', $totalP);
		update_post_meta($_POST['p_id'], '_proprietorRef', $prop_r_no);
		$clients = get_post_meta($_POST['p_id'],'_client',true );
		if(isset($clients) && !empty($clients) && count($clients)>0){
		    foreach($clients as $client){
				$obj = new Xmlrpc_Client($client);
				if(!$obj->test_connection())
				    continue;			
				    $obj->xmlrpc_update_property_meta($_POST['p_id']);
		    }
		}	
	}
  die;	
}

  
//*********** End class **********//
}
