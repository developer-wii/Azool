<?php
/**class to manage property news letter subscription on azull server
 *@author:Dhananjay Pandey
 *@since:1.0
 *@package:wordpress
 *@subpackage:azull
 */

 //todo: some more work required in phase two and three
 //todo: move js and css in seperate file
 
defined('ABSPATH') or die("No script kiddies please!");

class Azull_Subscriber{
    
    static function profile_admin_buffer_start() { ob_start(array('Azull_Subscriber','remove_plain_bio')); }
    static function profile_admin_buffer_end() { ob_end_flush(); }
    
    static function remove_plain_bio($buffer) {
	$titles = array('#<h3>About Yourself</h3>#','#<h3>About the user</h3>#');
	$buffer=preg_replace($titles,'<h3>Password</h3>',$buffer,1);
	$biotable='#<h3>Password</h3>.+?<table.+?/tr>#s';
	$buffer=preg_replace($biotable,'<h3>Password</h3> <table>',$buffer,1);
	return $buffer;
        //todo:need to check if we need to implement translation here or not....
    }
    
    static function _profile( $contactmethods ) {
        unset($contactmethods['aim']);
        unset($contactmethods['jabber']);
        unset($contactmethods['yim']);
        
        /*$contactmethods['house'] = 'House number';
        $contactmethods['street'] = 'Street name';
        $contactmethods['city'] = 'City/Place';
        $contactmethods['state'] = 'State/Region';
        $contactmethods['country'] = 'Country';
        $contactmethods['zip'] = 'Zip/Postal code';
        $contactmethods['phone'] = 'Phone Number';
        $contactmethods['ip'] = 'Registration IP';
        $contactmethods['language'] = 'Registration language';
        $contactmethods['selection'] = 'Selection Tags';*/
        
        return $contactmethods;
    }
    
    static function hide_personal_options(){
        echo "<script type='text/javascript'>
	    jQuery(document).ready(function($) { $('form#your-profile > h3:first').hide(); $('form#your-profile > table:first').hide();
	    $('form#your-profile').show(); 
	     $('.user-url-wrap').hide(); 

	});
	</script>";
    }    
    

    static function azull_email() {
            add_submenu_page(  null, 'Azull Email', 'Azull Email', 'manage_options', 'email', array('Azull_Subscriber','email' )); 
    }
    
    
    static function set_html_content_type( $content_type ){
	    return 'text/html';
    }
    
    static function email() {        
          
	global $q_config;
	
	global $wpdb;
	$table_name = $wpdb->prefix . "company";
	/*$company = $wpdb->get_results(
		"SELECT * FROM {$table_name}"
	);*/
	$company = get_posts(array('post_type'=>'company','post_status'=>'publish','order' => 'ASC'));
	//$sql = "SELECT * FROM wp_posts where post_type='company' AND post_status='publish' ORDER BY id ASC";
	//$company = $wpdb->get_results($sql);

	//echo $wpdb->last_query;die('chk');
	//print('<pre>');print_r($company);die;
	$new_locale =(isset($_POST['language']) && $_POST['language']!='') ? $_POST['language'] :'nl';
	//$new_locale =(isset($_POST['language']) && $_POST['language']!='') ? $_POST['language'] :qtranxf_getLanguage();	
	$old_locale = get_locale();
	setlocale(LC_ALL, $new_locale);
	$q_config['language'] = substr($new_locale, 0, 2);
	//send selected property to all email ids....
	if(isset($_POST['emails']) && $_POST['emails']!=''){
		$emails =$pieces = explode(",",$_POST['emails']);
		foreach ($emails as $email){
		    $user = get_user_by( 'id', $email );		   
		    $send_emails[] =$user->data->user_email;                    
		}
		$subject=$_POST['subject'];
		$from_email_str = "<".$_POST['from_email'].">";
		$headers[] = __('From','azull').': Azull  '.$from_email_str;
		$html ='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
		$html .='<html xmlns="http://www.w3.org/1999/xhtml">';
		$html .='<head>';
		$html .='<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';
		$html .='<title>'.$subject.'</title>';		
		$html .='</head>';
		$html .='<body>';
		$html .= stripslashes($_POST['emaileditor']);
		$html .='</body>';
		$html .='</html';			
		add_filter( 'wp_mail_content_type', array('Azull_Subscriber','set_html_content_type'));		
		$result=wp_mail($send_emails, $subject,$html, $headers );
		$html ='';
		if($result){
		    $html .="<div style='margin:0px; padding: 10px;' class='updated'><strong>".__('Sucessfully sent email to','azull')." </strong> ".rtrim(implode(',', $send_emails), ',').'</div>';
		}
	}
           

            $html .= '<form method="post" ><div class="wrap">';
            $html .= '<div style="padding:0" class="postbox">';           
            $html .= '<table width="100%;" cellspacing="10" cellpadding="0">';
            $html .= '<tr>';
            $html .= '<th style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left;"><label>'.__("Language","azull").'</label></th>';
	    $html .= '<td>';
	    
                $html .="<select id='emaillanguage' name='language' >";
		
                foreach ($q_config['enabled_languages'] as $l){
                    $html .='<option value="' . $l . '" '.(($new_locale==$l)? "selected='selected'":"").' >' . $q_config['language_name'][$l] . '</option>';                
                }            
                $html .="</select>";

            $url=get_option('redirect_url');    
            $html .= '<a style=" float:right; margin-right: 30px;" href="'.$url.'"><input class="button-primary" type="button" value="Back"></a>';
            $html .= '</td>';
            $html .= '</tr>';
            
            $html .= '<tr>';
            $html .= '<th style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left;   width: 20%;"><label>To:</label></th>';
	    $html .= '<td>';
	    
                        $blogusers = get_users( 'blog_id=1&orderby=nicename' ); 
                        $html .='<input type="text" id="emails" name="emails" />';            
                        $html .='<script>';
                        $html .='jQuery(document).ready(function() {
                        jQuery("#emails").tokenInput([
                        ';
                            foreach ( $blogusers as $user ) {
                               $html .='{id:'.esc_html( $user->ID ).', name: "'.esc_html( $user->user_email ).'"},';			      
                           }
                            
                        $html .='],{preventDuplicates: true,theme: "facebook", hintText: "Type to search email",noResultsText: "No emails found"});
                    });';
                    $html .= '</script>';
        
            $html .= '</td>';
            $html .= '</tr>';
            $html .= '</tr>';
	    $html .= '<th style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left;   width: 20%;"><label>From:</label></th>';
	    $azull = get_option('azullsettings',false); //get from emails id from saved options.
	    
	    $current_user = wp_get_current_user(); 
	   
	    $html .= '<td><input style="width:400px;" autocomplete="off"  type="text" name="from_email"  value="'.((isset($azull['from_email']) && $azull['from_email']!='') ? $azull['from_email']:$current_user->user_email).'" />';
            $html .= '</tr>';
	    
	    
	    $html .='<tr>';
	    $html .= '<th style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left;"><label>'.__("Company","azull").'</label></th>';
	    $html .= '<td>';
                $html .="<select id='company' name='company' class='cltCmp'>";
                foreach ($company as $cmp){
                    $html .='<option value="'.$cmp->ID.'"> '.qtranxf_use(qtranxf_getLanguage(),$cmp->post_title).'</option>';                
                }            
                $html .="</select>";
            $html .= '</td>';
	    $html .='</tr>';
            $html .= '<tr>';
            $html .= '<th style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;  text-align: left;   width: 20%;"><label>Subject</label></th>';
	    $html .= '<td style="width: 60%;"><input style="width:37%" autocomplete="off"  type="text" name="subject"  value="" />';
            $html .= '<tr>';
            $html .= '<th style="background: none repeat scroll 0 0 hsl(0, 0%, 93%);padding: 10px;"><label>Message:</label></th>';
	    $html .= '<td >';
	    //$html .= '<div id="mailMessage" style="border: 1px solid hsl(0, 0%, 80%); overflow: scroll;Me">';	
	    $html .= '<div id="mailMessage">';	    
            echo $html;
	    $html='';
	   $tpl .='<table width="1024" cellspacing="10" cellpadding="0" align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333; line-height:20px;">';
	   $ids=unserialize(base64_decode($_GET['ids']));
               if(!empty($ids))
            foreach($ids as $val){
               $post = get_post($val);
	       
                $tpl .=self::email_template($post->ID);
                
            }
	    $emailsignature = stripslashes(htmlspecialchars_decode(get_option('emailsignature_'. qtranxf_getLanguage(),false)));
	    if(isset($emailsignature) && !empty($emailsignature)){
		    $tpl .='<tr>';
		    $tpl .='<td bgcolor="#F1F3F2" colspan="2" style="padding:8px;">';
		    $tpl .= $emailsignature;
			$tpl .='</td>';
			$tpl .='</tr>';
		}
	    $tpl .='</table>';
	    $tpl .='<input type="hidden" name="emaileditor" value="'.htmlspecialchars($tpl).'">';
	    echo $tpl;
	    
            $html .= '</div>';
            $html .= '</td>';
            $html .= '</tr>'; 
            $html .= '</table>'; 

        $html .= '</div>';
        $html .= '</div>';
	
        $html .='<input class="button-primary" type="submit" value="'.__('Send email','azull').'" /></form>'; 

        echo $html;
	
	//todo:reset text domain here.. to make translation working....
	setlocale(LC_ALL, $old_locale);	
	$q_config['language'] = substr($old_locale, 0, 2);  
	
        $ajax_nonce = wp_create_nonce( "email-string" );
        if(isset($_GET['ids'])){        
        //todo: move to some.js file
        ?>
        <script>
            jQuery( document ).ready( function( $ ) {
			load();
		    jQuery(".cltCmp").change(function() {
	            load();             
	        });  
	        jQuery("#emaillanguage").change(function() { 
                load();              
            });  
        });
	    
	    
	    function load(){
            cmpval=jQuery("#company").val();
            l =jQuery("#emaillanguage").val();
            var ids = '<?php echo $_GET['ids']; ?>';
            var data = {
                action: 'cmp_email_template',
                type: 'POST',
                dataType:'json',
                security: '<?php echo $ajax_nonce; ?>',
                l:l,
			    cmaval:cmpval,
                ids: ids
            };         
            jQuery.post( ajaxurl, data, function( response ) {
		        jQuery('#mailMessage').html(response);
	        });                
	    }
    </script>
    <?php 
        }
    }
    static function email_callback() {
        global $q_config;
	$l=$_POST['l'];
	
        $ids=unserialize(base64_decode($_POST['ids']));
        $html="";
        
	$new_locale =$q_config['locale'][$l];	
        $old_locale = get_locale();
	
	//set local to traslate it $l
	setlocale(LC_ALL, $new_locale);
	$q_config['language'] = substr($new_locale, 0, 2);
	$tpl .='<table width="1024" cellspacing="10" cellpadding="0" align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333; line-height:20px;">';
	   $ids=unserialize(base64_decode($_POST['ids']));
               
            foreach($ids as $val){
		$post = get_post($val);
                $tpl .=self::email_template($post->ID);
            }
	    $emailsignature = stripslashes(htmlspecialchars_decode(get_option('emailsignature_'. qtranxf_getLanguage(),false)));
	    if(isset($emailsignature) && !empty($emailsignature)){
		    $tpl .='<tr>';
		    $tpl .='<td bgcolor="#F1F3F2" colspan="2" style="padding:8px;">';
		    $tpl .= $emailsignature;
			$tpl .='</td>';
			$tpl .='</tr>';
		}
	   /* $tpl .='<tr>';
	    $tpl .='<td bgcolor="#F1F3F2" colspan="2" style="padding:8px;">';
	    $tpl .=stripslashes(htmlspecialchars_decode(get_option('emailsignature_'.$l,false)));
		$tpl .='</td>';
		$tpl .='</tr>';	*/
	    $tpl .='</table>';
	    $tpl .='<input type="hidden" name="emaileditor" value="'.htmlspecialchars($tpl).'">';
	setlocale(LC_ALL, $old_locale);
	$q_config['language'] = substr($old_locale, 0, 2);
        die($tpl);
    }
    
    
    /* Get Template by clients  */
    
    function get_cmp_email_template(){
		global $q_config;
		$l = $_POST['l'];
		$cmpval = '';
		$cmpval = $_POST['cmaval'];
	    $ids = unserialize(base64_decode($_POST['ids']));
        $html = "";
		$new_locale = $q_config['locale'][$l];
        $old_locale = get_locale();
		//set local to traslate it $l
		setlocale(LC_ALL, $new_locale);
		$q_config['language'] = substr($new_locale, 0, 2); 
		$tpl .='<table width="1024" cellspacing="10" cellpadding="0" align="center" style="font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333; line-height:20px;">';
	    $ids=unserialize(base64_decode($_POST['ids']));
        if(isset($ids) && !empty($ids)){   
			foreach($ids as $val){
			    $post = get_post($val);
			    $tpl .=self::email_template($post->ID,$cmpval);
			    $tpl .='<tr><td bgcolor="#F1F3F2" colspan="2" style="padding:8px;"><a href="'.get_site_url().'?format=pdf&tpl=4&lng='.$l.'&clnt='.$cmpval.'&id='.$post->ID.'" style="text-decoration:none;">'.self::getTranslatedString('en',$q_config['language'],'Click here for pdf').'</a></td></tr>';
			}
	    }
	    $emailsignature = stripslashes(htmlspecialchars_decode(get_option('emailsignature_'. qtranxf_getLanguage(),false)));
	    if(isset($emailsignature) && !empty($emailsignature) && strlen($emailsignature)>68){
		    $tpl .='<tr>';
		    $tpl .='<td bgcolor="#F1F3F2" colspan="2" style="padding:8px;">';
		    $tpl .= $emailsignature;
			$tpl .='</td>';
			$tpl .='</tr>';
		}
	    /*$tpl .='<tr>';
	    $tpl .='<td bgcolor="#F1F3F2" colspan="2" style="padding:8px;">';
	    $tpl .=stripslashes(htmlspecialchars_decode(get_option('emailsignature_'.$l,false)));
		$tpl .='</td>';
		$tpl .='</tr>';	*/
	    $tpl .='</table>';
	    $tpl .='<input type="hidden" name="emaileditor" value="'.htmlspecialchars($tpl).'">';
		setlocale(LC_ALL, $old_locale);
		$q_config['language'] = substr($old_locale, 0, 2);
	    die($tpl);
    }
 
/* Get translated string 
   Date:01-09-2016 abhi.p
*/    
function getTranslatedString($l1,$l2,$str){
    $allstring=get_option('azullString');
    $stringD=json_decode($allstring);
    $strArray=array();
    foreach ($stringD as $key => $value) {
         $strArray=$value;
         foreach ($strArray as $key1 => $value1) {
         	if($strArray->$l1 == $str){
                $getstrArray[]=$strArray->$l2;
         	}
         }
    }
    if($getstrArray[0]!=''){
       return $getstrArray[0];
    }else{
       return $str;
    }
    
}

function email_template($post_id, $clientid=""){

    $color = "#1566B1";
    $color = get_post_meta($clientid, '_companyclr', true);
    if(!isset($color)){
	  $color = "#1566B1";
    }
    global $q_config,$aj_config;
    $html="";
    $post = get_post($post_id); 
    /*code for add title and content if not define in language*/
    $title_array = qtranxf_split($post->post_title); 
    $content_array = qtranxf_split($post->post_content);
  
    if(isset($title_array) && !empty($title_array)){
       if($title_array[$_POST['l']]!=''){
        $title=qtranxf_use(qtranxf_getLanguage(),get_the_title($post->ID));
       }else{   
         $title=getTitleContent($post->ID,$_POST['l']);
       }
     }
     if(isset($content_array) && !empty($content_array)){
       if($content_array[$_POST['l']]!=''){
         $content=qtranxf_use(qtranxf_getLanguage(),$post->post_content);
       }else{   
         $content=getTitleContent($post->ID,$_POST['l']);
       }
     }       
    $term =get_the_terms($post->ID, 'category');
    $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID),'large' );	
    $settings = get_option('azullsettings');
    
	$html .='<tr>';
	    $html .='<td colspan="2" bgcolor="'.$color.'">';
		$html .='<table width="100%" cellspacing="10" cellpadding="10">';
		    $html .='<tr>';
		   // $html .='<td style="font-family:Arial, Helvetica, sans-serif; color:#fff; font-size:16px; text-transform:uppercase;">'.qtranxf_use(qtranxf_getLanguage(),get_the_title($post->ID)).'</td>';
		    $html .='<td style="font-family:Arial, Helvetica, sans-serif; color:#fff; font-size:16px; text-transform:uppercase;">'.$title.'</td>';
            $html .='<td align="right" style="font-family:Arial, Helvetica, sans-serif; color:#fff; font-size:16px; text-transform:uppercase;"> Ref.&nbsp;'.get_post_meta($post_id,'_nreal_id',true).'</td>';
			//$html .='<td style="font-family:Arial, Helvetica, sans-serif; color:#fff; font-size:16px; text-transform:uppercase;">'.qtranxf_use(qtranxf_getLanguage(),get_the_title($post->ID)).' - Ref. '.get_post_meta($post->ID,"_nreal_id",true).'</td>';
		    $html .='</tr>';
		$html .='</table>';
	    $html .='</td>';
	$html .='</tr>';
	$html .='<tr>';
    $html .='<td width="70%" valign="top"><img style="display:block;" src="'.$url.'" width="695" height="440" alt="" /></td>';
    $html .='<td valign="top">';
    $html .= self::azull_email_gallery($post_id,6,'thumbnail'); 
    $html .='</td>';
	$html .='</tr>';
	$html .='<tr>';
   	$html .='<td valign="top">';
	$html .='<table width="100%" cellspacing="0" cellpadding="10" style="margin-bottom:10px;">';
    $html .='<tr>';
	$html .='<td colspan="2" bgcolor="#E5F2FF"><pre style="font-family: calibriregular, Arial, Helvetica, sans-serif;border: none;white-space: pre-wrap;display: inline-block;margin:0;padding:2px;">'.$content.'</pre></td>';
    $html .='</tr>';	   
	$html .='</table>';
	$html .='<table width="100%" cellspacing="0" cellpadding="10">';
    $html .='<tr>';
	$html .='<td width="50%" bgcolor="#F1F3F2">';
		if(azull_price("Sales price",$post->ID) && azull_price("Sales Price",$post->ID)!="")
		//$html .='<p style="margin:0"><strong>'.__("Sales Price","azull").' : '.number_format ( (integer)azull_price("Sales price",$post->ID) , 0 , "" , "." ).$aj_config["currency"].'</strong></p>';

	   $html .='<p style="margin:0"><strong>'.self::getTranslatedString('en','nl','Sales Price').' : '.number_format ( (integer)azull_price("Sales price",$post->ID) , 0 , "" , "." ).$settings['currency'].'</strong></p>';
		
		if(azull_price("Sales price",$post->ID) && azull_price("Total Price",$post->ID)!="")
		//$html .='<p style="margin:0"><strong>'.__("Total Price","azull").' : '.number_format ( (integer)azull_price("Total price",$post->ID) , 0 , "" , "." ).$aj_config["currency"].'</strong></p>';

		$html .='<p style="margin:0"><strong>'.self::getTranslatedString('en','nl','Total Price').' : '.number_format ( (integer)azull_price("Total price",$post->ID) , 0 , "" , "." ).$settings['currency'].'</strong></p>';					
		//$aj_config["currency"]
		//$html .='<p style="font-size: 10px; margin: 0 0 5px;padding:0px;">('.__("Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.","azull").')</p>';
		$html .='<p style="font-size: 10px; margin: 0 0 5px;padding:0px;">('.self::getTranslatedString('en','nl','Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.').')</p>';
	$html .'</td>';
	$html .='<td bgcolor="#F1F3F2" style="border-left-width:10px; border-left-color:#ffffff; border-left-style:solid;">';
		if(property_category($post->ID) && property_category($post->ID)!='')
		//$html .='<p style="margin:0"><strong>'.__("Category","azull").' : '.'</strong>'.property_category($post->ID).'</p>';
	   //$trs= self::getTranslatedString('en','nl','Category');
        $html .='<p style="margin:0"><strong>'.self::getTranslatedString('en','nl','Category').' : '.'</strong>'.property_category($post->ID).'</p>';
		if(property_status($post->ID) && property_status($post->ID)!='')
			$html .='<p style="margin:0"><strong>'.self::getTranslatedString('en','nl','Status').' : '.'</strong>'.property_status($post->ID).'</p>';
			
			if(build_year($post->ID) && build_year($post->ID)!='')
			$html .='<p style="margin:0"><strong>'.__("Build Year","azull").' : '.'</strong>'.build_year($post->ID).'</p>';
			if(property_location($post->ID) && property_location($post->ID)!='')
			//$html .='<p style="margin:0"><strong>'.__("Location","azull").' : '.'</strong>'.property_location($post->ID).'</p>';
          $html .='<p style="margin:0"><strong>'.self::getTranslatedString('en','nl','Location').' : '.'</strong>'.property_location($post->ID).'</p>';
			$html .='</td>';
		    $html .='</tr>';
		$html .='</table>';
		
	    $html .='</td>';
	    
	    $html .='<td valign="top">';
		$html .=self::features_icon($post->ID,false,$color);          
	    $html .='</td>';
		$html .='</tr>';
	    return $html;
    }
    
 private function features_icon($post_id=false,$flag=false,$color){
     if(!$post_id){
	  global $post;
	  $post_id = $post->ID;
	 
	}
	$i=1;
	$j=0;
	$html ='<table width="100%" cellspacing="0" cellpadding="0">';	
	
	$terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){	
	    $taxonomy_meta['type']=1;$taxonomy_meta['search']=0;
              foreach ( $terms as $term ) {
      $fnuber= get_post_meta($post_id,'_feature_'.$term->term_id,true);
      $fnuber =(isset($fnuber ) && is_numeric($fnuber)) ? $fnuber: $fnuber;
	  $fnuber =(isset($fnuber ) && !is_numeric($fnuber)) ?__($fnuber,'azull'): $fnuber;
     if($term && $fnuber!=0){
	       $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
	            if($taxonomy_meta['type']==2 && get_post_meta($post_id,'_feature_'.$term->term_id,true)!='' && z_taxonomy_image_url($term->term_id)!=''){
			if($i%4==1)
			    $html .='<tr>';
			    $fnuber= get_post_meta($post_id,'_feature_'.$term->term_id,true);
	            $fnuber =(isset($fnuber ) && is_numeric($fnuber)) ? $fnuber: $fnuber;
		        $fnuber =(isset($fnuber ) && !is_numeric($fnuber)) ?__($fnuber,'azull'): $fnuber;
		    
			    $html .='<td bgcolor="'.$color.'" valign="top" style="border-bottom-width:10px; border-bottom-color:#ffffff; border-bottom-style:solid;'.(($j%4!=0) ? "border-left-width:10px; border-left-color:#ffffff; border-left-style:solid;":"").'">';
			    $html .='<table width="100%" cellspacing="0" cellpadding="0">';
				   
				    $html .='<tr>';
					$html .='<td valign="top"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66" height="66" /></td>';
				    $html .='</tr>';
				     $html .='<tr>';
				         
					    if($fnuber && $fnuber!=0){
							$html .='<td align="center" valign="top" style="background-color:#fff; color:'.$color.'; border-width:1px; border-style:solid; border-color:'.$color.';"><span style="font-size:13px; line-height:16px;">'.$fnuber.'</span></td>';
					    }
					    	 
					    
				         $html .='</tr>';
			    $html .='</table>';		     
                        
			if($i%4==0)	
				$html .='</tr>';
			
			$i++;
			$j++;
		    }
		         $taxonomy_meta['search']=0;  
               }
            } 
        }
	
	$terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );  
	if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	  foreach ( $terms as $term ) {	
	      $distance="";
	      $val=get_post_meta($post_id,'_scores_'.$term->term_id,true);
	      if(isset($val) && $val!="" && z_taxonomy_image_url($term->term_id)!='' && $val!= 0){
		$distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km' : number_format((float)$val,0,".","") .'m'; 	    

		  
		if($i%4==1)
		    $html .='<tr>';
			    
		$html .='<td bgcolor="'.$color.'" valign="top" style="border-bottom-width:10px; border-bottom-color:#ffffff; border-bottom-style:solid;'.(($j%4!=0) ? "border-left-width:10px; border-left-color:#ffffff; border-left-style:solid;":"").'">';
		    $html .='<table width="100%" cellspacing="0" cellpadding="0">';

			$html .='<tr>';
				$html .='<td valign="top"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66" height="66" /></td>';
			$html .='</tr>';
			$html .='<tr>';
				$html .='<td align="center" valign="top" style="background-color:#fff; color:'.$color.'; border-width:1px; border-style:solid; border-color:#20A342;"><span style="font-size:13px; line-height:16px;">'.$distance.'</span></td>';
			$html .='</tr>';
		    $html .='</table>';			     
                        
		if($i%4==0)
		    $html .='</tr>';
		$i++;
		$j++;
	      }
	    }
	}
	
	$terms  = get_terms( 'dimensions', 'orderby=id&hide_empty=0' ); 
	if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	  foreach ( $terms as $term ) {	
	      $distance="";
	      $val=get_post_meta($post_id,'_dimensions_'.$term->term_id,true);
	      if(isset($val) && $val!="" && z_taxonomy_image_url($term->term_id)!='' && $val!= 0){
		//$distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km²' : number_format((float)$val,0,".","") .'m²'; 	    
          $distance .= ((float)$val>999) ? number_format(((float)$val),0,".","").'m²' : number_format((float)$val,0,".","") .'m²'; 
		  
		if($i%4==1)
		    $html .='<tr>';
			    
		$html .='<td bgcolor="'.$color.'" valign="top" style="border-bottom-width:10px; border-bottom-color:#ffffff; border-bottom-style:solid;'.(($j%4!=0) ? "border-left-width:10px; border-left-color:#ffffff; border-left-style:solid;":"").'">';
		    $html .='<table width="100%" cellspacing="0" cellpadding="0">';

			$html .='<tr>';
				$html .='<td valign="top"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66" height="66" /></td>';
			$html .='</tr>';
			$html .='<tr>';
				$html .='<td align="center" valign="top" style="background-color:#fff; color:'.$color.'; border-width:1px; border-style:solid; border-color:'.$color.';"><span style="font-size:13px; line-height:16px;">'.$distance.'</span></td>';
			$html .='</tr>';
		    $html .='</table>';			     
                        
		if($i%4==0)
		    $html .='</tr>';
		$i++;
		$j++;
	      }
	    }
	}
	
	$taxonomys= array('locality','feature','interior','exterior');
	
	foreach($taxonomys as $taxonomy){
	$terms = wp_get_post_terms($post_id, $taxonomy);
	if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	  foreach ( $terms as $term ) {	
	  	if(isset($term) && $term!="" && z_taxonomy_image_url($term->term_id)!=''){
		if($i%4==1)
		    $html .='<tr>';
			    
		$html .='<td bgcolor="'.$color.'" valign="top" style="border-bottom-width:10px; border-bottom-color:#ffffff; border-bottom-style:solid;'.(($j%4!=0) ? "border-left-width:10px; border-left-color:#ffffff; border-left-style:solid;":"").'">';
		    $html .='<table width="100%" cellspacing="0" cellpadding="0">';
			
			$html .='<tr>';
				$html .='<td valign="top"><img src="'.z_taxonomy_image_url($term->term_id).'" width="66" height="66" /></td>';
			$html .='</tr>';
		    $html .='</table>';			     
                        
		if($i%4==0)
		    $html .='</tr>';
		$i++;
		$j++;
	      }
	   }
	}
    }	
	
    $html .='</table>';
      
    if($flag)
	echo $html;
	
    return $html;
    
    
 } // End cmp Feachear icon+
    
    
    
    
    private  function azull_email_gallery($post_id,$limit,$size='full'){    
	$html="";                 
	$i=0;
	$j=1;	  
	$html .='<table width="100%" cellspacing="0" cellpadding="0">';
	foreach (  Property_Meta::azull_gallery($post_id) as $id ) {
		
		    if(get_post_thumbnail_id( $post_id )!=$id && $i< $limit && $id!=''):	    
		    $url =wp_get_attachment_image_src( $id, $size );
		    if($j%2==1)
		    $html .='<tr>';	    
			$html .='<td style="padding-bottom:10px;'.(($j%2==0) ?"padding-left:10px;":"").'"><img style="display:block;" width="142" height="140" src="'.$url[0].'" width="100%" height="140px" alt="" /></td>';		
		     if($j%2==0)
		    $html .='</tr>';
		    $j++;
		    $i++;
		    endif;
	}
	$html .='</table>';
	return $html;		 
	return false;		           
    }    
    
}
