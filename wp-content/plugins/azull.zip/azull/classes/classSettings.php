<?php
/*
 * 
 * Tags: azull_meta_keywords, azull_meta_description 
 * @package:wordpress
 * @subpackage:azull
 */
defined('ABSPATH') or die("No script kiddies please!");

class Settings{    

   static function init() {
    add_options_page( 'Azull Setting','Azull','manage_options','azull', array( "Settings", 'settings_page' ) );
   }
   
  static function  settings_page () {
   global $aj_config,$q_config;
   $languages = qtranxf_getSortedLanguages();
   
   foreach($languages as $lang) {
      if(isset($_POST['emailsignature_'.$lang])){		
	 	update_option('emailsignature_'.$lang,htmlspecialchars($_POST['emailsignature_'.$lang]));
      }

      if(isset($_POST['pdfsignature_'.$lang])){		
	 	update_option('pdfsignature_'.$lang,htmlspecialchars($_POST['pdfsignature_'.$lang]));
      }
   }

	
   if(isset($_POST['azull']))
   
        
   	update_option('azullsettings',$_POST['azull']);

        if((isset($_POST['country']) && $_POST['country']!='') && ((isset($_POST['region']) && $_POST['region']=='') && (isset($_POST['province']) && $_POST['province']=='') )){
	    update_option('country_tax_'.$_POST['country'],json_encode($_POST['azullTax']));
	    
	    
	    foreach(azull::get_sites() as $site){
	       $obj = new Xmlrpc_Client($site);	 	       
	       $term = get_term_by('id', (int)$_POST['country'], 'country');
	       $remote_term_id = $obj->has_taxonomy('country',$term->slug);
	       $obj->manage_client_option('country_tax_'.$remote_term_id,json_encode($_POST['azullTax']),'siteoptions');	       
	    } 
	    
	 }
	 
	 if( isset($_POST['region'] ) && $_POST['region']!='' && (isset($_POST['province']) && $_POST['province']=='' && isset($_POST['country']) && $_POST['country']!='' ) ){
	   update_option('region_tax_'.$_POST['region'],json_encode($_POST['azullTax']));
	   
	   foreach(azull::get_sites() as $site){
	       $obj = new Xmlrpc_Client($site);	 	       
	       $term = get_term_by('id', (int)$_POST['region'], 'region');
	       $remote_term_id = $obj->has_taxonomy('region',$term->slug);
	       $obj->manage_client_option('region_tax_'.$remote_term_id,json_encode($_POST['azullTax']),'siteoptions');
	       
	    }
	 }
	 
	  if( isset($_POST['province'] ) && $_POST['province']!='' && (isset($_POST['region']) && $_POST['region']!='' && isset($_POST['country']) && $_POST['country']!='' ) ){
	    update_option('province_tax_'.$_POST['province'],json_encode($_POST['azullTax']));
	    
	    foreach(azull::get_sites() as $site){
	       $obj = new Xmlrpc_Client($site);	 	       
	       $term = get_term_by('id', (int)$_POST['province'], 'provinces');
	       $remote_term_id = $obj->has_taxonomy('provinces',$term->slug);
	       
	       $obj->manage_client_option('region_tax_'.$remote_term_id,json_encode($_POST['azullTax']),'siteoptions');
	       
	    }	    
	 }	 

   $azull = get_option('azullsettings',false);   
   require_once( AZULL_DIR . 'template/settings.php' );

   //todo: user worpress api structure...
  }

  static function lists_members($apikey,$listId){       
        //@ref:http://apidocs.mailchimp.com/api/2.0/lists/members.php
        $result = array();
        $Mailchimp = new Mailchimp($apikey);        
        $result = $Mailchimp ->call('lists/members', array('id' => $listId ));
	
        if( $result === false || !is_array($result)) {
             $result= array();
        }

        return  $result;
         
    }
    
 
}
