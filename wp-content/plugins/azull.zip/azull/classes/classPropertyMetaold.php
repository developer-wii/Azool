<?php

/* The class defines all methods required to handle post meta associated with azull property, some of the post meta has been implemented
 * using seperate class for some the metabox like location and seo metabox.
 * @package:wordpress
 * @subpackage:azull
 */

defined('ABSPATH') or die("No script kiddies please!");

class Property_Meta {

   //class instance
   private static $instance;

   public static function instance() {
      if (!isset(self::$instance)) {
         self::$instance = new self;
         self::$instance->init();
      }
      return self::$instance;
   }

   // The function that outputs the gallery html
   static function property_gallery_metabox() {
      global $post;
      $values = get_post_custom($post->ID);
      if (isset($values['property_gallery']))
         $ids = json_decode(base64_decode($values['property_gallery'][0]));
      else
         $ids = array();
      wp_nonce_field('my_meta_box_nonce', 'meta_box_nonce');
      if(isset($ids) && !empty($ids))
        $cs_ids = implode(",", $ids);

      $html = do_shortcode('[gallery link="none" ids="' . $cs_ids . '"]');
      $html .= '<input id="property_gallery_ids" type="hidden" name="property_gallery_ids" value="' . $cs_ids . '" />';
      $html .= '<hr/><p><input id="manage_gallery" class="button button-primary button-large" title="Manage gallery" type="button" value="' . __("Manage gallery", "azull") . '" />' . __("Note: Manage gallery for poperty", "azull") . '</p>';
      echo $html;
   }

   static function azull_gallery($post_id) {
      $values = get_post_custom($post_id);
      //d($values);
      if(isset($values['property_gallery']))          
      {
         foreach ($values['property_gallery'] as  $value) {
            $ids = json_decode(base64_decode($value));
         }
      }else{
          $ids = array();
      }
      //$cs_ids = implode(",",$ids);  
      return  $ids;
   }       

        
   static function add_property_gallery_metabox() {
      add_meta_box('property_gallery', __('Property Gallery', 'azull'), array('Property_Meta', 'property_gallery_metabox'), 'property', 'normal', 'high');
   }

   static function save_property_metaboxes($post_id) {
      if (!isset($_POST['meta_box_nonce']) || !wp_verify_nonce($_POST['meta_box_nonce'], 'my_meta_box_nonce'))
         return;
      if (!current_user_can('edit_post'))
         return;

      if (isset($_POST['property_gallery_ids'])) {
         // Encode so it can be stored an retrieved properly
         $encode = base64_encode(json_encode(explode(',', $_POST['property_gallery_ids'])));
         update_post_meta($post_id, 'property_gallery', $encode);
      }
   }

   static function save_taxonomy_meta($term_id) {
      if (isset($_POST['taxonomy_meta']))
         update_option('azull_taxonomy_meta_' . $term_id, $_POST['taxonomy_meta']);
   }

   static function category_options($term) {
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      if ($_GET['post_type'] == 'property') {
         echo '<script>jQuery( document ).ready(function() {jQuery("#parent").closest(".form-field").css("display", "none");});</script>';
      }
      global $typenow;
      echo '<input type="hidden" name="taxonomy_meta[type]" value="' . $typenow . '" >';
   }

   static function region_add_options($term) {
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      $terms = get_terms('country', array('orderby' => 'name', 'hide_empty' => false));
      //$terms = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $html .="<div class='form-field'><label for='taxonomy_image'>" . __('Country', 'azull') . "</label><select id='country_terms' name='taxonomy_meta[country]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms as $term):
         $html .= "<option value='" . $term->term_id . "' " . ((isset($taxonomy_meta['country']) && $taxonomy_meta['country'] == $term->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "</option>";
      endforeach;
      $html .= "</select></div>";
      echo $html;
   }

   static function region_edit_options($term) {

      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      $terms = get_terms('country', array('orderby' => 'name', 'hide_empty' => false));
      //$terms = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $html .="<tr class='form-field'>";
      $html .="<th valign='top' scope='row'><label for='taxonomy_image'>" . __('Country', 'azull') . "</label></th>";
      $html .="<td><select id='country_terms' name='taxonomy_meta[country]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms as $term):
         $html .= "<option value='" . $term->term_id . "' " . ((isset($taxonomy_meta['country']) && $taxonomy_meta['country'] == $term->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "</option>";
      endforeach;
      $html .= "</select></td></tr>";
      echo $html;
   }

   static function provinces_add_options($term) {

      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      $terms_c = get_terms('country', array('orderby' => 'name', 'hide_empty' => false));
      $terms_r = get_terms('region', array('orderby' => 'name', 'hide_empty' => false));
      //$terms_c = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      //$terms_r = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
      $html .="<div class='form-field'>";
      $html .="<label for='taxonomy_image'>" . __('Country', 'azull') . "</label>";
      $html .="<select id='country_terms' name='taxonomy_meta[country]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_c as $term_c):
         $html .= "<option value='" . $term_c->term_id . "' " . ((isset($taxonomy_meta['country']) && $taxonomy_meta['country'] == $term_c->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_c->name) . "</option>";
      endforeach;

      $html .= "</select><br/>";
      $html .="<label for='taxonomy_image'>" . __('Region', 'azull') . "</label>";
      $html .="<select id='region_terms' name='taxonomy_meta[region]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_r as $term_r):
         $html .= "<option value='" . $term_r->term_id . "' " . ((isset($taxonomy_meta['region']) && $taxonomy_meta['region'] == $term_r->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_r->name) . "</option>";
      endforeach;

      $html .= "</select></div>";
      echo $html;
   }

   static function provinces_edit_options($term) {
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      $terms_c = get_terms('country', array('orderby' => 'name', 'hide_empty' => false));
      $terms_r = get_terms('region', array('orderby' => 'name', 'hide_empty' => false));
      /*$terms_c = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $terms_r = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));*/
      $html .="<tr class='form-field'>";
      $html .="<th valign='top' scope='row'><label for='taxonomy_image'>" . __('Country', 'azull') . "</label></th>";
      $html .="<td><select id='country_terms' name='taxonomy_meta[country]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_c as $term_c):
         $html .= "<option value='" . $term_c->term_id . "' " . ((isset($taxonomy_meta['country']) && $taxonomy_meta['country'] == $term_c->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_c->name) . "</option>";
      endforeach;
      $html .= "</select></td></tr>";

      $html .="<tr class='form-field'>";
      $html .="<th valign='top' scope='row'><label for='taxonomy_image'>" . __('Region', 'azull') . "</label></th>";
      $html .="<td><select id='region_terms' name='taxonomy_meta[region]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_r as $term_r):
         $html .= "<option value='" . $term_r->term_id . "' " . ((isset($taxonomy_meta['region']) && $taxonomy_meta['region'] == $term_r->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_r->name) . "</option>";
      endforeach;
      $html .= "</select></td></tr>";
      echo $html;
   }

   static function place_add_options($term) {
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      $terms_c = get_terms('country', array('orderby' => 'name', 'hide_empty' => false));
      $terms_r = get_terms('region', array('orderby' => 'name', 'hide_empty' => false));
      $terms_p = get_terms('provinces', array('orderby' => 'name', 'hide_empty' => false));
      /*$terms_c = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $terms_r = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
      $terms_p = get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));
      */
      $html .="<div class='form-field'>";
      $html .="<label for='taxonomy_image'>" . __('Country', 'azull') . "</label>";
      $html .="<select id='country_terms' name='taxonomy_meta[country]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_c as $term_c):
         $html .= "<option value='" . $term_c->term_id . "' " . ((isset($taxonomy_meta['country']) && $taxonomy_meta['country'] == $term_c->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_c->name) . "</option>";
      endforeach;
      $html .= "</select><br/>";

      $html .="<label for='taxonomy_image'>" . __('Region', 'azull') . "</label>";
      $html .="<select id='region_terms' name='taxonomy_meta[region]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_r as $term_r):
         $html .= "<option value='" . $term_r->term_id . "' " . ((isset($taxonomy_meta['region']) && $taxonomy_meta['region'] == $term_r->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_r->name) . "</option>";
      endforeach;
      $html .= "</select><br/>";

      $html .="<label for='taxonomy_image'>" . __('Provinces', 'azull') . "</label>";
      $html .="<select id='provinces_terms' name='taxonomy_meta[provinces]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_p as $term_p):
         $html .= "<option value='" . $term_p->term_id . "' " . ((isset($taxonomy_meta['provinces']) && $taxonomy_meta['provinces'] == $term_p->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_p->name) . "</option>";
      endforeach;

      $html .= "</select></div>";
      echo $html;
   }

   static function place_edit_options($term) {
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      $terms_c = get_terms('country', array('orderby' => 'name', 'hide_empty' => false));
      $terms_r = get_terms('region', array('orderby' => 'name', 'hide_empty' => false));
      $terms_p = get_terms('provinces', array('orderby' => 'name', 'hide_empty' => false));
      /*$terms_c = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $terms_r = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
      $terms_p = get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));*/
      $html .="<tr class='form-field'>";
      $html .="<th valign='top' scope='row'><label for='taxonomy_image'>" . __('Country', 'azull') . "</label></th>";
      $html .="<td><select id='country_terms' name='taxonomy_meta[country]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_c as $term_c):
         $html .= "<option value='" . $term_c->term_id . "' " . ((isset($taxonomy_meta['country']) && $taxonomy_meta['country'] == $term_c->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_c->name) . "</option>";
      endforeach;
      $html .= "</select></td></tr>";


      $html .="<tr class='form-field'>";
      $html .="<th valign='top' scope='row'><label for='taxonomy_image'>" . __('Region', 'azull') . "</label></th>";
      $html .="<td><select id='region_terms' name='taxonomy_meta[region]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_r as $term_r):
         $html .= "<option value='" . $term_r->term_id . "' " . ((isset($taxonomy_meta['region']) && $taxonomy_meta['region'] == $term_r->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_r->name) . "</option>";
      endforeach;
      $html .= "</select></td></tr>";


      $html .="<tr class='form-field'>";
      $html .="<th valign='top' scope='row'><label for='taxonomy_image'>" . __('Provinces', 'azull') . "</label></th>";
      $html .="<td><select id='provinces_terms' name='taxonomy_meta[provinces]'>";
      $html .= "<option value=''>--</option>";
      foreach ($terms_p as $term_p):
         $html .= "<option value='" . $term_p->term_id . "' " . ((isset($taxonomy_meta['provinces']) && $taxonomy_meta['provinces'] == $term_p->term_id) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $term_p->name) . "</option>";
      endforeach;
      $html .= "</select></td></tr>";

      echo $html;
   }

   static function proprietor_options($term) {

      $obj = new Azull_Subscriber(); 
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      //print_r($taxonomy_meta); die();

      if (!$taxonomy_meta)
         $taxonomy_meta['type'] = 1;

      $html = '<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      //$html .='<label for="qtranxf_term_en">' . __("Proprietorship", "azull") . '</label>';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Proprietor type')
 . ':</label>';
      
$obj->getTranslatedString('en','nl','Financial Information');

      $html .='</th>';

      $html .='<td>';
      
      //$html .='<input type="radio" checked name="taxonomy_meta[type]" value="1" >'.__('Agent','azull');
      //$html .='<input type="radio" disabled name="taxonomy_meta[type]" value="2" >'.__('Owner','azull');
      //$html .='<input type="radio" disabled name="taxonomy_meta[type]" value="3">'.__('Builder','azull');
     
     /* $html .='<input type="radio" name="taxonomy_meta[type]" value="1" ' . ((isset($taxonomy_meta["type"]) && $taxonomy_meta["type"] == 1) ? "checked" : "") . '>' . __('Agent', 'azull');
      $html .='<input type="radio"  name="taxonomy_meta[type]" value="2" ' . ((isset($taxonomy_meta["type"]) && $taxonomy_meta["type"] == 2) ? "checked" : "") . '>' . __('Owner', 'azull');
      $html .='<input type="radio" name="taxonomy_meta[type]" value="3" ' . ((isset($taxonomy_meta["type"]) && $taxonomy_meta["type"] == 3) ? "checked" : "") . '>' . __('Builder', 'azull');*/

      if($taxonomy_meta["type"]!='' && is_array($taxonomy_meta["type"])){

         $html .='<input type="checkbox" name="taxonomy_meta[type][]" value="1" ' . ((isset($taxonomy_meta["type"]) && in_array(1, $taxonomy_meta["type"])) ? "checked" : "") . '>' . __('Agent', 'azull'); 
      $html .='&nbsp;<input type="checkbox" name="taxonomy_meta[type][]" value="2" ' . ((isset($taxonomy_meta["type"]) && in_array(2, $taxonomy_meta["type"])) ? "checked" : "") . '>' . __('Owner', 'azull');
      $html .='&nbsp;<input type="checkbox" name="taxonomy_meta[type][]" value="3" ' . ((isset($taxonomy_meta["type"]) && in_array(3, $taxonomy_meta["type"])) ? "checked" : "") . '>' . __('Builder', 'azull');

      }else{
     
         $html .='<input type="checkbox" name="taxonomy_meta[type][]" value="1" ' . ((isset($taxonomy_meta["type"]) && $taxonomy_meta["type"] == 1) ? "checked" : "") . '>' . __('Agent', 'azull'); 
      $html .='&nbsp;<input type="checkbox" name="taxonomy_meta[type][]" value="2" ' . ((isset($taxonomy_meta["type"]) && $taxonomy_meta["type"] == 2) ? "checked" : "") . '>' . __('Owner', 'azull');
      $html .='&nbsp;<input type="checkbox" name="taxonomy_meta[type][]" value="3" ' . ((isset($taxonomy_meta["type"]) && $taxonomy_meta["type"] == 3) ? "checked" : "") . '>' . __('Builder', 'azull');

      }

      $html .='<p class="description"><?php _e( "Select proprietorship","azull" ); ?></p>';
      $html .='</td>';
      $html .='</tr>';

      $html .='<tr class="form-field">';
      $html .= '<td> <input type="hidden" name="taxonomy_meta[role]" value="agent"> </td>';

      /* $html .= '<select id="taxonomy_meta[role]" name = "taxonomy_meta[role]">';
        //if(isset($taxonomy_meta[role])) $role = $taxonomy_meta[role];
        $html .= "<option value=''>--</option>";
        $html .= "<option value='agent'".((isset($taxonomy_meta["role"]) && $taxonomy_meta["role"]=='agent')? "selected":"").">".qtranxf_use(qtranxf_getLanguage(),"Property Agent")."</option>";
        $html .= "<option value='view'".((isset($taxonomy_meta["role"]) && $taxonomy_meta["role"]=='view')? "selected":"").">".qtranxf_use(qtranxf_getLanguage(),"View")."</option>";
        $html .= "<option value='office'".((isset($taxonomy_meta["role"]) && $taxonomy_meta["role"]=='office')? "selected":"").">".qtranxf_use(qtranxf_getLanguage(),"Office")."</option>";
        $html .= '</select>'; */

      $html .='</tr>';


      //$html .='<input type="text" name="taxonomy_meta[role]" ';
      //if(isset($taxonomy_meta[role])) $role = $taxonomy_meta[role];
      //$html .= 'value="'.$role.'">';				


      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      //$html .='<label for="qtranxf_term_en">' . __("Proprietor Email", "azull") . '</label>';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Proprietor Email') . ':</label>';


      
      $html .='</th>';
      $html .='<td>';
      if (isset($taxonomy_meta[email]) && $taxonomy_meta[email] != "")
         $email = $taxonomy_meta[email];

      if ($term->term_id!='') {

         $html .='<input type="text" name="taxonomy_meta[email]" value="' . $email . '" >';
      } else {

         $html .="<input type='text' id='txnUemail' name='taxonomy_meta[email]'>";
      }

      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter Agent email address'). '</p>';
      $html .='</td>';
      $html .='</tr>';

      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
     // $html .='<label for="qtranxf_term_en">' . __("Proprietor Username", "azull") . '</label>';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Proprietor Username') . ':</label>';


      
      $html .='</th>';
      $html .='<td>';
      if (isset($taxonomy_meta[p_username]))
         $p_username = $taxonomy_meta[p_username];
      $html .='<input type="text" id="txnUname" name="taxonomy_meta[p_username]" value="' . $p_username . '">';
      //$html .='<p class="description">' . __("Enter Agent Login Username", "azull") . '</p>';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter Agent Login Username') . '</p>';
      
      $html .='</td>';
      $html .='</tr>';

      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' .$obj->getTranslatedString('en','nl','Proprietor Password'). ':</label>';
      $html .='</th>';
      $html .='<td>';
      if (isset($taxonomy_meta[password]))
         $password = $taxonomy_meta[password];
      $html .='<input type="text" id="txnUpass" name="taxonomy_meta[password]" value="' . $password . '">';
      //$html .='<p class="description">' . __("Enter Agent Login password", "azull") . '</p>';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter Agent Login password') . '</p>';

      $html .='</td>';
      $html .='</tr>';

       $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . __("Bank", "azull") . '</label>';
      $html .='</th>';
      $html .='<td>';
      $checked=0;
      if (isset($taxonomy_meta[bank]))
         $bank = $taxonomy_meta[bank];
   if($bank!='' && $bank==1){
        $html .='<input type="radio" checked name="taxonomy_meta[bank]" value="1" >'.__('Yes','azull');
      $html .='&nbsp;';
      $html .='<input type="radio" name="taxonomy_meta[bank]" value="0" >'.__('No','azull');
   }else{
       $html .='<input type="radio" name="taxonomy_meta[bank]" value="1" >'.__('Yes','azull');
      $html .='&nbsp;';
      $html .='<input type="radio" checked name="taxonomy_meta[bank]" value="0" >'.__('No','azull');
      }
      $html .='</td>';
      $html .='</tr>';
      $html .='<p class="description">' . __("", "azull") . '</p>';
      echo $html;
?>



<?php

      
   }

   /*    * **************************************************
     Function : create_agents
     Description : This function adds agent user to the
     database while creating a Proprietor term
    * *************************************************** */

   static function create_agents($term_id) {



      if (isset($_POST['taxonomy_meta']))
         $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term_id, $_POST['taxonomy_meta']);

      $username = $taxonomy_meta[p_username];
      $email = $taxonomy_meta[email];
      $password = $taxonomy_meta[password];

      $userdata = array(
          'user_login' => $username,
          'user_pass' => $password,
          'user_email' => $email,
          'role' => $taxonomy_meta[role]
      );

      $userid = wp_insert_user($userdata);

      //die();

      if (is_wp_error($userid)) {

         wp_delete_term($term_id, 'proprietor');
         echo $userid->get_error_message();
         die();
      } else {

         $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term_id, $_POST['taxonomy_meta']);
         $taxonomy_meta[userid] = $userid;
         update_option('azull_taxonomy_meta_' . $term_id, $taxonomy_meta);
         $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term_id);

         add_user_meta($userid, 'proprietor_id', $term_id);

         //wp_new_user_notification( $userid, $password);
         return $userid;
      }
   }

   /*    * **************************************************
     Function : update_agents
     Description : This function update agent user to the
     database while creating a updating Proprietor term
    * *************************************************** */

   static function update_agents($term_id) {

      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term_id);

      $locale = get_locale();
      $locale = explode("_", $locale);
      $locale = $locale[0];

      $street = $taxonomy_meta[street][$locale];
      $country = $taxonomy_meta[country][$locale];
      $state = $taxonomy_meta[state][$locale];
      $city = $taxonomy_meta[city][$locale];
      $house = $taxonomy_meta[house][$locale];

      //echo "<pre>";print_r($taxonomy_meta);

      $country = json_encode($country);
      $state = json_encode($state);

      $user = get_user_by('email', $taxonomy_meta[email]);
      $userid = $user->ID;

      $user = get_userdata($userid);

      $all_meta_for_user = get_user_meta($userid);

      $userdata = array(
          'ID' => $userid,
          'user_login' => $taxonomy_meta[p_username],
          'user_pass' => $taxonomy_meta[password],
          'user_email' => $taxonomy_meta[email],
          'role' => $taxonomy_meta[role],
          'user_url' => $taxonomy_meta[web],
          'phone' => $taxonomy_meta[phone],
          'zip' => $taxonomy_meta[zip],
          'street' => $street,
          'country' => $country,
          'state' => $state,
          'city' => $city,
          'house' => $house,
          'proprietor_id' => $term_id // When creating an user, `user_pass` is expected.
      );

      $userid = wp_update_user($userdata);
      return $userid;
   }

   static function exclude_editor_role($all_roles) {
      unset($all_roles['editor']);
      return $all_roles;
   }

   /*    * **************************************************
     Function : create_agent_term
     Description : This function create agent/proprieter
     term to the database while creating a user
    * *************************************************** */

   static function create_agent_term($user_id) {

      if ($_POST[role] == 'agent') {

         $term = $_POST[first_name] . '' . $_POST[last_name];
         $termid = wp_insert_term($term, 'proprietor');

         $taxonomy_meta = array(
             'role' => $_POST[role],
             'email' => $_POST[email],
             'p_username' => $_POST[user_login],
             'password' => $_POST[pass2],
             'userid' => $user_id,
             'taxonomy_image' => '',
             'type' => '',
         );

         if (is_wp_error($termid)) {
            echo $termid->get_error_message();
         } else {
            update_option('azull_taxonomy_meta_' . $term_id, $taxonomy_meta);
            add_user_meta($user_id, 'proprietor_id', $term_id);
         }
      }
   }

   static function features_options($term) {

      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);

      if (!$taxonomy_meta)
         $taxonomy_meta['type'] = 1;

      $html = '<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . __("Feature type", "azull") . '</label>';
      $html .='</th>';

      $html .='<td>';
      $html .='<input type="radio" name="taxonomy_meta[type]" value="1" ' . (( $taxonomy_meta["type"] == 1) ? "checked" : "") . '>' . __('Check selection', 'azull');
      $html .='<input type="radio" name="taxonomy_meta[type]" value="2" ' . (( $taxonomy_meta["type"] == 2) ? "checked" : "") . '>' . __('Numeric value', 'azull');
      $html .='<p class="description">' . __("Select feature type", "azull") . '</p>';
      $html .='</td>';
      $html .='</tr>';

      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . __("Include in search", "azull") . '</label>';
      $html .='</th>';
      $html .='<td>';
      $html .='<input type="checkbox" name="taxonomy_meta[search]" value="1" ' . ((isset($taxonomy_meta["search"]) && $taxonomy_meta["search"] == 1) ? "checked" : "") . '>' . __('Check selection', 'azull');
      $html .='<p class="description">' . __("Will only apply to features with value", "azull") . '</p>';
      $html .='</td>';
      $html .='</tr>';


      echo $html;
   }

   function term_add($term) {
      if ($term->parent == 0)
         return;

      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      require_once( AZULL_DIR . 'template/address.php' );
   }

   static function term_edit($term) {

      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      require_once( AZULL_DIR . 'template/address.php' );
   }

   static function get_property_meta_essential() {
      global $post, $aj_config, $q_config;
      $html = '';
      $val = array();
      $languages = qtranxf_getSortedLanguages();
      if($post->post_type == 'property' && $post->post_status!='auto-draft'){
         $is_xml = get_post_meta($post->ID, '_xmlref', true);
         //print('<pre>');print_r($is_xml);die;
         //_xmlref
         if(isset($is_xml) && !empty($is_xml) && $is_xml!=0){
            if($post->post_status == 'rejected'){
               $complete = ' selected=\"selected\"';
               $label = '<span id=\"post-status-display\">Rejected</span>';
               echo '<script>
                  jQuery(document).ready(function($){
                     jQuery("#save-post").val("Save as Rejected");
                  });
               </script>';
            }
            echo '<script>
            jQuery(document).ready(function($){
                 $("select#post_status").append("<option value=\"rejected\" '.$complete.'>Reject</option>");
                 $(".misc-pub-section label").append("'.$label.'");
                 jQuery("#post-status-select a.save-post-status").click(function(){
                  var p_status = jQuery("#post_status").val();
                  if(p_status && p_status=="rejected"){
                     setTimeout("jQuery(\"#save-post\").val(\"Save as Rejected\");", 100);
                  }
                });
                jQuery("#save-post").click(function(){
                  var p_status = jQuery("#post_status").val();
                  if(p_status && p_status=="rejected"){
                     setTimeout("jQuery(\"#save-post\").val(\"Save as Rejected\");", 100);
                  }
                });
            });
            </script>';
         }
      }
      //todo:need to check still using...
      $html .="<script>
	    jQuery(document).ready(function($){ 
		jQuery('#postimagediv .inside p img').each(function(){
		    jQuery(this).width(164)
		    jQuery(this).height(100);
		});
	     
	    });
	    </script>";
      $html .= "<table class='form-table property_general' style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);'>";
      $html .= get_main_sites_list() . "<style>.SumoSelect{width:96%;}</style>";
      $html .= "</table>";
      $html .= "<hr>";
      $html .= "<table class='form-table property_general' style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);'>";
      $html .= self::azull_sites() . "<style>.SumoSelect{width:96%;}</style>";
      $html .= "</table>";
      $html .= "<table class='form-table property_general' style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);'>";
      $html .= "<hr>";
      $html .= "<tr class='form-field'>";

      //get propritor... proptitor details
      $html .= self::proprietor_generate();

      $proprietorRef = get_post_meta($post->ID, '_proprietorRef', true);

      $html .= "<tr class='form-field'>";
      $html .= "<th  valign='top' scope='row'><label>#ref. eig.</th>";
      $html .= "<td><input  autocomplete='off' maxlength='12' type='text' name='property_meta_essential[proprietorRef]' placeholder='Proprietor Reference Number' value='".((isset($proprietorRef))? $proprietorRef:'')."' />
         <br><span class='description'>".__('Enter proprietor reference number','azull')."</span>
           </td>";
      $html .= "</tr>";

      /* ===============*/

      
      $html .='</table>';
      $html.='<hr>';
$html .= "<table class='form-table property_general' style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);'>";

    $html .= "<tr>";
      $html .="<th><label for='property_meta_name'>" . __('Project Name', 'azull') . "</label> </th>";
      $html .= "<td><input type='text' name='property_meta_essential[propertyName]' id='property_meta_name' value='" . get_post_meta($post->ID, '_propertyName', true) . "'  /></td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .="<th><label for='property_meta_project'>" . __('Project', 'azull') . "</label> </th>";
      $html .= "<td><span id='project_box'>";
      
      $html .='<select class="SlectBox" name="property_meta_essential[project]" id="property_meta_essential[project]">
      <option value="" selected>'. __("Select project", "azull").'</option>';
      $p_project = get_post_meta($post->ID, '_project', true);
      $proprietor_id = get_post_meta($post->ID, '_proprietor', true);
      $terms  = get_terms('project',array('orderby' => 'name', 'hide_empty' => false));
      if(isset($terms) && !empty($terms)){
         global $wpdb;
         $p_project = get_post_meta($post->ID, '_project', true);
         foreach ($terms as $term) {
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
            if(isset($taxonomy_meta['proprietor']) && !empty($taxonomy_meta['proprietor']) && $taxonomy_meta['proprietor'] == $proprietor_id){
               $trans_name = qtranxf_use(qtranxf_getLanguage(), $term->name);
               if(isset($trans_name) && !empty($trans_name)){
                  $t_name = $trans_name;
               }else{
                  $term_data = $wpdb->get_row("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_terms.term_id = '$term->term_id' AND wp_term_taxonomy.taxonomy = '$term->taxonomy'");
                  $t_name = (isset($term_data->name) && !empty($term_data->name))?$term_data->name:'';
               }
               $html .='<option value="' . $term->term_id . '" '.((isset($p_project) && !empty($p_project) && $term->term_id == $p_project)?"selected":"").'>' .$t_name. '</option>';
            }
         }
      }
      $html .='</select>';
      $html .= "</span></td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .= "<td colspan='2'>";
      $html .= "</td>";
      $html .= "</tr>";
      $html .='</table>';
      $html.='<hr>';

      $html .= "<table class='form-table property_general' style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);'>";

      $html .= "<tr class='form-field'>";
      $html .= "<td style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);' colspan='2'>" . self::location_meta_generate() . "</td>";
      $html .= "</tr>";
        
      
      $html .='</table>';
      $html.='<hr>';
    

    $html .= "<table class='form-table property_general' style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);'>";
      $html .= "<tr class='form-field'>";

      $html .= "<th  valign='top' scope='row'><label>#" . __('Ref', 'azull') . ":</th><td><input type='text' name='_nreal_id' id='nrealid' value='".get_post_meta($post->ID, "_nreal_id", true)."' style='border: 1px solid hsl(0, 0%, 80%); display: inline-block;font-size: 12px; padding: 2px; width: 90%;'><br><span class='description'>" . __('System generated reference number.', 'azull') . "</span></td>";
      $html .= "</tr>";
      
      $html .= "<tr class='form-field' id='fimg'>";
      $html .= "<th  valign='top' scope='row'></th>";
      $html .= "<td>" . self::featured_image_generate() . "</td>";
      $html .='</tr>';
    


      $proprietorUrl = get_post_meta($post->ID,'_proprietorUrl',true);    
      $html .= "<tr class='form-field'>";
      $html .= "<th  valign='top' scope='row'><label>".__('Proprietor Url','azull')."</th>";
      $html .= "<td><input  autocomplete='off'  type='text' name='property_meta_essential[proprietorUrl]' value='".((isset($proprietorUrl))? $proprietorUrl:'')."' />
         <br><span class='description'>".__('Enter proprietor url','azull')."</span>
           </td>";
      $html .= "</tr>";

      //year number
      $year = get_post_meta($post->ID, '_year', true);
      $html .= "<tr class='form-field'>";
      $html .= "<th  valign='top' scope='row'><label>" . __('Build year', 'azull') . "</th>";
      $html .= "<td><input  autocomplete='off' class='numeric' maxlength='4' type='text' name='property_meta_essential[year]' value='" . ((isset($year)) ? $year : '') . "' />
			<br><span class='description'>" . __('Enter build year eg. (yyyy)', 'azull') . "</span>
		     </td>";
      $html .= "</tr>";

      /* get all categories terms. */
      $html .= self::category_generate();


      $taxonomy_meta['type'] = 1;
      $terms = get_terms('feature', 'orderby=id&hide_empty=0');

      // Generate Fetures meta box type number.... linke number of bedrooms, number of bathrooms
      if (!empty($terms) && !is_wp_error($terms)) {

         foreach ($terms as $term) {
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
            if ($taxonomy_meta['type'] == 2) {
               $html .= "<tr class='form-field'>";
               $fnuber = get_post_meta($post->ID, '_feature_' . $term->term_id, true);
               //fix floor entery as string...

               $fnuber = (isset($fnuber) && is_numeric($fnuber)) ? $fnuber : $fnuber;
               $fnuber = (isset($fnuber) && !is_numeric($fnuber)) ? __($fnuber, 'azull') : $fnuber;
               $html .= "<th  valign='top' scope='row'><label>" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "</th>";
               $html .= "<td><input autocomplete='off'  maxlength='30' type='text' name='property_meta_essential[" . $term->term_id . "]' value='" . $fnuber . "' />
						  <br><span class='description'>" . __('Enter Number of', 'azull') . " <strong>" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "</strong>. eg(DD).</span>
						  </td>";
               $html .= "</tr>";
            }
         }
      }

      $html .= "<tr class='form-field'>";
      $bank = get_post_meta($post->ID, '_bank', true);
      $html .= "<th  valign='top' scope='row'><label>" . __('Bank', 'azull') . ":</th><td>
				    <select name='property_meta_essential[bank]'>
						<option value=''>--</option>	    
						<option value='0' " . (($bank != '' && 0 == $bank) ? 'selected' : '') . ">" . __('No', 'azull') . "</option>
                  <option value='1' " . (($bank != '' && 1 == $bank) ? 'selected' : '') . ">" . __('Yes', 'azull') . "</option>
				    </select>
	    			<br><span class='description'>" . __('Select', 'azull') . " <strong>" . __('Bank', 'azull') . "</strong>.</span>
	     		 </td>";
      $html .= "</tr>";
      $html .= "<tr class='form-field'>";
      $penthouse = get_post_meta($post->ID, '_penthouse', true);
      $html .= "<th  valign='top' scope='row'><label>" . __('Penthouse', 'azull') . ":</th><td>	   
				    <select name='property_meta_essential[penthouse]'>
							<option value=''>--</option>
                     <option value='0' " . (( $penthouse != '' && 0 == $penthouse) ? 'selected' : '') . ">" . __('No', 'azull') . "</option>
							<option value='1' " . (($penthouse != '' && 1 == $penthouse) ? 'selected' : '') . ">" . __('Yes', 'azull') . "</option>
				    </select>
	  				 <br><span class='description'>" . __('Select penthouse', 'azull') . "</td>";
      $html .= "</tr>";


      //Get all Banner terms. 
      $html .= self::banner_generate();
      $html .= self::orientation_generate();
      // $html .= self::locality_generate();
      // $html .= self::view_generate();
      $html .= "</table>";
      $html .= "</hr>";
      $html .= "<table class='form-table property_general' style='background: none repeat scroll 0 0 hsl(0, 0%, 93%);'>";
      $energyCurrent = get_post_meta($post->ID, '_energyCurrent', true);
      $energyPotential = get_post_meta($post->ID, '_energyPotential', true);
      $html .= "<tr style='background: none repeat scroll 0 0 hsl(0, 0%, 95%);border: 4px solid hsl(0, 0%, 95%);'>";
      $html .= "<th  valign='top' scope='row'><label" . __('EPC energy', 'azull') . "</th><td><input  autocomplete='off' class='numeric' maxlength='2' size='7' placeholder='" . __('Current', 'azull') . "' type='text' name='property_meta_essential[energy][current]' value='" . (( $energyCurrent != '') ? $energyCurrent : '') . "' />
								<input  autocomplete='off' class='numeric' maxlength='2' size='7'  placeholder='" . __('Potential', 'azull') . "' type='text' name='property_meta_essential[energy][potential]' value='" . (( $energyPotential != '') ? $energyPotential : '') . "' />
								<br><span class='description'>" . __('EPC energy efficiency rating (%)', 'azull') . "</span></td>";
      $html .= "</tr>";

      $co2Current = get_post_meta($post->ID, '_co2Current', true);
      $co2Potential = get_post_meta($post->ID, '_co2Potential', true);
      $html .= "<tr style='background: none repeat scroll 0 0 hsl(0, 0%, 95%);border: 4px solid hsl(0, 0%, 95%);'>";
      $html .= "<th  valign='top' scope='row'><label>EPC(CO2)</th><td>
								<input  autocomplete='off' class='numeric' maxlength='2' size='7'  placeholder='" . __('Current', 'azull') . "' type='text' name='property_meta_essential[co2][current]' value='" . (( $co2Current != '') ? $co2Current : '') . "' />
								<input  autocomplete='off' class='numeric' maxlength='2' size='7'  placeholder='" . __('Potential', 'azull') . "' type='text' name='property_meta_essential[co2][potential]' value='" . (( $co2Potential != '') ? $co2Potential : '') . "' />
								<br><span class='description'>" . __('EPC CO2 efficiency rating (%)', 'azull') . "</span></td>";
      $html .= "</tr>";
      $epc_e = get_post_meta($post->ID, '_epc_e', true);
      $html .= "<tr style='background: none repeat scroll 0 0 hsl(0, 0%, 95%);border: 4px solid hsl(0, 0%, 95%);'>";
      $html .= "<th  valign='top' scope='row'><label>(" . __('EPC energy', 'azull') . ")</th><td>
								<ul>
								<li><input type='checkbox' name='property_meta_essential[epc_e][]' value='0' " . (($epc_e != '' && in_array(0, $epc_e)) ? 'checked' : '') . ">" . __('Show EPC', 'azull') . "</li>
								<li><input type='checkbox' name='property_meta_essential[epc_e][]' value='1' " . (($epc_e != '' && in_array(1, $epc_e)) ? 'checked' : '') . " >" . __('Applied for', 'azull') . "</li>
								</ul></td>";
      $html .= "</tr>";
      $epc_c = get_post_meta($post->ID, '_epc_c', true);
      $html .= "<tr style='background: none repeat scroll 0 0 hsl(0, 0%, 95%);border: 4px solid hsl(0, 0%, 95%);'>";
      $html .= "<th  valign='top' scope='row'><label>EPC(CO2)</th><td>
								<ul>
								<li><input type='checkbox' name='property_meta_essential[epc_c][]' value='0' " . (($epc_c != '' && in_array(0, $epc_c)) ? 'checked' : '') . " >" . __('Show EPC', 'azull') . "</li>
								<li><input type='checkbox' name='property_meta_essential[epc_c][]' value='1' " . (($epc_c != '' && in_array(1, $epc_c)) ? 'checked' : '') . ">" . __('Applied for', 'azull') . "</li>
						</ul><br><span class='description'><strong>EPC</strong> " . __('graph will be displayed as per selection', 'azull') . ".</span></td>";
      $html .= "</tr>";
      $html .= "<tr style='background: none repeat scroll 0 0 hsl(0, 0%, 95%);border: 4px solid hsl(0, 0%, 95%);'>";
      $agentCheck = get_post_meta($post->ID, '_agentCheck', true);
      $html .= "<th  valign='top' scope='row'><label>" . __('Agent check', 'azull') . "</th><td>
								<ul>
								<li><input type='checkbox' name='property_meta_essential[agent][]' value='0' " . (($agentCheck != '' && in_array(0, $agentCheck)) ? 'checked' : '') . " >" . __('Show property agent', 'azull') . "</li>
								<li><input type='checkbox' name='property_meta_essential[agent][]' value='1' " . (($agentCheck != '' && in_array(1, $agentCheck)) ? 'checked' : '') . " >" . __('Show agent contact form', 'azull') . "</li>
								</ul></td>";
      $html .= "</tr>";
      $html .= "</table>";
      echo $html;
   }

   private function azull_sites() {

      global $post, $wpdb;
      $val = array();
      $val = get_post_meta($post->ID, "_client", true);

      $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY post_title ASC");

      $html .= "<th  valign='top' scope='row'><label>" . __('Client visibility:', 'azull') . "</label></th>";
      $html .= "<td>";
      $html .= '<select style="min-height: 26px; width: 180px" class="SlectBox" name="client[]" multiple>';
      $html .= '<option value="" disabled selected>' . __('Select site', 'azull') . '</option>';

      foreach ($datas as $data) {

         if (isset($data->post_title)) {

            $sitename = explode(']', $data->post_title);
            $sitename = explode('[', $sitename[1]);
            $sitename = $sitename[0];
         }

         $html .= "<option value='" . $data->ID . "' " . (( is_array($val) && in_array($data->ID, $val)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $data->post_title) . "</option>";


         // $html .= "<option value='".$data->ID."' ".(( is_array($val) && in_array($data->ID,$val)) ? 'selected' : '').">".$sitename."</option>";
      }
      $html .= "</select><br>";
      $html .= "<br><span class='description'>" . __('Select one or more clients website.', 'azull') . "</span>";
      $html .= "</td>";
      $html .='</tr>';

      return $html;
   }

   static function remove_property_posts_column($columns) {
      unset(
              $columns['date'],
              $columns['comments']
      );
      return $columns;
   }

   static function property_column($columns) {
  //  print_r($columns);
      foreach ($columns as $key => $title) {

         if ($key == 'title')
            unset($columns['title']);
          unset($columns['language']);

         $columns['property_ref'] = '#Ref';

         $columns[$key] = $title;
     
      }

      $cols = array(
          
          'featured_image' => __('Featured Image', 'azull'),
          'property_cat' => __('Category', 'azull'),
          'proprietor_ref' => __('Proprietor', 'azull'),
          'property_name' => __('Project Name', 'azull'),
          'property_ref_nbr' => __('#P.ref', 'azull'),
          'salesPrice' => __('Sales Price', 'azull'),
          'country' => __('Country', 'azull'),
          'region' => __('Region', 'azull'),
          'provinces' => __('Provinces', 'azull'),
          'place' => __('Place', 'azull'),
          'websites' => __('Websites', 'azull'),
          'language' => __('Language', 'azull'),
          'xmlproperty' => __('XML', 'azull'),
          'propertystatus' => __('Status', 'azull'),
      );
      $columns = array_merge($columns, $cols);
      return $columns;
   }

   static function property_sortable_columns($columns) {
      $columns['property_ref'] = 'property_ref';
      $columns['proprietor_ref'] = 'proprietor_ref';
      $columns['salesPrice'] = 'salesPrice';
      $columns['property_cat'] = 'property_cat';
      $columns['property_name'] = 'property_name';	     
      $columns['region'] = 'region';      
      $columns['country'] = 'country';      
      $columns['place'] = 'place';   
      $columns['websites'] = 'websites'; 
      $columns['xmlproperty'] = 'property';


      return $columns;
   }
   
   static function category_options_hide_post($term) {
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
      if ($_GET['taxonomy'] == 'category') {
         echo '<script>jQuery( document ).ready(function() {jQuery("#parent").closest(".form-field").css("display", "none");});</script>';
      }
      global $typenow;
      echo '<input type="hidden" name="taxonomy_meta[type]" value="' . $typenow . '" >';
   }



   static function property_sorting($query) {

      global $post;

      if ($query->is_main_query() && ( $orderby = $query->get('orderby') )) {

         switch ($orderby) {
            case 'property_ref':
               $query->set('meta_key', '_nreal_id');
               //$query->set('orderby', get_post_meta($post->ID, '_nreal_id', true));
               $query->set('orderby', 'meta_value_num');
               break;
            case 'proprietor_ref':
               $query->set('meta_key', '_proprietorRef');
               $query->set('orderby', 'meta_value');
               break;
            case 'salesPrice':
               $query->set('meta_key', '_salesPrice');
               $query->set('orderby', 'meta_value_num');
               break;
            case 'websites':
               $query->set( 'orderby', 'title' );
               $query->set( 'order', $query->get('order') );
               break;           
         }
      }
   }

   
  
   
   
/**Sorting the terms name alphabetically*/
  
 static  function mbe_sort_custom_column($clauses, $wp_query){
        global $wpdb;
        // case for category
        if(isset($wp_query->query['orderby']) && $wp_query->query['orderby'] == 'property_cat'){
            $clauses['join'] .= <<<SQL
LEFT OUTER JOIN {$wpdb->term_relationships} ON {$wpdb->posts}.ID={$wpdb->term_relationships}.object_id
LEFT OUTER JOIN {$wpdb->term_taxonomy} USING (term_taxonomy_id)
LEFT OUTER JOIN {$wpdb->terms} USING (term_id)
SQL;
            $clauses['where'] .= "AND (taxonomy = 'category' OR taxonomy IS NULL)";
            $clauses['groupby'] = "object_id";
            $clauses['orderby'] = "GROUP_CONCAT({$wpdb->terms}.name ORDER BY name ASC)";
            if(strtoupper($wp_query->get('order')) == 'ASC'){
                $clauses['orderby'] .= 'ASC';
            } else{
                $clauses['orderby'] .= 'DESC';
            }
        }
        // case for properitor
           if(isset($wp_query->query['orderby']) && $wp_query->query['orderby'] == 'proprietor_ref'){
            $clauses['join'] .= <<<SQL
LEFT OUTER JOIN {$wpdb->term_relationships} ON {$wpdb->posts}.ID={$wpdb->term_relationships}.object_id
LEFT OUTER JOIN {$wpdb->term_taxonomy} USING (term_taxonomy_id)
LEFT OUTER JOIN {$wpdb->terms} USING (term_id)
SQL;
            $clauses['where'] .= "AND (taxonomy = 'proprietor' OR taxonomy IS NULL)";
            $clauses['groupby'] = "object_id";
            $clauses['orderby'] = "GROUP_CONCAT({$wpdb->terms}.name ORDER BY name ASC)";
            if(strtoupper($wp_query->get('order')) == 'ASC'){
                $clauses['orderby'] .= 'ASC';
            } else{
                $clauses['orderby'] .= 'DESC';
            }
        }

            // case for region
           if(isset($wp_query->query['orderby']) && $wp_query->query['orderby'] == 'region'){
            $clauses['join'] .= <<<SQL
LEFT OUTER JOIN {$wpdb->term_relationships} ON {$wpdb->posts}.ID={$wpdb->term_relationships}.object_id
LEFT OUTER JOIN {$wpdb->term_taxonomy} USING (term_taxonomy_id)
LEFT OUTER JOIN {$wpdb->terms} USING (term_id)
SQL;
            $clauses['where'] .= "AND (taxonomy = 'region' OR taxonomy IS NULL)";
            $clauses['groupby'] = "object_id";
            $clauses['orderby'] = "GROUP_CONCAT({$wpdb->terms}.name ORDER BY name ASC)";
            if(strtoupper($wp_query->get('order')) == 'ASC'){
                $clauses['orderby'] .= 'ASC';
            } else{
                $clauses['orderby'] .= 'DESC';
            }
        }

           // case for place
           if(isset($wp_query->query['orderby']) && $wp_query->query['orderby'] == 'place'){
            $clauses['join'] .= <<<SQL
LEFT OUTER JOIN {$wpdb->term_relationships} ON {$wpdb->posts}.ID={$wpdb->term_relationships}.object_id
LEFT OUTER JOIN {$wpdb->term_taxonomy} USING (term_taxonomy_id)
LEFT OUTER JOIN {$wpdb->terms} USING (term_id)
SQL;
            $clauses['where'] .= "AND (taxonomy = 'place' OR taxonomy IS NULL)";
            $clauses['groupby'] = "object_id";
            $clauses['orderby'] = "GROUP_CONCAT({$wpdb->terms}.name ORDER BY name ASC)";
            if(strtoupper($wp_query->get('order')) == 'ASC'){
                $clauses['orderby'] .= 'ASC';
            } else{
                $clauses['orderby'] .= 'DESC';
            }
        }

         // case for country
           if(isset($wp_query->query['orderby']) && $wp_query->query['orderby'] == 'country'){
            $clauses['join'] .= <<<SQL
LEFT OUTER JOIN {$wpdb->term_relationships} ON {$wpdb->posts}.ID={$wpdb->term_relationships}.object_id
LEFT OUTER JOIN {$wpdb->term_taxonomy} USING (term_taxonomy_id)
LEFT OUTER JOIN {$wpdb->terms} USING (term_id)
SQL;
            $clauses['where'] .= "AND (taxonomy = 'country' OR taxonomy IS NULL)";
            $clauses['groupby'] = "object_id";
            $clauses['orderby'] = "GROUP_CONCAT({$wpdb->terms}.name ORDER BY name ASC)";
            if(strtoupper($wp_query->get('order')) == 'ASC'){
                $clauses['orderby'] .= 'ASC';
            } else{
                $clauses['orderby'] .= 'DESC';
            }
        }
   

        return $clauses;
    }
 



   static function property_column_content($column_name, $post_ID) {
      global $q_config;
      global $post;
      $thumbnail_id = get_post_thumbnail_id($post_ID);
      $val = get_post_meta($post_ID, 'property_meta_essential', true);

      if ($thumbnail_id) {
         $post_thumbnail_img = wp_get_attachment_image_src($thumbnail_id, 'thumbnail');
         $url = $post_thumbnail_img[0];
      }


     if (isset($url) && $column_name == 'featured_image'){
         $explodeurl = explode('uploads', $url);
         $upload_dir= wp_upload_dir();
         $explodeurlN = explode('uploads', $upload_dir['path']);
         $realpath = $explodeurlN[0].'uploads'.$explodeurl[1];
          //  $size = getimagesize($realpath);
              if(file_exists($realpath)){
                    echo '<img width="100" height="80" src="' . $url . '" />';
              }else{
               echo '<img width="80" height="40" src="' . WP_PLUGIN_URL. '/azull/images/default.png" />';
              }
               
        }


      if (!isset($url) && $column_name == 'featured_image') {
         echo '<img width="80" height="40" src="' . WP_PLUGIN_URL . '/azull/images/default.png" />';
      }

      if ($column_name == 'property_ref') {
         echo get_post_meta($post_ID, '_nreal_id', true);
      }



      if ($column_name == 'proprietor_ref' && get_post_meta($post_ID, '_proprietor', true)) {
         $term = get_term(get_post_meta($post_ID, '_proprietor', true), 'proprietor');

         $Pname = str_replace("(English)","",qtranxf_use(qtranxf_getLanguage(),$term->name)); 
         $Pname = str_replace("(Nederlands)","", $Pname);
         echo str_replace("(Frech)","", $Pname);
      }
      if ($column_name == 'property_ref_nbr') {
         echo get_post_meta($post_ID, '_proprietorRef', true);
      }
      if ($column_name == 'property_name') {
         $pname = get_post_meta($post_ID, '_propertyName', true);
         echo (isset($pname) ) ? $pname : '';
      }

      if ($column_name == 'property_cat') {
         $assigned_terms = wp_get_post_terms($post_ID, 'category', array("fields" => "ids"));
         $term = get_term((integer) $assigned_terms[0], 'category');
         echo qtranxf_use(qtranxf_getLanguage(), $term->name);
      }


      if ($column_name == 'salesPrice') {
         get_post_meta($post_ID, 'salesPrice', true);
         global $aj_config;
         echo $aj_config['currency'] . get_post_meta($post_ID, '_salesPrice', true);
      }

      if ($column_name == 'country') {
         $assigned_terms = wp_get_post_terms($post_ID, 'country', array("fields" => "ids"));
         $term = get_term((integer) $assigned_terms[0], 'country');
         echo qtranxf_use(qtranxf_getLanguage(), $term->name);
      }

      if ($column_name == 'region') {

         $assigned_terms = wp_get_post_terms($post_ID, 'region', array("fields" => "ids"));
         $term = get_term((integer) $assigned_terms[0], 'region');
         echo qtranxf_use(qtranxf_getLanguage(), $term->name);
      }


      if ($column_name == 'provinces') {

         $assigned_terms = wp_get_post_terms($post_ID, 'provinces', array("fields" => "ids"));
         $term = get_term((integer) $assigned_terms[0], 'provinces');
         echo qtranxf_use(qtranxf_getLanguage(), $term->name);
      }
      if ($column_name == 'place') {
         $assigned_terms = wp_get_post_terms($post_ID, 'place', array("fields" => "ids"));
         $term = get_term((integer) $assigned_terms[0], 'place');
         echo qtranxf_use(qtranxf_getLanguage(), $term->name);
      }
      if ($column_name == 'websites') {
         global$wpdb;
         $val = array();
         $val = get_post_meta($post_ID, "_client", true);
         $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");

         foreach ($datas as $data) {
            if (is_array($val) && in_array($data->ID, $val))
               echo qtranxf_use(qtranxf_getLanguage(),$data->post_title). " ";
         }
      }

      if ($column_name == 'xmlproperty') {
           $xmlVal= get_post_meta($post_ID, '_xmlref', true);
          if(isset($xmlVal) && $xmlVal!=''){
              echo "Xml";
          }
      }

      if ($column_name == 'propertystatus') {
         echo $post->post_status;
      }
   }

   private function featured_image_generate() {
      global $post;
      $html = '';
      $html .="<div id='postimagediv'><div  style='padding:0px;' class='inside'>";
      $thumbnail_id = get_post_meta($post->ID, '_thumbnail_id', true);
      $html .= _wp_post_thumbnail_html($thumbnail_id);
      $html .= "</div></div>";
      return $html;
   }

   public function proprietor_generate($idc=''){ 
     
      $display='';
      global $post, $aj_config, $q_config, $wpdb;
      $html = '';
      $l = $q_config['default_language'];

      $proprietors = get_terms('proprietor', array('orderby' => 'slug', 'hide_empty' => false));
       

      if (!empty($proprietors) && !is_wp_error($proprietors)) {
         $assigned_terms = array();
        $userInfo=get_userdata(get_current_user_id());
        $sql = "SELECT * FROM wp_terms where slug='".$userInfo->user_login."'";
        $termId = $wpdb->get_var($sql);
        $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }
         /*for condetion for agant role
          Date:- 16/july/2016 deepak (ab)
         */
      if($userRole!='' && $userRole=='agent'){
         $display='disabled';
         $assigned_terms = array($termId);
      }else{
      if($idc !=''){
         $assigned_terms = array($idc);
      }else{
         $assigned_terms = wp_get_post_terms($post->ID, 'proprietor', array("fields" => "ids"));   
      }

      }

      
          //$assigned_terms = array();
        //   $assigned_terms = array();
        // $assigned_terms = wp_get_post_terms($post->ID, 'proprietor', array("fields" => "ids"));
        
         $html .="<style>ul.selectator_options { margin-top: 26px !important;}</style>";
         $html .= "<tr class='form-field'>";
         $html .= "<th  valign='top' scope='row'><label>" . __('Proprietor', 'azull') . ":</label></th>";
         $html .= "<td>";
         $html .="<select id='activate_proprietor' ".$display." name='property_meta_essential[proprietor]' onchange='return get_projects(this.value);'>"; 
         $html .= "<option value=''>--</option>";

         //$html .= "<optgroup style='margin: 0 0 0 5px;' label='" . __('Agent', 'azull') . "'>";
         foreach ($proprietors as $pterm):
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $pterm->term_id);

                  if($taxonomy_meta['type'] && is_array($taxonomy_meta['type'])){
                      if((in_array(1, $taxonomy_meta["type"])) && (in_array(2, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
                          $role = "B, A, O";
                      }else if((in_array(1, $taxonomy_meta["type"])) && (in_array(2, $taxonomy_meta["type"]))){
                                $role = "A, O";
                      }
                      else if((in_array(2, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
                                $role = "B, O";
                      }
                      else if((in_array(1, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
                                $role = "A, B";
                      }else if(in_array(1, $taxonomy_meta["type"])){
                          $role = "A";
                      }
                      else if(in_array(2, $taxonomy_meta["type"])){
                          $role = "O";
                      }
                      else if(in_array(3, $taxonomy_meta["type"])){
                          $role = "B";
                      }
                   }else{
                       if($taxonomy_meta['type']!='' && $taxonomy_meta['type']==1){
                         $role = "A";
                       }else if($taxonomy_meta['type']!='' && $taxonomy_meta['type']==2){
                         $role = "O";
                       }
                       else if($taxonomy_meta['type']!='' && $taxonomy_meta['type']==3){
                         $role = "B";
                       }
                   }

            //if ($taxonomy_meta['type'] == 1) {

               $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';

               $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : '';

               //$html .= "<option value='".$pterm->term_id."' data-subtitle='".__('Phone','azull').":" . $phone . "<br/>".__('Email','azull').":" . $email."'  data-left=\"<img src='".z_taxonomy_image_url($term->term_id)."' >\" data-right='".$pterm->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id,$assigned_terms)) ? 'selected' : '')." >".qtranxf_use(qtranxf_getLanguage(),$pterm->name)."</option>";

               $html .= "<option value='" . $pterm->term_id . "' data-subtitle='" . __('Phone', 'azull') . ":" . $phone . "<br/>" . __('Email', 'azull') . ":" . $email . "' data-right='<b>" . $role . "</b>' " . ((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $pterm->name) . "</option>";
            //}
         endforeach;
         //$html .= "</optgroup>";

        /* $html .= "<optgroup style='margin: 0 0 0 5px;' label='" . __('Owner', 'azull') . "'>";
         foreach ($proprietors as $pterm):
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $pterm->term_id);
            if ($taxonomy_meta['type'] == 2) {

               $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';

               $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : '';

               //$html .= "<option value='".$pterm->term_id."' data-subtitle='".__('Phone','azull').":" . $phone . "<br/>".__('Email','azull').":" . $email."'  data-left=\"<img src='".z_taxonomy_image_url($pterm->term_id)."' >\" data-right='".$pterm->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id,$assigned_terms)) ? 'selected' : '')." >".qtranxf_use(qtranxf_getLanguage(),$pterm->name)."</option>";

               $html .= "<option value='" . $pterm->term_id . "' data-subtitle='" . __('Phone', 'azull') . ":" . $phone . "<br/>" . __('Email', 'azull') . ":" . $email . "' data-right='" . $pterm->term_id . "' " . ((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $pterm->name) . "</option>";
            }


         endforeach;
         $html .= "</optgroup>";

         $html .= "<optgroup style='margin: 0 0 0 5px;' label='" . __('Builder', 'azull') . "'>";

         foreach ($proprietors as $pterm):

            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $pterm->term_id);
            if ($taxonomy_meta['type'] == 3) {
               $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';
               $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : '';

               $html .= "<option value='" . $pterm->term_id . "' data-subtitle='" . __('Phone', 'azull') . ":" . $phone . "<br/>" . __('Email', 'azull') . ":" . $email . "'  data-left=\"<img src='" . z_taxonomy_image_url($pterm->term_id) . "' >\" data-right='" . $pterm->term_id . "' " . ((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $pterm->name) . "</option>";
            }
         endforeach;
         $html .= "</optgroup>";*/

         $html .= "</select><input value='activate selectator' id='activate_proprietor_click' type='hidden'>";

         $html .= "<br><span class='description'>" . __('Select proprietor', 'azull') . "</span>";
         $html .= "</td></tr>";
      }

      return $html;
   }

   private function location_meta_generate() {
      global $post, $aj_config, $q_config;
      $html = '';
      $l = $q_config['default_language'];
      $cflag = '';
      $rflag = '';
      $pflag = '';

      /*$countries = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
      $provinces = get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));
      $places = get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));*/
      $countries = get_terms('country', array('orderby' => 'name', 'hide_empty' => false));
      $regions = get_terms('region', array('orderby' => 'name', 'hide_empty' => false));
      $provinces = get_terms('provinces', array('orderby' => 'name', 'hide_empty' => false));
      $places = get_terms('place', array('orderby' => 'name', 'hide_empty' => false));

      $html .= "<table id='property_meta_location_language' class='property_meta_table property_meta_location' >";
      $html .="<tr>";
      $html .="<td id='rgnMsg' colspan='2' style='padding: 0%;width:100%; color:red; font-size:14px; text-align: center;'>";
      $html .="</td>";
      $html .="</tr>";
     /* $html .= "<tr>";
      $html .="<th><label for='property_meta_name'>" . __('Project Name', 'azull') . "</label> </th>";
      $html .= "<td><input type='text' name='property_meta_essential[propertyName]' id='property_meta_name' value='" . get_post_meta($post->ID, '_propertyName', true) . "'  /></td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .="<th><label for='property_meta_project'>" . __('Project', 'azull') . "</label> </th>";
      $html .= "<td>";
      $terms  = get_terms('project',array('orderby' => 'name', 'hide_empty' => false));
      $html .='<select class="SlectBox" name="property_meta_essential[project]" id="property_meta_essential[project]">
      <option value="" selected>'. __("Select project", "azull").'</option>';
      if(isset($terms) && !empty($terms)){
         global $wpdb;
         $p_project = get_post_meta($post->ID, '_project', true);
         foreach ($terms as $term) {
            $trans_name = qtranxf_use(qtranxf_getLanguage(), $term->name);
            if(isset($trans_name) && !empty($trans_name)){
               $t_name = $trans_name;
            }else{
               $term_data = $wpdb->get_row("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_terms.term_id = '$term->term_id' AND wp_term_taxonomy.taxonomy = '$term->taxonomy'");
               $t_name = (isset($term_data->name) && !empty($term_data->name))?$term_data->name:'';
            }
            $html .='<option value="' . $term->term_id . '" '.((isset($p_project) && !empty($p_project) && $term->term_id == $p_project)?"selected":"").'>' .$t_name. '</option>';
         }
      }
      $html .='</select>';
      $html .= "</td>";
      $html .= "</tr>";*/
   
      $html .= "<tr>";
      $html .="<th><label for='property_meta_country'>" . __('Country', 'azull') . ":</label></th>";
      $html .= "<td>";
      if (!empty($countries) && !is_wp_error($countries)) {
         $html .="<select postID='" . $post->ID . "' id='property_meta_country' name='property_meta_essential[country]'>";
         $html .= "<option value='' selected='selected'>--</option>";

         $assigned_terms = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
         if(empty($assigned_terms)) $assigned_terms = array('116');
         foreach ($countries as $countrie):
            if ($cflag == '')
               $cflag = (!empty($assigned_terms) && in_array($countrie->term_id, $assigned_terms)) ? $countrie->term_id : '';

            $html .= "<option value='" . $countrie->term_id . "' " . ((!empty($assigned_terms) && in_array($countrie->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";

         endforeach;

         $html .="</select>";
      }else {
         $html .="<select postID='" . $post->ID . "' id='property_meta_country' name='property_meta_essential[country]'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }

      $html .= "</td>";
      $html .= "</tr>";

      $html .= "<tr>";
      $html .="<th><label for='property_meta_region'>" . __('Region', 'azull') . ":</label> </th>";
      $html .= "<td>";

      if (!empty($regions) && !is_wp_error($regions)) {
         $assigned_terms = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
         $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
         $cntry= (isset($cntryId[0]))?$cntryId[0]:116 ;
         
         $html .="<select postID='" . $post->ID . "' id='property_meta_region' name='property_meta_essential[region]'>";
         $html .= "<option >--</option>";
            
         foreach ($regions as $region):
            
               $taxonomy_meta = get_option('azull_taxonomy_meta_' . $region->term_id); 
                 
                    if(isset($taxonomy_meta['country']) && isset($cntryId) && $taxonomy_meta['country']==$cntry){ 
                         $html .= "<option value='" . $region->term_id . "'  " . ((!empty($assigned_terms) && in_array($region->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
                    }
         endforeach;

         $html .="</select>";
      } else {
         $html .="<select postID='" . $post->ID . "' id='property_meta_region' name='property_meta_essential[region]'>";
         $html .= "<option  selected='selected'>--</option>";
         $html .="</select>";
      }

      $html .= "</td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .="<th><label for='property_meta_province'>" . __('Province', 'azull') . ":</label> </th>";
      $html .= "<td>";
      
       $assigned_termsP = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
       $assigned_termsR = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
       //echo  "helllo".$assigned_termsP.$assigned_termsR;die;
      if (!empty($provinces) && !is_wp_error($provinces)) {
      //if (!empty($assigned_termsP) || !empty($assigned_termsR)) {
          
         $html .="<select postID='" . $post->ID . "' id='property_meta_province' name='property_meta_essential[province]'>";
         $html .= "<option >--</option>";
         $assigned_terms = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
         $reginId = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
         $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));

         $cntry= (isset($cntryId[0]))?$cntryId[0]:'' ;
         $region= (isset($reginId[0]))?$reginId[0]:'' ;
         foreach ($provinces as $province):
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $province->term_id);
         /*
            if ($pflag == '')
               $pflag = (!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? $province->term_id : '';

            if ($cflag != '' && $rflag != '' && $taxonomy_meta['country'] == $cflag && $taxonomy_meta['region'] == $rflag) {

               $html .= "<option value='" . $province->term_id . "' " . ((!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
            } elseif ($cflag != '' && $taxonomy_meta['country'] == $cflag) {
               $html .= "<option value='" . $province->term_id . "' " . ((!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
            } elseif ($rflag != '' && $taxonomy_meta['region'] == $rflag) {
               $html .= "<option value='" . $province->term_id . "' " . ((!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
            } elseif ($cflag == '' && $rflag == '') {
               $html .= "<option value='" . $province->term_id . "' " . ((!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
            } */
        
          if(isset($taxonomy_meta['country']) && $taxonomy_meta['country']==$cntry){
	    if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$region){ 
			$html .= "<option value='" . $province->term_id . "' " . ((!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
		    }
	 }
          
         endforeach;
         $html .="</select>";
      } else {
         $html .="<select postID='" . $post->ID . "' id='property_meta_province' name='property_meta_essential[province]'>";
         $html .= "<option selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .= "</td>";
      $html .= "</tr>";

      $html .= "<tr>";
      $html .="<th><label for='property_meta_place'>" . __('Place', 'azull') . ":</label> </th>";
      $html .= "<td>";
      $assigned_termsC = wp_get_post_terms($post->ID, 'place', array("fields" => "ids"));
      //echo print_r($assigned_termsC);die; 
     //if (isset($assigned_termsC) && !empty($assigned_termsC)) {

     ///print_r($places);
      //$assigned_terms = wp_get_post_terms($post->ID, 'place', array("fields" => "ids"));
    /// print_r($assigned_terms);die;
      if (!empty($places) && !is_wp_error($places)) {
         $html .="<select postID='" . $post->ID . "' id='property_meta_place' name='property_meta_essential[place]'>";
         $html .= "<option >--</option>";
         
         $assigned_terms = wp_get_post_terms($post->ID, 'place', array("fields" => "ids"));
         
         $reginId = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
         $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
         $provience = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
         
         $cntry= (isset($cntryId[0]))?$cntryId[0]:'' ;
         $region= (isset($reginId[0]))?$reginId[0]:'' ;
         $provien = (isset($provience[0]))?$provience[0]:'' ;
         
         foreach ($places as $place):
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $place->term_id);
         /*
            if ($cflag != '' && $pflag != '' && $taxonomy_meta['country'] == $cflag && $taxonomy_meta['provinces'] == $pflag) {
               $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
            } elseif ($cflag != '' && $taxonomy_meta['country'] == $cflag) {
               $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
            } elseif ($pflag != '' && $taxonomy_meta['provinces'] == $pflag) {
               $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
            } elseif ($cflag == '' && $rflag == '') {
               $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
            }
*/
         
if(isset($taxonomy_meta['country']) && $taxonomy_meta['country']==$cntry){
  if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$region){		
    if(isset($taxonomy_meta['provinces'])  &&  $taxonomy_meta['provinces']==$provien){ 
				  $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
				}else{   
				  $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
				}
		    }			
		}  

            

         endforeach;
         $html .="</select>";
      } else {
         $html .="<select  postID='" . $post->ID . "' id='property_meta_place' name='property_meta_essential[place]'>";
         $html .= "<option selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .= "</td>";
      $html .= "</tr>";
      $html .="<tr>";
      $html .="<th  style='width:50%;'>";
      //$html .="<th'>";
      $html .="<label for='property_meta_zip' '>" . __('Zip:', 'azull') . "</label>";
      $html .="</th>";
      $html .="<td>";
      $html .="<input type='text' name='property_meta_essential[zip]' id='property_meta_zip' value='" . ((get_post_meta($post->ID, '_zip', true)) ? get_post_meta($post->ID, '_zip', true) : '') . "' />";
      $html .="</td>";
      $html .="</tr>";
      $html .="<tr>";
      $html .="<th colspan='2' style='width:100%;'>";
      $html .="<label for='property_meta_lat' style='width:48%;display:inline-block;'>" . __('Latitude', 'azull') . "</label><label for='property_meta_lang' style='width:48%;display:inline-block;'>" . __('Longitude', 'Longitude') . "</label>";
      $html .="</th>";
      $html .="</tr>";
      $html .="<tr>";
      $html .="<td colspan='2' style='padding: 0%;width:100%;'>";
      $lat =get_post_meta($post->ID,'_lat',true);
      $lng =get_post_meta($post->ID,'_lng',true);
      $html .='<input type="text" name="property_meta_essential[lat]" id="property_meta_lat"  style="width:48.5%;" value="'.((isset($lat) && $lat!='' ) ? $lat:'').'"/>';
      $html .='<input type="text" name="property_meta_essential[lng]" id="property_meta_long"  style="width:48.5%;" value="'.((isset($lng) && $lng!='' ) ? $lng:'').'"/>';
      //$html .="<input type='text' name='property_meta_essential[lat]' id='property_meta_lat' value='" . ((get_post_meta($post->ID, '_lat', true)) ? get_post_meta($post->ID, '_lat', true) : '') . "' style='width:48.5%;' />";
      //$html .="<input type='text' name='property_meta_essential[lng]' id='property_meta_long' value='" . ((get_post_meta($post->ID, '_lng', true)) ? get_post_meta($post->ID, '_lng', true) : '') . "' style='width:48.5%;' />";
      $html .="</td>";
      $html .="</tr>";
      $html .= "</table>";

      return $html;
   }

   
   
   static function remove_post_image() {
      remove_meta_box('postimagediv', 'property', 'side');
   }

   static function get_property_meta_finance() {
      global $post;
      $html = '';
      $val = array();
      $val = get_post_meta($post->ID, '_finance', true);
      require_once( AZULL_DIR . 'template/finance.php' );
   }

   static function get_property_meta() {
      $html .="<div data-activetab ='' id='tabbed_area' class='tabbed-area webgroup-area property-tabbed'>";
      $html .="<ul class='tabs group'>";
      $html .="<li class='active' ><a href='#features'><span>" . __('Features', 'azull') . "</span></a></li>";
      $html .="<li class='' ><a href='#exterior'><span>" . __('Exteriors', 'azull') . "</span></a></li>";
      $html .="<li class='' ><a href='#interior'><span>" . __('Interiors', 'azull') . "</span></a></li>";
      $html .=" <li class='' ><a href='#dimensions'><span>" . __('Dimensions', 'azull') . "</span></a></li>";
      $html .="<li class='' ><a href='#distance'><span>" . __('Distance Score', 'azull') . "</span></a></li>";
      $html .="<li class='' ><a href='#locality'><span>" . __('Locality', 'azull') . "</span></a></li>";
      $html .="<li class='' ><a href='#view'><span>" . __('View', 'azull') . "</span></a></li>";

      $html .="</ul>";
      $html .="</div>";
      $html .="<div id='features' class='webgroup property-tabbed-div'>" . self::get_property_meta_features() . "</div>";
      $html .="<div id='exterior' class='webgroup property-tabbed-div'>" . self::get_property_meta_exteriors() . "</div>";
      $html .="<div id='interior' class='webgroup property-tabbed-div'>" . self::get_property_meta_interiors() . "</div>";
      $html .="<div id='dimensions' class='webgroup property-tabbed-div'>" . self::get_property_meta_dimensions() . "</div>";
      $html .="<div id='distance' class='webgroup property-tabbed-div'>" . self::get_property_meta_walkScores() . "</div>";
      $html .="<div id='locality' class='webgroup property-tabbed-div'>" . self::locality_generate() . "</div>";
      $html .="<div id='view' class='webgroup property-tabbed-div'>" . self::view_generate() . "</div>";

      echo $html;
   }

  static function get_property_meta_exteriors(){
            global $post,$wpdb; $html = '';   
         $agentid = get_post_meta($post->ID, '_proprietor', false );

             $terms  = get_terms( 'exterior', 'orderby=id&hide_empty=0' );
           // Generate Exterior meta box HTML, concatenate in $html
                if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                        $html .="<ul class='form-table property-meta'>";
                $assigned_terms = wp_get_post_terms($post->ID, 'exterior', array("fields" => "ids"));
                 foreach ( $terms as $term ) {  
               $termname = $term->name;
                if(isset($agentid[0])){
                     $transName = $wpdb->get_results('select kyero_text from wp_feature_mapping where term_id= '.$term->term_id.' AND agentid='.$agentid[0], ARRAY_A);
                   if(!empty($transName)){ 
                     $options = get_option('qtranslate_term_name');
                     foreach ($options as $key => $value) {
                        if($key==$transName[0]['kyero_text']){
                           $str = "";  
                           foreach ($value as $key1 => $value1) {
                              $str .= '[:'.$key1.']'.$value1;  
                           }
                           $termname = $str;
                        }
                     }
                   }else{
                     $termname = $term->name;
                   }
             }

                   $html .= "<li>";
                   $html .= "<img width='30' height='28' src='".z_taxonomy_image_url($term->term_id)."' />";
                   $html .= "<input type='checkbox' name='property_meta_exteriors[]'  value='".$term->term_id."'  ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id,$assigned_terms))? 'checked':'')." />".qtranxf_use(qtranxf_getLanguage(),$termname);
                   $html .= "<br>";
                   $html .= "<span class='description'>".__('Select','azull')." <strong>".qtranxf_use(qtranxf_getLanguage(),$termname)."</strong>.</span>";
                   $html .= "</li>";                    
                 }
                 $html .= "</ul>";
                  
             }
            return $html;
        }

   static function get_property_meta_features(){
            global $post,$wpdb; $html = '';   
            $agentid = get_post_meta($post->ID, '_proprietor', false );
            $taxonomy_meta['type']=1;
            $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );
       // Generate Fetures meta box HTML, concatenate in $html 
            if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                   $html .= "<ul class='form-table property-meta'>";
                   $assigned_terms = wp_get_post_terms($post->ID, 'feature', array("fields" => "ids"));
                  foreach ( $terms as $term ) {
                     $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);     
                     if($taxonomy_meta['type']!=2){
                        $termname = $term->name;
                      if(isset($agentid[0])){
                           $transName = $wpdb->get_results('select kyero_text from wp_feature_mapping where term_id= '.$term->term_id.' AND agentid='.$agentid[0], ARRAY_A);
                     if(!empty($transName)){ 
                        $options = get_option('qtranslate_term_name');
                        foreach ($options as $key => $value) {
                           if($key==$transName[0]['kyero_text']){
                              $str = "";  
                              foreach ($value as $key1 => $value1) {
                                 $str .= '[:'.$key1.']'.$value1;  
                              }
                              $termname = $str;
                           }
                        }
                     }else{
                        $termname = $term->name;
                     }
                  }
            $html .= "<li><img width='30' height='28' src='".z_taxonomy_image_url($term->term_id)."' />";
            $html .= "<input type='checkbox' name='property_meta_fetures[]'   
             value='".$term->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id,$assigned_terms))? 'checked':'')." />".qtranxf_use(qtranxf_getLanguage(),$termname);  
            $html .= "<br>";  
            $html .= "<span class='description'>".__('Select','azull')." <strong>".qtranxf_use(qtranxf_getLanguage(),$termname)."</strong>.</span>";
            $html .= "</li>";
            }
         }
         $html .= "</ul>";
                }  
            return $html;
        }

   static function get_property_meta_interiors(){
         global $post,$wpdb; $html = '';   
         $agentid = get_post_meta($post->ID, '_proprietor', false );
            $terms  = get_terms( 'interior', 'orderby=id&hide_empty=0' );  
       // Generate Interiors meta box HTML, concatenate in $html
            if ( !empty( $terms ) && !is_wp_error( $terms ) ){
             $assigned_terms = wp_get_post_terms($post->ID, 'interior', array("fields" => "ids"));
            $html .= "<ul class='form-table property-meta'>";
            foreach ( $terms as $term ) {
                $termname = $term->name;
                if(isset($agentid[0])){
                     $transName = $wpdb->get_results('select kyero_text from wp_feature_mapping where term_id= '.$term->term_id.' AND agentid='.$agentid[0], ARRAY_A);
                   if(!empty($transName)){ 
                     $options = get_option('qtranslate_term_name');
                     foreach ($options as $key => $value) {
                        if($key==$transName[0]['kyero_text']){
                           $str = "";  
                           foreach ($value as $key1 => $value1) {
                              $str .= '[:'.$key1.']'.$value1;  
                           }
                           $termname = $str;
                        }
                     }
                   }else{
                     $termname = $term->name;
                   }
             }
         
           $html .= "<li>";
           $html .= "<img width='30' height='28' src='".z_taxonomy_image_url($term->term_id)."' />";
                $html .= "<input type='checkbox' name='property_meta_interiors[]'  value='".$term->term_id."'  ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id,$assigned_terms))? 'checked':'')." />".qtranxf_use(qtranxf_getLanguage(),$termname);
                $html .= "<br>";
           $html .= "<span class='description'>".__('Select','azull')." <strong>".qtranxf_use(qtranxf_getLanguage(),$termname)."</strong>.</span>";
           $html .= "</li>";                   
            
         }
         $html .= "</ul>";
                  
                }
                
            return $html;
        }


   static function get_property_meta_dimensions() {
      global $post;
      $html = '';
      $val = array();
      $terms = get_terms('dimensions', 'orderby=id&hide_empty=0');
      if (!empty($terms) && !is_wp_error($terms)) {
         $html .= "<ul class='form-table property-meta'>";
         foreach ($terms as $term) {
            $dimensions = get_post_meta($post->ID, '_dimensions_' . $term->term_id, true);

            $html .= "<li>";
            $html .= "<img width='30' height='28' src='" . z_taxonomy_image_url($term->term_id) . "' />";
            $html .= "<input autocomplete='off' maxlength='10' type='text' class='numeric' name='property_meta_dimensions[" . $term->term_id . "]'  value='" . ((isset($dimensions)) ? $dimensions : '') . "' />";
            $html .= "<br>";
            $html .= "<span class='description'>" . __('Enter', 'azull') . " <strong>" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "</strong> " . __('in meters square', 'azull') . ".</span>";
            $html .= "</li>";
         }
         $html .= "</ul>";
      }
      return $html;
   }

   static function get_property_meta_walkScores() {
      global $post;
      $html = '';
      $val = array();
      $terms = get_terms('walkscores', 'orderby=id&hide_empty=0');
      if (!empty($terms) && !is_wp_error($terms)) {
         $html .= "<ul class='form-table property-meta'>";
         foreach ($terms as $term) {
            $walscore = get_post_meta($post->ID, '_scores_' . $term->term_id, true);
            $html .= "<li>";
            $html .= "<img width='30' height='28' src='" . z_taxonomy_image_url($term->term_id) . "' />";
            $html .= "<input autocomplete='off' maxlength='10' class='numeric' type='text' name='property_meta_distance_score[" . $term->term_id . "]'  value='" . ((isset($walscore)) ? $walscore : '') . "' />";
            $html .= "<br>";
            $html .= "<span class='description'>" . __('Enter distance from', 'azull') . " <strong>" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "</strong> " . __('in meters', 'azull') . ".</span>";
            $html .= "</li>";
         }
         $html .= "</ul>";
      }

      return $html;
   }

 private function locality_generate(){
           global $post,$wpdb; $html = '';   
         $agentid = get_post_meta($post->ID, '_proprietor', false );
         $terms  = get_terms( 'locality', 'orderby=id&hide_empty=0' );
            if(!empty($terms) && !is_wp_error( $terms ) ){
                $html .= "<ul class='form-table property-meta'>";              
                $assigned_terms = wp_get_post_terms($post->ID, 'locality', array("fields" => "ids"));
                foreach ( $terms as $term ) { 

                $termname = $term->name;
             if(isset($agentid[0])){
               $transName = $wpdb->get_results('select kyero_text from wp_feature_mapping where term_id= '.$term->term_id.' AND agentid='.$agentid[0], ARRAY_A);
                if(!empty($transName)){ 
                  $options = get_option('qtranslate_term_name');
                  foreach ($options as $key => $value) {
                     if($key==$transName[0]['kyero_text']){
                        $str = "";  
                        foreach ($value as $key1 => $value1) {
                           $str .= '[:'.$key1.']'.$value1;  
                        }
                        $termname = $str;
                     }
                  }
                }else{
                  $termname = $term->name;
             }
         }

         $html .=  "<li>";
         $html .= "<img width='30' height='28' src='".z_taxonomy_image_url($term->term_id)."' />";
         $html .=  "<input type='checkbox' name='property_meta_essential[locality][]' value='".$term->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id,$assigned_terms))? 'checked':'')." >".qtranxf_use(qtranxf_getLanguage(),$termname);
         $html .=  "<br><span class='description'>".__('Select one or more property','azull')." <strong>".__('locality','azull')."</strong></span>";         
         $html .="</li>"; 
                }
                 $html .= "</ul>";
                
             }
       return $html;
      
   }

  private function view_generate(){ 
           global $post,$wpdb; $html = '';   
         $agentid = get_post_meta($post->ID, '_proprietor', false );
            $terms  = get_terms( 'view', 'orderby=id&hide_empty=0' );
            if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                $html .= "<ul class='form-table property-meta'>";           
                 $assigned_terms = wp_get_post_terms($post->ID, 'view', array("fields" => "ids"));
                 foreach ( $terms as $term ){ 
                 $termname = $term->name;
                if(isset($agentid[0])){
                     $transName = $wpdb->get_results('select kyero_text from wp_feature_mapping where term_id= '.$term->term_id.' AND agentid='.$agentid[0], ARRAY_A);
                   if(!empty($transName)){  
                     $options = get_option('qtranslate_term_name');
                     foreach ($options as $key => $value){ 
                        if($key==$transName[0]['kyero_text']){
                           $str = "";   
                           foreach ($value as $key1 => $value1) {
                              $str .= '[:'.$key1.']'.$value1;  
                           }
                           $termname = $str;  
                        }
                     } 
                   }else{ 
                     $termname = $term->name;
                }
             }
       $html .="<li>";  
      $html .= "<img width='30' height='28' src='".z_taxonomy_image_url($term->term_id)."' />"; 
      $html .= "<input type='checkbox' name='property_meta_essential[view][]' value='".$term->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id,$assigned_terms))? 'checked':'')."  >".qtranxf_use(qtranxf_getLanguage(),$termname);
      $html .= "<br><span class='description'>".__('Select one or more property','azull')." <strong>".__('view','azull')."</strong></span>"; 
       $html .="</li>"; 
                }
                 $html .= "</ul>";
                  
            }
       return $html;
   }

   private function category_generate() {
       global $post,$wpdb; $html = '';   
         $agentid = get_post_meta($post->ID, '_proprietor', false );
      $html = '';
      //$terms = get_terms('category', 'orderby=id&hide_empty=0');
      $terms = get_terms('category', array('orderby' => 'name', 'hide_empty' => false));
      if (!empty($terms) && !is_wp_error($terms)) {
         $assigned_terms = array();
         $assigned_terms = wp_get_post_terms($post->ID, 'category', array("fields" => "ids"));
         $html .= "<tr class='form-field'>";
         $html .= "<th  valign='top' scope='row'>" . __('Category', 'azull') . "</th>";
         $html .= "<td>";
         $html .= "<select id='property_category' name='property_meta_essential[category]'>";
         $html .= "<option value=''>--</option>";

         foreach ($terms as $term) {
               $termname = $term->name;
                if(isset($agentid[0])){
                     $transName = $wpdb->get_results('select kyero_text from wp_feature_mapping where term_id= '.$term->term_id.' AND agentid='.$agentid[0], ARRAY_A);
                   if(!empty($transName)){  
                     $options = get_option('qtranslate_term_name');
                     foreach ($options as $key => $value){ 
                        if($key==$transName[0]['kyero_text']){
                           $str = "";   
                           foreach ($value as $key1 => $value1) {
                              $str .= '[:'.$key1.']'.$value1;  
                           }
                           $termname = $str;  
                        }
                     } 
                   }else{ 
                     $termname = $term->name;
                }
             }
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
            if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'property') {
               $html .= "<option value='" . $term->term_id . "' " . ((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(),$termname) . "</option>";
            }
         }
         $html .= "</select><br>";
         $html .= "<span class='description'>" . __('Select property', 'azull') . " <strong>" . __('category', 'azull') . "</strong>.</span>";
         $html .= "</td></tr>";
      }

      return $html;
   }

   private function banner_generate() {
      global $post;
      $html = '';
      //$terms = get_terms('banner', 'orderby=id&hide_empty=0');
      $terms = get_terms('banner', array('orderby' => 'slug', 'hide_empty' => false));
      if (!empty($terms) && !is_wp_error($terms)) {
         $assigned_terms = array();
         $assigned_terms = wp_get_post_terms($post->ID, 'banner', array("fields" => "ids"));
         $html .= "<tr class='form-field'>";
         $html .= "<th  valign='top' scope='row'>" . __('Banner', 'azull') . "</th>";
         $html .= "<td>";
         $html .= "<select name='property_meta_essential[banner]'>";
         $html .= "<option value=''>--</option>";
         foreach ($terms as $term) {
            $html .= "<option value='" . $term->term_id . "' " . ((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id, $assigned_terms)) ? 'selected' : '') . " >" . $term->name . "</option>";
         }
         $html .= "</select><br>";
         $html .= "<span class='description'>" . __('Select', 'azull') . " <strong> " . __('banner', 'azull') . " </strong>" . __('for property image', 'azull') . ".</span>";
         $html .= "</td></tr>";
      }
      return $html;
   }

   private function orientation_generate() {
      global $post;
      $newTerm=array();
      $html = '';
      //$terms = get_terms('orientation', 'orderby=id&hide_empty=0');
      $terms = get_terms('orientation', array('orderby' => 'name', 'hide_empty' => false));
      if (!empty($terms) && !is_wp_error($terms)) {
         $assigned_terms = array();
         $assigned_terms = wp_get_post_terms($post->ID, 'orientation', array("fields" => "ids"));
         $html .= "<tr class='form-field'>";
         $html .= "<th  valign='top' scope='row'>" . __('Orientation', 'azull') . "</th>";
         $html .= "<td>";
         $html .= "<select name='property_meta_essential[orientation]'>";
         $html .= "<option value=''>--</option>";
         foreach ($terms as $term) {
            $newTerm[$term->term_id]=ucfirst(qtranxf_use(qtranxf_getLanguage(), $term->name));
            //$html .= "<option value='" . $term->term_id . "' " . ((is_array($assigned_terms) && !empty($assigned_terms) && in_array($term->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "</option>";
         }
         /* shorting ascending order */
         asort($newTerm);
         foreach ($newTerm as $tId => $tName) {
           $html .= "<option value='" . $tId . "' " . ((is_array($assigned_terms) && !empty($assigned_terms) && in_array($tId, $assigned_terms)) ? 'selected' : '') . ">" . $tName . "</option>";

         }
         $html .= "</select><br>";
         $html .= "<span class='description'>" . __('Select property', 'azull') . " <strong>" . __('orientation', 'azull') . "</strong></span>";
         $html .= "</td></tr>";
      }
      return $html;
   }

   static function save_property($post_id) {
      
      
      if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
         return;
      if (get_post_type($post_id) != 'property')
         return;
      


       /* check property cron job running */
      /*global $wpdb;
      $getRow = $wpdb->get_results('SELECT  id FROM wp_xml_record WHERE status = 0 OR status = 1 AND type= 1 ', ARRAY_A);
      $countgetRow=count($getRow);
      if(isset($countgetRow) && $countgetRow >0){
         $url =get_admin_url()."edit.php?post_type=property";
         $variable_to_send = '1';
         wp_redirect( $url.'&crerror='.$variable_to_send );
         exit();
      }*/

      //Note- $nreal_id is old property id, it must work with current post id- fix to do it..
      $nreal_id = get_post_meta($post_id, '_nreal_id', true);
      
      if (isset($_POST['_nreal_id'])){
         update_post_meta($post_id, '_nreal_id', $_POST['_nreal_id']);
         //update_post_meta($post_id, '_nreal_id_man', $_POST['_nreal_id']);

      }else{
         if (!$nreal_id) {
                 global $wpdb;
                 $lastRefId='';
         /*$terms = $wpdb->get_results('SELECT  meta_value FROM wp_postmeta WHERE meta_key ="_xmlref" order by meta_value desc limit 1', ARRAY_A);*/
         

         /*old 30/jan/2016 */
         //$terms = $wpdb->get_results('SELECT  meta_value FROM wp_postmeta WHERE meta_key ="_nreal_id" order by meta_value desc limit 1', ARRAY_A);

         /*update 30/jan/2016 */
         //$terms = $wpdb->get_results('SELECT  meta_value FROM wp_postmeta WHERE meta_key ="_nreal_id" order by post_id desc limit 1', ARRAY_A);

         /*Tien update Feb 24 2017 to fix old id appears again*/
         $terms = $wpdb->get_results('SELECT MAX( CONVERT( meta_value, SIGNED INTEGER ) ) AS meta_value FROM wp_postmeta WHERE meta_key =  "_nreal_id"', ARRAY_A);
         
         //$terms = $wpdb->get_results('SELECT  meta_value FROM wp_postmeta WHERE meta_key ="_nreal_id"', ARRAY_A);
          //$lastRefId= max((array_column($terms, 'meta_value')));
 
            if(!empty($terms)){
                  $refid = (int)$terms[0]['meta_value'];
                  //$refid=$lastRefId;
                  $refid++;
              }else{
                update_post_meta($post_id, '_nreal_id_man',3600);
              }
         //echo $refid;die('test');

         update_post_meta($post_id, '_nreal_id', $refid);
         update_post_meta($post_id, '_nreal_id_man',$refid);
         //update_post_meta($post_id, '_xmlref', $refid);
         
         }
         
      }
      
      if (isset($_POST['property_meta_essential']['energy']['current']))
         update_post_meta($post_id, '_energyCurrent', $_POST['property_meta_essential']['energy']['current']);

      if (isset($_POST['property_meta_essential']['energy']['potential']))
         update_post_meta($post_id, '_energyPotential', $_POST['property_meta_essential']['energy']['potential']);

      if (isset($_POST['property_meta_essential']['co2']['current']))
         update_post_meta($post_id, '_co2Current', $_POST['property_meta_essential']['co2']['current']);

      if (isset($_POST['property_meta_essential']['co2']['potential']))
         update_post_meta($post_id, '_co2Potential', $_POST['property_meta_essential']['co2']['potential']);

      if (isset($_POST['property_meta_essential']['epc_e']))
         update_post_meta($post_id, '_epc_e', $_POST['property_meta_essential']['epc_e']);

      if (isset($_POST['property_meta_essential']['epc_c']))
         update_post_meta($post_id, '_epc_c', $_POST['property_meta_essential']['epc_c']);

      if (isset($_POST['property_meta_essential']['agent']))
         update_post_meta($post_id, '_agentCheck', $_POST['property_meta_essential']['agent']);

      //taxonomy features,interios,exterior view and type are used for search and filters

      if (isset($_POST['property_meta_essential']['category'])) {
         //property categories terms
         $categories_ids = array_map('intval', (array) $_POST['property_meta_essential']['category']);
         $categories_ids = array_unique($categories_ids);
         wp_set_object_terms($post_id, $categories_ids, 'category', false);
      }

      if (isset($_POST['property_meta_fetures'])) {
         //property type terms
         $feature_ids = array_map('intval', $_POST['property_meta_fetures']);
         $feature_ids = array_unique($feature_ids);
         wp_set_object_terms($post_id, $feature_ids, 'feature', false);
      }

      if (isset($_POST['property_meta_interiors'])) {
         //property interior terms
         $interior_ids = array_map('intval', $_POST['property_meta_interiors']);
         $interior_ids = array_unique($interior_ids);
         wp_set_object_terms($post_id, $interior_ids, 'interior', false);
      }

      if (isset($_POST['property_meta_exteriors'])) {
         //property exterior terms
         $exterior_ids = array_map('intval', $_POST['property_meta_exteriors']);
         $exterior_ids = array_unique($exterior_ids);
         wp_set_object_terms($post_id, $exterior_ids, 'exterior', false);
      }

      if (isset($_POST['property_meta_essential']['view'])) {
         //property view terms
         $view_ids = array_map('intval', $_POST['property_meta_essential']['view']);
         $view_ids = array_unique($view_ids);
         wp_set_object_terms($post_id, $view_ids, 'view', false);
      }

      if (isset($_POST['property_meta_essential']['locality'])) {
         //property view terms
         $type_ids = array_map('intval', $_POST['property_meta_essential']['locality']);
         $type_ids = array_unique($type_ids);
         wp_set_object_terms($post_id, $type_ids, 'locality', false);
      }

      //the keyholder is same as proprieto
      //todo:change keyholder to proprietor during final deployment

      if (isset($_POST['property_meta_essential']['proprietor'])) {
         //property proprietor terms
         $proprietor_ids = array_map('intval', (array) $_POST['property_meta_essential']['proprietor']);
         $proprietor_ids = array_unique($proprietor_ids);
         wp_set_object_terms($post_id, $proprietor_ids, 'proprietor', false);
         update_post_meta($post_id, '_proprietor', $_POST['property_meta_essential']['proprietor']);
      }
      if (isset($_POST['property_meta_finance']['agent'])) {
         //property agent terms
         $agent_ids = array_map('intval', (array) $_POST['property_meta_finance']['agent']);
         $agent_ids = array_unique($agent_ids);
         wp_set_object_terms($post_id, $agent_ids, 'agent', false);
         update_post_meta($post_id, '_agent', $_POST['property_meta_finance']['agent']);
      }

      if (isset($_POST['property_meta_essential']['orientation'])) {

         $orientation_ids = array_map('intval', (array) $_POST['property_meta_essential']['orientation']);
         $orientation_ids = array_unique($orientation_ids);
         wp_set_object_terms($post_id, $orientation_ids, 'orientation', false);
      }

      //taxonomy banner,dimension,walkscore are not support for search and filter property

      if (isset($_POST['property_meta_essential']['banner'])) {

         $banner_ids = array_map('intval', (array) $_POST['property_meta_essential']['banner']);
         $banner_ids = array_unique($banner_ids);
         wp_set_object_terms($post_id, $banner_ids, 'banner', false);
      }

      if (isset($_POST['property_meta_essential']['banner'])) {

         $banner_ids = array_map('intval', (array) $_POST['property_meta_essential']['banner']);
         $banner_ids = array_unique($banner_ids);
         wp_set_object_terms($post_id, $banner_ids, 'banner', false);
      }



      $terms = get_terms('walkscores','hide_empty=0');
      foreach ($terms as $term)
         update_post_meta($post_id, '_scores_' . $term->term_id, $_POST['property_meta_distance_score'][$term->term_id]);

      $terms = get_terms('dimensions','hide_empty=0');
      foreach ($terms as $term)
         update_post_meta($post_id, '_dimensions_' . $term->term_id, $_POST['property_meta_dimensions'][$term->term_id]);


      $terms = get_terms('feature', 'orderby=id&hide_empty=0');
      foreach ($terms as $term) {

         $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
         if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 2)
            update_post_meta($post_id, '_feature_' . $term->term_id, $_POST['property_meta_essential'][$term->term_id]);
      }




      //add custom meta for structured to be used in filters......			
      if (isset($_POST['property_meta_essential']['year']))
         update_post_meta($post_id, '_year', $_POST['property_meta_essential']['year']);

      if (isset($_POST['property_meta_essential']['bank']))
         update_post_meta($post_id, '_bank', $_POST['property_meta_essential']['bank']);

      if (isset($_POST['property_meta_essential']['penthouse']))
         update_post_meta($post_id, '_penthouse', $_POST['property_meta_essential']['penthouse']);

      if (isset($_POST['property_meta_essential']['proprietorRef']))
         update_post_meta($post_id, '_proprietorRef', $_POST['property_meta_essential']['proprietorRef']);

      if(isset($_POST['property_meta_essential']['proprietorUrl']) )
         update_post_meta( $post_id, '_proprietorUrl',  $_POST['property_meta_essential']['proprietorUrl'] );

      if (isset($_POST['property_meta_finance']['salesPrice']))
         update_post_meta($post_id, '_salesPrice', $_POST['property_meta_finance']['salesPrice']);

      if (isset($_POST['property_meta_finance']['totalPrice']))
         update_post_meta($post_id, '_totalPrice', $_POST['property_meta_finance']['totalPrice']);

      if (isset($_POST['property_meta_finance']['commissionPere']))
         update_post_meta($post_id, '_commissionPer', $_POST['property_meta_finance']['commissionPer']);

      if (isset($_POST['property_meta_finance']['reservationAmount']))
         update_post_meta($post_id, '_reservationAmount', $_POST['property_meta_finance']['reservationAmount']);

      if (isset($_POST['property_meta_finance']['monthlyCharges']))
         update_post_meta($post_id, '_monthlyCharges', $_POST['property_meta_finance']['monthlyCharges']);

      if (isset($_POST['property_meta_finance']['oldPrice']))
         update_post_meta($post_id, '_oldPrice', $_POST['property_meta_finance']['oldPrice']);

      if (isset($_POST['property_meta_finance']['buildType']))
         update_post_meta($post_id, '_buildType', $_POST['property_meta_finance']['buildType']);

      if (isset($_POST['property_meta_essential']['propertyName']))
         update_post_meta($post_id, '_propertyName', $_POST['property_meta_essential']['propertyName']);

      if (isset($_POST['property_meta_essential']['country'])) {

         $country_ids = array_map('intval', (array) $_POST['property_meta_essential']['country']);
         $country_ids = array_unique($country_ids);
         wp_set_object_terms($post_id, $country_ids, 'country', false);

         update_post_meta($post_id, '_country', $_POST['property_meta_essential']['country']);
      }

      if (isset($_POST['property_meta_essential']['region'])) {

         $region_ids = array_map('intval', (array) $_POST['property_meta_essential']['region']);
         $region_ids = array_unique($region_ids);
         wp_set_object_terms($post_id, $region_ids, 'region', false);

         update_post_meta($post_id, '_region', $_POST['property_meta_essential']['region']);
      }

      if (isset($_POST['property_meta_essential']['province'])) {
         $province_ids = array_map('intval', (array) $_POST['property_meta_essential']['province']);
         $province_ids = array_unique($province_ids);
         wp_set_object_terms($post_id, $province_ids, 'provinces', false);
         update_post_meta($post_id, '_province', $_POST['property_meta_essential']['province']);
      }

      if (isset($_POST['property_meta_essential']['place'])) {

         $place_ids = array_map('intval', (array) $_POST['property_meta_essential']['place']);
         $placee_ids = array_unique($place_ids);
         wp_set_object_terms($post_id, $place_ids, 'place', false);

         update_post_meta($post_id, '_place', $_POST['property_meta_essential']['place']);
      }

      if (isset($_POST['property_meta_essential']['lat'])){
         update_post_meta($post_id, '_lat', $_POST['property_meta_essential']['lat']);
      }
      if (isset($_POST['property_meta_essential']['lng'])){
         update_post_meta($post_id, '_lng', $_POST['property_meta_essential']['lng']);
      }   

      if (isset($_POST['property_meta_essential']['zip']))
         update_post_meta($post_id, '_zip', $_POST['property_meta_essential']['zip']);


      if (isset($_POST['property_meta_finance']['vat']))
         update_post_meta($post_id, '_vat', $_POST['property_meta_finance']['vat']);

      if (isset($_POST['property_meta_finance']['transmissionTax']))
         update_post_meta($post_id, '_transmissionTax', $_POST['property_meta_finance']['transmissionTax']);

      if (isset($_POST['property_meta_finance']['stampDuty']))
         update_post_meta($post_id, '_stampDuty', $_POST['property_meta_finance']['stampDuty']);

      if (isset($_POST['property_meta_finance']['notaryCost']))
         update_post_meta($post_id, '_notaryCost', $_POST['property_meta_finance']['notaryCost']);

      if (isset($_POST['property_meta_finance']['lawyerCost']))
         update_post_meta($post_id, '_lawyerCost', $_POST['property_meta_finance']['lawyerCost']);


      if (isset($_POST['property_meta_finance']['utilitiesConnectionCost']))
         update_post_meta($post_id, '_utilitiesConnectionCost', $_POST['property_meta_finance']['utilitiesConnectionCost']);

      if (isset($_POST['property_meta_finance']['buyerCost']))
         update_post_meta($post_id, '_buyerCost', $_POST['property_meta_finance']['buyerCost']);


      if (isset($_POST['property_meta_finance']['moreInformation']))
         update_post_meta($post_id, '_moreInformation', $_POST['property_meta_finance']['moreInformation']);

      if (isset($_POST['property_meta_finance']['commissionAmount']))
         update_post_meta($post_id, '_commissionAmount', $_POST['property_meta_finance']['commissionAmount']);

      if (isset($_POST['property_meta_finance']['commissionPer']))
         update_post_meta($post_id, '_commissionPer', $_POST['property_meta_finance']['commissionPer']);


      if (isset($_POST['property_meta_finance']['fstatus'])) {
         //property status terms		        
         $status_ids = array_map('intval', (array) $_POST['property_meta_finance']['fstatus']);
         $status_ids = array_unique($status_ids);
         update_post_meta($post_id, '_status', (integer) $_POST['property_meta_finance']['fstatus']);
         //wp_set_object_terms($post_id, $status_ids, 'status', true);
         wp_set_object_terms($post_id, $status_ids, 'status', false);
      }
      if (isset($_POST['property_meta_essential']['project'])) {
         update_post_meta($post_id, '_project', $_POST['property_meta_essential']['project']);
      }

     /*function to display project count */
      if (isset($_POST['property_meta_essential']['project'])) {

         $project_ids = array_map('intval', (array) $_POST['property_meta_essential']['project']);
         $project_ids = array_unique($project_ids);
         wp_set_object_terms($post_id, $project_ids, 'project', false);
      }






      /*update property slug name
        Date:- 11/jan/2017
       */
      $cat=get_the_category($post_id);
      $cat_name=$cat[0]->cat_name;
      $countryName = $regionName = $country= $region='';
      $country=get_post_meta($post_id,'_country');  
      $region=get_post_meta($post_id,'_region');
      $place=get_post_meta($post_id,'_place');
      $country=$country[0];
      $place=$place[0];
      $region=$region[0];
      $countryName = self::get_termName($country);
      $place = self::get_termName($place);
      $regionName = self::get_termName($region);

      $all_terms = get_option('qtranslate_term_name');
         foreach ($all_terms as $key => $value) {
         if($country && $country==$key) $countryName = $value['nl'];
         if($region && $region==$key) $regionName = $value['nl'];
         if($cat_name==$key) $cat_name = $value['nl'];
         if($place==$key) $place = $value['nl'];
      }
      $refid=get_post_meta($post_id,'_nreal_id');
      $post_slug =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",strtolower($countryName));
      global $wpdb;
      $wpdb->query("update wp_posts set post_name='".$post_slug."' where ID=".$post_id);
      

      //self::weatehrInfoRun($post_id);
      /*====End code===*/
      
       updatePropertyGalerryImage($post_id);
      //die('dointest');
      return;
   }

/* 
 * Date : 11-January-2017
 * Method : Function for manage location translation
 */
function get_termName($termId) {
    global $wpdb;
    $terms = $wpdb->get_results('SELECT name FROM wp_terms WHERE term_id =' . $termId, ARRAY_A);
    if (isset($terms[0]['name']))
        return $terms[0]['name'];
    return false;
}



function weatehrInfoRun($post_id){

  global $wpdb; 
  
 $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];
  //echo '<br>'.$post_id."---nbrl---".$nbId."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

$postName =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",strtolower($countryName));
  

  global $wpdb; 
  $table_name='wp_posts';
  /*/update post name*/       
  $wpdb->query("UPDATE $table_name SET  post_name='$postName' WHERE ID=$post_id");


  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    //echo '<pre>';print_r($ids);
    //die;////////
  /* run for all post attachment id*/ 
  $i=0; 
  $temp=false;
 if(isset($ids) && !empty($ids)){ 
  
  foreach ($ids as $atchid) {
      $addedFilesNames=array('');
      foreach ($ids as $atID) {
       $addedFilesNames[] = get_attached_file($atID);
      }
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;
        $postname =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
  
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
            /*oldFileName*/
              //$oldnamefile=$filepath.'/'.$prvName;
              //$newfile = $filepath.'/'.$name.'.'.$ext;
              //$atchData=get_post_meta($atchid,'_wp_attached_file');

  $file = get_attached_file($atchid);
  $newfileName=$pathName['dirname']."/".$name.'.'.$pathName['extension'];
  if(!in_array($newfileName, $addedFilesNames)){
      $path = pathinfo($file);       
      if($path['basename']!='' && $path['basename'] != $name.'.'.$ext){
        $updatedPostID[]=$post_id.'-'.$nbId;
            //echo 'in--  ';    
                global $wpdb; 
                $table_name='wp_posts';
                $table_name1='wp_postmeta';
                /*/update post meta*/       
                $wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$postname' WHERE ID=$atchid");
                $wpdb->query("UPDATE $table_name1 SET meta_value='$name' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");

                /* get wp_attached_file data */
                $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];
                
                /*rename attact fileName */
                  if(file_exists($file)){
                   rename($file, $newwp_attached_file); 
                   update_attached_file( $atchid, $newwp_attached_file );
                  }
                  
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
               //echo '<pre>';
               //print_r($atchData1);
               
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;

              /*Update attechment data*/ 
 
                $thumbnail= $atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $atchData1[0]['sizes']['medium']['file'];
                $large= $atchData1[0]['sizes']['large']['file'];
                
                $pdfLarge= $atchData1[0]['sizes']['pdf-large']['file'];
                $pdfSmall= $atchData1[0]['sizes']['pdf-small']['file'];
                $printA5Large= $atchData1[0]['sizes']['print-A5-large']['file'];
                

        if($pdfLarge!='' || $pdfSmall!='' || $printA5Large!=''){
                 ///echo $atchid.'pdfin<br>';
                  
                if($pdfLarge!=''){

                    $pdfLarge = $filepath.'/'.$atchData1[0]['sizes']['pdf-large']['file'];
                    if(file_exists($pdfLarge)){
                      $atchData1[0]['sizes']['pdf-large']['file']= $name.'-.jpg';
                      rename($pdfLarge, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($pdfSmall!=''){

                  $pdfSmall = $filepath.'/'.$atchData1[0]['sizes']['pdf-small']['file'];
                    if(file_exists($pdfSmall)){
                      $atchData1[0]['sizes']['pdf-small']['file']= $name.'-.jpg';
                      rename($pdfSmall, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($printA5Large!=''){

                     $printA5Large = $filepath.'/'.$atchData1[0]['sizes']['print-A5-large']['file'];
                    if(file_exists($printA5Large)){
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['print-A5-large']['file']= $name.'-.jpg';
                      
                    }  
                }


                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                      rename($thumbnail, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-small.jpg';
                      
                    }  
                }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                      rename($medium, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['medium']['file']= $name.'-medium.jpg';
                      
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-.jpg';
                      
                    }  
                }    
             }else{
                    
                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                      rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                    }  
                  }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                       rename($medium, $filepath."/".$name.'-300x169.jpg');
                       $atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                      rename($large, $filepath."/".$name.'-1024x576.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                    }  
                }
                
             }         
                      
             $updatedAttachData=serialize($atchData1);
             //$atchData1=unserialize($updatedAttachData);
             //echo '<pre>';
             //print_r($atchData1);
           
          global $wpdb; 
          $table_name1='wp_postmeta';
          $table_name='wp_posts';
           
            $wpdb->query("DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'");
             
            $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");

            $wpdb->query("UPDATE $table_name1 SET meta_value='$name' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'"); 

            /*/update post meta*/       
            $wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$postname' WHERE ID=$atchid"); 
        }
        else{ //end check attachmentImage title and updation
              $notupdate[]=$post_id.'-'.$nbId;
        }
      }else{
        global $wpdb;
        $table_name1='wp_postmeta';
        $table_name='wp_posts';
        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $altName=$pathName['filename'];
        $wpdb->query("UPDATE $table_name1 SET meta_value='$altName' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");
        /*/update post meta*/
       // echo "UPDATE $table_name SET post_title='$altName', post_name='$altName' WHERE ID=$atchid";  
        //echo "UPDATE $table_name1 SET meta_value='$altName' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'";

         $wpdb->query("UPDATE $table_name SET post_title='$altName', post_name='$altName' WHERE ID=$atchid"); 
      }
    $i++;
    //die('atch');
  }//end for attachment id
}//check atchId
//die('ddddd');
}




/*
* Date: 02-Nov-2016
* Method: function for add fields on project add page
*/
static function add_project_options($term) {
   ?>
<script type="text/javascript">
  var pVal='';
jQuery(document).ready(function(){
   var prpValue =jQuery("#taxonomy_meta_propriter").val();
   var projectFromVal=jQuery("#submit").val();
   if(projectFromVal=='Add New Project'){
    jQuery('#submit').attr('disabled',true);
   }
   jQuery('#taxonomy_meta_propriter').change(function() {
     var pVal=jQuery(this).val();
      if(pVal!=''){
        jQuery("#pReq").hide(); 
        jQuery('#submit').attr('disabled',false);
        jQuery("#proMsg").removeClass('error');
     }
   });
   jQuery("#tag-name").mouseover(function() {
      var prpValue =jQuery("#taxonomy_meta_propriter").val();
        if(prpValue == ''){
          jQuery("#proMsg").addClass('error');
        }
   });
});
</script>
   <?php
   $obj = new Azull_Subscriber();
   $html = '<div class="form-field"><label>'.$obj->getTranslatedString('en','nl','Proprietor').'</label>';
   $terms  = get_terms('proprietor',array('orderby' => 'name', 'hide_empty' => false));
   $html .='<select class="SlectBox" name="taxonomy_meta[proprietor][]" id="taxonomy_meta_propriter">
   <option value="" selected>'. __("Select proprietor", "azull").'</option>';
   if(isset($terms) && !empty($terms)){
      foreach ($terms as $term) {
         $html .='<option value="' . $term->term_id . '">' . qtranxf_use(qtranxf_getLanguage(), $term->name) . '</option>';
      }
   }
   $html .='</select><br>';
   $html .='<span id="proMsg" class="description">' . $obj->getTranslatedString('en','nl','Select one or more proprietors') . '</span></div>';
   $html .='<style>.SumoSelect{width:96%;}</style>';
   echo $html;
}
/*
* Date: 26-Oct-2016
* Method: function for add fields on project edit page
*/
static function edit_project_options($term) {
   $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
   $obj = new Azull_Subscriber();
   if (!$taxonomy_meta)
      $taxonomy_meta['type'] = 1;

      global $aj_config, $post,$q_config;  
      $languages = qtranxf_getSortedLanguages();
      $html = '<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label>' . $obj->getTranslatedString('en','nl','Pricelist') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_price_list = (isset($taxonomy_meta['price_list']) && !empty($taxonomy_meta['price_list']))?$taxonomy_meta['price_list']:'';
      $html .='<input type="text" name="taxonomy_meta[price_list]" value="' . $p_price_list . '" >';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project price list') . '</p>';
      $html .='</td>';

      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label>' . $obj->getTranslatedString('en','nl','Plan') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_plan = (isset($taxonomy_meta['project_plan']) && !empty($taxonomy_meta['project_plan']))?$taxonomy_meta['project_plan']:'';
      $html .='<input type="text" name="taxonomy_meta[project_plan]" value="' . $p_plan . '">';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project plans') . '</p>';
      $html .='</td>';
      $html .='</tr>';
     
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Status') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_status = (isset($taxonomy_meta['project_status']) && !empty($taxonomy_meta['project_status']))?$taxonomy_meta['project_status']:'';
      $html .='<input type="text" name="taxonomy_meta[project_status]" value="' . $p_status . '">';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project status') . '</p>';
      $html .='</td>';
      $html .='</tr>';


      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Extra information') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $project_extra_information = (isset($taxonomy_meta['project_extra_information']) && !empty($taxonomy_meta['project_extra_information']))?$taxonomy_meta['project_extra_information']:'';
      $html .='<input type="text" name="taxonomy_meta[project_extra_information]" value="' . $project_extra_information . '">';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Extra information') . '</p>';
      $html .='</td>';
      $html .='</tr>';



      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Azull photos') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $project_photos = (isset($taxonomy_meta['project_photos']) && !empty($taxonomy_meta['project_photos']))?$taxonomy_meta['project_photos']:'';
      $html .='<input type="text" name="taxonomy_meta[project_photos]" value="' . $project_photos . '">';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Azull photos') . '</p>';
      $html .='</td>';
      $html .='</tr>';




      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Website') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_website = (isset($taxonomy_meta['project_website']) && !empty($taxonomy_meta['project_website']))?$taxonomy_meta['project_website']:'';
      $html .='<input type="text" name="taxonomy_meta[project_website]" value="' . $p_website . '" >';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project website URL') . '</p>';
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Address') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $html .=self::location_fields($taxonomy_meta);
      foreach($languages as $lang):
         $sly = ($aj_config["default_language"]==$lang)?"style = display:block":'';
         //$tax_house = (isset($taxonomy_meta["house"][$lang]))? $taxonomy_meta["house"][$lang]:"";
         $tax_street = (isset($taxonomy_meta["street"][$lang]))? $taxonomy_meta["street"][$lang]:"";
         //$tax_city = (isset($taxonomy_meta["city"][$lang]))? $taxonomy_meta["city"][$lang]:"";
         $html .='<div id="term_address_'.$lang.'" class="property_meta_table term_project_div '.$sly.'">';
          /*$html .='<div  class="form-field">
            <input type="text" name="taxonomy_meta[house]['.$lang.']" id="taxonomy_meta[house]['.$lang.']" value="'.$tax_house.'">
             <p class="description">'.$obj->getTranslatedString('en','nl','Enter house Number').'</p>
          </div>'; */
          $html .='<div class="form-field">
            <input type="text" name="taxonomy_meta[street]['.$lang.']" id="taxonomy_meta[street]['.$lang.']" value="'.$tax_street.'">
             <p class="description">'.$obj->getTranslatedString('en','nl','Enter street').'</p>
          </div>';
          $html .='</div>';
      endforeach;
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','GPS') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_gps = (isset($taxonomy_meta['project_gps']) && !empty($taxonomy_meta['project_gps']))?$taxonomy_meta['project_gps']:'';
      $html .='<input type="text" name="taxonomy_meta[project_gps]" value="' . $p_gps . '" >';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project GPS co-ordinates') . '</p>';
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Contact person') . '</label>';
      $html .='</th>';
      $html .='<td>';

      foreach($languages as $lang):
      $p_contact_person = (isset($taxonomy_meta['project_contact_person'][$lang]) && !empty($taxonomy_meta['project_contact_person'][$lang]))?$taxonomy_meta['project_contact_person'][$lang]:'';
      $html .='<div id="term_contact_'.$lang.'" class="term_project_div">';
      $html .='<input type="text" name="taxonomy_meta[project_contact_person]['.$lang.']" value="' . $p_contact_person . '" >';
      $html .='</div>';
      endforeach;
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project contact person') . '</p>';
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' .$obj->getTranslatedString('en','nl','Email') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_contact_person_email = (isset($taxonomy_meta['contact_person_email']) && !empty($taxonomy_meta['contact_person_email']))?$taxonomy_meta['contact_person_email']:'';
      $html .='<input type="text" name="taxonomy_meta[contact_person_email]" value="' . $p_contact_person_email . '" >';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project contact email'). '</p>';
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Phone') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_contact_person_phone = (isset($taxonomy_meta['contact_person_phone']) && !empty($taxonomy_meta['contact_person_phone']))?$taxonomy_meta['contact_person_phone']:'';
      $html .='<input type="text" name="taxonomy_meta[contact_person_phone]" value="' . $p_contact_person_phone . '" >';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project contact phone'). '</p>';
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','GSM') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $p_contact_person_gsm = (isset($taxonomy_meta['contact_person_gsm']) && !empty($taxonomy_meta['contact_person_gsm']))?$taxonomy_meta['contact_person_gsm']:'';
      $html .='<input type="text" name="taxonomy_meta[contact_person_gsm]" value="' . $p_contact_person_gsm . '" >';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project contact mobile phone') . '</p>';
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Opening Hours') . '</label>';
      $html .='</th>';
      $html .='<td>';
      foreach($languages as $lang):
      $p_opening_hrs = (isset($taxonomy_meta['project_opening_hrs'][$lang]) && !empty($taxonomy_meta['project_opening_hrs'][$lang]))?$taxonomy_meta['project_opening_hrs'][$lang]:'';
      $html .='<div id="term_opening_hrs_'.$lang.'" class="term_project_div">';
      //$html .='<input type="text" name="taxonomy_meta[project_opening_hrs]['.$lang.']" value="' . $p_opening_hrs . '" >';

      $html .='<textarea rows="6" name="taxonomy_meta[project_opening_hrs]['.$lang.']">'.$p_opening_hrs.'</textarea>';


      $html .='</div>';
      endforeach;
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project opening hours') . '</p>';
      $html .='</td>';
      $html .='</tr>';
      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label for="qtranxf_term_en">' . $obj->getTranslatedString('en','nl','Comment') . '</label>';
      $html .='</th>';
      $html .='<td>';
      foreach($languages as $lang):
         $p_comment = (isset($taxonomy_meta['project_comment'][$lang]) && !empty($taxonomy_meta['project_comment'][$lang]))?$taxonomy_meta['project_comment'][$lang]:'';
         $html .='<div id="term_comment_'.$lang.'" class="term_project_div">';
         $html .='<textarea rows="6" name="taxonomy_meta[project_comment]['.$lang.']">'.$p_comment.'</textarea>';
         $html .='</div>';
      endforeach;
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Enter project comments') . '</p>';
      $html .='</td>';
      $html .='</tr>';


      $html .='<tr class="form-field">';
      $html .='<th valign="top" scope="row">';
      $html .='<label>' . $obj->getTranslatedString('en','nl','Proprietor') . '</label>';
      $html .='</th>';
      $html .='<td>';
      $terms  = get_terms('proprietor',array('orderby' => 'name', 'hide_empty' => false));
      $html .='<select style="width: 50%" class="SlectBox" name="taxonomy_meta[proprietor]" id="taxonomy_meta[proprietor]">
      <option value="" selected>'. __("Select proprietor", "azull").'</option>';
      if(isset($terms) && !empty($terms)){
         $p_proprietor = (isset($taxonomy_meta['proprietor']) && !empty($taxonomy_meta['proprietor']))?$taxonomy_meta['proprietor']:'';
         //print('<pre>');print_r($p_proprietors);die;
         foreach ($terms as $term) {
            $html .='<option value="' . $term->term_id . '" '.((isset($p_proprietor) && !empty($p_proprietor) && $term->term_id == $p_proprietor)?"selected":"").'>' . qtranxf_use(qtranxf_getLanguage(), $term->name) . '</option>';
         }
      }
      $html .='</select><br><br>';
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Select proprietors') . '</p>';
      $html .='</td>';
      $html .='</tr>';


      $html .='<script>
      jQuery(".term_project_div").hide();
      jQuery("#term_address_'.$q_config["default_language"].'").show();
      jQuery("#term_contact_'.$q_config["default_language"].'").show();
      jQuery("#term_opening_hrs_'.$q_config["default_language"].'").show();
      jQuery("#term_comment_'.$q_config["default_language"].'").show();
      jQuery(document).ready(function() {
         jQuery(".wrap").on("click","ul.qtranxs-lang-switch-wrap li.qtranxs-lang-switch",function(n){
            //alert(jQuery(this).attr("lang"));
            var lang = jQuery(this).attr("lang");';
            $html .='jQuery(".term_project_div").hide();
            jQuery("#term_address_"+lang).show();
            jQuery("#term_contact_"+lang).show();
            jQuery("#term_opening_hrs_"+lang).show();
            jQuery("#term_comment_"+lang).show();
         });
      });
    </script>
    <style>.form-table td {padding: 4px 0px;}.form-table th {padding: 8px 10px 20px 0;}</style>';
      echo $html;
   }
   /*
   * Date: 26-Oct-2016
   * Method: function for add country,region and place fields on project edit page
   */
   function location_fields($taxonomy_meta) {
      global $post, $wpdb;
      $obj = new Azull_Subscriber();
      $html = '';
      $countries = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
      $places = get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));

      $added_cntry = (isset($taxonomy_meta['country']) && !empty($taxonomy_meta['country']))?$taxonomy_meta['country']:'';
      $added_regn = (isset($taxonomy_meta['region']) && !empty($taxonomy_meta['region']))?$taxonomy_meta['region']:'';
      $added_plce = (isset($taxonomy_meta['place']) && !empty($taxonomy_meta['place']))?$taxonomy_meta['place']:'';
      $html .= "<table width='100%' style='margin-left:-2px;' celpadding='0'>";
      $html .= "<tr>";
      $html .= "<td>";
      if (!empty($countries) && !is_wp_error($countries)) {
         $html .="<select id='property_meta_country' name='taxonomy_meta[country]' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         foreach ($countries as $countrie):
            $html .= "<option value='" . $countrie->term_id . "' " . ((isset($added_cntry) && $countrie->term_id == $added_cntry) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
         endforeach;
         $html .="</select>";
      }else {
         $html .="<select id='property_meta_country' name='taxonomy_meta[country]' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Select country') . '</p>';
      $html .= "</td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .= "<td>";
      if (!empty($regions) && !is_wp_error($regions)) {
         $html .="<select id='property_meta_region' name='taxonomy_meta[region]' class='weather_info_frm'>";
         $html .= "<option>--</option>";
         foreach ($regions as $region):
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $region->term_id);
            if(isset($taxonomy_meta['country'])){ 
               $html .= "<option value='" . $region->term_id . "'  " . ((isset($added_regn) && $region->term_id == $added_regn) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
            }
         endforeach;
         $html .="</select>";
      } else {
         $html .="<select id='property_meta_region' name='taxonomy_meta[region]' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Select Region') . '</p>';
      $html .= "</td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .= "<td>";
      if (!empty($places) && !is_wp_error($places)) {
         $html .="<select id='property_meta_place' name='taxonomy_meta[place]' class='weather_info_frm'>";
          $html .= "<option >--</option>";
         foreach ($places as $place):
            $html .= "<option value='" . $place->term_id . "' " . (((isset($added_plce) && $place->term_id == $added_plce)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
         endforeach;
         $html .="</select>";
      } else {
         $html .="<select id='property_meta_place' name='taxonomy_meta[place]' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .='<p class="description">' . $obj->getTranslatedString('en','nl','Select Place') . '</p>';
      $html .= "</td>";
      $html .= "</tr>";
      $html .= "</table>";
      return $html;
   }
   /*
   * Date: 14-Feb-2017
   * Method: function for add Order column in infodays overview list
   */
   static function infodays_column($columns) {
      $columns['menu_order'] = __('Order', 'azull');
      return $columns;
   }
   /*
   * Date: 14-Feb-2017
   * Method: function for display Order column value in infodays overview list
   */
   static function infodays_column_content($column_name, $post_ID) {
      if ($column_name == 'menu_order') {
         if(isset($post_ID) && !empty($post_ID)){
            $post_data = get_post();
            echo $post_data->menu_order;
         }
      }
   }
   /*
   * Date: 14-Feb-2017
   * Method: function for display Order column sorting in infodays overview list
   */
   static function infodays_sortable_columns($columns) {
      $columns['menu_order'] = 'menu_order';
      return $columns;
   }
//****** End Class ***********//
}
