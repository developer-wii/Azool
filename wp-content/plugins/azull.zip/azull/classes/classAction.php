<?php
class Azull_Action{

    static function pdf_page() {
            add_submenu_page(  null, 'PDF', 'PDF', 'manage_options', 'pdf', array('azull_action','azull_pdf' )); 
    }
    /*
     * Comment for pdf action in action list
     * Date:- 31-may-2016
     *
     *static function azull_pdf(){
	$html = "";	
	$ids=unserialize(base64_decode($_GET['ids'])); //get all selected post ids	
  if(!$ids)
	  return;
    
        $languages = qtranxf_getSortedLanguages();
	$currentLang = qtranxf_getLanguage();
	$clients = get_posts(array('post_type'=>'azull_site','post_status'=>'draft'));


	$html .='<div class="wrap">';
	$html .='<div class="azull-toolbar">';
	
	$html .= '<ul>';
         $html .='<li>';   
         $html .='<select class="print-ajax" id="azull-clients">';
          if(!empty($clients)){
          	$clients = array_reverse($clients);
           foreach ($clients as $value) { 
                 $html .='<option value="'.$value->ID.'">'.qtranxf_use(qtranxf_getLanguage(),$value->post_title).'</option>';
           }
         }
        $html .='</select>';
        $html .='</li>';

	    $html .='<li>';
	    $html .='<select id="azull-template">'; 
	//	$html .='<option selected="selected" value="0">'.__("Select template","azull").'</option>';
		$html .='<option value="0">'.__("AZULL PDF(A4)",'azull').'</option>';
		$html .='</select>';
	    $html .='</li>';
	    
	    $html .='<li>';
	    $html .='<select id="azull-languag">';
	  //   $html .='<option selected="selected" value="'.$currentLang.'">'.__('Select language','azull').'</option>';	     
		foreach($languages as $lang){
		    $html .='<option value="'.$lang.'">'.qtranxf_getLanguageName($lang).'</option>';
		}
	    
	    $html .='</select>';
	    $html .='</li>';


	$html .='</ul>';
	
	$html .='</div>';
	
	$html .='<ul class="azull-pdf">';
        foreach($ids as $id){
	    $html .='<li>
		    <a class="azull-pdf-link" target="_blank" rel="noindex,nofollow" download href="" data-id="'.$id.'" data-link="'.get_site_url().'" title="' . get_the_title($id).'"><img width="128" title="' . get_the_title($id).'"  alt="azull pdf" src="'.AZULL_URL.'images/pdf.png">
		    <h5>Ref.'.get_post_meta($id,'_nreal_id',true).'</h5>
		    <h5>'.azull_short_text(get_the_title($id),false,25).'</h5>
		    </a></li>'; 
	}
	$html .='</ul></div>';
	
	$html .='<script>
		jQuery(document).ready(function() {		
		    setpdflink();
		});
		jQuery("#azull-template").change(function(){
		   setpdflink();
		});
		jQuery("#azull-languag").change(function(){
		   setpdflink();
		});
		jQuery("#azull-clients").change(function(){
		   setpdflink();
		});
		function setpdflink(){
		    jQuery("a.azull-pdf-link").each(function() {  
			 var _href= jQuery(this).attr("data-link");
			 _href = _href + "?format=pdf";
			_href = _href + "&tpl=" + jQuery("#azull-template").val();
			_href = _href + "&lng=" + jQuery("#azull-languag").val();			
			_href = _href + "&clnt=" + jQuery("#azull-clients").val();			
			_href = _href + "&id=" + jQuery(this).attr("data-id");
			jQuery(this).attr("href",_href);
		     });
		    
		}
		</script>';
	
        echo $html;
        
        
    }
    
    
    */
    
    
    static function print_page() {
           global $printpage;
           $printpage=add_submenu_page(  null, __('Print','azull'), __('Print','azull'), 'manage_options', 'print', array('azull_action','azull_print' ));
           //add_action("load-$printpage",  array('azull_action',"print_screen_options"));
    }
    static function print_screen_options(){
        global $printpage;       
        $screen = get_current_screen();        
	
		// get out of here if we are not on our settings page
		if(!is_object($screen) || $screen->id != $printpage)
		return; 

		$args = array();
		add_screen_option( 'per_page', $args );        
    }

    
    static function print_screen_settings($status, $args){       
        $screen = get_current_screen();
       
        $return = $status;
	if(!is_object($screen) || $screen->id != 'edit-property')
		return;
            
    global $aj_config,$q_config;
	$user = get_current_user_id();
	$option = $screen->get_option('per_page', 'option');
	
    $option = $screen->get_option('edit_property_per_page ', 'print');	
	$per_page = get_user_meta($user, $option, false);
	$p = unserialize($per_page['print'][0]);
	
        $button = get_submit_button( __( 'Apply' ), 'button', 'screen-options-apply', false );
        $return .= "<fieldset style='border-top: 1px solid hsl(0, 0%, 80%); width: 100%;'><legend><h4>".__('Select Language','azull')."</h4></legend>";
        $languages = qtranxf_getSortedLanguages();
                 
        foreach ($languages as $lang):
	   		 $return .= "<input type='radio' value='".$lang."' name='print_l[]' ".((isset($p[l]) && $p[l]==$lang) ?"checked='checked'":'')." />".qtranxf_getLanguageName($lang)."</label>";
        endforeach;
	 
        $return .= "</fieldset><p class='description'>".__('PDF/Print will be generated in selected language','azull').".</p>" ;
        $return .= "<fieldset style='border-top: 1px solid hsl(0, 0%, 80%); width: 100%;'><legend><h4>".__('Print/pdf template','azull')."</h4></legend>";
		$return .="<input type='radio' value='0' name='print_t[]' ".((isset($p[t]) && $p[t]==0) ?"checked='checked'":'')." />Azull(Default)</label>";
        $return .="<input type='radio' value='1' name='print_t[]' ".((isset($p[t]) && $p[t]==1) ?"checked='checked'":'')." />Azull A4</label>";
        $return .="<input type='radio' value='2' name='print_t[]' ".((isset($p[t]) && $p[t]==2) ?"checked='checked'":'')." />Azull A5</label>";
        $return .= "</fieldset><p class='description'>Selected template will used while generating pdf/print</p>" ;
        $return .="<div><input type='hidden' name='wp_screen_options[option]' value='print' /></div><style>#screen-options-apply{ bottom: 7px;left: 330px; position: absolute;}</style>"; 
        return $return;
    }
    static function azull_print(){	
	
	$html = "";
	$img='<img src="'.AZULL_URL.'images/site.gif">';
	if( !isset($_GET['ids']) && $_GET['ids']!='')
	  return;
	$ids=$_GET['ids']; //get all selected post ids
    	$html .="<script>jQuery(document).ready(function($) {
	change_tpl();
	});	
	jQuery(document).on('change','#azull-language',function(){
           change_tpl();
	}); 
	jQuery(document).on('change','#azull-template',function(){
	  change_tpl();
	    
	});
  jQuery(document).on('change','#azull-clients',function(){
      change_tpl();
  });

	function change_tpl(){
	     jQuery('#print-wrap').html('');
	     jQuery('#print-wrap').html('.$img.');
                            var lng = jQuery('#azull-language').val();
			    var tpl = jQuery('#azull-template').val();
                            var clnt = jQuery('#azull-clients').val();
                            var data = {
                                    action: 'print_action',
                                    type: 'POST',
                                    dataType:'json',                                   
                                    lng:lng,
                                    tpl: tpl,
                                    clnt: clnt,
				    ids:'".$ids."'
                                    };         
                                     
                                    jQuery.post( ajaxurl, data, function( response ) {
				    
				   jQuery('#print-wrap').html(response);
                                                                       
                            });
			    
	}
	
	
	</script>";
	
    $languages = qtranxf_getSortedLanguages();
	$currentLang = qtranxf_getLanguage();
	//$clients = get_posts(array('post_type'=>'azull_site','post_status'=>'draft'));
	$clients = get_posts(array('post_type'=>'company','post_status'=>'publish','order' => 'ASC'));
        /*global $wpdb;
	$table_name = $wpdb->prefix . "company";
	$clients = $wpdb->get_results(
		"SELECT * FROM {$table_name}"
	);*/
          
	$html .='<div class="azull-toolbar">';
   	$html .='<ul>';

        $html .='</li>';
	    $html .='<li>';
	    /*$url=get_option('redirect_url'); 
	    $html .='<a  id="azullprint" href="'.$url.'" target="_blank"><input class="button-primary" type="button" value="Back"></a>'; 
	    $html .='</li>';*/


      $html .='<li>';
      $html .='<select class="print-ajax" id="azull-clients">';
        if(!empty($clients)){
          foreach ($clients as $value){
            //$html .='<option value="'.$value->ID.'">'.qtranxf_use(qtranxf_getLanguage(),$value->post_title).'</option>';
	    $html .='<option value="'.$value->ID.'">'.qtranxf_use(qtranxf_getLanguage(),$value->post_title).'</option>';
          }
        }
      $html .='</select>';
      $html .='</li>';


	    $html .='<li>';
	    $html .='<select class="print-ajax" id="azull-template">';
	//	$html .='<option selected="selected" value="1">'.__("Select template",'azull').'</option>';
		    //$html .='<option value="1">AZULL(A4)</option>';
		    $html .='<option value="2">AZULL PRINT</option>';
		    $html .='<option value="4">AZULL PDF</option>';
		$html .='</select>';
	    $html .='</li>';
	    
	    $html .='<li>';
	    $html .='<select class="print-ajax" id="azull-language">';
	     $html .='<option selected="selected" value="'.$currentLang.'">'.__("Select languagee","azull").'</option>';	     
		foreach($languages as $lang){
		    $html .='<option value="'.$lang.'" '.(($lang==$currentLang) ?"selected" :"").'>'.qtranxf_getLanguageName($lang).'</option>';
		}
	    
	    $html .='</select>';
	    $html .='</li>';
	    $html .='<li>';
	    $html .='<a  id="azullprint" href="#"><img title="'.__("Print content",'azull').'" alt="image_print" src="'.AZULL_URL.'images/print.png"></a>'; 
	    $html .='</li>';

	$html .='</ul></div>';
	$html .='<div id="print-wrap" class="wrap"><img src="'.AZULL_URL.'images/site.gif">';
	$html .='</div>';
     
     echo $html;
    }
    
    
    
    static function ajax_print_tpl(){
	global $q_config;
	$new_locale =$_POST['lng'];	
        $old_locale = get_locale();
	

	setlocale(LC_ALL, $new_locale);
	$q_config['language'] = substr($new_locale, 0, 2);
	
	$ids=unserialize(base64_decode($_POST['ids'])); //get all selected post ids
	switch ($_POST['tpl']) {
	    case 0:
		require_once( AZULL_DIR . 'template/defaultPrint.php' );
		break;
	    case 1:
		require_once( AZULL_DIR . 'template/printA4.php' );
		break;
	    case 2:
		require_once( AZULL_DIR . 'template/printA5.php' );
		break;
	    case 4:
		require_once( AZULL_DIR . 'template/createpdf.php' );
		break;
	    default:			
	        break;
        }
	setlocale(LC_ALL, $old_locale);
	$q_config['language'] = substr($old_locale, 0, 2);
	$html = $html."<script> jQuery('#azullprint').click(function() {
		jQuery('.template').print();
		return false;
	});</script>";
	die($html);
     
    }

    static function import_csv_page() {
            add_submenu_page(  null, 'CSV', 'CSV', 'manage_options', 'import-csv', array('azull_action','import_csv' )); 
    }
    static function import_csv(){
        
    }
    static function export_csv_page() {
            add_submenu_page(  null, 'CSV', 'CSV', 'manage_options', 'export-csv', array('azull_action','export_csv' )); 
    }
    static function export_csv(){
        
    }
    static function import_xml_page() {
            add_submenu_page(  null, 'xml', 'xml', 'manage_options', 'import-xml', array('azull_action','export_csv' )); 
    }
    static function export_xml_page() {
            add_submenu_page(  null, 'xml', 'xml', 'manage_options', 'export-xml', array('azull_action','export_csv' )); 
    }

    static function export_xml(){
        
    }
    
    static function azull_set_screen($status, $option, $value) {      
      
        if ( 'print' == $option ) { 
		$value = array('l'=>(isset($_POST['print_l'][0])? $_POST['print_l'][0]:''),
			       't'=>(isset($_POST['print_t'][0])? $_POST['print_t'][0]:'')
			       );
	}
	return $value;
    }
    
    static function azull_bulk_admin_notices(){
	global $post_type, $pagenow;        
	if($pagenow == 'edit.php' && isset($_REQUEST['msg'])) {
		global $wpdb;
		if(isset($_REQUEST['msg'])){     

			switch ($_REQUEST['msg']) {
				case 'publish':
					$message = __("Property published successfully",'azull');
					break;
				case 'unpublish':
					$message = __("Property Unpublished successfully",'azull'); 
					break;	
				case 'remove':
					$message = __("Property removed successfully",'azull');
					break;	
				case 'copysite':
					$message = __("Selected Property started to copy on client site",'azull');
					break;		
				case 'removesite':
					$message = __("Selected Property started to remove from client site",'azull');
					break;	
				case 'publishandcopysite':
					$message = __("Selected Property started to publish and copy on client site",'azull');
					break;
				case 'copyproperty':
					$message = __("Selected property(s) started to copy on client site",'azull');
					break;
				case 'copypost':
					$message = __("Selected blog post(s) started to copy on client site",'azull');
					break;
				case 'copypage':
					$message = __("Selected page(s) started to copy on client site",'azull');
					break;
				case 'removeproperty':
					$message = __("Selected property(s) started to remove from client site",'azull');
					break;
				case 'removepost':
					$message = __("Selected blog post(s) started to remove from client site",'azull');
					break;
				case 'removepage':
					$message = __("Selected page(s) started to remove from client site",'azull');
					break;
				case 'publishcopyproperty':
					$message = __("Selected property(s) started to publish and copy on client site",'azull');
					break;
				case 'publishcopypost':
					$message = __("Selected blog post(s) started to publish and copy on client site",'azull');
					break;
				case 'publishcopypage':
					$message = __("Selected page(s) started to publish and copy on client site",'azull');
					break;				
			}//end switch
       	}// end inner if
       	if(isset($message) && $message !='')     
		echo "<div class='updated'><p>{$message}</p></div>";
	}// end if
 }// end function
    
 
}// end class