<?php
/* The class defines all methods to duplicate a property and publish it as draft
 * @package:wordpress
 * @subpackage:azull
 */

 //todo: to include meta data while making copy of property like, finincial data and property fetures.

defined('ABSPATH') or die("No script kiddies please!");

class Clone_Post{
        private static $instance;
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self;
			self::$instance->init();
                                                
		}
		return self::$instance;
	}
	function init() {
	     global $post;
	
	     add_action( 'admin_enqueue_scripts', array($this ,'azull_enqueue_script') );
	     add_filter( 'post_row_actions', array($this ,'azull_row_actions'), 10, 2 );
	     add_action( 'post_submitbox_misc_actions', array($this ,'azull_button') );
             add_action( 'wp_ajax_azull_clone', array('Clone_Post' ,'azull_copy_action') );
	 }
	 function azull_enqueue_script( ) {
		wp_register_script( 'clone-script', AZULL_URL .'js/clone-post.js');
		wp_localize_script( 'clone-script', 'cloneajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
		wp_enqueue_script( 'clone-script' );
	 }

	 /**
	 * Add "Copy" link to Table Row Actions
	 *
	 * @since 1.0
	 * @param  array  $actions  Default Row Actions
	 * @return array  $actions  Modified Row Actions
	 */
	function azull_row_actions( $actions, $post ) {
		// Create Nonce
		
	       if(!in_array(get_post_type( $post ),array('post','page','property')))
		return;
		
		$azull_nonce = wp_create_nonce( 'azull_nonce' );
		$link = '<a href="' . admin_url( "admin-ajax.php?action=azull_clone&nonce=" . $azull_nonce . "&post_id=" . $post->ID ) . '" >' . __( 'Copy', 'azull' ) . '</a>';
		$actions = array_slice( $actions, 0, 2, true ) +
			array( 'azull-copy-post' => $link ) +
			array_slice( $actions, 2, NULL, true );
		return $actions;
	}
	/**
	 * Register Submit Box Field
	 * @since 1.0
	 */
	function azull_button() {
		global $post;
		
	        if(!in_array(get_post_type( $post ),array('post','page','property')))
		return;
		
		$post_id = $post->ID;
		$post_type = get_post_type( $post_id );

		// Create Nonce
		$azull_nonce = wp_create_nonce( 'azull_nonce' );

		// Render Content of the Meta Box
		echo '</div><div class="misc-pub-section misc-pub-section-azull" style="text-align: right;">'; //Yes, this is here on purpose.
		echo '<div id="azull-message" style="display: none; margin-bottom: 5px; padding: 5px 10px; text-align: left;"></div>';
		echo '<a href="#" id="azull-copy-post" class="button-secondary" title="Copy '. $post_type .'" data-nonce="' . $azull_nonce . '" data-post-id="' . $post_id . '">' . __( 'Copy ', 'azull' ).$post_type.'</a>';
	}
	/**
	 * Copy Post Action
	 *
	 * Verifies nonce, checks for capabilities, then copies content from
	 * original post ($old_post) into a new post object.  Then, it inserts the post, and
	 * if it's a page, it copies the Page Template.  Finally, if this
	 * is an ajax request, a response is returned. If not, the page is refreshed.
	 *
	 * @since 1.0
	 */	

	static function azull_copy_action() {

		// Check if this is a GET or POST request (Table List vs Edit Post view)
		if ( isset( $_GET['nonce'] ) && isset( $_GET['post_id'] ) ) {
			$nonce = $_GET['nonce'];
			$post_id = $_GET['post_id'];
		} else {
			$nonce = $_POST['nonce'];
			$post_id = $_POST['post_id'];
		}

		// Verify Nonce
		if ( ! isset( $nonce ) || ! wp_verify_nonce( $nonce, 'azull_nonce' ) )
			return;

		// Check Capabilities
		if ( ! current_user_can( 'edit_post', $post_id ) || ! current_user_can( 'edit_page', $post_id ) )
			return;

		// Get the Old Post
		$old_post = get_post( $post_id );

		/**
		 * If Old Post is unpublished, exit.
		 *
		 * This only applies to copies made from the "Edit Post" screen.
		 * If copied before published, the Post tile says "Autosave"
		 * This doesn't happen when posts are copied from the Table List ("All Posts") view.
		 */
		if ( ! ( "publish" == $old_post->post_status || "draft" == $old_post->post_status ) ) {
			$response['type'] = 'not-published';
			$response['message'] = __( 'Copies can only be made of Published Posts.', 'azull3' );
			echo json_encode( $response );
			die();
		}

		/**
		 * Copy Post Object Values
		 *
		 * Notice times are not copied over to new post to avoid conflicts
		 * Also, the post_status is draft, so users can make adjustments before
		 * publishing.
		 */
		$new_post = array(
			'post_status'    => 'publish',
			//'post_status'    => 'draft',
			'menu_order'     => $old_post->menu_order,
			'post_type'      => $old_post->post_type,
			'comment_status' => $old_post->comment_status,
			'ping_status'    => $old_post->ping_status,
			'pinged'         => $old_post->pinged,
			'post_author'    => $old_post->post_author,
			'post_category'  => $old_post->post_category,
			'post_content'   => $old_post->post_content,
			'post_excerpt'   => $old_post->post_excerpt,
			'post_name'      => $old_post->post_name,
			'post_parent'    => $old_post->post_parent,
			'post_password'  => $old_post->post_password,
			'post_title'     => $old_post->post_title . ' (' . __( 'copy', 'azull' ) . ')',
			'post_type'      => $old_post->post_type,
			'tags_input'     => $old_post->tags_input,
			'to_ping'        => $old_post->to_ping,
			'tax_input'      => $old_post->tax_input,
		);
                //todo: check we need to use_qtranslate() on $old_post->post_title
		
		// Create new Post
		$new_post_id = wp_insert_post( $new_post );

		// Copy Page Template if applicable
		if ( $new_post_id && ( 'page' == $old_post->post_type ) ) {
			$page_template = get_post_meta( $post_id, '_wp_page_template' );
			update_post_meta( $new_post_id, '_wp_page_template', $page_template );
		}

		// Prepare Response
		if ( $new_post_id ) {
			$response['type'] = 'success';
			$response['message'] = __( 'Post successfully copied.', 'azull' );
		} else {
			$response['type'] = 'error';
			$response['message'] = __( 'There was an error copying this post.', 'azull' );
		}

		
		if ( ! empty( $_SERVER['HTTP_X_REQUESTED_WITH'] ) && strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) == 'xmlhttprequest' ) {
			echo json_encode( $response );
			die();
		// If not, redirect to the same page.
		} else {
			header( "Location: ".$_SERVER["HTTP_REFERER"] );
		}
       }
}
