<?php

/* * class to manage clinet website details usiging custom post type
 * @author:Dhananjay Pandey
 * @since:1.0
 * @package:wordpress
 * @subpackage:azull
 */

defined('ABSPATH') or die("No script kiddies please!");

class Class_Site {

    private static $instance;

    public static function instance() {

        if (!isset(self::$instance)) {
            self::$instance = new self;
            self::$instance->init();
        }

        return self::$instance;

    }

    static function init() {

        register_post_type(
                'azull_site', array(
            'labels' => array(
                'name' => __('Websites', 'azull'),
                'singular_name' => __('Websites', 'azull'),
                'add_new' => __('Add Website', 'azull'),
                'add_new_item' => __('Add New Website', 'azull'),
                'edit_item' => __('Edit Website', 'azull'),
                'new_item' => __('New Website', 'azull'),
                'view_item' => __('View Website', 'azull'),
                'search_items' => __('Search Website', 'azull'),
            ),
            'description' => __('Sites in the netowrk', 'azull'),
            'public' => false,
            'show_ui' => true,
            'publicly_queryable' => false,
            'exclude_from_search' => false,
            'menu_position' => 80,
            'menu_icon' => 'dashicons-admin-site',
            'supports' => array('title'),
            'register_meta_box_cb' => array('Class_Site', 'site_metaboxes'),
                )
        );

        add_action('save_post', array('Class_Site', 'save_site_settings'));
    }

    static function site_metaboxes() {

        add_meta_box('sitediv', __(' '), array('Class_Site', 'add_site_settings_metabox'), 'azull_site', 'normal', 'high');

        remove_meta_box('submitdiv', 'azull_site', 'side');
    }

    static function add_site_settings_metabox($post) {

        global $post;

        // nonce for verification when saving
        wp_nonce_field(plugin_basename(__FILE__), 'site_settings_noncename');

        try {
            
            Server_Setting::display_server_settings($post, 'Xmlrpc_Client');

        } catch (Exception $e) {
            die;
        }
    }

    /*
     * Update all site settings like header footer , options , api ids and site related details onclient site.
     * Params : all server post values
     */

    static function save_site_settings() {

  

        ini_set('max_execution_time', -1);
        global $post;

        // autosave verification
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;

        if (get_post_type($post->ID) != 'azull_site')
            return;

        //  if (!current_user_can('manage_options'))
        //   return;
        //Todo:implement encription on key
        
        update_post_meta($post->ID, '_key', crypt($_POST['access']['key'], $post->ID));
        update_post_meta($post->ID, 'access', $_POST['access']);


         /* Code for add/update site page/sidebar order
            Date:- 25-july-2016 De(a.n)
         */
        
        if(isset($_POST['block']) && $_POST['block']!=''){
        
        /* fuction to check unique order Date:- 06-oct-2016 */
            /*function array_has_dupes($array) {
               return count($array) !== count(array_unique($array));
            }*/

        function array_has_dupes($array) {
            if(array_filter($array)) {
               return count(array_filter($array)) !== count(array_unique(array_filter($array)));
            }else{
                return false;
            }
        }
        /* ==== */ 

            $blockType=$_POST['block'];
            $layout=$_POST['layout'];
            $blockTypeLayout=$_POST['block']."_".$layout;
            $getAllBlockorder=array();
            $obj = new azull();

            if($layout=='mobile'){
                $getArrayResult=$obj->get_page_side_array();
            }else{
                $getArrayResult=$obj->getpageArray($blockType);
            }

            foreach ($getArrayResult as $key => $value) {
              if($layout=="mobile"){
                $arrayRes[]=array($key=>array($key.'_dis'=>$_POST[$key.'_dis'],$key.'_order'=>$_POST[$key.'_order'],$key.'_collapse'=>$_POST[$key.'_collapse']));
                $getAllBlockorder[]=$_POST[$key.'_order'];
            }else{
                $arrayRes[]=array($key=>array($key.'_dis'=>$_POST[$key.'_dis'],$key.'_order'=>$_POST[$key.'_order']));
                $getAllBlockorder[]=$_POST[$key.'_order'];
            }
            }

            /*check unique block order*/ 
               $uniqueCount=array_has_dupes($getAllBlockorder);
               //echo $uniqueCount;die;
               if(isset($uniqueCount) && $uniqueCount>0){
                  $url =get_admin_url()."post.php?post='".get_the_ID()."'&action=edit";
                   wp_redirect( $url.'&ord_error=1');
                   exit();
               }
            /*===*/ 

           // echo "<pre>";print_r($arrayRes);die;
            $general = get_post_meta($post->ID,'general',true);
            //echo "<pre>";print_r($general);die('hellelellel');
        
            /* for desktop layout*/
            if($layout == 'desktop'){

                $_POST['general']['main_block_mobile']=$general['main_block_mobile'];
                $_POST['general']['side_block_mobile']=$general['side_block_mobile'];

                    if($blockTypeLayout=='main_block_desktop'){
                        $_POST['general']['main_block_desktop']=$arrayRes;
                        $_POST['general']['side_block_desktop']=$general['side_block_desktop'];
                    }
                    else{
                        $_POST['general']['side_block_desktop']=$arrayRes;
                        $_POST['general']['main_block_desktop']=$general['main_block_desktop'];
                    }
                    $_POST['general']['mobile_block']=$general['mobile_block'];
            }else{
                   $_POST['general']['main_block_desktop']=$general['main_block_desktop'];
                   $_POST['general']['side_block_desktop']=$general['side_block_desktop'];
                   $_POST['general']['mobile_block']=$arrayRes;
                
            }
        }
        //for add/edit email title in different languages
        $emailTitle = (isset($general['email_title']) && !empty($general['email_title']))?$general['email_title']:'';
        if(isset($_POST['email_type']) && !empty($_POST['email_type'])){
            if(isset($_POST['email_title_text']) && !empty($_POST['email_title_text'])){
                $emailTitle[$_POST['email_type']] = $_POST['email_title_text'];
            }
        }
        $_POST['general']['email_title'] = $emailTitle;
        $emailText = (isset($general['email_text']) && !empty($general['email_text']))?$general['email_text']:'';
        if(isset($_POST['email_type']) && !empty($_POST['email_type'])){
            if(isset($_POST['email_text']) && !empty($_POST['email_text'])){
                $emailText[$_POST['email_type']] = $_POST['email_text'];
            }
        }


       //echo "<pre>";
       //print_r($_POST['general']);die;

        $_POST['general']['email_text'] = $emailText;
        //echo '<pee>';print_r($_POST['general']);die;
        update_post_meta($post->ID, 'general', $_POST['general']);
        update_post_meta($post->ID, 'language', $_POST['language']);

        if(!get_post_meta($post->ID, '_created_date', true)){
            update_post_meta($post->ID, '_created_date',date('Y-m-d h:i:s'));
        }
        $obj = new Xmlrpc_Client($post->ID);
        $obj->set_key($post->ID);

        if (isset($_POST['language']))
            $obj->manage_client_option('language', json_encode($_POST['language']), 'siteoptions');

        //die("step2test232");
        // for update qtranslate enabled languages set website active languages as enabled for qtranslate 
        $enable_langs = false;
        if (isset($_POST['language']['a']) && !empty($_POST['language']['a'])) {
            foreach ($_POST['language']['a'] as $key => $value) {
                $enable_langs[] = $value;
            }
        }

        //echo serialize(json_encode($enable_langs));die;
        $serialize_langs = serialize($enable_langs);

        if (isset($_POST['language']['a'])) {
            $obj->manage_client_option('qtranslate_enabled_languages', $serialize_langs, 'siteoptions');
        }
       
        // for update qtranslate default languages, Set website default language to qtranslate default lanugage 
        if (isset($_POST['language']['d'])) {
            $obj->manage_client_option('qtranslate_default_language', $_POST['language']['d'], 'siteoptions');
        }
        
        // for update qtranslate_term_name string on client websites 
        if (get_option('qtranslate_term_name')){
            $obj->manage_client_option('qtranslate_term_name', get_option("qtranslate_term_name"), 'siteoptions');
        }
        
        
//          if (isset($_POST['language']['a'])) {
//            $obj->manage_client_option('azull_enabled_languages', $serialize_langs, 'siteoptions');
//        }
//       
//        // for update qtranslate default languages, Set website default language to qtranslate default lanugage 
//        if (isset($_POST['language']['d'])) {
//            $obj->manage_client_option('azull_default_language', $_POST['language']['d'], 'siteoptions');
//        }


        if (isset($_POST['access']['mailChipKey'])) {
            $obj->manage_client_option('mailChipKey', $_POST['access']['mailChipKey'], 'siteoptions');
        }

        if (isset($_POST['access']['mailListID'])) {
            $obj->manage_client_option('mailListID', $_POST['access']['mailListID'], 'siteoptions');
        }

        if (isset($_POST['general']['logo'])) {
            $att_id = self::get_attachment_id_from_url($_POST['general']['logo']);
            $att_id_remote = get_post_meta($att_id, '_remote_' . $post->ID, true);
            if (!$att_id_remote) {
                $obj->add_attachment($att_id);
                $att_id_remote = get_post_meta($att_id, '_remote_' . $post->ID, true);
            }
            $_POST['general']['logo'] = $att_id_remote;
        }

        if (isset($_POST['general']['favicon'])) {
            $att_id = self::get_attachment_id_from_url($_POST['general']['favicon']);
            $att_id_remote = get_post_meta($att_id, '_remote_' . $post->ID, true);
            if (!$att_id_remote) {
                $obj->add_attachment($att_id);
                $att_id_remote = get_post_meta($att_id, '_remote_' . $post->ID, true);
            }
            $_POST['general']['favicon'] = $att_id_remote;
        }

        if (isset($_POST['general']['remoteCountry'])) {
            $remote_term_id = array();

            if (is_array($_POST['general']['remoteCountry'])) {
                foreach ($_POST['general']['remoteCountry'] as $val) {
                    $term = get_term_by('id', (int) $val, 'country');
                    $remote_term_id[] = $obj->has_taxonomy('country', $term->slug);
                }
                $_POST['general']['country'] = $remote_term_id;
            }
        }

        $carasoleBlocks = json_decode(get_post_meta($post->ID, '_carasoleBlock', true), true);
        $carasoleBlocks_remote = array();
        if (isset($carasoleBlocks)) {
            $carasoleBlocks_remote = $carasoleBlocks;
            foreach ($carasoleBlocks as $k => $carasoleBlock) {
                $term = get_term_by('id', (int) $carasoleBlock['term'], $carasoleBlock['taxonomy']);
                $carasoleBlocks_remote[$k] = array('term' => $obj->has_taxonomy($carasoleBlock['taxonomy'], $term->slug), 'taxonomy' => $carasoleBlock['taxonomy']);
            }
            if (!empty($carasoleBlocks_remote))
                $obj->manage_client_option('_carasoleBlock', json_encode($carasoleBlocks_remote), 'siteoptions');
        }

        if (isset($_POST['general']))
            $obj->manage_client_option('general', json_encode($_POST['general']), 'siteoptions');

        if (isset($_POST['general']['mheader']) && $_POST['general']['mheader'] != ''){
            //$obj->xmlrpc_nav_menu($_POST['general']['mheader'], 'primary');
        }

        if (isset($_POST['general']['mfooter']) && $_POST['general']['mfooter'] != ''){
            //$obj->xmlrpc_nav_menu($_POST['general']['mfooter'], 'footer');
        }

        return;
        //TODO:cod can be further optamized...
    }

// End save_site_settings

    static function add_site_columns($columns) {

        $new_columns['cb'] = '<input type="checkbox" />';
        $new_columns['date'] = __('Date', 'azull');
        $new_columns['website'] = __('Website', 'azull');
        $new_columns['subscribers'] = __('Subscribers', 'azull');
        $new_columns['quick-message'] = __('Quick message', 'azull');
        $new_columns['information-request'] = __('Information request', 'azull');
        $new_columns['bank-repossession'] = __('Bank repossession', 'azull');
        $new_columns['contact-us'] = __('Contact us', 'azull');


        return $new_columns;
    }

    static function site_fill_columns($column) {
        global $post;

        switch ($column) {
            case 'date' :
                echo get_the_date('', $post->ID);
                break;

            case 'website' :
                echo "<a href='" . get_admin_url('', 'post.php?') . "post=" . $post->ID . "&action=edit'>" . get_the_title($post->ID) . "</a>";

                break;
            case 'subscribers' :
                $access = get_post_meta($post->ID, 'access', true);

                if ($access['mailChipKey'] && $access['mailChipKey'] != '')
                    $subscribers = Settings::lists_members(($access['mailChipKey']) ? $access['mailChipKey'] : '', ($access['mailListID'] ) ? $access['mailListID'] : '');

                if ($subscribers['total'])
                    echo " ( " . $subscribers['total'] . " )";
                break;
            case 'quick-message' :

                break;

            case 'information-request' :

                break;
            case 'bank-repossession' :

                break;
            case 'contact-us' :

                break;
        }
    }

    function get_attachment_id_from_url($attachment_url = '') {

        global $wpdb;
        $attachment_id = false;

        // If there is no url, return.
        if ('' == $attachment_url)
            return;

        // Get the upload directory paths
        $upload_dir_paths = wp_upload_dir();
        $attachment_url = str_replace("http://", "https://", $attachment_url);

        // Make sure the upload path base directory exists in the attachment URL, to verify that we're working with a media library image
        if (false !== strpos($attachment_url, $upload_dir_paths['baseurl'])) {

            // If this is the URL of an auto-generated thumbnail, get the URL of the original image
            $attachment_url = preg_replace('/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $attachment_url);

            // Remove the upload path base directory from the attachment URL
            $attachment_url = str_replace($upload_dir_paths['baseurl'] . '/', '', $attachment_url);

            // Finally, run a custom database query to get the attachment ID from the modified attachment URL
            $attachment_id = $wpdb->get_var($wpdb->prepare("SELECT wposts.ID FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta WHERE wposts.ID = wpostmeta.post_id AND wpostmeta.meta_key = '_wp_attached_file' AND wpostmeta.meta_value = '%s' AND wposts.post_type = 'attachment'", $attachment_url));
        }

        return $attachment_id;
    }
    
    /*
    * Date : 31-03-2016
    * Method : Function for add form from client website
    */

   static function ninja_forms_submission() {
      global $post;
      if (isset($_POST['action']) && (($_POST['action'] == 'nf_admin_save_builder') || ($_POST['action'] == 'ninja_forms_new_field'))) {
         if (isset($_POST['form_id']) && $_POST['form_id'] != '') {
            //echo "<pre>";print_r($_POST);exit;
            add_transient_option($_POST['form_id']);
            //get all available website
            foreach (azull::get_sites() as $site) {
               $obj = new Xmlrpc_Client($site);
               $obj->add_ninja_forms($_POST);
            }
            //$obj = new Xmlrpc_Client(7933);
            //$obj->set_key(7933);
            //$obj->add_ninja_forms('ninja_forms', $_POST);
         }
      }
      if (isset($_POST) && $_POST['_tab'] == 'form_settings') {
         if (isset($_POST['_form_id']) && $_POST['_form_id'] != '') {
            //get all available website
            foreach (azull::get_sites() as $site) {
               $obj = new Xmlrpc_Client($site);
               $obj->update_ninja_forms_settings($_POST);
            }
            //$obj = new Xmlrpc_Client(7933);
            //$obj->set_key(7933);
            //$obj->update_ninja_forms_settings('ninja_forms', $_POST);
         }
      }

      return;
   }

   /*
    * Date : 31-03-2016
    * Method : Function for delete form from client website
    */

   static function ninja_forms_delete() {
      global $post;
      if (isset($_POST['action']) && (($_POST['action'] == 'ninja_forms_delete_form'))) {
         if (isset($_POST['form_id']) && $_POST['form_id'] != '') {
            $option_name1 = '_transient_nf_form_' . $_POST['form_id'];
            delete_option($option_name1);
            $option_name2 = '_transient_timeout_nf_form_' . $_POST['form_id'];
            delete_option($option_name2);
            //get all available website
            foreach (azull::get_sites() as $site) {
               $obj = new Xmlrpc_Client($site);
               $obj->delete_ninja_forms($_POST);
            }
         }
      }
      return;
   }

}
