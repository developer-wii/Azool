<?php
/* The class handles the search functionality on property table listing worpress backedn only. * 
 * @package:wordpress
 * @subpackage:azull
 */

defined('ABSPATH') or die("No script kiddies please!");

class Azull_Search{
         
     static function filter_display() {
     /* redirect to proipety list page after edit post
              * Date: 03-june-2016 
           */


    $pType=$_GET['post_type'];
    $url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	if(isset($pType) && $pType =='property'){
    	add_option('redirect_url', $url, '', 'yes' );
        update_option('redirect_url', $url, '', 'yes' );
    } 
     global $typenow; 
         
      if ($typenow=='property') {
	 
	 $html ='';
	 
	 /* Reference Number**/ 
	  $html .='<div class="SumoSelect"><input placeholder="#Ref" style="margin: 0; height: 29px; style="margin-right:0px;" name="pref" type="text" size="16" maxlength="16" value="'.((isset($_GET['pref'])) ? $_GET['pref'] :'').'"/></div>';
	 
	 
	 
	/* Propetitor**/

        /*for condetion for agant role
          Date:- 16/july/2016 deepak (ab)
        */
       global $wpdb;
       $userInfo=get_userdata(get_current_user_id());
        
        $sql = "SELECT * FROM wp_terms where slug='".$userInfo->user_login."'";
        $termId = $wpdb->get_var($sql);
        $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }
        /*if($userRole!='' && $userRole !='administrator'){
                 $display='disabled';
        }*/

	 $parent_terms = get_terms('proprietor', array('orderby' => 'slug', 'hide_empty' => false));     
         if ( !empty( $parent_terms ) && !is_wp_error( $parent_terms) ){ 

               if($userRole!='' && $userRole=='agent'){
                 $display='disabled';
                 $assigned_terms = array($termId);
               }else{
               	   $assigned_terms = array($_GET['proprietor']);
               }

                $html .="<div class='SumoSelect'><select style='width:197px;height:30px;font-size: 13px;font-style: italic;margin-top: 3px;'".$display." id='activate_proprietor' name='proprietor'>"; 
                $html .= "<option value=''>".__('Select proprietor','azull')."</option>";
		$html .= '<option value="" >--</option>';
                //$html .= "<optgroup style='margin: 0 0 0 5px;' label='".__('Agent','azull')."'>";
        $role='';        
		foreach ($parent_terms as $pterm):
                   $taxonomy_meta = get_option('azull_taxonomy_meta_' . $pterm->term_id);
					if($taxonomy_meta['type'] && is_array($taxonomy_meta['type'])){

					    if((in_array(1, $taxonomy_meta["type"])) && (in_array(2, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
					        $role = "B, A, O";
					    }else if((in_array(1, $taxonomy_meta["type"])) && (in_array(2, $taxonomy_meta["type"]))){
					        $role = "A, O";
					    }
					    else if((in_array(2, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
					              $role = "B, O";
					    }
					    else if((in_array(1, $taxonomy_meta["type"])) && (in_array(3, $taxonomy_meta["type"]))){
					              $role = "A, B";
					    }else if(in_array(1, $taxonomy_meta["type"])){
					        $role = "A";
					    }
					    else if(in_array(2, $taxonomy_meta["type"])){
					        $role = "O";
					    }
					    else if(in_array(3, $taxonomy_meta["type"])){
					        $role = "B";
					    }
					 }else{
					     if($taxonomy_meta['type']!='' && $taxonomy_meta['type']==1){
					       $role = "A";
					     }else if($taxonomy_meta['type']!='' && $taxonomy_meta['type']==2){
					       $role = "O";
					     }
					     else if($taxonomy_meta['type']!='' && $taxonomy_meta['type']==3){
					       $role = "B";
					     }
					 }


		   //if($taxonomy_meta['type']==1){
		   $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';

                   $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : ''; 
                   $html .= "<option value='".$pterm->term_id."' data-subtitle='".__('Phone','azull').":" . $phone . "<br/>".__('Email','azull').":" . $email."'  data-left=\"<img src='".z_taxonomy_image_url($term->term_id)."' >\" data-right='<b>".$role."</b>' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id,$assigned_terms)) ? 'selected' : '')." >".qtranxf_use(qtranxf_getLanguage(),$pterm->name)."</option>";
		   		  
		   //}
		endforeach;
		/*$html .= "</optgroup>";
		
		$html .= "<optgroup style='margin: 0 0 0 5px;' label='".__('Owner','azull')."'>";
		foreach ($parent_terms as $pterm):		   
		   $taxonomy_meta = get_option('azull_taxonomy_meta_' . $pterm->term_id);
                  if($taxonomy_meta['type']==2){
		   $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';
                   $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : '';                        
                   $html .= "<option value='".$pterm->term_id."' data-subtitle='".__('Phone','azull').":" . $phone . "<br/>".__('Email','azull').":" . $email."'  data-left=\"<img src='".z_taxonomy_image_url($pterm->term_id)."' >\" data-right='".$pterm->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id,$assigned_terms)) ? 'selected' : '')." >".qtranxf_use(qtranxf_getLanguage(),$pterm->name)."</option>";
		   }
		endforeach;
		$html .= "</optgroup>";
		
		$html .= "<optgroup style='margin: 0 0 0 5px;' label='".__('Builder','azull')."'>";
		foreach ($parent_terms as $pterm):		   
		   $taxonomy_meta = get_option('azull_taxonomy_meta_' . $pterm->term_id);
                  if($taxonomy_meta['type']==3){
		   $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';
                   $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : '';                        
                   $html .= "<option value='".$pterm->term_id."' data-subtitle='".__('Phone','azull').":" . $phone . "<br/>".__('Email','azull').":" . $email."'  data-left=\"<img src='".z_taxonomy_image_url($pterm->term_id)."' >\" data-right='".$pterm->term_id."' ".((is_array($assigned_terms) && !empty($assigned_terms) && in_array($pterm->term_id,$assigned_terms)) ? 'selected' : '')." >".qtranxf_use(qtranxf_getLanguage(),$pterm->name)."</option>";
		   }
		endforeach;*/
		
                $html .= "</select><input value='activate selectator' id='activate_proprietor_click' type='hidden'></div>";
               
         }
	 
	 /* Project Name**/
	   $html .='<div class="SumoSelect"  ><input id="project_name" style="margin:0; height: 29px;" placeholder="'.__('Project Name','azull').'" type="text" name="project_name" size="20" maxlength="30" value="'.((isset($_GET['project_name'])) ? $_GET['project_name'] :'').'"/></div>';
	 
	 
	 /* Propetitor Reference Number**/
	  $html .='<div  class="SumoSelect" ><input placeholder="#P. Ref" style="margin:0; height: 29px;" name="ref" type="text" size="15" maxlength="16" value="'.((isset($_GET['ref'])) ? $_GET['ref'] :'').'"/></div>';
	
	/* Country**/
	/* Region**/
	/* Location**/
	  $countries= get_terms('country', array('orderby' => 'name', 'hide_empty' => false));		
	  $regions=get_terms('region', array('orderby' => 'name', 'hide_empty' => false));
	  $provinces=get_terms('provinces', array('orderby' => 'name', 'hide_empty' => false));
	  $places=get_terms('place', array('orderby' => 'name', 'hide_empty' => false));
	 /*$countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));		
	  $regions=get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
	  $provinces=get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));
	  $places=get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));*/
	  if ( !empty($countries) && !is_wp_error( $countries ) ){
	       $azull = get_option('azullsettings',false);
	      
	       $c=(isset($azull['c'])) ? $azull['c']:'';	       
	       $html .="<select class='SlectCountry SlectBox' style='width:140px;' id='property_country'  name='country'>";                                       
	       $html .= "<option value='' disabled selected>".__('Select country','azull')."</option>";
	       $html .= "<option value='' >--</option>";
		    foreach ($countries as $countrie):					
		         $cflag =(isset($_GET['country']))? $_GET['country']:$c;
			 $html .= "<option value='".$countrie->term_id."' ".((isset($cflag) && $cflag!='' && $cflag==$countrie->term_id)? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";
		     endforeach;					
		    $html .="</select>";
	       }else{
		    $html .="<select id='property_country' class='SlectCountry SlectBox' name='country'>";
                    $html .= '<option disabled selected>'.__( 'Select country', 'azull' ).'</option>';
		    $html .="</select>";
	  }
	  
	  if ( !empty( $regions ) && !is_wp_error( $regions ) ){
	       $assigned_terms = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
	       $html .="<select  style='width: 180px;' id='property_region'  class='SlectRegion SlectBox' name='region'>";                                        
		    $html .= "<option value='' disabled selected>".__('Select region','azull')."</option>";
		    $html .= "<option value='' >--</option>";
		    foreach ($regions as $region):					
			 $taxonomy_meta = get_option('azull_taxonomy_meta_'.$region->term_id);
			 $rflag =(isset($_GET['region']))? $_GET['region']:'';					
			 if($cflag!='' && $taxonomy_meta['country']==$cflag ){						
			      $html .= "<option value='".$region->term_id."' ".((isset($_GET['region']) && $_GET['region']==$region->term_id)? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";
			 }elseif($cflag==''){	
			      $html .= "<option value='".$region->term_id."' ".((isset($_GET['region']) && $_GET['region']==$region->term_id)? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";  
			 }
		    endforeach;
		    $html .="</select>";
	  }else{
		    $html .="<select style='width: 120px;' class='SlectRegion SlectBox'  id='property_region' class='SlectRegion' name='region'>";
                    $html .= "<option value='' disabled selected>Select region</option>";
		    $html .="</select>";
	  }
	  
	  /*if ( !empty( $provinces ) && !is_wp_error( $provinces ) ){
	       $html .="<select id='property_meta_province' style='width:150px;margin-top: 2px;'  class='SlectProvince' name='province'>";                                       
	       $html .= "<option disabled selected>Select province</option>";
	       $assigned_terms = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
					
	       foreach ($provinces as $province):
		    $taxonomy_meta = get_option('azull_taxonomy_meta_'.$province->term_id);
		    $pflag =(!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? $province->term_id:'';
					
			 if($cflag !='' && $rflag!='' && $taxonomy_meta['country']==$cflag && $taxonomy_meta['region']==$rflag ){
			      $html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
			 }elseif($cflag!='' && $taxonomy_meta['country']==$cflag){
			      $html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
			 }elseif($rflag!='' && $taxonomy_meta['region']==$rflag){
						$html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
			 }elseif($cflag=='' && $rflag==''){
			      $html .= "<option value='".$province->term_id."' ".((!empty($assigned_terms) && in_array($province->term_id,$assigned_terms))? 'selected':'').">".qtranxf_use(qtranxf_getLanguage(),$province->name)."</option>";
			 }					
	       endforeach;
		    $html .="</select>";
	       }else{
		    $html .="<select style='width:150px;height:30px;margin-top: 2px;' class='SlectProvince' id='property_meta_province' name='province'>";
                    $html .= "<option value='' disabled selected>Select province</option>";
		    $html .="</select>";
	       }*/
	       
	  if ( !empty( $places) && !is_wp_error( $places ) ){
	       $html .="<select  style='width: 200px;' class='SlectPlace SlectBox' id='property_meta_place' name='place'>";
	       //$assigned_terms = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
	       $html .= "<option disabled selected>".__('Select place','azull')."</option>";
	       $html .= "<option value='' >--</option>";
	       $assigned_terms = wp_get_post_terms($post->ID, 'place', array("fields" => "ids"));
	       foreach ($places as $place):
	            $taxonomy_meta = get_option('azull_taxonomy_meta_'.$place->term_id);
		   
		    if($cflag!='' && $rflag!='' && $taxonomy_meta['country']==$cflag && $taxonomy_meta['region']==$rflag){			 
			  $html .= "<option value='".$place->term_id."' ".((isset($_GET['place']) && $_GET['place']==$place->term_id)? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$place->name)."</option>";
		    }elseif($cflag!='' && $taxonomy_meta['country']==$cflag ){
			 $html .= "<option value='".$place->term_id."' ".((isset($_GET['place']) && $_GET['place']==$place->term_id)? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$place->name)."</option>";
		    }else{
			  $html .= "<option value='".$place->term_id."' ".((isset($_GET['place']) && $_GET['place']==$place->term_id)? 'selected':'')." >".qtranxf_use(qtranxf_getLanguage(),$place->name)."</option>";
		    }				
					
	       endforeach;
		    $html .="</select>";
		    
	       }else{
		    $html .="<select  style='width:120px;' class='SlectPlace SlectBox' id='property_meta_place' name='place'>";
                    $html .= "<option disabled selected>Select place</option>";
		    $html .="</select>";
	       } 
	 
	/* Category**/
	 $terms  = get_terms( 'category', 'orderby=slug&hide_empty=0&order=ASC' );
	 
	 if ( !empty( $terms ) && !is_wp_error( $terms ) ){	      
		  $html .='<select style="width:145px;" class="Slectcat SlectBox" id="cat" name="cat">';
		  $html .= '<option value="" disabled selected>'.__("Select category",'azull').'</option>';
		  $html .= '<option value="" >--</option>';

		    foreach ( $terms as $term ) {

		    	//print_r($term);

			 $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
		          if(isset($taxonomy_meta['type']) && $taxonomy_meta['type']=='property')
			  $html .= "<option value='".$term->term_id."' ".((isset($_GET['cat']) && $term->term_id==$_GET['cat']) ? 'selected="selected"' :'' )." >".$term->slug."</option>";
		     }
		  $html .='</select>';	         
	 }
	/* Type**/
	    $html .='<select style="width: 120px;" name="buildtype" class="Slectbuildtype SlectBox">';
            $html .= '<option value="" disabled selected>'.__( 'Build Type', 'azull' ).'</option>';
	     $html .= '<option value="" >--</option>';
            $html .= '<option value="1" '.((isset($_GET['buildtype']) && $_GET['buildtype']==1) ? 'selected="selected"' :'' ).'>'.__('New','azull').'</option>';
            $html .= '<option value="2" '.((isset($_GET['buildtype']) && $_GET['buildtype']==2) ? 'selected="selected"' :'' ).'>'.__('Resale','azull').'</option>';
          $html .='</select>';
	/* FROM - TO**/
	 $html .='<div class="SumoSelect"  ><input id="min_fromPrice" style="margin:0; height: 29px;" placeholder="'.__('From sales price','azull').'" type="text" name="fromPrice" size="20" maxlength="30" value="'.((isset($_GET['fromPrice'])) ? $_GET['fromPrice'] :'').'"/>-<input id="max_toPrice" style="margin-top: 3px; height: 28px;" placeholder="'.__('To sales price','azull').'" type="text" name="toPrice" size="20" maxlength="30" value="'.((isset($_GET['toPrice'])) ? $_GET['toPrice'] :'').'"/> </div>';
	/* Bedroom**/
	 $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' ); 

         if ( !empty( $terms ) && !is_wp_error( $terms ) ){         
	   		$taxonomy_meta['type']=1;
              foreach ( $terms as $term ) {
	        $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
	            if($taxonomy_meta['type']==2 && $taxonomy_meta['search']==1)
		    $html .='<div class="SumoSelect"><input placeholder="'.qtranxf_use(qtranxf_getLanguage(),$term->name).'" style="margin:0; height: 29px;" name="_feature_'.$term->term_id.'" type="text" size="12" maxlength="2" value="'.((isset($_GET['_feature_'.$term->term_id])) ? $_GET['_feature_'.$term->term_id] :'').'"/></div>';
               }
         }
	/* Pethhouse**/	 	 
	    $html .='<select style="width:115px;margin-right: 0px;" name="penthouse" class="Slectpenthouse SlectBox">';
            $html .= '<option value="" disabled selected>'.__( 'Penthouse', 'azull' ).'</option>';
	     $html .= '<option value="" >--</option>';
           
            $html .= '<option value="0" '.((isset($_GET['penthouse']) && $_GET['penthouse']==0) ? 'selected="selected"' :'' ).'>'.__('No','azull').'</option>';
	     $html .= '<option value="1" '.((isset($_GET['penthouse']) && $_GET['penthouse']==1) ? 'selected="selected"' :'' ).'>'.__('Yes','azull').'</option>';
          $html .='</select>';
    /*****Bank*****/    
      $html .='<select style="margin-right: 0;width: 96px;" name="bank" class="SlectBank SlectBox">';
            $html .= '<option value="" disabled selected>'.__( 'Bank', 'azull' ).'</option>';
	     $html .= '<option value="" >--</option>';
            
            $html .= '<option value="0" '.((isset($_GET['bank']) && $_GET['bank']==0) ? 'selected="selected"' :'' ).'>'.__('No','azull').'</option>';
	    $html .= '<option value="1" '.((isset($_GET['bank']) && $_GET['bank']==1) ? 'selected="selected"' :'' ).'>'.__('Yes','azull').'</option>';
          $html .='</select>';    
    /*****Status*****/    
     $terms  = get_terms( 'status', 'orderby=id&hide_empty=0' );    
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                
            $html .='<select style=" width: 190px;" class="Selectfin SlectBox" name="status[]">';
            $html .= '<option value="" disabled selected>'.__("Financial status","azull").'</option>';
	    $html .= '<option value="" >--</option>';
              foreach ( $terms as $term ) {               
                    $html .= "<option value='".$term->term_id."' ".((isset($_GET['status']) && in_array($term->term_id,$_GET['status'])) ? 'selected="selected"' :'' )." >".$term->slug."</option>";
               }
            $html .='</select>';
                
         }  
    /****View******/      
    	 $terms  = get_terms( 'view', 'orderby=slug&hide_empty=0&order=ASC' );
	
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){                
            $html .='<select style="width:106px;" class="selecView SlectBox" name="view[]" multiple>';
            $html .= '<option value="" disabled selected>'.__("Select view","azull").'</option>';	    
              foreach ( $terms as $term ) {	            
			 $html .= "<option value='".$term->term_id."'  ".((isset($_GET['view']) && in_array($term->term_id,$_GET['view'])) ? 'selected="selected"' :'' )." >".$term->slug."</option>";
               }
            $html .='</select>'; 
         }
    /**** Features******/    
     $terms  = get_terms( 'feature', 'orderby=slug&hide_empty=0&order=ASC' );    
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                
            $html .='<select style="width:150px;" class="selecFeatre SlectBox" name="features[]" multiple>';
            $html .= '<option value="" disabled selected multiple>'.__( 'Select features', 'azull' ).'</option>';
	    $taxonomy_meta['type']=1;
              foreach ( $terms as $term ) {
	       $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
	            if($taxonomy_meta['type']!=2 )
                    $html .= "<option value='".$term->term_id."' ".((isset($_GET['features']) && in_array($term->term_id,$_GET['features'])) ? 'selected="selected"' :'' )." >".$term->slug."</option>";
               }
            $html .='</select>';
             
         }  
    /****Exterior******/   
       $terms  = get_terms( 'exterior', 'orderby=slug&hide_empty=0&order=ASC' );    
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                
            $html .='<select style="width:165px;" name="exteriors[]" class="selecExtr SlectBox" multiple>';
            $html .= '<option value="" disabled selected>'.__( 'Select exteriors', 'azull' ).'</option>';
              foreach ( $terms as $term ) {               
                    $html .= "<option value='".$term->term_id."' ".((isset($_GET['exteriors']) && in_array($term->term_id,$_GET['exteriors'])) ? 'selected="selected"' :'' )." >".$term->slug."</option>";
               }
            $html .='</select>';                
         }	  
	   /****Interior******/      
	 $terms  = get_terms( 'interior', 'orderby=slug&hide_empty=0&order=ASC' );	 
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                
            $html .='<select style="width:164px;" name="interiors[]" class="selecIntr SlectBox" multiple>';
            $html .= '<option value="" disabled selected>'.__( 'Select interiors', 'azull' ).'</option>';
              foreach ( $terms as $term ) {               
                    $html .= "<option value='".$term->term_id."' ".((isset($_GET['interiors']) && in_array($term->term_id,$_GET['interiors'])) ? 'selected="selected"' :'' )." >".$term->slug."</option>";
               }
            $html .='</select>';                
         }
	 
	   
    // $html .='<div class="SumoSelect"><input style="margin:0; height: 29px;" placeholder="'.__('Build year','azull').'" type="text" name="year" size="15" maxlength="9" value="'.((isset($_GET['year'])) ? $_GET['year'] :'').'"/></div>';
   
    /****Year build******/      
     $html .='<div class="SumoSelect"><input style="margin:0; height: 29px;" placeholder="'.__('Build year','azull').'" type="text" name="year" size="15" maxlength="9" value="'.((isset($_GET['year'])) ? $_GET['year'] :'').'"/></div>';
         /****Date published******/      
        $html .='<div class="SumoSelect"><input style="margin:0; height: 29px;" placeholder="'.__('Publish date','azull').'" type="text" name="datemin" size="17" maxlength="11" value="'.((isset($_GET['date'])) ? $_GET['date'] :'').'"/></div>';
         
		$html .='<input type="hidden" id="azullaction" name="azullaction" value="">';
		

    /**** Website******/ 

     global $wpdb;
     $datas=$wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
	 if(isset($datas) && !empty($datas)):
         $html .= '<select  style="width:184px;" class="selectwebsites SlectBox" name="websites">';
	 $html .= '<option value="" disabled selected>'.__("Select site",'azull').'</option>';
	 $html .= '<option value="" >--</option>';
	 foreach ($datas as $data){
	       $html .= "<option value='".$data->ID."' ".((isset($_GET['websites']) && $data->ID==$_GET['websites']) ? 'selected="selected"' :'' ).">".qtranxf_use(qtranxf_getLanguage(),$data->post_title)."</option>";
	  }
	 $html .= "</select>";
	 endif;

	/**** Check property ******/    
	
	$all_meta_for_user = get_user_meta(get_current_user_id());	
	$xmldisplayVal=$all_meta_for_user['xml_property'][0];  
	$disabled=''; 
	if(isset($xmldisplayVal) && $xmldisplayVal=='no'){
		$disabled="disabled";
	}   
    $prpArray = array('manual'=>'Manual property','xml'=>'Xml property');
    $html .='<select '.$disabled. ' style="width:168px;" class="propertytype SlectBox" name="property_type">';
    $html .= '<option value="" selected disabled>'.__("Property type",'azull').'</option>';	
    $html .= '<option value="" >--</option>';
       foreach ($prpArray as $key=> $pval) {
       $html .= "<option value=".$key." ".(isset($_GET['property_type']) && $_GET['property_type']==$key ?'selected="selected"' :'')."> ".$pval."</option>";
       }
    $html .='</select>';          
         

	 $terms = get_terms('agent', array('parent' => 0, 'orderby' => 'slug', 'hide_empty' => false));
	 if ( !empty( $terms ) && !is_wp_error( $terms ) ){
	        $html .="<div class='SumoSelect'><select id='activate_agent' name='agent'>";
                    foreach ($terms as $term):
                        $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
                        $phone = (isset($taxonomy_meta['phone'])) ? $taxonomy_meta['phone'] : '';
                        $email = (isset($taxonomy_meta['email'])) ? $taxonomy_meta['email'] : '';                        
                        $html .= "<option value='".$term->term_id."' data-subtitle='Phone :". $phone . "<br/>Email:" . $email."'  data-left=\"<img src='".z_taxonomy_image_url($term->term_id)."\" data-right='".$term->term_id."' ".((isset($val["agent"]) && $term->term_id == $val["agent"]) ? "selected" : "")." >".$term->name."</option>";
                    endforeach;
                    $html .= "<input value='activate selectator' id='activate_agent_click' type='hidden'></div>";
	 }
	  	$html .='<p style="bottom: -38px;left: 0;position: absolute;">* '.__('you can enter range for build year and publish date. both values should be sperated by','azull').' "-".</p>';
		$html .='<style> #post-query-submit{background: none repeat scroll 0 0 hsl(196, 63%, 49%);
		border-color: hsl(197, 100%, 32%);
		box-shadow: 0 1px 0 hsla(196, 69%, 69%, 0.5) inset, 0 1px 0 hsla(0, 0%, 0%, 0.15);
		color: hsl(0, 0%, 100%);margin: 5px 0 0 3px;
		text-decoration: none;}
		#post-query-reset{background: none repeat scroll 0 0 hsl(196, 63%, 49%); clear:both;
		border-color: hsl(197, 100%, 32%);
		float:left;
		box-shadow: 0 1px 0 hsla(196, 69%, 69%, 0.5) inset, 0 1px 0 hsla(0, 0%, 0%, 0.15);
		color: hsl(0, 0%, 100%);margin: 5px 0 0 3px;
		padding: 0px 12px 0px 13px;
		text-decoration: none;}
		.tablenav .actions{position:relative;padding:5px 0}
		.SumoSelect > input {
			font-size:13px !important;  
			font-style:italic !important;
			color:#23282d !important;
			 
		}
		#selectator_activate_proprietor{
			height: 28px !important;
			font-style:italic; 
		}
		</style>'; 
		//$html .= '<a id="post-query-reset" class="button" href="'.get_site_url().'/wp-admin/edit.php?post_type=property&post_status=publish&orderby=property_ref&order=desc">Reset</a>';
		$html .= '<a id="post-query-reset"  class="button" >Reset</a>';
		 echo $html;
/*echo "<div style='padding:10px;float:right'>
       <form>  
         <input type='text' id='searchfiels' name='searchfiels' placeholder='#Ref'>"
         . "<a class='button' href='javascript:void(0)' id='btnFocusDiv'>Goto</a>
         <input type='submit' value='Goto'>
         </div>
         </from>";  
     }*/

/*$searchfield=(isset($_GET["searchfield"]) && $_GET["searchfield"]!='')? $_GET["searchfield"] :'';
 echo "<div style='padding:10px;float:right'>
       <form method='method='get'>  
         <input type='text' value='".$searchfield."' id='searchfield' name='searchfield' placeholder='#Ref'>"
         . "
         <input class='button' type='submit' value='Goto'>
         </div>
         </from>"; */ 
     }    



     
     if ($typenow=='post') {
	     $html ='';
	     global $wpdb;
         $datas=$wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");

	 if(isset($datas) && !empty($datas)):
			$html .= '<select style="width:184px;" class="SlectBox" name="websites">';
			$html .= '<option value="" disabled selected> Website </option>';
			foreach ($datas as $data){
				$html .= "<option value='".$data->ID."' >".qtranxf_use(qtranxf_getLanguage(),$data->post_title)."</option>";
			}

			$html .= "</select>";
	 endif;
	 
	 $terms  = get_terms( 'category', 'orderby=name&hide_empty=0&order=ASC' );
	 
	 if ( !empty( $terms ) && !is_wp_error( $terms ) ){	      
		  $html .='<select style="width:156px;" class="SlectBox" name="cat">';
		  $html .= '<option value="" disabled selected>'.__("Select category","azull").'</option>';
		  $html .= '<option value="" >--</option>';
		    foreach ( $terms as $term ) {
			 $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
		          if(isset($taxonomy_meta['type']) && $taxonomy_meta['type']=='post')
			  $html .= "<option value='".$term->term_id."' ".((isset($_GET['cat']) && $term->term_id==$_GET['cat']) ? 'selected="selected"' :'' )." >".qtranxf_use(qtranxf_getLanguage(),$term->name)."</option>";
		     }
		  $html .='</select>';	         
	 }

	 $html .='<input type="hidden" id="azullaction" name="azullaction" value="">';
	 echo $html;
     }
     
     if ($typenow!='post' && $typenow!='property' && $typenow!='xml' && $_SERVER['SCRIPT_NAME']!='/wp-admin/upload.php') {	 
	 $html ='';
         global $wpdb;
         $datas=$wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
	 if(isset($datas) && !empty($datas)):
         $html .= '<select style="width:184px;" class="SlectBox" name="websites">';
	 $html .= '<option value="" disabled selected>'.__("Select  website","Select  website").'</option>';
	  $html .= '<option value="" >--</option>';
	 foreach ($datas as $data){
	      
	       $html .= "<option value='".$data->ID."' ".((isset($_GET['websites']) && $data->ID==$_GET['websites']) ? 'selected="selected"' :'' ).">".qtranxf_use(qtranxf_getLanguage(),$data->post_title)."</option>";
	  }
	 $html .= "</select>";
	 endif;	 
	 
	 echo $html;
     }
	 
     }



     
     static function filter_query($query){
      
      $taxquery = array();
	  $taxquery_pre = array();
	  $metaquery = array();
	  $metaquery_pre = array();		
	  $metaquery_pre_ext = array();  
	 
         $userRole='';
         $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }
         
         if(isset($_GET['cat']) && $_GET['cat']!='' && $_GET['cat']!=0 && $_GET['post_type']=="property"){
		  
		  	$taxquery_pre[] = array(
			'taxonomy' => 'category',
			'field' => 'term_id',
			'terms' => $_GET['cat'],
			'operator' => 'IN'
			);
	    }

	    
	  if(isset($_GET['view']) && $_GET['view']!=''){
		  
		  	$taxquery_pre[] = array(
			'taxonomy' => 'view',
			'field' => 'term_id',
			'terms' => $_GET['view'],
			'operator' => 'AND'
			);
	  }	
	  
	  if(isset($_GET['type']) && $_GET['type']!=''){
		  
		  	$taxquery_pre[] = array(
			'taxonomy' => 'type',
			'field' => 'term_id',
			'terms' => $_GET['type'],
			'operator' => 'AND'
			);
	  }	     
	  if(isset($_GET['features']) && $_GET['features']!=''){
		  
		  	$taxquery_pre[] = array(
			'taxonomy' => 'feature',
			'field' => 'term_id',
			'terms' => $_GET['features'],
			'operator' => 'AND'
			);
	  }	     
	  if(isset($_GET['exteriors']) && $_GET['exteriors']!=''){
		  
		  	$taxquery_pre[] = array(
			'taxonomy' => 'exterior',
			'field' => 'term_id',
			'terms' => $_GET['exteriors'],
			'operator' => 'AND'
			);
	  }	     
	  if(isset($_GET['interiors']) && $_GET['interiors']!=''){
		  
		  	$taxquery_pre[] = array(
			'taxonomy' => 'interior',
			'field' => 'term_id',
			'terms' => $_GET['interiors'],
			'operator' => 'AND'
			);
	  }             
          if(isset($_GET['status']) && $_GET['status']!=''){
		  
		  	$taxquery_pre[] = array(
			'taxonomy' => 'status',
			'field' => 'term_id',
			'terms' => $_GET['status'],
			'operator' => 'AND'
			);
	  }	 
	  if(!empty($taxquery_pre)){
               $taxquery= array( 'relation' => 'AND' );
               foreach ( $taxquery_pre as $key => $value ) {
                   $taxquery[] =  $value;
               }
	  }
          if(isset($_GET['yearmin']) && isset($_GET['yearmax']) && $_GET['yearmin']!='' && $_GET['yearmax']!=''){ 
               $metaquery_pre[] = array( 
                                'key' => '_year', 
                                'value' => array($_GET['yearmin'],$_GET['yearmax']) ,
                                'compare' => 'BETWEEN'
                              );
          }		  
          if(isset($_GET['yearmin']) && isset($_GET['-']) && $_GET['yearmin']=='' && $_GET['yearmax']!=''){
               $metaquery_pre[] = array( 
                                'key' => '_year', 
                                'value' => $_GET['yearmax'],
                                'compare' => '='
                            );
          }	  
		  
          if(isset($_GET['yearmin']) && isset($_GET['yearmax']) && $_GET['yearmin']!='' && $_GET['yearmax']==''){ 
           
               $metaquery_pre[] = array( 
                                'key' => '_year', 
                                'value' => $_GET['yearmin'],
                                'compare' => '='
                            );
          }         
          
          if(isset($_GET['penthouse']) && $_GET['penthouse'] !=''){ 
           
               $metaquery_pre[] = array( 
                                'key' => '_penthouse', 
                                'value' => $_GET['penthouse'],
                                'compare' => '='
                            );
          }          
          if(isset($_GET['bank']) && $_GET['bank']!=''){ 
           
               $metaquery_pre[] = array( 
                                'key' => '_bank', 
                                'value' => $_GET['bank'],
                                'compare' => '='
                            );
          }         
	  
	  if(isset($_GET['websites']) && $_GET['websites']!=''){
	               
		  	$metaquery_pre[] = array( 
                                'key' => '_ext_'.(integer)$_GET['websites'], 
                                'value' => "",
                                'compare' => '!=' 
                            );
	  }        
        	  
          if(isset($_GET['fromPrice']) && isset($_GET['toPrice']) && $_GET['fromPrice']!='' && $_GET['toPrice']!=''){ 
           
               $metaquery_pre[] = array( 
                                 'key' => '_salesPrice', 
                                 'value' => array($_GET['fromPrice'],$_GET['toPrice']) ,
                                 'compare' => 'BETWEEN',
				 'type' => 'numeric'
                             );
          }		  
          if(isset($_GET['fromPrice']) && isset($_GET['toPrice']) && $_GET['fromPrice']=='' && $_GET['toPrice']!=''){ 
           
               $metaquery_pre[] = array( 
                            'key' => '_salesPrice', 
                            'value' => $_GET['toPrice'],
                            'compare' => '<=',
			    'type' => 'numeric'
                        );
          }		  
          if(isset($_GET['fromPrice']) && isset($_GET['toPrice']) && $_GET['fromPrice']!='' && $_GET['toPrice']==''){
                   
           $metaquery_pre[] = array( 
                            'key' => '_salesPrice', 
                            'value' => $_GET['fromPrice'],
                            'compare' => '='
                        );
          }
		  
         /* if(isset($_GET['country'])  && $_GET['country']!=''){			   
          $metaquery_pre[] = array( 
                            'key' => '_country', 
                            'value' => $_GET['country'],
                            'compare' => '>=',
			    'type' => 'numeric'
                        );
          }    */      
          if(isset($_GET['buildtype'])  && $_GET['buildtype']!=''){			   
          $metaquery_pre[] = array( 
                            'key' => '_buildType', 
                            'value' => $_GET['buildtype'],
                            'compare' => '='
                        );
          }          
       if(isset($_GET['proprietor'])  && $_GET['proprietor']!=''){	       
          $metaquery_pre[] = array( 
                            'key' => '_proprietor', 
                            'value' => $_GET['proprietor'],
                            'compare' => '='
                         );
          }         
          if(isset($_GET['agent'])  && $_GET['agent']!=''){			   
          $metaquery_pre[] = array( 
                            'key' => '_agent', 
                            'value' => $_GET['agent'],
                            'compare' => '='
                        );
          }         
		  
                    
		  if(isset($_GET['pref']) && $_GET['pref']!=''){	   
	              $metaquery_pre[] = array( 
	                                'key' => '_nreal_id', 
	                                'value' => $_GET['pref'],
	                                'compare' => '=',
					'type' => 'numeric' 
	                            );
		      
	          }

       /*if(isset($_GET['searchfield']) && $_GET['searchfield']!=''){	   
              $metaquery_pre[] = array( 
                                'key' => '_nreal_id', 
                                'value' => $_GET['searchfield'],
                                'compare' => 'like',
				'type' => 'numeric' 
                            );
	      
          } */  
	  
         if(isset($_GET['_feature_37']) && $_GET['_feature_37']!=''){	   
              $metaquery_pre[] = array( 
                                'key' => '_feature_37', 
                                'value' => $_GET['_feature_37'],
                                'compare' => '=',
				'type' => 'numeric'
                            ); 
	      
          }
             
	  if(isset($_GET['ref']) && $_GET['ref']!=''){	    
              $metaquery_pre[] = array( 
                                'key' => '_proprietorRef', 
                                'value' => $_GET['ref'],
                                'compare' => '=',
			        'type' => 'varchar'
                            );
	      
	       //Note:if we dont have importd nreal_id we assising post id to it, so search works form old property id and new property id as well
          }
	  
	  if(isset($_GET['region'])  && $_GET['region']!=''){			   
          $metaquery_pre[] = array( 
                            'key' => '_region', 
                            'value' => $_GET['region'],
                            'compare' => '='
                        );
          }
	  if(isset($_GET['place'])  && $_GET['place']!=''){			   
               $metaquery_pre[] = array( 
                                 'key' => '_place', 
                                 'value' => $_GET['place'],
                                 'compare' => '='
                             );
          }
	  /* This is use for display project name
	   * Date:- 07-july-2016
	  */
	  if(isset($_GET['project_name'])  && $_GET['project_name']!=''){			   
               $metaquery_pre[] = array( 
                                 'key' => '_propertyName', 
                                 'value' => $_GET['project_name'],
                                 'compare' => 'like'
                             );
          }
	  
	  /*if(isset($userRole) && $userRole !='' && $userRole =='agent'){
	       global $wpdb;
	       
               if($_GET['post'] == '' && !isset($_GET['post'])){

               $userInfo=get_userdata(get_current_user_id());
               $sql = "SELECT * FROM wp_terms where slug='".$userInfo->user_login."'";
               $termId = $wpdb->get_var($sql);
               $metaquery_pre[] = array( 
                                'key' =>'_proprietor', 
                                'value' => $termId,
                                'compare' => '=',
				'type' => 'numeric',
				'operator' => 'AND'
                         );
	        }
        }*/
	  



/*  This is use for display xml and other property
    Date:- 21-sep-2016
*/
if(isset($_GET['property_type'])  && $_GET['property_type']!=''){
	     	//echo $_GET['property_type'];die;
	     	if($_GET['property_type']=='xml'){
                $metaquery_pre[] = array( 
                                'key' =>'_xmlref', 
                                'value' => "",
                                'compare' => '!='
                               
                            );

	     	}else{
	     		$metaquery_pre[] = array( 
		                                'key' =>'_xmlref', 
		                                'compare' => 'NOT EXISTS'
		                               
		                            ); 
	     	}
}

	     if(isset($_GET['property_type'])  && $_GET['property_type']!=''){
	    if($_GET['property_type']=='manual'){
	     		 $metaquery_pre[] = array( 
                                'key' =>'_azullinfo_import', 
                                'value' => 1,
                                'compare' => '=',
                                'type' => 'numeric'
				                
                               
                            );

	     	}
	     }


	  /* This is use for display only xml import role on propertec listing
	   * Date:- 27-june-2016
	  */
	     if(isset($userRole) && $userRole!='' && $userRole =='ie' ){
              $metaquery_pre[] = array( 
                                'key' =>'_xmlref', 
                                'value' => "",
                                'compare' => '!='
                               
                            );
          }


      if(isset($userRole) && $userRole!='' && $userRole!='administrator'){
		    $all_meta_for_user = get_user_meta(get_current_user_id());	
		    $xmldisplayVal=$all_meta_for_user['xml_property'][0];

		    /*if(isset($xmldisplayVal) && $xmldisplayVal=='yes' && $_GET['post_type']=='property'){
		              $metaquery_pre[] = array( 
		                                'key' =>'_xmlref', 
		                                'value' => "",
		                                'compare' => '!='
		                               
		                            );
            }*/
            if(isset($xmldisplayVal) && $xmldisplayVal=='no' && $_GET['post_type']=='property'){
                $metaquery_pre[] = array( 
		                                'key' =>'_xmlref', 
		                                'compare' => 'NOT EXISTS'
		                               
		                            ); 
            }
            /* condition for display property according to websites*/
            $websitePropertyval = get_user_meta(get_current_user_id(), 'website_property', true);

          if(isset($userRole) && $userRole!='' && $userRole!='office'){
          	 if(isset($websitePropertyval) && !empty($websitePropertyval)){

	                foreach ($websitePropertyval as $siteId) {
		                $metaquery_pre_ext[] = array( 
					                    'key' => '_ext_'.(integer)$siteId,
					                    'value' => "",
					                    'compare' => '!='
					                );
	                } 
              
            }
          }
            
                
    }

    //print_r($metaquery_pre);die;



	  
         $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){
         
              $taxonomy_meta['type']=1;
              foreach ( $terms as $term ) {
	       $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
	            if($taxonomy_meta['type']==2 && $taxonomy_meta['search']==1){
			 if(isset($_GET[$term->slug])  && $_GET[$term->slug]!=''){			   
			      $metaquery_pre[] = array( 
						'key' => '_'.$term->slug, 
						'value' => $_GET[$term->slug],
						'compare' => '='
					    );
			 }
		    }
		    
               }
          } 

        if(!empty($metaquery_pre_ext) && count($metaquery_pre_ext) >=1 && $_GET['post_type']=='property'){
			     $meta_query = array( 'relation' => 'OR' );
			     foreach ( $metaquery_pre_ext as $key => $value ) {
			            $meta_query[] =  $value;
			        }                 
			}
		/*condition for use "OR" in metaquery */
		if(!empty($metaquery_pre_ext) && count($metaquery_pre_ext) ==1 && $_GET['post_type']=='property'){
			     foreach ( $metaquery_pre_ext as $key => $value ) {
			            $meta_query[] =  $value;
			        }                 
			}
        if(!empty($metaquery_pre) && count($metaquery_pre) >=1){
                 $meta_query = array( 'relation' => 'AND' );
                 
                 foreach ( $metaquery_pre as $key => $value ) {
                        $meta_query[] =  $value;
                    }                 
          }	     
        if(!empty($metaquery_pre) && count($metaquery_pre) ==1){
                 $meta_query = array();	   
                 foreach ( $metaquery_pre as $key => $value ) {
                        $meta_query[] =  $value;
                 }                 
          }

          
			
          //print_r($metaquery_pre);die;
		  
          if(!empty($taxquery)){
               $query->set('tax_query',$taxquery);
          }
          if(!empty($meta_query)){
               $query->set( 'meta_query', $meta_query );	
          }	  
	  
	  if(isset($_GET['categories']) && $_GET['categories']!='' && $_GET['post_type']=="post"){
	    
	       $query->set('cat',(integer)$_GET['categories'][0]);
	  }  
          
          /*if(isset($_GET['ref']) && $_GET['ref']!=''){
               add_filter( 'posts_where', array('azull_Search','filter_where_p'));
          }*/
          
          if((isset($_GET['datemin']) && isset($_GET['datemax']) && $_GET['datemin']!=''  &&  $_GET['datemax']!='') ||  (isset($_GET['datemin'])  &&  $_GET['datemin']!='') || (isset($_GET['datemax'])  &&  $_GET['datemax']!=''))
          add_filter( 'posts_where', array('azull_Search','filter_where'));          	
         
	 
     }
     
     static  function filter_where_p( $where = '' ){
          $where = " AND wp_posts.ID IN ('{$_GET['ref']}' ) AND wp_posts.post_type = '{$_GET['post_type']}' ";
          return $where;
     }
     static  function filter_where( $where = '' ) {
	  // posts for March 1 to March 15, 2010        
          if((isset($_GET['datemin']) && isset($_GET['datemax']) && $_GET['datemin']!=''  &&  $_GET['datemax']!='')){
               $datemin = date('Y-mm-d', strtotime($_GET['datemin']));
               $datemax = date('Y-m-d', strtotime($_GET['datemax']));
               $where .= " AND post_date <= '".$datemax."' AND post_date >= '".$datemin."'";
          }
          
          if((isset($_GET['datemin'])  &&  $_GET['datemin']!='')){
               $datemin = date('Y-m-d', strtotime($_GET['datemin']));
               $where .= " AND post_date >='$datemin'";
          }
          
          if((isset($_GET['datemax'])  &&  $_GET['datemax']!='')){
               $datemax = date('Y-m-d', strtotime($_GET['datemax']));
               $where .= " AND post_date <= '".$datemax."'";
          }
	  return  $where;
     }
    
     
}
