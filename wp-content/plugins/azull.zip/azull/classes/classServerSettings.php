<?php
/*
 * 
 * Tags: azull_meta_keywords, azull_meta_description 
 * @package:wordpress
 * @subpackage:azull
 */
defined('ABSPATH') or die("No script kiddies please!");
include_once( dirname( __FILE__ ) . '/classXmlrpc.php');

class Server_Setting {

	public static function get_client( $class, $site_ID ) {		
		if( class_exists($class) ) {
			return new $class( $site_ID );
		}
		throw new Exception($class.' class not found');
	}

	public static function display_server_settings( $site,$class) {	
		
	    $obj= new Xmlrpc_Client($site->ID);	   

		if($obj->test_connection()){

		    $hits_data = $obj->get_client_hits_counter();
		 	//$hits_data = json_decode($hits_data, FALSE);		 
		 //	print_r($hits_data); die;
		}   

		if( class_exists($class) ) {

			return call_user_func( array( $class, 'display_settings' ), array( $site, $hits_data));
		}

		throw new Exception($class.' class not found');
	}

	public static function save_client_settings( $site_ID, $class ) {		
		if( class_exists($class) ) {
			return call_user_func( array( $class, 'save_settings' ), $site_ID );
		}
		throw new Exception($class.' class not found');
	}
}