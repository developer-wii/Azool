<?php
class Azull_XMLmap{

 static function createMappingform(){
 //print_r($_POST);
 global $wpdb;
 // insert code


/*
DONT REMOVE
$records = $wpdb->get_results('SELECT * FROM wp_posts WHERE post_type = "property" ', ARRAY_A);




$dire = wp_upload_dir();

//print_r($dire['basedir']); die;

$fp = fopen($dire['basedir'].'/registrars.xls', 'w');

$list = array (
    array('#Post ID','Property Ref' ,'Proprietor Ref', 'Property Ref by Proprietor','Country', 'Province','Place'),
);
foreach ($records as $value1) {
    $recordsmeta = $wpdb->get_results('SELECT * FROM wp_postmeta WHERE post_id = '.$value1['ID'], ARRAY_A);
    $contry = $place= $prov=$p_ref=$p_prop=$p_imporid="";
    if(!empty($recordsmeta))
    foreach ($recordsmeta as $key => $value) {
       if($value['meta_key']=='_country'){  $contry = get_term_by('id', $value['meta_value'],'country'); $contry->name;    }
       if($value['meta_key']=='_place'){ $place = get_term_by('id', $value['meta_value'],'place'); $place->name; }
       if($value['meta_key']=='_province'){ $prov = get_term_by('id', $value['meta_value'],'provinces'); $prov->name; }
       if($value['meta_key']=='_nreal_id'){ $p_ref = $value['meta_value']; $p_ref->name;  }
       if($value['meta_key']=='_proprietor' &&  $value['meta_value']!=''){ $p_prop = get_term_by('id', $value['meta_value'],'proprietor');  $p_prop->name;   }
       if($value['meta_key']=='_proprietorRef'){ $p_imporid = $value['meta_value'];  }

       
    }
    $list[] = array($value1['ID'],$p_ref,$p_prop->name,$p_imporid,$contry->name,$prov->name,$place->name);
}

//$list[] = array($row["ID"],$row["ID"],$row["ID"],$row["ID"],$row["ID"]);

foreach ($list as $fields) {
    fputcsv($fp, $fields, "\t", '"');
}
chmod($dire['basedir'].'/registrars.xls', 0777);


fclose($fp);



die;

*/

 if(isset($_POST['save']) &&  $_POST['save']!='')
 {


     
     $qtranslate = $_POST['qtranslate'];
     $term_id=$_POST['term_id'];
     $agent_id=$_POST['property_meta_essential']['proprietor'];
     $featcher_name=$_POST['featcher_name'];
     $check_allagent =$_POST['check_allagent'];
     $table_name = "wp_feature_mapping" ;
     $options = get_option('qtranslate_term_name'); 
     $check = true;
      foreach ($options as $key => $value) {
        if($key == $featcher_name) $check = false;
    }
     if($check){ // check if not exist add to translation
      $options[$qtranslate['tanslate']['en']]  = array('en'=>$qtranslate['tanslate']['en'],'fr'=>$qtranslate['tanslate']['fr'],'nl'=>$qtranslate['tanslate']['nl']);
       update_option( 'qtranslate_term_name', $options );
     } 
       if(isset($_POST['editval']) && $_POST['editval']!=''){
            $id=$_POST['editval'];
            if($check_allagent==0) $agent_id=0;
            $wpdb->query("UPDATE wp_feature_mapping SET kyero_text= '$featcher_name', agentid=$agent_id, term_id=$term_id  WHERE id = $id ");
        }else{
          $wpdb->insert( $table_name, array( 'kyero_text' => $featcher_name, 'agentid' => $agent_id, 'term_id'=> $term_id));

        }
     wp_redirect(get_admin_url() . 'admin.php?page=properties');
  }  
  // delete code 
   if(isset($_GET['id']) && $_GET['action']=="delete"){
     $wpdb->delete( 'wp_feature_mapping', array( 'id' => base64_decode($_GET['id']) ) );
     ///wp_redirect(get_admin_url() . '/wp-admin/admin.php?page=Addnew'); 
      
             wp_redirect(get_admin_url() . 'admin.php?page=properties');
       exit;

   }
   // update code
   if(isset($_GET['id'])){
       
       $sql = "SELECT * FROM wp_feature_mapping where id=".base64_decode($_GET['id'])."";
       $getResult = $wpdb->get_row($sql);
       $kyero_text=$getResult->kyero_text;
       $agentid=$getResult->agentid;
       $term_id=$getResult->term_id;
       $update_id=$getResult->id;
       
   }   
   $orderby ="";
  if(isset($_GET['orderby'])){
     $orderby = "order by ".$_GET['orderby']." ".$_GET['order'] ;
  } 

   $where_c = "";
  if(isset($_GET['searchfeature']) && $_GET['searchfeature'] !=''){
     $where_c = "where kyero_text LIKE '%".$_GET['searchfeature']."%'";
  } 



  $order = (isset($_GET['order']) && $_GET['order'] =='asc') ? 'desc' : 'asc';
  $big = 999999999; // need an unlikely integer
  $paged = ( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
  $str = 0; 
  $end = 10;
  if($paged>1){
  		$str = $end*$paged;
  }
  global $wpdb;
  $sql1 = "SELECT * FROM wp_feature_mapping as wfm left join wp_terms as wt on wt.term_id = wfm.term_id left join wp_term_taxonomy as wtr on wtr.term_id = wt.term_id $where_c $orderby limit $str,$end "; 
  $sql2 = "SELECT * FROM wp_feature_mapping as wfm left join wp_terms as wt on wt.term_id = wfm.term_id left join wp_term_taxonomy as wtr on wtr.term_id = wt.term_id"; 
	$results = $wpdb->get_results($sql1);
	$results2 = $wpdb->get_results($sql2);
$html='
 
  <div class="wrap nosubsub">
<h1>'.__("XML Feature Mapping",'azull').'</h1>

<div id="ajax-response"></div>

<br class="clear">

<div id="col-container">

<div id="col-right">
<div class="col-wrap">
<ul class="qtranxs-lang-switch-wrap"><li lang="en" class="qtranxs-lang-switch active"><img src="'.plugins_url().'/qtranslate-x/flags/gb.png"><span>English</span></li><li lang="fr" class="qtranxs-lang-switch"><img src="'.plugins_url().'/qtranslate-x/flags/fr.png"><span>Français</span></li><li lang="nl" class="qtranxs-lang-switch"><img src="'.plugins_url().'/qtranslate-x/flags/nl.png"><span>Nederlands</span></li></ul>
<form id="posts-filter" method="get" action="'.get_admin_url() . 'admin.php">
<div class="tablenav top" style="margin:-18px 0 4px;">
<p class="search-box">
    <input type="hidden" id="post-search-input" name="page" value="properties">
	<label class="screen-reader-text" for="post-search-input">Zoeken:</label>
	<input type="search" id="post-search-input" name="searchfeature" value="'.$_GET['searchfeature'].'">
	<input type="submit" id="search-submit" class="button" value="Zoeken">
	</p>
</form> 

	<div class="tablenav-pages one-page">
      
   
<span class="pagination-links"><span class="tablenav-pages-navspan" aria-hidden="true">«</span>
<span class="tablenav-pages-navspan" aria-hidden="true">‹</span>
<span class="paging-input"><label for="current-page-selector" class="screen-reader-text">Current Page</label><input class="current-page" id="current-page-selector" type="text" name="paged" value="1" size="1" aria-describedby="table-paging"> of <span class="total-pages">1</span></span>
<span class="tablenav-pages-navspan" aria-hidden="true">›</span>
<span class="tablenav-pages-navspan" aria-hidden="true">»</span></span></div>
    <br class="clear">
  </div>
<h2 class="screen-reader-text">Tags list</h2><table class="wp-list-table widefat fixed striped tags">
  <thead>
  <tr>
    <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1">Select All</label></td>
    <th scope="col" id="name" class="manage-column column-name column-primary sortable '.$order.'">
    <a href="'.get_admin_url() . 'admin.php?post_type=xml&page=properties&amp;orderby=kyero_text&amp;order='.$order.'">
    <span>'.__("XML Feature Name",'azull').'</span><span class="sorting-indicator"></span></a></th>

<th scope="col" id="name" class="manage-column column-name column-primary sortable '.$order.'">
    <a href="'.get_admin_url() . 'admin.php?post_type=xml&page=properties&amp;orderby=taxonomy&amp;order='.$order.'">
    <span>'.__("Type",'azull').'</span><span class="sorting-indicator"></span></a></th>

    <th scope="col" id="description" class="manage-column column-description sortable desc">
    <a href="javascript:void(0);"><span>'.__("Agent Name",'azull').'</span><span class="sorting-indicator"></span></a></th><th scope="col" id="slug" class="manage-column column-slug sortable '.$order.'"><a href="'.get_admin_url() . 'admin.php?page=properties&amp;orderby=name&amp;order='.$order.'"><span>'.__("Feature Name",'azull').'</span><span class="sorting-indicator"></span></a></th><th scope="col" id="posts" class="manage-column column-posts num sortable desc"><a href="http://localhost/azulllive/wp-admin/edit-tags.php?taxonomy=exterior&amp;post_type=property&amp;orderby=count&amp;order=asc"><span>Modify Date</span><span class="sorting-indicator"></span></a></th>  </tr>
  </thead>'; 

  
if(!empty($results)){
  foreach ($results as $result) {
    # code...
         $editurl = admin_url(). "admin.php?post_type=xml&page=properties&id=".base64_encode($result->id);
         $deleteurl = admin_url(). "admin.php?post_type=xml&page=properties&id=".base64_encode($result->id)."&action=delete";
          $termname = $result->kyero_text;
          $options = get_option('qtranslate_term_name');
              foreach ($options as $key => $value) {
                if($key==$result->kyero_text){
                  $str = "";  
                  foreach ($value as $key1 => $value1) {
                    $str .= '[:'.$key1.']'.$value1; 
                  }
                  $termname = $str;
                }
              }

  $html .= '<tbody id="the-list" data-wp-lists="list:tag">
    <tr id="tag-79">
      <td class="thumb column-thumb" data-colname="Image"></td>
      <td class="name column-name has-row-actions column-primary" data-colname="Name"><strong><a class="row-title" href="'.$editurl.'" title="Edit">'.qtranxf_use(qtranxf_getLanguage(),$termname).'</a></strong><br>
         <div class="hidden" id="inline_79"><div class="name">[:en]'.$result->kyero_text.'[:fr]Ancrage privée[:nl]Aanlegsteiger[:de]Private Anchorage[:]</div><div class="slug">'.$result->kyero_text.'</div>
         <div class="parent">0</div></div>
         <div class="row-actions">'; 
          $reord = get_term_by('term_id', $result->agentid, 'proprietor');

           $agentName = $reord->name;
           if($agentName !=0){ 
          $options = get_option('qtranslate_term_name');
              foreach ($options as $key => $value) {
                if($key==$reord->name){
                  $str = "";  
                  foreach ($value as $key1 => $value1) {
                    $str .= '[:'.$key1.']'.$value1; 
                  }
                  $agentName = $str;
                }
              }
            }
              $featureName = $result->name;
               foreach ($options as $key => $value) {
                if($key==$result->name){
                  $str = "";  
                  foreach ($value as $key1 => $value1) {
                    $str .= '[:'.$key1.']'.$value1; 
                  }
                  $featureName = $str;
                }
              }


         $html .= '<span class="edit"><a href="'.$editurl.'">Edit</a> | </span><span class="inline hide-if-no-js" style="display: none;"><a href="#" class="editinline">Quick&nbsp;Edit</a> | </span> 

         <span class="delete"><a class="delete-tag" href="'.$deleteurl.'">Delete</a>  </span></div><button type="button" class="toggle-row"><span class="screen-reader-text">Show more details</span></button></td>

        <td class="thumb column-thumb" data-colname="Image">'.ucwords($result->taxonomy).'</td>
         <td class="description column-description" data-colname="Description">'.qtranxf_use(qtranxf_getLanguage(),$agentName).'</td>
         <td class="slug column-slug" data-colname="Slug">'.qtranxf_use(qtranxf_getLanguage(),$featureName).'</td><td class="slug column-slug" data-colname="Count">'.date('d-M-Y', strtotime($result->modified_date)).'</td></tr>';
            }
          }
          $totalpages = count($results2)/$end;
  $html .= '</tbody>


  <tfoot>
<tr>
    <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1">Select All</label></td><th scope="col" id="name" class="manage-column column-name column-primary sortable '.$order.'">
    <a href="'.get_admin_url() . 'admin.php?post_type=xml&page=properties&amp;orderby=kyero_text&amp;order='.$order.'"><span>'.__("XML Feature Name",'azull').'</span><span class="sorting-indicator"></span></a></th>

<th scope="col" id="name" class="manage-column column-name column-primary sortable '.$order.'">
    <a href="'.get_admin_url() . 'admin.php?post_type=xml&page=properties&amp;orderby=taxonomy&amp;order='.$order.'">
    <span>'.__("Type",'azull').'</span><span class="sorting-indicator"></span></a></th>

    <th scope="col" id="description" class="manage-column column-description sortable desc">
    <a href="javascript:void(0);"><span>'.__("Agent Name",'azull').'</span><span class="sorting-indicator"></span></a></th><th scope="col" id="slug" class="manage-column column-slug sortable '.$order.'"><a href="'.get_admin_url() . 'admin.php?page=properties&amp;orderby=name&amp;order='.$order.'"><span>'.__("Feature Name",'azull').'</span><span class="sorting-indicator"></span></a></th><th scope="col" id="posts" class="manage-column column-posts num sortable desc"><a href="http://localhost/azulllive/wp-admin/edit-tags.php?taxonomy=exterior&amp;post_type=property&amp;orderby=count&amp;order=asc"><span>Modify Date</span><span class="sorting-indicator"></span></a></th>  </tr>
  </tfoot>

</table>
  <div class="tablenav bottom">

    <div class="tablenav-pages one-page"><span class="displaying-num">'.count($results2).' '.__("items",'azull').'</span>
'.paginate_links( array(
	'base' => str_replace("&&",  "&", str_replace("#038;",  "&", str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ))),
	'format' => '?paged=%#%',
	'current' => max( 1, $paged),
	'mid-size' => 1,
	'prev_next' => True,
    'prev_text' => __( '<' ),
    'next_text' => __( '>' ),
	'total' => $totalpages
) ).'

</div>
    <br class="clear">
  </div>

<br class="clear">


</div>
</div><!-- /col-right -->

<div id="col-left" style="height: 500px;">
<div class="col-wrap">';

$html .= '
  <script>
        jQuery(document).ready(function(){
            jQuery(".qtranxs-lang-switch").click(function(){  
                var lang = jQuery(".active").attr("lang");
                var culang = jQuery(this).attr("lang");
                
                    if(jQuery(".featcher_name-"+lang).val() !=""){
                      jQuery("#featcher_name").val(""); 
                      jQuery("#featcher_name").val(jQuery(".featcher_name-"+culang).val());
                    }else{
                      jQuery(".featcher_name-"+lang).val(jQuery("#featcher_name").val());
                      jQuery("#featcher_name").val("");
                    }
                if(!jQuery(this).hasClass("active")){ 
                    jQuery(".qtranxs-lang-switch").removeClass("active");
                    jQuery(this).addClass("active")
                }
            });
              jQuery("#check_allagent").click(function(){  
                if(this.checked){
                  jQuery("#prop_div").hide();
                }else{
                  jQuery("#prop_div").show();
                }

              });
        });
 </script> ';
        $valueEn = $valueFr = $valueNl= ''; 
        $options = get_option('qtranslate_term_name');
              foreach ($options as $key => $value) {
                if($key == @$kyero_text){
                      $valueEn  = $value['en'];  
                      $valueFr  = $value['fr'];  
                      $valueNl  = $value['nl']; 
                }
            }
$html .= '<div class="form-wrap">
<h3>'.__("Map XML Feature to Azull Feature",'azull').'</h3>
<form id="" method="post" action="" class="validate">

<div class="form-field form-required term-name-wrap">
  <label for="tag-name">'.__("XML Feature",'azull').':</label>
  <input name="featcher_name" id="featcher_name" type="text" value="'.@$kyero_text.'" size="40" aria-required="true" class="qtranxs-translatable">
  <input name="qtranslate[tanslate][en]" type="hidden" class="hidden featcher_name-en" value="'.$valueEn.'">
  <input name="qtranslate[tanslate][fr]" type="hidden" class="hidden featcher_name-fr" value="'.$valueFr.'">
  <input name="qtranslate[tanslate][nl]" type="hidden" class="hidden featcher_name-nl" value="'.$valueNl.'">
  <p>'.__("The name is how it appears on your site.",'azull').'</p> 
</div>';

require_once( ABSPATH . 'wp-content/plugins/azull/classes/classPropertyMeta.php' ); 
          $pro_obj = new Property_Meta(); // To add agent drop-down   
              
    $style = $selected = ''; $label = 'Add';      if(isset($agentid) && $agentid==0){ 
        $style ='style= "display:none"'; $selected = 'checked'; 
         $label= 'Edit';
      }
$html .='<div class="form-field">
  
      <label for="tag-name">'.__("For All Agent",'azull').': <input type="checkbox" '.$selected.' id="check_allagent" name="check_allagent" value="0" /></label>
      <div id="prop_div" '.$style.' >
     <br>
    
    '.
  
  $pro_obj->proprietor_generate(@$agentid);   
    $html .= '<br>
   
    </div>
    
  </div>';


$html .= '<div class="form-field"><label for="tag-name">'.__("Azull Features",'azull').':</label>';
global $wpdb;
             $terms_record = $wpdb->get_results('SELECT  wt.term_id, name,wtt.taxonomy  FROM wp_term_taxonomy as wtt  join wp_terms as wt on wtt.term_id = wt.term_id WHERE taxonomy ="interior" or taxonomy ="exterior" or taxonomy ="view" or taxonomy ="feature" or taxonomy="locality" or taxonomy="category" order by wtt.taxonomy ', ARRAY_A); 

                $html .= '<select class="dropdown" id="term_id" name="term_id" >';
             $html .= '<option value="">Select</option>'; 
        $html .= "<optgroup   label='".__('Feature','azull')."' >";
            if(!empty($terms_record)){ 
    foreach ($terms_record as $key => $value) { 
          if($value["taxonomy"] != "category"){
        $selected = (isset($term_id)) && $term_id== $value['term_id'] ? "selected" : "";
        $html .= '<option '.$selected.' value="'.$value['term_id'].'">'.$value['name'].'</option>';
       
      }
    }
     $html .= "</optgroup>";
         $html .= "<optgroup  label='".__('Category','azull')."' >";
            if(!empty($terms_record)){ 
    foreach ($terms_record as $key => $value) { 
          if($value["taxonomy"] == "category"){
        $selected = (isset($term_id)) && $term_id== $value['term_id'] ? "selected" : "";
        $html .= '<option '.$selected.' value="'.$value['term_id'].'">'.$value['name'].'</option>';
       
      }
    }
  }
     $html .= "</optgroup>";


  }
  $html .= '</select>';

    $html .= '<br>
  </div><input type="hidden" name="save" value="save">
    <input type="hidden" id="editval" name="editval" value="'.$update_id.'" >
  ';

$html .='<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" 
value="'.__("$label XML Feature",'azull').'">
<a href="'.get_admin_url() . 'admin.php?page=properties"><input type="submit" name="cancel" id="cancel" class="button button-primary" 
value="Cancel">
</a>
</p></form></div>
</div>
</div><!-- /col-left -->

</div><!-- /col-container -->
</div>';

echo $html;


    }// end function

    static function xmlimport(){
          $importfile  = ""; 
   if ($_SERVER['REQUEST_METHOD'] === 'POST') {
       $type = $_FILES['xml_import']['type'];
       $size = $_FILES['xml_import']['size'];
       $name = $_FILES['xml_import']['name'];
       $ext = end(explode('.', $name)); 
       $agentId = $_POST['property_meta_essential']['proprietor'];
       if($_POST['xmlType']==1){ // if file type xml 
       // function to check the file type 
       if(strtolower($ext) == 'xml' && $agentId !=''){ 
            if ( ! function_exists( 'wp_handle_upload' ) ) {
               require_once( ABSPATH . 'wp-admin/includes/file.php' ); 
              }
              $uploadedfile = $_FILES['xml_import'];
              $upload_overrides = array( 'test_form' => false ); 
              add_filter('upload_dir','wpse_141088_upload_dir');
              add_filter('wp_handle_upload_prefilter', 'custom_upload_filter' );
              $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
              if ( $movefile && !isset( $movefile['error'] ) ) {
                      $uploadedfileName = $_FILES['xml_import']['name'];    
                      $filespath = wp_upload_dir();
                      $filespath =  $filespath['path'].'/'.$uploadedfileName;  // pass file path to display record
                      remove_filter( 'upload_dir','wpse_141088_upload_dir'); 
                      global $wpdb;  
                      $wpdb->insert('wp_xml_record',array('path' =>  $movefile['file'],'agentId' =>  $agentId,'type'=>1)); 
                     //require_once( ABSPATH .'wp-content/plugins/azull/classes/xmlfiles.php'); 
                      echo "<h3>".__('File Uploaded Successfully and started to upload','azull')."</h3>"; exit();
              }else{ 
                      echo $movefile['error'];
               }   
        }else{ // end if 
           $importfile  = "<div class='error' style='margin-top:2%;'>".__('Please select Required fields or upload proper xml file','azull').".<br /> <br /> 
           <a class='button button-primary button-large' href='".the_permalink()."'>Back</a></div>";
         }// end else 
        }else{   // if file type xml  in URL
              $xmlinUrl = $_POST['xml_url'];
              if( $xmlinUrl !='' && $agentId !=''){
               
                      add_option('proprietor_'.$agentId, $xmlinUrl, '', 'yes' );
                      update_option('proprietor_'.$agentId, $xmlinUrl, '', 'yes' );
                      global $wpdb; 
                      $wpdb->insert('wp_xml_record',array('path' =>  $xmlinUrl,'agentId' =>  $agentId,'type'=>1)); 
                    echo "<h3>".__('File Uploaded Successfully and started to upload','azull')."</h3>"; exit();
              }else{
                    $importfile  = "<div class='error' style='margin-top:2%;'>".__('Please select Required fields or upload proper xml file','azull').".<br /> <br /> 
                   <a class='button button-primary button-large' href='".the_permalink()."'>Back</a></div>";
              }
        }
  }else{
          require_once( ABSPATH . 'wp-content/plugins/azull/classes/classPropertyMeta.php' ); 
          $pro_obj = new Property_Meta(); // To add agent drop-down    
          $importfile .= '<div class="wrap">
                    <script>
                             jQuery(document).ready(function(){
                                jQuery("divId_2").hide();
                                
                                jQuery("#activate_proprietor").change(function(){
                                   pRValue=jQuery("#activate_proprietor").val();

                                   var data = {
                                    action: "get_proprietor_url",
                                    type: "POST",
                                    dataType:"json",
                                    pId:pRValue,
                                    };         
                                    jQuery.post( ajaxurl, data, function( response ) {
                                      if(response!=""){
                                       jQuery("#xml_url").val(response);
                                      } else{
                                       jQuery("#xml_url").val("");
                                       jQuery("#xml_url").attr("placeholder", "Please enter proprietor url");
                                      }
                                     });  

                              });
                                
                                
                              jQuery("#publish").click(function(){
                                    jQuery(".spinner").addClass("spinner is-active");
                                    jQuery("#publish").addClass("button button-primary button-large disabled ");
                                    jQuery("#infospan").html("Please wait while properties are imported, do not refresh this page....");
                              });
                              jQuery("input[name=xmlType]").change(function(){
                                  if(jQuery(this).val()==1){
                                      jQuery("#divId_1").show();
                                      jQuery("#divId_2").hide(); 
                                  }else{
                                      jQuery("#divId_2").show();
                                      jQuery("#divId_1").hide();
                                  }

                              });
                             });  
                    </script>';   
          $importfile .='<h1>'.__('Import XML File','azull').'</h1>';
          $importfile .='<p>'.__('Upload XML file to insert property into the database','azull').':</p>';
          $importfile .='<form action="" method="post" enctype="multipart/form-data">'; 
          $importfile .='<table class="widefat importers striped">';
          $importfile .='<tbody>'; 
          $importfile .='<tr><td class="form-field">Upload XML File</td>';
          $importfile .='<td class="desc"> 
                            <div>
                              <span> <input type="radio" checked name="xmlType" value="1" /> '.__('XML File','azull').' </span>
                              <span> <input type="radio" name="xmlType" value="2" /> '.__('XML URL','azull').'</span>
                            </div>
                              <br />
                            <div id="divId_1">
                                <input type="file" name="xml_import" class="" />
                            </div>
                            <div id="divId_2" style="display:none;">
                                <input type="text" name="xml_url" id="xml_url" placeholder="Please enter proprietor url "/>
                              <div> 
                              </td>
                            </tr>';
          //$importfile .='<tr><td class="import-system row-title"></td>';
          ///$importfile .='<td class="desc">'.$pro_obj->proprietor_generate().'</td></tr>';
        global $wpdb;
        $userInfo=get_userdata(get_current_user_id());
        //$userName= str_replace('-', ' ', $userInfo->user_login);
        $sql = "SELECT * FROM wp_terms where slug='".$userInfo->user_login."'";
        $termId = $wpdb->get_var($sql);
        $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }
         if(isset($termId) && $termId !='' && $userRole=='agent'){
             $importfile .='<input type="hidden" name="property_meta_essential[proprietor]" value="'.$termId.'">';
         }else{
             $importfile .='<tr><td class="import-system row-title"></td>';
             $importfile .='<td class="desc">'.$pro_obj->proprietor_generate().'</td></tr>'; 
         }
          
          $importfile .='<tr><td class="import-system row-title">
            <div id="publishing-action">
              <span class="spinner"></span>  
              <input type="hidden" value="Update" id="original_publish" name="original_publish">
              <input type="submit" value="'.__('Submit','azull').'" id="publish" class="button button-primary button-large " name="submit">
            </div>
              </td><td><span id="infospan" style="color:red;">* '.__('Both fields are required','azull').' </span></td></tr>';
          $importfile .='</tbody></table>';
          $importfile .='</form></div>';
        }
      echo $importfile ; 
    }


}