<?php
/* The class used to define to cutom tags to manage media attachement
 * @package:wordpress
 * @subpackage:azull
 */
defined('ABSPATH') or die("No script kiddies please!");

if ( !class_exists( 'Media_Attachment' ) ) :

class Media_Attachment{

     private static $instance;
    	/**
	 * Main Instance for Media_Attachment class
	 * @staticvar 	array 	$instance
	 * @return the one true instance
	 */    
    	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self;
			self::$instance->init();
		  }
	    return self::$instance;
	}
        function init(){

			 global $wp_taxonomies;	

        	 add_action( 'init', array($this,'media_taxonomies') );        	 
	 		 add_action( 'admin_menu', array($this,'custom_menu_page_removing') ); 

	 		 //add_action( 'init', array($this,'custom_add_terms_category_media') );

	 		 add_action( 'save_post', array($this, 'custom_assign_termto_images'), 10, 2 );
	 		 add_filter( 'image_make_intermediate_size', array($this, 'azull_rename_intermediates'));
	 		 add_filter('the_content', array($this, 'azull_image_seo_filter_content'), 100);		
        }



	function media_taxonomies(){
		  //category_media
		  global $wp_taxonomies;

		 // print_r($wp_taxonomies['category_media']);
          if(isset($wp_taxonomies['category_media'])){
			   $cat = $wp_taxonomies['category_media'];
			   $cat->label = __('Categories','azull');
			   $cat->labels->singular_name = __('Media Category','azull');
			   $cat->labels->name = __('Media Category','azull');
			   $cat->labels->menu_name =__('Categories','azull');
			   $cat->labels->all_items =__('All Categories','azull');
			   $cat->labels->edit_item =__('Edit Category','azull');
			   $cat->labels->view_item =__('View Category','azull');
			   $cat->labels->update_item =__('Update Category','azull');
			   $cat->labels->add_new_item =__('Add New Category','azull');
			   $cat->labels->parent_item =__('Parent Category','azull');
			   $cat->labels->parent_item_colon =__('Parent Category:','azull');
			   $cat->labels->search_items =__('Search Categories','azull');

		  }			
		  
		  if($media_options=get_option('wp-media-category-management-options',false)){		 
			  
			   $arg=array (
			      'wp_mcm_toggle_assign' => 1,
				  'wp_mcm_media_taxonomy_to_use' => 'category_media',
				  'wp_mcm_custom_taxonomy_name' => '',
				  'wp_mcm_custom_taxonomy_name_single' =>'',
				  'wp_mcm_use_post_taxonomy' =>'',
				  'wp_mcm_search_media_library' =>'',
				  'wp_mcm_use_default_category' =>1,
				  'wp_mcm_default_media_category' => 'uncategorized',
				  'wp_mcm_default_post_category' =>'',
				  'wp_mcm_version' =>($media_options['wp_mcm_version'])? $media_options['wp_mcm_version'] : ''
			   )  ;
			   
			   //need to test
			   update_option( 'wp-media-category-management-option', $arg );

			   //Force update Alt image content
		   	   if(get_option('azull_image_alt_override' == '') || !get_option('azull_image_alt_override')) {
					add_option('azull_image_alt_override', 'on');				
			   }	
		  }
	 }
	 function custom_menu_page_removing() {
		  remove_menu_page( 'wp-mcm' );
     }

     // This function will add custom terms to media attachments taxonomy to filter media library 
     function custom_add_terms_category_media(){   

       	$parent_term_arr = array('All Posts','Azull Adds','Azull offices','Info days','pages','properties','Testimonials');

        foreach($parent_term_arr as $parent_term){
     		if( !term_exists($parent_term, 'category_media'))
  			  $term_data = wp_insert_term ($parent_term, "category_media");   			 		 				   		
     	 }      	

     	/* $args = array(
     	 	 'post_type' => array( 'post', 'page', 'azulloffice', 'testimonial', 'infodays', 'azulladds', 'property'),    		  
    		 'posts_per_page'=> -1
    	 );	

		 $child_terms = get_posts($args);

		 $term_post =  get_term_by('slug', "all-posts", "category_media");
		 $term_properties =  get_term_by('slug', "properties", "category_media");		 
		 $term_page =  get_term_by('slug', "pages", "category_media");
		 $term_offices =  get_term_by('slug', "azull-offices", "category_media");
		 $term_testimonials =  get_term_by('slug', "testimonials", "category_media");
		 $term_infodays =  get_term_by('slug', "info-days", "category_media");
		 $term_adds =  get_term_by('slug', "azull-adds", "category_media");

		 if($child_terms){	

			 foreach($child_terms as $page){

			 	$slug = ucfirst( str_replace("-"," ",basename( get_permalink($page->ID)) ) );			 		

			 	switch ($page->post_type) {

				    case "post":
				    	if( !term_exists($slug, 'category_media'))
				        	wp_insert_term ($slug, "category_media", array('parent'=> $term_post->term_id) );
				        break; 

				    case "page":  				    		 	
    				    if( !term_exists($slug, 'category_media'))
				           wp_insert_term ($slug, "category_media",  array('parent'=> $term_page->term_id));
				        break;

				    case "azulloffice":
				    	if( !term_exists($slug, 'category_media'))
				       		wp_insert_term ($slug, "category_media", array('parent'=> $term_offices->term_id));
				        break;

				    case "property":
				    	if( !term_exists($slug, 'category_media'))
				       		 wp_insert_term ($slug, "category_media", array('parent'=> $term_properties->term_id) );
				        break;

				    case "testimonial":
				   		if( !term_exists($slug, 'category_media'))
				       		 wp_insert_term ($slug, "category_media", array('parent'=> $term_testimonials->term_id) );
				        break;

				    case "infodays":
				    	if( !term_exists($slug, 'category_media'))
				        	wp_insert_term ($slug, "category_media", array('parent'=> $term_infodays->term_id) );
				        break;

				    case "azulladds":
				    	if( !term_exists($slug, 'category_media'))
				       		 wp_insert_term ($slug, "category_media", array('parent'=> $term_adds->term_id) );
				        break;

				    default:				        
				}				
			} 

		 }	*/
		
     }

     function custom_assign_termto_images($post_id){ 

     		$post = get_post($post_id);

     		//Call to function to rename all attachments
			$this->azull_rename_attachments($post_id, $post);     		

     		$post_type = $post->post_type;    		

     		$parent_term_arr = array('All Posts','Azull Adds','Azull offices','Info days','pages','properties','Testimonials');

	        foreach($parent_term_arr as $parent_term){
	     		if( !term_exists($parent_term, 'category_media'))
	  			  $term_data = wp_insert_term ($parent_term, "category_media");   			 		 				   		
	     	 }

     		if($post->post_title != "Auto Draft"){

     			 switch ($post_type) {

				    	case "post":
					    	$term_data =  get_term_by('slug', "all-posts", "category_media"); 
							break;

						case "page": 
							$term_data =  get_term_by('slug', "pages", "category_media");   
					        break;

					    case "azulloffice":
					    	$term_data =  get_term_by('slug', "azull-offices", "category_media");					    		
					        break;

					    case "property":
					       	$term_data =  get_term_by('slug', "properties", "category_media"); 
					        break;

					    case "testimonial":
					    	$term_data =  get_term_by('slug', "testimonials", "category_media");					   			
					        break;

					    case "infodays":
					    	$term_data =  get_term_by('slug', "info-days", "category_media");					    		
					        break;

					    case "azulladds":
					    	$term_data =  get_term_by('slug', "azull-adds", "category_media");					    		
					        break;

				        default: 
				    }				   

					//moving attachments to term created 
					$args = array(
					   'post_type' => 'attachment',
					   'numberposts' => -1,				   
					   'post_parent' => $post->ID
				  	);

					$attachments = get_posts( $args );					
					
				    if ( $attachments ){
				        foreach ( $attachments as $attachment ){
				         	if(!has_term($term_data->term_id, "category_media"))
				 				wp_set_object_terms($attachment->ID, $term_data->term_id, "category_media", true);
				     	}
					}
     		}			

       		// CODE TO ASSIGN GALLERY IMAGES TO PROERTIES POST TYPES
     		if($post_type == "property"){  

     			$meta_arr = get_post_meta($post_id);
	     		$gallery_ids = $meta_arr['property_gallery'][0];
	     		$gallery_img_ids = json_decode(base64_decode($gallery_ids)); 	     	   			

	     		if($gallery_img_ids){

					$term_data = get_term_by('slug', 'properties', "category_media");
	     			foreach($gallery_img_ids as $postid){
		 				if(!has_term($term_data->term_id, "category_media"))
		 				 	wp_set_object_terms($postid, $term_data->term_id, "category_media", true);
	     			}
	     		}
     		}     		
     }

    
	public function azull_rename_attachments($post_id, $post_single) {

		//eg - 3091-te-koop-villa-marbella-01.jpg

		$post = get_post($post_id);
		$post_type = $post->post_type;

		if($post_type == 'property'){

			$property_ref = get_post_meta($post_id,'_nreal_id',true);
			$property_category = property_category($post_id);	
			$property_category = str_replace(" ","-", $property_category);

			$property_location = property_location($post_id);
			$property_alt_location = property_location($post_id);
			$property_location = str_replace(","," ", $property_location);
			$property_location = str_replace(" ","-", $property_location);
		}	
		
		$name = '';

		$args = array(
			'post_type' => 'attachment',
			'numberposts' => -1,				   
			'post_parent' => $post_id
		);
		$attachments = get_posts( $args );					
		$post_title = $post_single->post_title;					
		if($post_type == 'page'){
			$post_title = str_replace("(Nederlands) ","", get_the_title($post_id));
		}
		if ( $attachments ) {
			$i = 1;
			foreach ( $attachments as $attachment ) {
				
				$fpost_id = $attachment->ID;
				$fpost_title = sanitize_title($post_title);

				$seo_title = str_replace("-"," ", $fpost_title);	

				 if($post_type == 'property'){				

					$property_location = remove_character_accent($property_location);
	              //$post_title = $property_ref.'-te-koop-'.$property_category.'-'.$property_location.'-'.$i;
	            	 $post_title = $property_ref.'-'.$property_category.'-te-koop-'.'-'.$property_location.'-'.$i;
	                $fpost_title = str_replace("--","-", $post_title);

	                //$image_alt = $property_category." te koop in ".$property_alt_location."-".$seo_title;
	                $image_alt= $property_ref.'-'.$property_category.'-te-koop-'.$property_location.'-'.$i;

	             }else{

	             	$image_alt = $seo_title;

	            	$fpost_title = $fpost_title.'-'.$i;
	             }			

				//CALLING FUNCTION TO RENAME INTERMEDIATE SIZED IMAGES IN MEDIA
				$new_filename = $fpost_title;	
				$success = $this->do_rename($fpost_id, $new_filename);

				//$image_alt = "<!--:nl-->".$image_alt."<!--:-->";

        		$data = array();		
  				$data = array(   
		       	   'image_meta' => array(             
		              	 'caption' => $image_alt,
		                 'title' => $image_alt 
		            )
		        );

				update_post_meta($fpost_id, '_wp_attachment_image_alt', $image_alt);
				wp_update_attachment_metadata($fpost_id, $data);

				  $my_post = array(
				      'ID'           => $fpost_id,
				      'post_excerpt'   => $image_alt,
				      'post_content' => $image_alt,
				  );
				 
				wp_update_post( $my_post );				
				
				if($success == 1){

					//RENAMING ATTACHMENTS IMAGES IN MEDIA
					$fpost_path = get_attached_file($attachment->ID);
		            $fpost_guid = get_the_guid($fpost_id);		           		            

		            $fpost_ext = pathinfo($fpost_path, PATHINFO_EXTENSION);
		            $fpost_new_path = str_replace(basename($fpost_path, '.'.$fpost_ext), $fpost_title, $fpost_path);
		            $fpost_new_guid = str_replace(basename($fpost_guid, '.'.$fpost_ext), $fpost_title, $fpost_guid);

		            if( file_exists($fpost_path) && file_exists($fpost_new_path) ){	            	

		            	$name = rename($fpost_path, $fpost_new_path);
		            	if ($name == 1) {
						   update_attached_file($fpost_id, $fpost_new_path);				   

			               $my_post = array(
			                    'post_title'  => $fpost_title,
			                    'post_name'   => $fpost_title,
			                    'guid'        => $fpost_new_guid
			                );

			                global $wpdb;
			                $wpdb->update('wp_posts', $my_post, array('ID'=> $fpost_id)); 	    			
		    			}       	
		            }	
	            }              
 
	            $i++;	
			} 
		}

		//RENAMING POST THUMBNAIL IMAGES IN MEDIA
        if (has_post_thumbnail($post_id)) {
            $fpost_id = get_post_thumbnail_id($post_id);
            $fpost_path = get_attached_file($fpost_id);
            $fpost_guid = get_the_guid($fpost_id);

            $post_title = sanitize_title($post_single->post_title);           

            if($post_type == 'property'){
            	$fpost_title = $property_ref.'-te-koop-'.$property_category.'-'.$property_location;
                $fpost_title = str_replace("--","-", $fpost_title);
            }else{
            	$fpost_title = $post_title;
            }

            $fpost_ext = pathinfo($fpost_path, PATHINFO_EXTENSION);
            $fpost_new_path = str_replace(basename($fpost_path, '.'.$fpost_ext), $fpost_title, $fpost_path);
            $fpost_new_guid = str_replace(basename($fpost_guid, '.'.$fpost_ext), $fpost_title, $fpost_guid);

            if( file_exists($fpost_path) && file_exists($fpost_new_path) ){

	            $name = rename($fpost_path, $fpost_new_path);
		        if ($name == 1) {
	                update_attached_file($fpost_id, $fpost_new_path);
	                $my_post = array(
	                    'post_title'  => $fpost_title,
	                    'post_name'   => $fpost_title,
	                    'guid'        => $fpost_new_guid
	                );
	                // Update the post into the database
	                global $wpdb;
	                $wpdb->update('wp_posts', $my_post, array('ID'=> $fpost_id));
	            }
       		}
        }        
    }

    /**********************************************************
	    Description : This function rename the intermediate 
	    image attachments, and modify their urls in post 
	    content wherever they are being used	    
    **********************************************************/    
	public function do_rename($attachment_id, $new_filename, $retitle = 0) {

		// Variables
		$post = get_post($attachment_id);
		$file_parts = self::get_file_parts($attachment_id);

		$file_abs_path = get_attached_file($post->ID);
		$file_abs_dir = dirname( $file_abs_path );
		$new_file_abs_path = preg_replace('~[^/]+$~', $new_filename . '.' . $file_parts['extension'], $file_abs_path);

		$file_rel_path = get_post_meta($post->ID, '_wp_attached_file', 1);
		$new_file_rel_path = preg_replace('~[^/]+$~', $new_filename . '.' . $file_parts['extension'], $file_rel_path);

		$uploads_path = wp_upload_dir();
		$uploads_path = $uploads_path['basedir'];

		$searches = self::get_attachment_urls($attachment_id);
		
		//Validations
		if (!$post) return __('Post with ID ' . $attachment_id . ' does not exist!');
		if ($post && $post->post_type != 'attachment') return __('Post with ID ' . $attachment_id . ' is not an attachment!');
		if (!$new_filename) return __('The field is empty!');
		//if ( ($new_filename != sanitize_file_name($new_filename)) || preg_match('~[^\p{Common}\p{Latin}]~u', $new_filename) ) return __('Bad characters or invalid filename!');
		if (file_exists($new_file_abs_path)) return __('A file with that name already exists in the containing folder!');
		if (!is_writable($file_abs_dir)) return __('The media containing directory is not writable!');

		// Change the attachment post
		$post_changes['ID'] = $post->ID;
		$post_changes['guid'] = preg_replace('~[^/]+$~', $new_filename . '.' . $file_parts['extension'], $post->guid);
		$post_changes['post_title'] = ($retitle) ? self::filename_to_title($new_filename) : $post->post_title;
		$post_changes['post_name'] = wp_unique_post_slug($new_filename, $post->ID, $post->post_status, $post->post_type, $post->post_parent);
		wp_update_post($post_changes);

		// Change attachment post metas & rename files
		foreach (get_intermediate_image_sizes() as $size) {
			$size_data = image_get_intermediate_size($attachment_id, $size);
			
			@unlink( $uploads_path . DIRECTORY_SEPARATOR . $size_data['path'] );
		}

		if ( !@rename($file_abs_path, $new_file_abs_path) ) return __('File renaming error!');
		update_post_meta($attachment_id, '_wp_attached_file', $new_file_rel_path);
		wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $new_file_abs_path));

		// Replace the old with the new media link in the content of all posts and metas
		$replaces = self::get_attachment_urls($attachment_id);

		$i = 0;
		$post_types = get_post_types();
		unset( $post_types['attachment'] );
		
		while ( $posts = get_posts(array( 'post_type' => $post_types, 'post_status' => 'any', 'numberposts' => 100, 'offset' => $i * 100 )) ) {
			foreach ($posts as &$post) {
				// Updating post content if necessary
				$new_post = array( 'ID' => $post->ID );
				$new_post['post_content'] = str_replace($searches, $replaces, $post->post_content);
				if ($new_post['post_content'] != $post->post_content) wp_update_post($new_post);
				
				// Updating post metas if necessary
				$metas = get_post_meta($post->ID);
				foreach ($metas as $key => $meta) {
					$meta[0] = self::unserialize_deep($meta[0]);
					$new_meta = self::replace_media_urls($meta[0], $searches, $replaces);
					if ($new_meta != $meta[0]) update_post_meta($post->ID, $key, $new_meta, $meta[0]);
				}
			}

			$i++;
		}

		$success = 1;
		return $success;

	}	

    // Extracts filename and extension form an attachment post
	public static function get_file_parts($post_id) {
		preg_match('~([^/]+)\.([^\.]+)$~', get_attached_file($post_id), $file_parts); // extract current filename and extension
		return array(
			'filename' => $file_parts[1],
			'extension' => $file_parts[2]
		);
	}

	// Returns the attachment URL and sizes URLs, in case of an image
	public static function get_attachment_urls($attachment_id) {
		$urls = array( wp_get_attachment_url($attachment_id) );
		if ( wp_attachment_is_image($attachment_id) ) {
			foreach (get_intermediate_image_sizes() as $size) {
				$image = wp_get_attachment_image_src($attachment_id, $size);
				$urls[] = $image[0];
			}
		}

		return array_unique($urls);
	}


	// Convert filename to post title
	public static function filename_to_title($filename) {
		return ucwords( preg_replace('~[^a-zA-Z0-9]~', ' ', $filename) );
	}


	// Get all options
	public static function get_all_options() {
		return $GLOBALS['wpdb']->get_results("SELECT option_name as name, option_value as value FROM {$GLOBALS['wpdb']->options}", ARRAY_A);
	}

	// Unserializes a variable until reaching a non-serialized value
	public static function unserialize_deep($var) {
		while ( is_serialized($var) ) {
			$var = unserialize($var);
		}

		return $var;
	}

	// Replace the media url and fix serialization if necessary
	public static function replace_media_urls($subj, &$searches, &$replaces) {
		$subj = is_object($subj) ? clone $subj : $subj;

		if (!is_scalar($subj) && count($subj)) {
			foreach($subj as &$item) {
				$item = self::replace_media_urls($item, $searches, $replaces);
			}
		} else {
			$subj = is_string($subj) ? str_replace($searches, $replaces, $subj) : $subj;
		}
		
		return $subj;
	}

	// REPLACING IMAGES THUMBNAILS DIMENSIONS
	function azull_rename_intermediates( $image ){
	    // Split the $image path into directory/extension/name
	    $info = pathinfo($image);
	    $dir = $info['dirname'] . '/';
	    $ext = '.' . $info['extension'];
	    $name = wp_basename( $image, "$ext" );

	    // Get image information 
	    // Image edtor is used for this
	    $img = wp_get_image_editor( $image );
	    // Get image size, width and height
	    $img_size = $img->get_size();

	    // Image prefix small/medium/large
	    // Here based on image width
	    // Customize this to fit it to your needs
	    // Setup image name prefix variable
	    switch( $img_size['width'] )
	    {
	        case '150' :
	            $size_based_img_name_prefix = 'small';
	            break;
	        case '300' :
	            $size_based_img_name_prefix = 'medium';
	            break;
	        case '450' :
	            $size_based_img_name_prefix = 'large';
	            break;
	    }

	    // Build our new image name
	    $name_prefix = substr( $name, 0, strrpos( $name, '-' ) );
	    // The next line isn't needed for what you want
	    //$size_extension = substr( $name, strrpos( $name, '-' ) + 1 );
	    // Use the new name prefix variable instead
	    $new_name = $dir .$name_prefix . '-' . $size_based_img_name_prefix . $ext;

	    // Rename the intermediate size
	    $did_it = rename( $image, $new_name );

	    // Renaming successful, return new name
	    if( $did_it )
	        return $new_name;

	    return $image;
	}


	function wp_image_seo_process_images($matches){

		global $post;		

		$post_id = $post->ID;

		$post_type = $post->post_type;

		$post_title = sanitize_title($post->post_title);	

		if($post_type == 'property'){
			$property_ref = get_post_meta($post_id,'_nreal_id',true);
			$property_category = property_category($post_id);	
			$property_category = str_replace(" ","-", $property_category);
			$property_location = property_location($post_id);
			//$property_location = str_replace(","," ", $property_location);
			//$property_location = str_replace(" ","-", $property_location);

			$post_title = str_replace("-"," ", $post_title);
			$fpost_title = $property_category." te koop in ".$property_location." - ".$post_title;           

            $title = $fpost_title;
            $alt_txt = $fpost_title;

		}else{

			$title = $post_title;
			$alt_txt = $post_title;
		}
		
		$alttext_rep = "%name";
		$titletext_rep = "%name";
		$override= get_option('azull_image_alt_override');

		# take care of unsusal endings
		$matches[0]=preg_replace('|([\'"])[/ ]*$|', '\1 /', $matches[0]);
	
		### Normalize spacing around attributes.
		$matches[0] = preg_replace('/\s*=\s*/', '=', substr($matches[0],0,strlen($matches[0])-2));
		### Get source.
	
		preg_match('/src\s*=\s*([\'"])?((?(1).+?|[^\s>]+))(?(1)\1)/', $matches[0], $source);
	
		$saved=$source[2];
	
		### Swap with file's base name.
		preg_match('%[^/]+(?=\.[a-z]{3}\z)%', $source[2], $source);
		### Separate URL by attributes.
		$pieces = preg_split('/(\w+=)/', $matches[0], -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
		### Add missing pieces.
	
		$postcats=get_the_category();
		$cats="";
		if ($postcats) {
			foreach($postcats as $cat) {
				$cats = $cat->slug. ' '. $cats;
			}
		}
	
		$posttags = get_the_tags();
	
		$tags="";
		if ($posttags) {
			foreach($posttags as $tag) {
				$tags = $tag->name . ' ' . $tags;
			}
		}
	
		if (!in_array('title=', $pieces)) {

			$titletext_rep=str_replace("%title", $title, $titletext_rep);
			$titletext_rep=str_replace("%name", $alt_txt, $titletext_rep);			
		
			$titletext_rep=str_replace('"', '', $titletext_rep);
			$titletext_rep=str_replace("'", "", $titletext_rep);
		
			$titletext_rep=str_replace("_", " ", $titletext_rep);
			//$titletext_rep=str_replace("-", " ", $titletext_rep);
			//$titletext_rep=ucwords(strtolower($titletext_rep));
			if (!in_array('title=', $pieces)) {
				array_push($pieces, ' title="' . $titletext_rep . '"');
			} else {
				$key=array_search('title=',$pieces);
				$pieces[$key+1]='"'.$titletext_rep.'" ';
			}
		}
	
		if (!in_array('alt=', $pieces) || $override=="on") {
			$alttext_rep=str_replace("%title", $alt_txt, $alttext_rep);
			$alttext_rep=str_replace("%name", $alt_txt, $alttext_rep);

			$alttext_rep=str_replace("\"", "", $alttext_rep);
			$alttext_rep=str_replace("'", "", $alttext_rep);
			//$alttext_rep=(str_replace("-", " ", $alttext_rep));
			$alttext_rep=(str_replace("_", " ", $alttext_rep));
		
			if (!in_array('alt=', $pieces)) {
				array_push($pieces, ' alt="' . $alttext_rep . '"');
			} else {
				$key=array_search('alt=',$pieces);
				$pieces[$key+1]='"'.$alttext_rep.'" ';
			}
		}
		return implode('', $pieces).' /';
	}
	

	function azull_image_seo_filter_content($content) {
		 $content = preg_replace_callback('/<img[^>]+/',array($this, 'wp_image_seo_process_images'), $content);
		 return $content;
	}
  
	/*******************************************************
	delete terms assign to attachments if post is deleted
	*******************************************************/

    /* add_action( 'delete_post', 'codex_sync', 10 );
	function codex_sync( $pid ) {
	    global $wpdb;
	    if ( $wpdb->get_var( $wpdb->prepare( 'SELECT post_id FROM codex_postmeta WHERE post_id = %d', $pid ) ) ) {
	        return $wpdb->query( $wpdb->prepare( 'DELETE FROM codex_postmeta WHERE post_id = %d', $pid ) );
	    }
	    return true;
	}*/

	
	


}//end of class       
endif;
