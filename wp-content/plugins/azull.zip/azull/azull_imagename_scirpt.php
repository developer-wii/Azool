<?php
// get all upated id
function weatehrInfoRun(){
  global $wpdb; 
$query = "SELECT wp_posts.ID FROM wp_posts
  JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id where wp_postmeta.meta_key='_xmlref' and wp_postmeta.meta_value!='' ORDER BY ID DESC LIMIT 2500, 50";

//echo $query."<br>";
$allPostId = $wpdb->get_results($query, ARRAY_A);
//echo '<pre>';
//print_r($allPostId);
//echo count($allPostId);
//die;
//$allPostId=array(291716);
/* run for all xml post id*/
foreach ($allPostId  as $key => $pId) {
 //foreach ($allPostId as $post_id) { 
 //if($key==32){
$post_id= $pId['ID'];
 echo $post_id."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

 // $imageTitle =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName));
  
  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    //echo '<pre>';print_r($ids);
    //die;////////
  /* run for all post attachment id*/ 
  $i=0; 
  $temp=false;
 if(isset($ids) && !empty($ids)){ 
  foreach ($ids as $atchid) {
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
            /*oldFileName*/
              //$oldnamefile=$filepath.'/'.$prvName;
              //$newfile = $filepath.'/'.$name.'.'.$ext;
              //$atchData=get_post_meta($atchid,'_wp_attached_file');
              
              

      $file = get_attached_file($atchid);
      $path = pathinfo($file);  
      //echo $path['basename'].'--';
      //echo 'new...'.$name.'.'.$ext."<br><br>";
         
      if($path['basename']!='' && $path['basename'] != $name.'.'.$ext){
                
                 global $wpdb; 
                $table_name='wp_posts';
                /*update post meta*/       
              //$wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$name' WHERE ID=$atchid");

                /* get wp_attached_file data */
                $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];
                
                /*rename attact fileName */
                  if(file_exists($file)){
                   // rename($file, $newwp_attached_file); 
                    //update_attached_file( $atchid, $newwp_attached_file );
                  }
                  
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
              //echo '<pre>';
              //print_r($atchData1);
               
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;

              /*Update attechment data*/ 
 
                $thumbnail= $atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $atchData1[0]['sizes']['medium']['file'];
                $large= $atchData1[0]['sizes']['large']['file'];
                
                $pdfLarge= $atchData1[0]['sizes']['pdf-large']['file'];
                $pdfSmall= $atchData1[0]['sizes']['pdf-small']['file'];
                $printA5Large= $atchData1[0]['sizes']['print-A5-large']['file'];
                // echo $pdfLarge."<br>";
                // echo $pdfSmall;

        if($pdfLarge!='' && $pdfSmall!='' && $printA5Large!=''){
                 ///echo $atchid.'pdfin<br>';
                  
                  $pdfLarge = $filepath.'/'.$atchData1[0]['sizes']['pdf-large']['file'];
                  $pdfSmall = $filepath.'/'.$atchData1[0]['sizes']['pdf-small']['file'];
                  $printA5Large = $filepath.'/'.$atchData1[0]['sizes']['print-A5-large']['file'];
                  $thumbnail= $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                  $medium= $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                  $large= $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                
            if(file_exists($pdfLarge) && file_exists($pdfSmall) && file_exists($printA5Large) && file_exists($thumbnail) && file_exists($medium) && file_exists($large)){
                      
                      /*rename($pdfLarge, $filepath."/".$name.'-.jpg');
                      rename($pdfSmall, $filepath."/".$name.'-.jpg');
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      rename($thumbnail, $filepath."/".$name.'-small.jpg');
                      rename($medium, $filepath."/".$name.'-medium.jpg');
                      rename($large, $filepath."/".$name.'-.jpg');
                      
                      $atchData1[0]['sizes']['pdf-large']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['pdf-small']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['print-A5-large']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-small.jpg';
                      $atchData1[0]['sizes']['medium']['file']= $name.'-medium.jpg';
                      $atchData1[0]['sizes']['large']['file']= $name.'-.jpg';
                      $updatedAttachData=serialize($atchData1);
                      
                  $wpdb->query( "DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'" );
                  $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");*/
                  $updatedPostID[]= $post_id.'-'.$nbId;

           }
        }else{
                if($thumbnail!='' && $medium!='' && $large!=''){
                //echo $atchid.'out-----<br>';
                  $thumbnail= $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                  $medium= $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                  $large= $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                  //echo $thumbnail."<br>";
                  //echo 'nwww--'.$filepath."/".$name.'-150x150.jpg';
                  //echo $medium."<br>";
                  //echo $large."<br>";
                  if(file_exists($thumbnail)){
                       //rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                       //$atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                  }else if(file_exists($thumbnail)){
                       //rename($medium, $filepath."/".$name.'-300x169.jpg');
                       //$atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                  }else if(file_exists($large)){
                      //rename($large, $filepath."/".$name.'-1024x576.jpg');
                      //$atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                  }
                  //$atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                  //$atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                  //$atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                  //echo '<pre>';
                  //print_r($atchData1);
                  //$updatedAttachData=serialize($atchData1);
                  $table_name1='wp_postmeta';
                  global $wpdb;
                  //$wpdb->query( "DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'");
                  //$wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");

                  $updatedPostID[]=$post_id.'-'.$nbId;
                 } 
          }
        } else{ //end check attachmentImage title and updation
                  $notupdate[]=$post_id.'-'.$nbId;
          }
    $i++;
    //die('atch');
  }//end for attachment id
}//check atchId

}// end for post id    

if(!empty($updatedPostID)){
 $updatedPostID=array_unique($updatedPostID); 
 $myfile1 = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id1.txt", "w") or die("Unable to open file!");
foreach ($updatedPostID as $ids) {
   $txt=$ids.'--';
  fwrite($myfile1, $txt);
}
fclose($myfile1);
}

if(!empty($notupdate)){
 $notupdate=array_unique($notupdate); 
  $myfile = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id.txt", "w") or die("Unable to open file!");
//$txt = "John Doe\n";
foreach ($notupdate as $ids) {
   $txt=$ids.'--';
  fwrite($myfile, $txt);
}
fclose($myfile);

}

die('-- ');
}



// script for update image name and ids
function updatedPostIds(){

global $wpdb; 
$query = "SELECT wp_posts.ID FROM wp_posts
  JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id where wp_postmeta.meta_key='_xmlref' and wp_postmeta.meta_value!='' ORDER BY ID DESC LIMIT 40,50";

//$allPostId = $wpdb->get_results($query, ARRAY_A);

$allPostId=array(291462,291251,291241,291052,290342,289977,289772,289725);
//$allPostId=array(,151856,97802,97740,97733,96844,96733,96355,96241);
//$allPostId=array(293504);

/* run for all xml post id*/
//foreach ($allPostId as $key => $pId) {
 foreach ($allPostId as $post_id) { 
 //if($key==32){
  //$post_id= $pId['ID'];
 //echo $post_id."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

 // $imageTitle =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName));
  
  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    echo '<pre>';print_r($ids);
    //die;
    //die;////////
  /* run for all post attachment id*/ 
  $i=0; 
  $temp=false;
 if(isset($ids) && !empty($ids)){ 
  foreach ($ids as $atchid) {
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
            /*oldFileName*/
              //$oldnamefile=$filepath.'/'.$prvName;
              //$newfile = $filepath.'/'.$name.'.'.$ext;
              //$atchData=get_post_meta($atchid,'_wp_attached_file');
              
              

      $file = get_attached_file($atchid);
      $path = pathinfo($file);  
      echo $path['basename'].'--';
      echo 'new...'.$name.'.'.$ext."<br><br>";
         
     if($path['basename']!='' && $path['basename'] != $name.'.'.$ext){
                
                 global $wpdb; 
                $table_name='wp_posts';
                /*update post meta*/       
              $wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$name' WHERE ID=$atchid");

                /* get wp_attached_file data */
                $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];
                
                /*rename attact fileName */
                  if(file_exists($file)){
                    rename($file, $newwp_attached_file); 
                    update_attached_file( $atchid, $newwp_attached_file );
                  }
                  
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
              echo 'attech ile------<pre>';
              print_r($atchData1);
               
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;

              /*Update attechment data*/ 
 
                $thumbnail= $atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $atchData1[0]['sizes']['medium']['file'];
                $large= $atchData1[0]['sizes']['large']['file'];
                
                $pdfLarge= $atchData1[0]['sizes']['pdf-large']['file'];
                $pdfSmall= $atchData1[0]['sizes']['pdf-small']['file'];
                $printA5Large= $atchData1[0]['sizes']['print-A5-large']['file'];
               // echo $pdfLarge."<br>";
               // echo $pdfSmall."<br>";

        if($pdfLarge!='' && $pdfSmall!='' && $printA5Large!=''){
                 //echo $atchid.'pdfin<br>';
                  
                  $pdfLarge = $filepath.'/'.$atchData1[0]['sizes']['pdf-large']['file'];
                  $pdfSmall = $filepath.'/'.$atchData1[0]['sizes']['pdf-small']['file'];
                  $printA5Large = $filepath.'/'.$atchData1[0]['sizes']['print-A5-large']['file'];
                  $thumbnail= $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                  $medium= $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                  $large= $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                
            if(file_exists($pdfLarge) && file_exists($pdfSmall) && file_exists($printA5Large) && file_exists($thumbnail) && file_exists($medium) && file_exists($large)){
                   
                    echo 'exists<br>';  
                      rename($pdfLarge, $filepath."/".$name.'-.jpg');
                      rename($pdfSmall, $filepath."/".$name.'-.jpg');
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      rename($thumbnail, $filepath."/".$name.'-small.jpg');
                      rename($medium, $filepath."/".$name.'-medium.jpg');
                      rename($large, $filepath."/".$name.'-.jpg');
                      
                      $atchData1[0]['sizes']['pdf-large']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['pdf-small']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['print-A5-large']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-small.jpg';
                      $atchData1[0]['sizes']['medium']['file']= $name.'-medium.jpg';
                      $atchData1[0]['sizes']['large']['file']= $name.'-.jpg';
                      $updatedAttachData=serialize($atchData1);
                  
                  echo 'newAttecgmetData================================<br>';    
                  print_r(unserialize($updatedAttachData));

                  global $wpdb;
                  $table_name1='wp_postmeta';   


                  $wpdb->query( "DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'" );

                  $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");
                  

           }
        }else{
                if($thumbnail!='' && $medium!='' && $large!=''){
                //echo $atchid.'out-----<br>';
                  $thumbnail= $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                  $medium= $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                  $large= $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
  
                  if(file_exists($thumbnail)){
                      rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                       $atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                  }else if(file_exists($thumbnail)){
                       rename($medium, $filepath."/".$name.'-300x169.jpg');
                       $atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                  }else if(file_exists($large)){
                      rename($large, $filepath."/".$name.'-1024x576.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                  }
                  
                  $updatedAttachData=serialize($atchData1);
                  $table_name1='wp_postmeta';
                  global $wpdb;
                  $wpdb->query( "DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'");
                  $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");

                  //$updatedPostID[]=$post_id.'-'.$nbId;
                 } 
          }
        } else{ //end check attachmentImage title and updation
                  $notupdate[]=$post_id.'-'.$nbId;
          }
    $i++;
    //die('atch');
  }//end for attachment id
}//check atchId
}// end for post id    



/*if(!empty($updatedPostID)){
 $updatedPostID=array_unique($updatedPostID); 
 $myfile1 = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id1.txt", "w") or die("Unable to open file!");
foreach ($updatedPostID as $ids) {
   $txt=$ids.'--';
  fwrite($myfile1, $txt);
}
fclose($myfile1);
}

if(!empty($notupdate)){
 $notupdate=array_unique($notupdate); 
  $myfile = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id.txt", "w") or die("Unable to open file!");
//$txt = "John Doe\n";
foreach ($notupdate as $ids) {
   $txt=$ids.'--';
  fwrite($myfile, $txt);
}
fclose($myfile);

}*/


die('-- ');

}

function get_termName($termId) {
    global $wpdb;
    $terms = $wpdb->get_results('SELECT name FROM wp_terms WHERE term_id =' . $termId, ARRAY_A);
    if (isset($terms[0]['name']))
        return $terms[0]['name'];
    return false;
}
?>