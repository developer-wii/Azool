<?php
/*
  Plugin Name: Azull server
  Plugin URI: http://cisinlabs.com
  Description: Azull property server, is developed as an tool to manage property data on single wordpress instalation and serve data to regional property portals.
  Author: Dhananjay Pandey
  Version: 1.0
  Tags: azull,multilingual, multi, language, admin, tinymce, qTranslate, Polyglot, bilingual, widget, switcher, professional, human, translation, service
  Author URI: http://cisinlabs.com

  Important Note:Language translation has been adopted from qtranslate and mqtranslate, all the file has be kept as lib and can be changed safely with new updates, but some modfication will be needed
  to support property custom post type and associated taxonomy. and make it work with azull.
 */
//todo: regeneration translation before deploying on live website.
defined('ABSPATH') or die("No script kiddies please!");
require_once(dirname(__FILE__) . "/lib/qtranslate_config.php");
//Adding functionality to show click history
require_once(dirname(__FILE__) . "/history/newstatpress.php");
//require_once(dirname(__FILE__)."/roles/members.php");
if (!class_exists('azull')): //class if starts
   class azull {
      private static $instance;
      //todo: implemen version checking and implemntion some security hacks.
      private $version = 1.0;
      private $id = 'azull';
      /**
       * Main Instance
       * @staticvar 	array 	$instance
       * @return the one true instance
       */
      public static function instance() {
         if (!isset(self::$instance)) {
            self::$instance = new self;
            self::$instance->constants();
            self::$instance->init();
            self::$instance->required();
            self::$instance->_hooks();
            //self::$instance->_hook_pluging_load();                    
         }
         return self::$instance;
      }

      private function constants() {
         define('AZULL_VERSION', $this->version);
         define('AZULL_SETTINGS', $this->id);
         define('AZULL_DIR', plugin_dir_path(__FILE__));
         define('AZULL_URL', plugin_dir_url(__FILE__));
         define('AZULL_FILE', __FILE__);
      }

      private function required() {
         if (!class_exists('Azull_XMLmap'))
            require_once( AZULL_DIR . 'classes/classXMLmap.php' );

         if (!class_exists('Ajull_Property'))
            require_once( AZULL_DIR . 'classes/classProperty.php' );

         if (!class_exists('Property_Meta'))
            require_once( AZULL_DIR . 'classes/classPropertyMeta.php' );

         if (!class_exists('Azull_Seo_Meta'))
            require_once( AZULL_DIR . 'classes/classSeoMeta.php' );

         if (!class_exists('Azull_Meta'))
            require_once( AZULL_DIR . 'classes/classMeta.php' );

         if (!class_exists('Ajull_CustomPosts'))
            require_once( AZULL_DIR . 'classes/classCustomPosts.php' );

         if (!class_exists('Server_Setting'))
            require_once( AZULL_DIR . 'classes/classServerSettings.php' );
         if (!class_exists('Class_Site'))
            require_once( AZULL_DIR . 'classes/classSite.php' );
         if (!class_exists('Azull_Action'))
            require_once( AZULL_DIR . 'classes/classAction.php' );
         if (!class_exists('Settings'))
            require_once( AZULL_DIR . 'classes/classSettings.php' );
         if (!class_exists('Clone_Post'))
            require_once( AZULL_DIR . 'classes/classClone.php' );
         if (!class_exists('Azull_Search'))
            require_once( AZULL_DIR . 'classes/classSearch.php' );

         //if( ! class_exists( 'Azull_Subscriber' ) )
         require_once( AZULL_DIR . 'classes/classSubscriber.php' );

         if (!class_exists('Azull_Utility'))
            require_once( AZULL_DIR . 'classes/classUtility.php' );

         if (!class_exists('Media_Attachment'))
            require_once( AZULL_DIR . 'classes/classMediaAttachment.php' );

         //if( ! class_exists( 'Social_Media_Sharing' ) )
         //require_once( AZULL_DIR . 'classes/classSocialMedia.php' );

         require_once( AZULL_DIR . '/functions.php' );
      }

      function _hooks() {
         require_once(dirname(__FILE__) . "/hooks.php");
      }

      static function _hook_meta() {   
         //remove all metabox and so we can organise theme in single box, to clean edit area.
         remove_meta_box('tagsdiv-walkscores', 'property', 'normal');
         remove_meta_box('tagsdiv-orientation', 'property', 'normal');
         remove_meta_box('tagsdiv-banner', 'property', 'normal');
         remove_meta_box('tagsdiv-status', 'property', 'normal');
         remove_meta_box('tagsdiv-type', 'property', 'normal');
         remove_meta_box('tagsdiv-categories', 'property', 'normal');
         remove_meta_box('tagsdiv-view', 'property', 'normal');
         remove_meta_box('tagsdiv-interior', 'property', 'normal');
         remove_meta_box('tagsdiv-exterior', 'property', 'normal');
         remove_meta_box('tagsdiv-agent', 'property', 'normal');
         remove_meta_box('tagsdiv-owner', 'property', 'normal');
         remove_meta_box('tagsdiv-feature', 'property', 'normal');
         remove_meta_box('tagsdiv-dimensions', 'property', 'normal');
         remove_meta_box('tagsdiv-websites', 'property', 'normal');
         remove_meta_box('locationdiv', 'property', 'normal');
         remove_meta_box('keyholderdiv', 'property', 'normal');
         remove_meta_box('categorydiv', 'property', 'normal');
         remove_meta_box('tagsdiv-proprietor', 'property', 'normal');
         remove_meta_box('tagsdiv-locality', 'property', 'normal');
         remove_meta_box('categorydiv', 'post', 'normal');
         remove_meta_box('postimagediv', 'post', 'normal');
         remove_meta_box('pageparentdiv', 'page', 'normal');
         remove_meta_box('slugdiv', 'property', 'normal');
         remove_meta_box('slugdiv', 'post', 'normal');
         remove_meta_box('slugdiv', 'page', 'normal');
         remove_meta_box('slugdiv', 'page', 'normal');
         remove_meta_box('tagsdiv-project', 'property', 'normal');

         $Post_settings = __('Post settings', 'azull');
         $Offices_settings = __('Offices settings', 'azull');
         $Slide_settings = __('Slide settings', 'azull');
         $Adds_settings = __('Adds settings', 'azull');
         $Infodays_settings = __('Infodays settings', 'azull');
         $Testimonials_settings = __('Testimonials settings', 'azull');
         $Page_settings = __('Page settings', 'azull');
         $Property_meta_data = __('Property meta data', 'azull');
         $Property_financial_data = __('Property financial data', 'azull');


         add_meta_box('post_settings', $Post_settings, array('Azull_Meta', 'post_meta'), 'post', 'side', 'high');
         add_meta_box('page_settings', $Page_settings, array('Azull_Meta', 'post_meta'), 'page', 'side', 'high');

         add_meta_box('testimonial_settings', $Testimonials_settings, array('Azull_Meta', 'post_meta'), 'testimonial', 'side', 'high');
         add_meta_box('infoday_settings', $Infodays_settings, array('Azull_Meta', 'post_meta'), 'infodays', 'side', 'high');
         add_meta_box('azulladds_settings', $Adds_settings, array('Azull_Meta', 'post_meta'), 'azulladds', 'side', 'high');
         add_meta_box('slider_settings', $Slide_settings, array('Azull_Meta', 'post_meta'), 'slider', 'side', 'high');
         add_meta_box('azulloffice_settings', $Offices_settings, array('Azull_Meta', 'post_meta'), 'azulloffice', 'side', 'high');

         add_meta_box('property_meta', $Property_meta_data, array('Property_Meta', 'get_property_meta'), 'property', 'normal', 'high');
         add_meta_box('property_finance', $Property_financial_data, array('Property_Meta', 'get_property_meta_finance'), 'property', 'normal', 'high');

         $essentail_name = __('Essential Information', 'azull');

         add_meta_box('property_meta_essential', $essentail_name, array('Property_Meta', 'get_property_meta_essential'), 'property', 'side', 'high');
         add_filter('manage_property_posts_columns', array('Property_Meta', 'property_column'), 10);
         add_action('manage_edit-property_columns', array('Property_Meta', 'remove_property_posts_column'));
         add_action('manage_property_posts_custom_column', array('Property_Meta', 'property_column_content'), 10, 2);
         add_filter('manage_edit-property_sortable_columns', array('Property_Meta', 'property_sortable_columns'));
         //add order column in infodays overview list
         add_filter('manage_infodays_posts_columns', array('Property_Meta', 'infodays_column'), 10);
         add_action('manage_infodays_posts_custom_column', array('Property_Meta', 'infodays_column_content'), 10, 2);
         add_filter( 'manage_edit-infodays_sortable_columns', array('Property_Meta', 'infodays_sortable_columns'));

         //add order column in office overview list
         add_filter('manage_azulloffice_posts_columns', array('Property_Meta', 'infodays_column'), 10);
         add_action('manage_azulloffice_posts_custom_column', array('Property_Meta', 'infodays_column_content'), 10, 2);
         add_filter( 'manage_edit-azulloffice_sortable_columns', array('Property_Meta', 'infodays_sortable_columns'));

      }

      function _js() {
         wp_enqueue_style('adminstyles');
         wp_enqueue_style('thickbox');
         wp_enqueue_script('thickbox');
         wp_enqueue_script('media-upload');
         wp_enqueue_script('ajull-js', AZULL_URL . 'js/ajull.js');
         wp_enqueue_script('ajull-js');
         wp_enqueue_script('gallery-meta', AZULL_URL . 'js/gallery.js');
         wp_enqueue_script('gallery-meta');
         wp_enqueue_script('jPages', AZULL_URL . 'js/jPages.min.js');
         wp_enqueue_script('jPages');
         wp_enqueue_script('fmselectator', AZULL_URL . 'js/fm.selectator.jquery.js');
         wp_enqueue_script('fmselectator');
         wp_enqueue_script('sumoselect', AZULL_URL . 'js/jquery.sumoselect.min.js');
         wp_enqueue_script('sumoselect');
         wp_enqueue_script('print', AZULL_URL . 'js/jQuery.print.js');
         wp_enqueue_script('print');
         wp_enqueue_script('price-format-js');
         wp_enqueue_script('price-format-js', AZULL_URL . 'js/jquery.price_format.min.js');
      }

      function _css() {
         wp_register_style('ajull-css', AZULL_URL . 'css/ajull.css');
         wp_enqueue_style('ajull-css');
         wp_register_style('fm.selectator.jquery', AZULL_URL . 'css/fm.selectator.jquery.css');
         wp_enqueue_style('fm.selectator.jquery');
         wp_register_style('translate-css', AZULL_URL . 'css/translate.css');
         wp_enqueue_style('translate-css');

      }

      private function init() {
         // Load Translation lib
         require_once(dirname(__FILE__) . "/classes/classXmlrpc.php");
         require_once(dirname(__FILE__) . "/lib/taxonomy-images.php");
         require_once(dirname(__FILE__) . "/mpdf/mpdf.php");
         require_once(dirname(__FILE__) . "/lib/MCAPI_2.0.class.php");
      }

      static function activate() {
         
      }

      static function deactivate() {
         
      }

      /* will return all client website. client website are beeing handled as custom postype sites
       *
       * @param:none
       * @return:array of client website ID.
       *
       */

      static function get_sites() {
         global $wpdb;
         $sites = array();
         $datas = $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
         $i = 0;

         foreach ($datas as $data) {
            $obj = new Xmlrpc_Client($data->ID);
            if ($obj->test_connection()) {
               $sites[$i] = $data->ID;
               $i++;
            }
         }

         return $sites;
      }

      /* create metabox listing all client website, called on property,post and page
       * content on client webste.
       * @param:none
       *
       */

      static function get_client_sites() {
         global $post, $wpdb;
         $html = '';

         $val = get_post_meta($post->ID, "azull_sites", true);
         $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
         $html .= '<select style="width:159px;" class="SlectBox" name="access[]" multiple>';

         foreach ($datas as $data) {
            $html .= "<option value='".$data->ID."'>" .qtranxf_use(qtranxf_getLanguage(),$data->post_title). "</option>";    
            //$options=get_post_meta( get_the_ID(), 'access', true);
         }
         $html .= "</select>";
         return $html;
      }

      static function azull_first() {
         global $wpdb;
         $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
         if (!$datas)
            return false;
         foreach ($datas as $data) {
            if ($data->ID != '') {
               $c = $data->ID;
               if (!session_id()) {
                  session_start();
               }
               $_SESSION['c'] = $c;
               $_SESSION['l'] = '';

               return $data->ID;
            }
         }
         return false;
      }

      function xmlrpc_created_term($term_id, $tt_id, $taxonomy) {
         global $a_config;
         $terms = get_option('taxonomy_' . $taxonomy . '_' . $term_id);
         $taxonomybyid = get_term_by('id', $term_id, $taxonomy);
         if ($terms) {
            foreach ($terms as $key => $val) {
               foreach ($val as $ln => $lanval) {
                  $a_config['term_name'][$key][$ln] = $lanval;
               }
            }
         }
         foreach (azull::get_sites() as $site) {
            $obj = new Xmlrpc_Client($site);
            $obj->add_taxonomy($taxonomy, $taxonomybyid->slug, $taxonomybyid->name);

            if ($obj->getresponse()) {

               $obj->manage_client_option('taxonomy_' . $taxonomy . '_' . $obj->getresponse(), $a_config['term_name'], 'set');

               if (function_exists('z_taxonomy_image_url'))
                  $obj->manage_client_option('taxonomy_img_' . $taxonomy . '_' . $obj->getresponse(), z_taxonomy_image_url($term_id), 'set');
            }
         }
         return;
      }

      function xmlrpc_edited_term($term_id, $tt_id) {

         global $a_config;
         $terms = get_option('taxonomy_' . $tt_id . '_' . $term_id);
         $taxonomybyid = get_term_by('id', $term_id, $tt_id);
         if ($terms) {
            foreach ($terms as $key => $val) {
               foreach ($val as $ln => $lanval) {
                  $a_config['term_name'][$key][$ln] = $lanval;
               }
            }
         }
         foreach (azull::get_sites() as $site) {
            $obj = new Xmlrpc_Client($site);
            $id = $obj->edit_taxonomy($tt_id, $taxonomybyid->slug, $taxonomybyid->name);
            if ($obj->getresponse()) {
               $obj->manage_client_option('taxonomy_' . $tt_id . '_' . $id, $a_config['term_name'], 'set');
               if (function_exists('z_taxonomy_image_url'))
                  $obj->manage_client_option('taxonomy_img_' . $tt_id . '_' . $id, z_taxonomy_image_url($term_id), 'set');
            }
         }
         return;
      }

      function xmlrpc_delete_term($term_id, $tt_id, $taxonomy, $deleted_term) {

         global $a_config;

         delete_option('taxonomy_' . $deleted_term->taxonomy . '_' . $deleted_term->term_id);

         foreach (azull::get_sites() as $site) {

            $obj = new Xmlrpc_Client($site);
            $obj->delete_taxonomy($deleted_term->taxonomy, $deleted_term->slug);

            if ($obj->getresponse()) {
               $obj->manage_client_option('taxonomy_' . $deleted_term->taxonomy . '_' . $obj->getresponse(), $a_config['term_name'], 'unset');
               if (function_exists('z_taxonomy_image_url'))
                  $obj->manage_client_option('taxonomy_img_' . $deleted_term->taxonomy . '_' . $obj->getresponse(), z_taxonomy_image_url($deleted_term->term_id), 'unset');
            }
         }
         return;
      }

      //add attachement on all website wheneever a new file is upoaded
      static function add_attachment($attachment_id) {

         foreach (azull::get_sites() as $site) {
            $obj = new Xmlrpc_Client($site);
            if (!$obj->test_connection())
               continue;

            $obj = new Xmlrpc_Client($site);
            $obj->add_attachment($attachment_id);
         }
      }

      //delete meida library from all client website
      static function delete_attachment($attachment_id) {
         foreach (azull::get_sites() as $site) {
            $obj = new Xmlrpc_Client($site);
            if (!$obj->test_connection())
               continue;

            $obj = new Xmlrpc_Client($site);
            $obj->delete_attachment($attachment_id);
         }
      }

      static function generate_pdf() {

         if (!isset($_GET['format']) || (isset($_GET['format']) && $_GET['format'] != 'pdf') || !isset($_GET['tpl']) || !isset($_GET['lng']))
            return;

         /* @remark:not supporting other template kept as an options.
          * @ref:using mpdf lib for generating pdf
          */

         switch ($_GET['tpl']) {
            case 0:
            case 1:
            case 2:
            default:
               require_once( AZULL_DIR . 'template/defaultPdf.php' );
               break;
         }

         //can add more templates check bulk action class        
         //todo:reset text domain here.. to make translation working....
         //setlocale(LC_ALL, $old_locale);	
         //$q_config['language'] = substr($old_locale, 0, 2);
      }

      static function bulk_action() {
         global $post_type;

         if ($_SERVER['SCRIPT_NAME'] == '/wp-admin/post-new.php')
            return;

         if ($_SERVER['SCRIPT_NAME'] == '/wp-admin/upload.php')
            return;

         if ($_SERVER['SCRIPT_NAME'] == '/cisin/wp-admin/post-new.php')
            return;

         if ($_SERVER['SCRIPT_NAME'] == '/cisin/wp-admin/upload.php')
            return;

         if (!isset($_GET['post_type']) && $post_type != 'post')
            return;

         if (isset($_GET['taxonomy']) && $_GET['taxonomy']!='post_tag')
            return;

         if (isset($_GET['post_type']) && $post_type == 'xml') {
            global $wp_list_table;
            $wp_list_table->_actions =  array(
            );
            return;
         }
         
         //Add this to allow tag editing - Tien - 24/4/2017
         if (isset($_GET['taxonomy']))
            return;
         if (isset($_GET['action']))
            return;

         global $wp_list_table, $wpdb;

         $current_user = wp_get_current_user();
         $admin_role = $current_user->roles;
         $userRole='';
         $user_object = get_userdata( get_current_user_id() );
         foreach($user_object->roles as $role){
           $userRole=$role;
         }
         $azullclients = array(); 

       /*  if (in_array("administrator", $admin_role)) {
            // client want hidden this untill there will be function
          //  $azullclients['importxml'] = __('Import(XML APP)', 'azull');
         //   $azullclients['exportxml'] = __('Export(XML APP)', 'azull');

            $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft'");
            if (isset($datas) && !empty($datas)):
               foreach ($datas as $data) {
                  $azullclients['action_' . $data->ID] = qtranxf_use(qtranxf_getLanguage(),$data->post_title);  
                  $azullclients['publish_' . $data->ID] = "--" . __('Publish', 'azull') . "/" . __('Update', 'azull');
                  $azullclients['unpublish_' . $data->ID] = "--" . __('Unpublish', 'azull');
                  $azullclients['remove_' . $data->ID] = "--" . __('Remove');
               }

            endif;
         }*/  

 
         if (isset($_GET['post_type']) && $_GET['post_type'] == 'property' && $userRole =='administrator') {
            if (isset($_GET['post_status']) && $_GET['post_status'] == 'publish') {
		  $wp_list_table->_actions =  array('email' => __('Send Emails', 'azull'),
                          'print' => __('Print', 'azull').'/'.__('PDF', 'azull'),
                          'unpublish' => __('Unpublish', 'azull'),
                          'remove' => __('Remove', 'azull'),
                          'copy_site' => __('Copy to site (publish on client site)', 'azull'),
                          'remove_site' => __('Remove from site (remove on client site)', 'azull'),
                          'rejected' => __('Reject', 'azull'),
                          'export' => __('Export', 'azull'),
                          'trash' => __('Move to Trash', 'azull')
                     );
	    }else if(isset($_GET['post_status']) && $_GET['post_status'] == 'draft'){
		  $wp_list_table->_actions =  array('email' => __('Send Emails', 'azull'),
                          'print' => __('Print', 'azull').'/'.__('PDF', 'azull'),
                          'publish' => __('Publish', 'azull'),
                          'remove' => __('Remove', 'azull'),
                          //'copy_site' => __('Copy to site (publish on client site)', 'azull'),
                          //'remove_site' => __('Remove from site (remove on client site)', 'azull'),
                          'publish_copy_site' => __('Publish and copy to site', 'azull'),
                          'rejected' => __('Reject', 'azull'),
                          'export' => __('Export', 'azull'),
                          'trash' => __('Move to Trash', 'azull')
                    );
	    }else if(isset($_GET['post_status']) && $_GET['post_status'] == 'rejected'){
               $wp_list_table->_actions =  array('email' => __('Send Emails', 'azull'),
                          'print' => __('Print', 'azull').'/'.__('PDF', 'azull'),
                          'publish' => __('Publish', 'azull'),
                          'remove' => __('Remove', 'azull'),
                          //'copy_site' => __('Copy to site (publish on client site)', 'azull'),
                          //'remove_site' => __('Remove from site (remove on client site)', 'azull'),
                          'publish_copy_site' => __('Publish and copy to site', 'azull'),
                          'export' => __('Export', 'azull'),
                          'trash' => __('Move to Trash', 'azull')
                    );
       }else{
		   @$wp_list_table->_actions =  array('email' => __('Send Emails', 'azull'),
                          'print' => __('Print', 'azull').'/'.__('PDF', 'azull'),
                          'publish' => __('Publish', 'azull'),
                          'unpublish' => __('Unpublish', 'azull'),
                          'remove' => __('Remove', 'azull'),
                          //'copy_site' => __('Copy to site (publish on client site)', 'azull'),
                          'remove_site' => __('Remove from site (remove on client site)', 'azull'),
                          'publish_copy_site' => __('Publish and copy to site', 'azull') ,
                          'rejected' => __('Reject', 'azull'),
                          'export' => __('Export', 'azull'),
                          'trash' => __('Move to Trash', 'azull')
                    ); 
	  }
         } else{
            @$wp_list_table->_actions =  array('email' => __('Send Emails', 'azull'),
                          'print' => __('Print', 'azull').'/'.__('PDF', 'azull')
                    ); 
            ?>
             
         <?php }

         if (isset($_GET['post_type']) && $_GET['post_type'] != 'property' && $_GET['post_type'] != 'xml') {
            $methods = $wp_list_table->get_bulk_actions();
            $wp_list_table->_actions = array_merge($methods, $azullclients);
         }

         if (!isset($_GET['post_type'])) {
            $methods = $wp_list_table->get_bulk_actions();
            $wp_list_table->_actions = array_merge($methods, $azullclients);
         }

         if (isset($_GET['taxonomy']) && $_GET['taxonomy']=='post_tag' && $_GET['post_type'] != 'property'){
            //$methods = $wp_list_table->get_bulk_actions();
            $wp_list_table->_actions =  array(
                 'remove' => __('Remove', 'azull'),
                 'copy_site' => __('Copy to site (publish on client site)', 'azull'),
                 'remove_site' => __('Remove from site (remove on client site)', 'azull'),
            );
            //$wp_list_table->_actions = array_merge($methods, $wp_list_table->_actions);
         }
         /*if (isset($post_type) && ($post_type=='post' || $post_type=='page') && $_GET['post_status']=='publish'){
            $wp_list_table->_actions =  array(
                 //'remove' => __('Remove', 'azull'),
                 'copy_site' => __('Copy to site (publish on client site)', 'azull'),
                 'remove_site' => __('Remove from site (remove on client site)', 'azull'),
            );
         }*/
         if (isset($post_type) && ($post_type=='post' || $post_type=='page' || $post_type=='infodays')){
            if ($_GET['post_status']=='publish'){
               $wp_list_table->_actions =  array(
                    //'remove' => __('Remove', 'azull'),
                    'copy_site' => __('Copy to site (publish on client site)', 'azull'),
                    'remove_site' => __('Remove from site (remove on client site)', 'azull'),
               );
            }else{
               $wp_list_table->_actions =  array(
                  'publish_copy_site' => __('Publish and copy to site', 'azull'),
                  'remove_site' => __('Remove from site (remove on client site)', 'azull')
               );
            }
         }
         ?>
         <script type="text/javascript">
            jQuery(document).ready(function() {
               jQuery('select[name=action2]').change(function(e) {
                  jQuery('#azullaction').val(jQuery(this).val());
                  jQuery('select[name=action2]').val(jQuery(this).val());
               });
            });
         </script>
         <?php
      }
   static function action_redirect() { 
      $post = '';
      global $wpdb;
      if (!isset($_GET['post_type']))
         return;

      if (isset($_GET['post_type']) && ($_GET['post_type'] == 'property' || $_GET['post_type'] == 'post' || $_GET['post_type'] == 'page' || $_GET['post_type'] == 'infodays')) {
         $url='';
		   $arrayEsky=array('orderby','s','post_status','post_type','m','cat','ref','pref','proprietor','country','fromPrice','toPrice','_feature_37','year','datemin','paged','mode','region','place','buildtype','penthouse','websites');
                foreach ($_GET as $key => $value) {
                     if(in_array($key,$arrayEsky)){
                       if($value != "")
                       $url .= '&'.$key.'='.$value;
                     }
                }	
            if (!isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == '' && !isset($_REQUEST['action2']) && $_REQUEST['action2'] == ''){
               return;
            }


            if ($_REQUEST['azullaction'] != 'export')
            {
               if (!session_id()) { session_start(); }
               unset($_SESSION['properties']);
            }
             /*Function for send email in action dropdown property*/  
            if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'email') {
               wp_redirect(get_admin_url() . 'tools.php?page=email&ids=' . base64_encode(serialize($_REQUEST['post'])));
               exit;
            }
            /*Function for print/pdf property*/  
            if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'print') {
               wp_redirect(get_admin_url() . 'tools.php?page=print&ids=' . base64_encode(serialize($_REQUEST['post'])));
               exit;
            }
             /*Function for publish property change status only*/  
            if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'publish')
            {
               if (isset($_REQUEST['post']) && !empty($_REQUEST['post'])) { 
                  foreach ($_REQUEST['post'] as $property_id) { 
                     // Update the post into the database
                     $wpdb->update('wp_posts',array('post_status'=>'publish'),array('ID' => $property_id));
                     //wp_update_post(array('ID' => $property_id,'post_status'=>'publish'));
                  }
                }
               //wp_redirect(get_admin_url() . 'edit.php?post_status=publish&post_type=property');
               wp_redirect(get_admin_url() . 'edit.php?msg=publish&'.$url);
               exit;
            }
            /*Function for Un-publish property change status only*/  
            if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'unpublish') {
                   if (isset($_REQUEST['post']) && !empty($_REQUEST['post'])) { 
                          foreach ($_REQUEST['post'] as $property_id) {
                              $p_client = get_post_meta($property_id, "_client", true);
                              if(isset($p_client) && !empty($p_client)){
                                 foreach ($p_client as $key => $clientId) {
                                    $wpdb->insert('wp_xml_record',array('path' => (integer) $property_id,'agentId' => (integer)$clientId,'status'=>0,'type'=>4)); 
                                 }
                              }
                              // Update the post into the database
                              $wpdb->update('wp_posts',array('post_status'=>'draft'),array('ID' => $property_id));
                              //wp_update_post(array('ID' => $property_id,'post_status'=>'draft'));
                          }
                   }
               //wp_redirect(get_admin_url() . 'edit.php?post_status=publish&post_type=property');
               wp_redirect(get_admin_url() . 'edit.php?msg=unpublish&'.$url);
               exit;
            } 
            /*Function for remove property first unpbulish then remove working using cron job*/  
            if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'remove') {
                   if (isset($_REQUEST['post']) && !empty($_REQUEST['post'])) { 
                          foreach ($_REQUEST['post'] as $property_id) { 
                              // Update the post into the database
                                  $wpdb->insert('wp_xml_record',array('path' => (integer) $property_id,'agentId' => 0,'status'=>0,'type'=>3)); 
                          }
                   }
              // wp_redirect(get_admin_url() . 'edit.php?post_status=publish&post_type=property');
              wp_redirect(get_admin_url() . 'edit.php?msg=remove&'.$url);
               exit;
            }
            /* Functions to publish property on client site and unpublish from client site*/
             if ($_REQUEST['azullaction'] == 'copy_site' || $_REQUEST['action2'] == 'copy_site') {
               if (isset($_REQUEST['post']) && !empty($_REQUEST['post']) && isset($_REQUEST['clients']) && !empty($_REQUEST['clients'])) { 
                  foreach ($_REQUEST['clients'] as $key => $clientId) {
                     foreach ($_REQUEST['post'] as $property_id) {
                        $sql = "SELECT * FROM wp_xml_record WHERE (status = 1 || status = 0) AND type = 2 AND agentId = $clientId AND path = $property_id";
                              $in_process_record = $wpdb->get_results($sql, ARRAY_A);
                        if (empty($in_process_record)) {
                           $wpdb->insert('wp_xml_record',array('path' => (integer) $property_id,'agentId' => (integer)$clientId,'status'=>0,'type'=>2));
                        } 
                    }
                  }
               }
               //wp_redirect(get_admin_url() . 'edit.php?post_status=publish&post_type=property');
               //wp_redirect(get_admin_url() . 'edit.php?msg=copysite&'.$url);
               $msg = 'copyproperty';
               switch ($_GET['post_type']) {
                  case 'property':
                     $msg = 'copyproperty';
                  break;
                  case 'post':
                     $msg = 'copypost';
                  break;
                  case 'page':
                     $msg = 'copypage';
                  break;
               }
               wp_redirect(get_admin_url() . 'edit.php?msg='.$msg.'&'.$url);
               exit;
            }
            //print('<pre>');print_r($_REQUEST);die;
         /* Functions to unpublish property on client site and unpublish from client site*/
              if ($_REQUEST['azullaction'] == 'remove_site' || $_REQUEST['action2'] == 'remove_site') {
                   if (isset($_REQUEST['post']) && !empty($_REQUEST['post']) && isset($_REQUEST['clients']) && !empty($_REQUEST['clients'])) { 
                        foreach ($_REQUEST['clients'] as $key => $clientId) {
                           foreach ($_REQUEST['post'] as $property_id) { 
                         $wpdb->insert('wp_xml_record',array('path' => (integer) $property_id,'agentId' => (integer)$clientId,'status'=>0,'type'=>4)); 
                          }
                        }
                   }
                  $msg = 'removeproperty';
                  switch ($_GET['post_type']) {
                     case 'property':
                        $msg = 'removeproperty';
                     break;
                     case 'post':
                        $msg = 'removepost';
                     break;
                     case 'page':
                        $msg = 'removepage';
                     break;
                  }
               wp_redirect(get_admin_url() . 'edit.php?msg='.$msg.'&'.$url);
               //wp_redirect(get_admin_url() . 'edit.php?post_status=publish&post_type=property');
               //wp_redirect(get_admin_url() . 'edit.php?msg=removesite&'.$url);
               exit;
            } 
               /* Functions to publish and copy property to selected clients*/
               if ($_REQUEST['azullaction'] == 'publish_copy_site' || $_REQUEST['action2'] == 'publish_copy_site') {
              //if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'publish_copy_site') {
                   if (isset($_REQUEST['post']) && !empty($_REQUEST['post']) && isset($_REQUEST['clients']) && !empty($_REQUEST['clients'])) { 
                        foreach ($_REQUEST['clients'] as $key => $clientId) {
                           foreach ($_REQUEST['post'] as $property_id) {
                              $sql = "SELECT * FROM wp_xml_record WHERE (status = 1 || status = 0) AND type = 6 AND agentId = $clientId AND path = $property_id";
                              $in_process_record = $wpdb->get_results($sql, ARRAY_A);
                              if (empty($in_process_record)) {
                                 $wpdb->insert('wp_xml_record',array('path' => (integer) $property_id,'agentId' => (integer)$clientId,'status'=>0,'type'=>6));   
                                }
                             }
                        }
                   }  

               ///wp_redirect(get_admin_url() . 'edit.php?post_status=publish&post_type=property');
               //wp_redirect(get_admin_url() . 'edit.php?msg=publishandcopysite&'.$url);
               $msg = 'publishcopyproperty';
               switch ($_GET['post_type']) {
                  case 'property':
                     $msg = 'publishcopyproperty';
                  break;
                  case 'post':
                     $msg = 'publishcopypost';
                  break;
                  case 'page':
                     $msg = 'publishcopypage';
                  break;
               }
               wp_redirect(get_admin_url() . 'edit.php?msg='.$msg.'&'.$url);
               exit;
            }
            //for reject any property
            if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'rejected')
            {
               if (isset($_REQUEST['post']) && !empty($_REQUEST['post'])) { 
                  foreach ($_REQUEST['post'] as $property_id){                           
                        /*code update to un-publish client sites*/
                        $allclientId = get_post_meta($property_id, '_client');
                        $clientIds = $allclientId[0];
                        if (!empty($clientIds)) {  
                           foreach ($clientIds as $cId) {
                              if(isset($cId) && $cId!=''){
                                 $wpdb->insert('wp_xml_record',array('path' => (integer) $property_id,'agentId' => (integer)$cId,'status'=>0,'type'=>4));  
                                  }
                              }
                        }                       
                     //update the post into the database
                     $wpdb->update('wp_posts',array('post_status'=>'rejected'),array('ID' => $property_id));
                  }
               }
               wp_redirect(get_admin_url() . 'edit.php?msg=reject&'.$url);
               exit;
            }

            //for export one or more properties in excel file
            if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'export')
            {
               if(isset($_REQUEST['action']) && $_REQUEST['action']=='azull-export'){
                 self::export_azull_properties(); 
               }else{
                  wp_redirect(get_admin_url() . 'admin.php?post_type=property&page=export-properties');
               }
               exit;
            }

         }

         if (isset($_GET['post_type']) && $_GET['post_type'] != 'property') {
            global $wpdb;
            $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
            $azullclients = array();
            $actioncounter = 0;

            if (isset($datas) && !empty($datas)):

               foreach ($datas as $data) {

                  if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'action_' . $data->ID) {
                     break;
                  }

                  if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'publish_' . $data->ID) {


                     //publish on client website....					    
                     if (isset($_REQUEST['post']) && !empty($_REQUEST['post'])) {

                        $client_arr = explode("_", $_REQUEST['azullaction']);
                        $client = array();
                        $client[] = $client_arr[1];

                        foreach ($_REQUEST['post'] as $property_id) {

                           update_post_meta($property_id, '_client', $client);

                           $obj = new Xmlrpc_Client($data->ID);
                           if (!$obj->test_connection())
                              continue;
                           //temp commented for check unpublish post event
                           //$remoteid = $obj->send_post_to($property_id);
                           $actioncounter++;
                        }
                     }
                  }
//print('<pre>');print_r($_REQUEST);die;
                  if (isset($_REQUEST['azullaction']) && $_REQUEST['azullaction'] == 'remove_' . $data->ID) {
                     //remove from the client website.....					    
                     if (isset($_REQUEST['post']) && !empty($_REQUEST['post'])) {

                        $client_arr = explode("_", $_REQUEST['azullaction']);
                        $client = array();
                        $client[] = $client_arr[1];

                        foreach ($_REQUEST['post'] as $property_id) {

                           $remove_arr = get_post_meta($property_id, '_client');
                           $remove_arr = $remove_arr[0];
                           $new_arr = array();

                           foreach ($remove_arr as $remove) {
                              if ($remove != $client_arr[1])
                                 $new_arr[] = $remove;
                           }

                           update_post_meta($property_id, '_client', $new_arr);

                           $obj = new Xmlrpc_Client($data->ID);
                           if (!$obj->test_connection())
                              continue;
                           //temp commented for check unpublish post event
                           //$obj->delete_post_single((integer) $property_id);
                           self::email_post_unpublish_bulk($property_id,$data->ID);
                           $actioncounter++;
                        }
                     }
                  }
               }
            endif;
         }

         return;
      }

      function export_azull_properties(){
         if (!session_id()) { session_start(); }
         $properties = $_SESSION['properties'];
         if (isset($properties) && !empty($properties)) {
            // output headers so that the file is downloaded rather than displayed
            $obj_subsciber = new Azull_Subscriber();
            $f_name = 'azull-properties-'.date("YmdHis").'.xls';
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header('Content-Description: File Transfer');
            //header("Content-type: text/xls");
            header('Content-type: application/xls; charset=utf-8');
            header("Content-Type: application/vnd.ms-excel");
            header("Content-Disposition: attachment; filename={$f_name}");
            header("Expires: 0");
            header("Pragma: public");
            // create a file pointer connected to the output stream
            $file = fopen('php://output', 'w');
            $columns = array(
               '',
               $obj_subsciber->getTranslatedString('en','nl','Reference'),
               $obj_subsciber->getTranslatedString('en','nl','Title'),
               $obj_subsciber->getTranslatedString('en','nl','Category'),
               $obj_subsciber->getTranslatedString('en','nl','Place'),
               $obj_subsciber->getTranslatedString('en','nl','Region'),
               $obj_subsciber->getTranslatedString('en','nl','Country'),
               $obj_subsciber->getTranslatedString('en','nl','Postal code'),
               $obj_subsciber->getTranslatedString('en','nl','Latitude'),
               $obj_subsciber->getTranslatedString('en','nl','Longitude'),
               $obj_subsciber->getTranslatedString('en','nl','Proprietor'),
               $obj_subsciber->getTranslatedString('en','nl','Proprietor Ref. No'),
               $obj_subsciber->getTranslatedString('en','nl','Proprietor Url'),
               $obj_subsciber->getTranslatedString('en','nl','Project Name'),
               $obj_subsciber->getTranslatedString('en','nl','Build Year'),
               $obj_subsciber->getTranslatedString('en','nl','Number of Bathrooms'),
               $obj_subsciber->getTranslatedString('en','nl','Number of Bedrooms'),
               $obj_subsciber->getTranslatedString('en','nl','Floor'),
               $obj_subsciber->getTranslatedString('en','nl','Floors'),
               $obj_subsciber->getTranslatedString('en','nl','Bank'),
               $obj_subsciber->getTranslatedString('en','nl','Penthouse'),
               $obj_subsciber->getTranslatedString('en','nl','Old Price'),
               $obj_subsciber->getTranslatedString('en','nl','Sales Price'),
               $obj_subsciber->getTranslatedString('en','nl','Build Size').' '.$obj_subsciber->getTranslatedString('en','nl','Dimensions'),
               $obj_subsciber->getTranslatedString('en','nl','Garden').' '.$obj_subsciber->getTranslatedString('en','nl','Dimensions'),
               $obj_subsciber->getTranslatedString('en','nl','Plot Size').' '.$obj_subsciber->getTranslatedString('en','nl','Dimensions'),
               $obj_subsciber->getTranslatedString('en','nl','Roof Terrace').' '.$obj_subsciber->getTranslatedString('en','nl','Dimensions'),
               $obj_subsciber->getTranslatedString('en','nl','Terrace').' '.$obj_subsciber->getTranslatedString('en','nl','Dimensions'),
               $obj_subsciber->getTranslatedString('en','nl','Useful Area').' '.$obj_subsciber->getTranslatedString('en','nl','Dimensions'),
               $obj_subsciber->getTranslatedString('en','nl','Distance').' '.$obj_subsciber->getTranslatedString('en','nl','From').' '.$obj_subsciber->getTranslatedString('en','nl','Airport'),
               $obj_subsciber->getTranslatedString('en','nl','Distance').' '.$obj_subsciber->getTranslatedString('en','nl','From').' '.$obj_subsciber->getTranslatedString('en','nl','Golf'),
               $obj_subsciber->getTranslatedString('en','nl','Distance').' '.$obj_subsciber->getTranslatedString('en','nl','From').' '.$obj_subsciber->getTranslatedString('en','nl','Main Road'),
               $obj_subsciber->getTranslatedString('en','nl','Distance').' '.$obj_subsciber->getTranslatedString('en','nl','From').' '.$obj_subsciber->getTranslatedString('en','nl','Restaurant'),
               $obj_subsciber->getTranslatedString('en','nl','Distance').' '.$obj_subsciber->getTranslatedString('en','nl','From').' '.$obj_subsciber->getTranslatedString('en','nl','Sea'),
               $obj_subsciber->getTranslatedString('en','nl','Distance').' '.$obj_subsciber->getTranslatedString('en','nl','From').' '.$obj_subsciber->getTranslatedString('en','nl','Shop'),
               $obj_subsciber->getTranslatedString('en','nl','Distance').' '.$obj_subsciber->getTranslatedString('en','nl','From').' '.$obj_subsciber->getTranslatedString('en','nl','Roof Terrace'),
               $obj_subsciber->getTranslatedString('en','nl','Property Features'),
               $obj_subsciber->getTranslatedString('en','nl','Property Status'),
               $obj_subsciber->getTranslatedString('en','nl','Post Status'),
               $obj_subsciber->getTranslatedString('en','nl','Publish date'),
               $obj_subsciber->getTranslatedString('en','nl','Modify Date'),
               $obj_subsciber->getTranslatedString('en','nl','Content')
            );
            fputcsv($file,$columns);
            $sno = 1;
            foreach ($properties as $property_id)
            { 
              $data = get_post($property_id, ARRAY_A);
               if (isset($data) && !empty($data)) {
                  $title = (isset($data['post_title']) && !empty($data['post_title']))?qtranxf_use('nl', $data['post_title']):' ';
                  $post_date = (isset($data['post_date']) && !empty($data['post_date']))?$data['post_date']:' ';
                  $content = (isset($data['post_content']) && !empty($data['post_content']))?strip_tags(qtranxf_use('nl', $data['post_content'])):' ';
                  $post_status = (isset($data['post_status']) && !empty($data['post_status']))?$data['post_status']:' ';
                  $post_modified = (isset($data['post_modified']) && !empty($data['post_modified']))?$data['post_modified']:' ';
                  if(isset($data['post_category'][0]) && !empty($data['post_category'][0])){
                         $category_term = get_term($data['post_category'][0],'category');
                         $category = (isset($category_term->name) && !empty($category_term->name))?ucwords(qtranxf_use('nl', $category_term->name)):' ';
                     }
                  $property_meta = get_post_meta($property_id);

                  if(isset($property_meta) && !empty($property_meta)){
                     $ref = (isset($property_meta['_nreal_id'][0]) && !empty($property_meta['_nreal_id'][0]))?$property_meta['_nreal_id'][0]:' ';
                     if(isset($property_meta['_place'][0]) && !empty($property_meta['_place'][0])){
                         $place_term = get_term($property_meta['_place'][0],'place');
                         $place = (isset($place_term->name) && !empty($place_term->name))?ucwords(qtranxf_use('nl', $place_term->name)):' ';
                     }
                     if(isset($property_meta['_region'][0]) && !empty($property_meta['_region'][0])){
                         $region_term = get_term($property_meta['_region'][0],'region');
                         $region = (isset($region_term->name) && !empty($region_term->name))?ucwords(qtranxf_use('nl', $region_term->name)):' ';
                     }
                     if(isset($property_meta['_country'][0]) && !empty($property_meta['_country'][0])){
                         $country_term = get_term($property_meta['_country'][0],'country');
                         $country = (isset($country_term->name) && !empty($country_term->name))?ucwords(qtranxf_use('nl', $country_term->name)):' ';
                     }
                     if(isset($property_meta['_proprietor'][0]) && !empty($property_meta['_proprietor'][0])){
                         $proprietor_term = get_term($property_meta['_proprietor'][0],'proprietor');
                         $proprietor = (isset($proprietor_term->name) && !empty($proprietor_term->name))?ucwords(qtranxf_use('nl', $proprietor_term->name)):' ';
                     }
                     $proprietorRef = (isset($property_meta['_proprietorRef'][0]) && !empty($property_meta['_proprietorRef'][0]))?$property_meta['_proprietorRef'][0]:' ';
                     $proprietorUrl = (isset($property_meta['_proprietorUrl'][0]) && !empty($property_meta['_proprietorUrl'][0]))?$property_meta['_proprietorUrl'][0]:'  ';
                     $project_name = (isset($property_meta['_propertyName'][0]) && !empty($property_meta['_propertyName'][0]))?$property_meta['_propertyName'][0]:' ';
                     $zip_code = (isset($property_meta['_zip'][0]) && !empty($property_meta['_zip'][0]))?$property_meta['_zip'][0]:' ';
                     $lat = (isset($property_meta['_lat'][0]) && !empty($property_meta['_lat'][0]))?$property_meta['_lat'][0]:' ';
                     $lng = (isset($property_meta['_lng'][0]) && !empty($property_meta['_lng'][0]))?$property_meta['_lng'][0]:' ';
                     $build_year = (isset($property_meta['_year'][0]) && !empty($property_meta['_year'][0]))?$property_meta['_year'][0]:' ';
                     $is_bank = (isset($property_meta['_bank'][0]) && !empty($property_meta['_bank'][0]) && $property_meta['_bank'][0]==1)?'Yes':'No';
                     $is_penthouse = (isset($property_meta['_penthouse'][0]) && !empty($property_meta['_penthouse'][0]) && $property_meta['_penthouse'][0]==1)?'Yes':'No';
                     $salesPrice = (isset($property_meta['_salesPrice'][0]) && !empty($property_meta['_salesPrice'][0]))?$property_meta['_salesPrice'][0]:' ';
                     $totalPrice = (isset($property_meta['_totalPrice'][0]) && !empty($property_meta['_totalPrice'][0]))?$property_meta['_totalPrice'][0]:' ';
                     $oldPrice = (isset($property_meta['_oldPrice'][0]) && !empty($property_meta['_oldPrice'][0]))?$property_meta['_oldPrice'][0]:' ';
                     if(isset($property_meta['_status'][0]) && !empty($property_meta['_status'][0])){
                        $status_term = get_term($property_meta['_status'][0],'status');
                        $status = (isset($status_term->name) && !empty($status_term->name))?ucwords(qtranxf_use('nl', $status_term->name)):' ';
                     }
                     $bathrooms = (isset($property_meta['_feature_36'][0]) && !empty($property_meta['_feature_36'][0]))?$property_meta['_feature_36'][0]:' ';
                     $bedrooms = (isset($property_meta['_feature_37'][0]) && !empty($property_meta['_feature_37'][0]))?$property_meta['_feature_37'][0]:' ';
                     $floor = (isset($property_meta['_feature_39'][0]) && !empty($property_meta['_feature_39'][0]))?$property_meta['_feature_39'][0]:' ';
                     $floors = (isset($property_meta['_feature_40'][0]) && !empty($property_meta['_feature_40'][0]))?$property_meta['_feature_40'][0]:' ';
                     $dimension_build_size = (isset($property_meta['_dimensions_81'][0]) && !empty($property_meta['_dimensions_81'][0]))?$property_meta['_dimensions_81'][0]:'  ';
                     $dimension_garden = (isset($property_meta['_dimensions_82'][0]) && !empty($property_meta['_dimensions_82'][0]))?$property_meta['_dimensions_82'][0]:' ';
                     $dimension_plot_size = (isset($property_meta['_dimensions_110'][0]) && !empty($property_meta['_dimensions_110'][0]))?$property_meta['_dimensions_110'][0]:' ';
                     $dimension_roof_terrace = (isset($property_meta['_dimensions_111'][0]) && !empty($property_meta['_dimensions_111'][0]))?$property_meta['_dimensions_111'][0]:' ';
                     $dimension_terrace = (isset($property_meta['_dimensions_112'][0]) && !empty($property_meta['_dimensions_112'][0]))?$property_meta['_dimensions_112'][0]:' ';
                     $dimension_useful_area = (isset($property_meta['_dimensions_113'][0]) && !empty($property_meta['_dimensions_113'][0]))?$property_meta['_dimensions_113'][0]:' ';
                     $distance_airport = (isset($property_meta['_scores_103'][0]) && !empty($property_meta['_scores_103'][0]))?$property_meta['_scores_103'][0]:' ';
                     $distance_golf = (isset($property_meta['_scores_104'][0]) && !empty($property_meta['_scores_104'][0]))?$property_meta['_scores_104'][0]:' ';
                     $distance_main_road = (isset($property_meta['_scores_105'][0]) && !empty($property_meta['_scores_105'][0]))?$property_meta['_scores_105'][0]:' ';
                     $distance_restaurant = (isset($property_meta['_scores_106'][0]) && !empty($property_meta['_scores_106'][0]))?$property_meta['_scores_106'][0]:' ';
                     $distance_sea = (isset($property_meta['_scores_107'][0]) && !empty($property_meta['_scores_107'][0]))?$property_meta['_scores_107'][0]:' ';
                     $distance_shop = (isset($property_meta['_scores_108'][0]) && !empty($property_meta['_scores_108'][0]))?$property_meta['_scores_108'][0]:' ';
                     $distance_roof_terrace = (isset($property_meta['_dimensions_113'][0]) && !empty($property_meta['_scores_109'][0]) && $property_meta['_scores_109'][0]!='')?$property_meta['_scores_109'][0]:' ';
                  }
                  $taxonomys= array('feature','interior','exterior','locality','view','banner','orientation');
                  $features = ' ';
                  foreach($taxonomys as $taxonomy){
                     $terms = wp_get_post_terms($property_id, $taxonomy);
                     if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                        $i=0;
                        foreach ( $terms as $term ) {
                           if(isset($term->name) && !empty($term->name)){
                              if($i>0){
                                $features .= ', '; 
                              }
                              $features .= ucwords(qtranxf_use('nl', $term->name));
                              $i++;
                           }          
                        }
                     }
                  }
                  
                  $row = array($sno,$ref,$title,$category,$place,$region,$country,$zip_code,$lat,$lng,$proprietor,$proprietorRef,$proprietorUrl,$project_name,$build_year,$bathrooms,$bedrooms,$floor,$floors,$is_bank,$is_penthouse,$oldPrice,$salesPrice,$dimension_build_size,$dimension_garden,$dimension_plot_size,$dimension_roof_terrace,$dimension_terrace,$dimension_useful_area,$distance_airport,$distance_golf,$distance_main_road,$distance_restaurant,$distance_sea,$distance_shop,$distance_roof_terrace,$features,$status,$post_status,$post_date,$post_modified,$content);
                  fputcsv($file, $row);
                  $sno++;
              }
            }
            fclose($file);
            unset($_SESSION['properties']);
         }else{
            wp_redirect(get_admin_url() . 'admin.php?page=export-properties');
         }
      }

      function email_post_unpublish_bulk( $post_id, $client ) {
     if(isset($post_id) && !empty($post_id)){
       //if($post->post_status!='auto-draft' && $post->post_type=='post'){
         $email = 'manoj.p@cisinlabs.com';
         $subject = 'Blog post unpublished on azull.biz';
         $message = 'A post was unpublished from bulk actions below is the post detail<br>';
         
         $message .= 'Client Id => '.$client.'<br>';
         $message .= 'Post Id => '.$post_id.'<br>';
         
         $ip = $_SERVER['REMOTE_ADDR'];
         $user = wp_get_current_user();
         $message .= 'User Ip => '.$ip.'<br>';
         $message .= 'User ID => '.$user->ID.'<br>';
         $message .= 'User Email => '.$user->user_email.'<br>';
         $message .= 'User Role => '.$user->roles[0].'<br>';
         if(isset($user) && !empty($user)){
           $user_meta = get_user_meta($user->ID);
           $f_name = (isset($user_meta['first_name'][0]))?$user_meta['first_name'][0]:'';
           $l_name = (isset($user_meta['last_name'][0]))?$user_meta['last_name'][0]:'';
           $message .= 'User First Name => '.$f_name.'<br>';
           $message .= 'User Last Name => '.$l_name.'<br>';
         }
         $message .= date("l jS \of F Y h:i:s A");
         $html = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
         $html .='<html xmlns="http://www.w3.org/1999/xhtml">';
         $html .='<head>';
         $html .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
         $html .='<title>' . $subject . '</title>';
         $html .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
         $html .='</head>';
         $html .='<body style="margin: 0; padding: 0;font-size:12px;">';
         $html .= $message;
         $html .='</body>';
         $html .='</html>';
         wp_mail($email, $subject, $html);
       //}
     }
   }
  /* Date : 11-Aug-2016
    * Method : function for get taxonomy (post tags) bulk action and process action accourdingly
    */
   function process_taxonomy_bulk_action() {
      if (isset($_REQUEST['post_type']) && $_REQUEST['post_type'] == 'post' && isset($_REQUEST['taxonomy']) && $_REQUEST['taxonomy'] == 'post_tag' && isset($_REQUEST['delete_tags']) && !empty($_REQUEST['delete_tags']) && isset($_REQUEST['action2']) && !empty($_REQUEST['action2'])) {
         global $wpdb;$url='';
         switch ($_REQUEST['action2']) {
            case 'copy_site':
               if (isset($_REQUEST['clients']) && !empty($_REQUEST['clients'])) {
                  foreach ($_REQUEST['clients'] as $key => $clientId) {
                     foreach ($_REQUEST['delete_tags'] as $tag_id) { 
                        $wpdb->insert('wp_xml_record',array('path' => (integer) $tag_id,'agentId' => (integer)$clientId,'status'=>0,'type'=>7)); 
                    }
                  }
                  wp_redirect(get_admin_url() . 'edit-tags.php?taxonomy=post_tag&azull=copy-site');
               }
            exit;
            break;
            case 'remove_site':
               if (isset($_REQUEST['clients']) && !empty($_REQUEST['clients'])) {
                  foreach ($_REQUEST['clients'] as $key => $clientId) {
                     foreach ($_REQUEST['delete_tags'] as $tag_id) { 
                   $wpdb->insert('wp_xml_record',array('path' => (integer) $tag_id,'agentId' => (integer)$clientId,'status'=>0,'type'=>8)); 
                    }
                  }
                  wp_redirect(get_admin_url() . 'edit-tags.php?taxonomy=post_tag&azull=remove-site');
                  exit;
               }
            break;
            case 'remove':
               foreach ($_REQUEST['delete_tags'] as $tag_id) {
                  $wpdb->insert('wp_xml_record',array('path' => (integer) $tag_id,'agentId' => (integer)$clientId,'status'=>0,'type'=>9)); 
               }
               wp_redirect(get_admin_url() . 'edit-tags.php?taxonomy=post_tag&azull=remove');
               exit;
            break;
         }
      }
   }

      static function restrict_wplogin() {
         global $pagenow;
         if (!is_user_logged_in() && $pagenow === 'wp-login.php')
            wp_redirect(site_url());
      }

      static function azull_preview_link($link) {

         if (!is_user_logged_in())
            return get_site_url();
         return $link;
      }

      static function check_username_password($login, $username, $password) {

         $referrer = $_SERVER['HTTP_REFERER'];

         if (!empty($referrer) && !strstr($referrer, 'wp-login') && !strstr($referrer, 'wp-admin')) {
            if ($username == "" || $password == "")
               wp_redirect(site_url("?login=empty"));
         }
      }

      static function front_end_login_fail($username) {
         $referrer = $_SERVER['HTTP_REFERER'];

         if (!empty($referrer) && !strstr($referrer, 'wp-login') && !strstr($referrer, 'wp-admin')) {
            wp_redirect(site_url('?login=failed'));
         }
      }

      static function remove_menus() {
         $theme = wp_get_theme('void');
         if ($theme->exists())
            remove_submenu_page('themes.php', 'customize.php');
      }

      static function restrict_frontend() {
         show_admin_bar(false);
      }

      /**
       * Load void theme textdomain.
       *
       * @since 1.0
       */
      static function azull_theme_setup() {


         load_theme_textdomain('azull', get_template_directory() . '/languages');
      }

      /**
       * Load plugin textdomain.
       * Note: langs folder contain qtranslate original .pot and .mo and must not be replaced
       * @since 1.0
       */
      function azull_load_textdomain() {
         $domain = 'azull';
         $locale = apply_filters('plugin_locale', get_locale(), $domain);
         load_textdomain($domain, trailingslashit(WP_LANG_DIR) . $domain . '/' . $domain . '-' . $locale . '.mo');
         load_plugin_textdomain($domain, FALSE, basename(dirname(__FILE__)) . '/languages/');
      }

      /*
       * If you find TinyMCE doesnt have enough depth, you can change the height to an arbitrary value using the	 *
       */

      function wptiny($initArray) {
         $initArray['height'] = '300px';
         return $initArray;
      }

      static function load_admin_things() {
         wp_enqueue_script('media-upload');
         wp_enqueue_script('thickbox');
         wp_enqueue_style('thickbox');
      }

      static function azull_setup() {
         register_nav_menu('top_pages', __('Top Menu', 'azull'));
         register_nav_menu('footer_pages', __('Bottom Menu', 'azull'));
      }

      static function register_location_page() {
         add_menu_page(__('Location', 'azull'), __('Location', 'azull'), 'manage_options', 't-location', array('azull', 'manage_options'), 'dashicons-location', 9);
         add_submenu_page('t-location', __('Country', 'azull'), __('Country', 'azull'), 'manage_options', 'edit-tags.php?taxonomy=country&post_type=property');
         add_submenu_page('t-location', __('Region', 'azull'), __('Region', 'azull'), 'manage_options', 'edit-tags.php?taxonomy=region&post_type=property');
         add_submenu_page('t-location', __('Provinces', 'azull'), __('Provinces', 'azull'), 'manage_options', 'edit-tags.php?taxonomy=provinces&post_type=property');
         add_submenu_page('t-location', __('Place', 'azull'), __('Place', 'azull'), 'manage_options', 'edit-tags.php?taxonomy=place&post_type=property');
         add_menu_page(__('Translation', 'azull'), __('Translation Table', 'azull'), 'manage_options', 'translation-page', array('azull', 'translation_table'), 'dashicons-list-view', 59);
      }

      static function register_location_page_office() {
         add_menu_page(__('Location', 'azull'), __('Location', 'azull'), 'manage_options', 't-location', array('azull', 'manage_options'), 'dashicons-location', 9);
         add_submenu_page('t-location', __('Place', 'azull'), __('Place', 'azull'), 'manage_options', 'edit-tags.php?taxonomy=place&post_type=property');
      } 


      function translation_table() {
         //phpinfo();
         /* ini_set('max_execution_time',900); // time consume by script
           set_time_limit(900); */
         
           /*$servername = "213.136.71.161";
           $username = "azull_realestate";
           $password = "azull2012realestate";
           $con = mysql_connect($servername, $username, $password);
           if (!$con) {
           die(mysql_error());
           } */


         /*$ch = curl_init();
         $url = 'http://www.azull.info/getInfo.php';
         curl_setopt($ch, CURLOPT_URL, $url);
         curl_setopt($ch, CURLOPT_POST, true);
         $postData = array('user' => 'cis', 'pass' => 'cis');
         curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
         //curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
         $output = curl_exec($ch);
         if (curl_errno($ch)) {
            print curl_error($ch);
         }
         curl_close($ch);
         $outputData = json_decode($output);
         var_dump($outputData);die('ok');

         if ($outputData->status == 1) {
            print_r($outputData->data);
         } else {
            echo $outputData->msg;
         }
         echo "Test";exit;*/

         //save server lables
      /*   if (isset($_POST['server_submit']) && $_POST['server_submit'] == 'Save translation') {
            unset($_POST[server_submit]);
            $translation = $_POST[azullString_s];
            $translation_json = json_encode($translation);
            update_option('azull_server_String', $translation_json);
         }*/

         /*code to create translation table xls sheet */
         /*$old_strings=get_option('azullString');
         $old_strings_val=json_decode($old_strings, ARRAY_A);
         //$file = fopen('/var/www/html/azulllive/wp-content/list.xls', 'w+');
         $file = fopen('/home/azullbiz/public_html/cisin/wp-content/translation-list1.csv', 'w+');
         fputcsv($file, array('English(En)','French(Fr)','Dutch(nl)'));
         //fputcsv($file, array('','',''));
         foreach ($old_strings_val as $values) {
            $en = (isset($values['en']) && !empty($values['en']))?$values['en']:'NA';
            $fr = (isset($values['fr']) && !empty($values['fr']))?$values['fr']:'NA';
            $nl = (isset($values['nl']) && !empty($values['nl']))?preg_replace('/\.[^.]+$/', '', $values['nl']):'NA';
            $row = array($en,$fr,$nl);
            fputcsv($file, $row);
         }
         
           fclose($file);
         die('done');*/

           $options = get_option('qtranslate_term_name'); 
           //echo '<pre>';
           //print_r($options);
         //$file = fopen('/var/www/html/azulllive/wp-content/list.xls', 'w+');
         
         /*$file = fopen('/home/azullbiz/public_html/cisin/wp-content/maptranslation-list1.csv', 'w+');
         fputcsv($file, array('','English(En)','French(Fr)','Dutch(nl)'));
         fputcsv($file, array('','','',''));

         foreach ($options as $key => $values) {
           fputcsv($file, array($key,'','',''));
            $en = (isset($values['en']) && !empty($values['en']))?$values['en']:'NA';
            $fr = (isset($values['fr']) && !empty($values['fr']))?$values['fr']:'NA';
            $nl = (isset($values['nl']) && !empty($values['nl']))?preg_replace('/\.[^.]+$/', '', $values['nl']):'NA';
            $row = array('',$en,$fr,$nl);
            fputcsv($file, $row);
           }
           die('doingtest');*/



         //save client side lable in server's options table as azullstring fields
         if (isset($_POST['submit']) && $_POST['submit'] == 'Save translation') {
            unset($_POST[submit]);
            $translation = $_POST[azullString];
            $translation_json = json_encode($translation);
            update_option('azullString', $translation_json);
         }
         //send data via xml-rpc and save to client's datadase options table
         if (isset($_POST['azullString']) && $_POST['azullString'] != '') {
            $translation = $_POST['azullString'];
            $translation_json = json_encode($translation);
            $sites = azull::get_sites(); // get all client sites
            foreach ($sites as $site) {
               $obj = new Xmlrpc_Client($site);
               $obj->manage_client_option('azullString', $translation_json, 'azullString');
            }
         }

         ?>

         <h2> Keywords Translation Table (For Clients)</h2>  
         <div id="col-left" style="float: left;background: #fff;border: 1px solid #ccc;width:48%; margin-right:20px;">
            <form action="" method="post" id="azull-static-string">
               <h3 style="border-bottom: 1px solid hsl(0, 0%, 80%);font-size: 14px;font-weight: normal;margin: 0;padding: 8px;" ><?php _e("Translate strings", "azull"); ?></h3>
               <?php
   
               global $aj_config, $post, $q_config,  $azullString ;
               $languages = qtranxf_getSortedLanguages();

               /**
                * This has been add to save Static word and string traslation
                * todo: need further optamization
                */
               $strings = array(
                   'Search on map click on the map to enable zoom',
                   'Property search',
                   'Country',
                   'Region',
                   'Place',
                   'Type',
                   'Minimum price',
                   'Maximum price',
                   'Number of Bedrooms',
                   'Search',
                   'First name',
                   'Last name',
                   'Email',
                   'Phone',
                   'Postal code',
                   'Your message',
                   'Click here for more info',
                   'Info days',
                   'Subscribe now',
                   'Testimonials',
                   'Not a member yet!',
                   'Your email',
                   'Sign up now',
                   'What is the result',
                   'Register',
                   'Copyright',
                   'All right reserved',
                   'Location to Office',
                   'Category',
                   'Build Year',
                   'Location',
                   'Sales Price',
                   'Total Price',
                   'Old Price',
                   'Related property',
                   'Azull club',
                   'Club login',
                   'Club registration',
                   'Your profile',
                   'Logout',
                   'Click to enable zoom',
                   'Loading Maps',
                   'Search term',
                   'Read more',
                   'What is the result',
                   'Submit',
                   'Property Details',
                   'Topic',
                   'Read more',
                   'Post comment',
                   'Find property location on google map',
                   'Mortgage Calculator',
                   'Phone number',
                   'Reference number',
                   'Save selection',
                   'Login now!',
                   'Nothing Found',
                   'Number of',
                   'Read More',
                   'Login failed: You have entered an incorrect email or password!',
                   'Please enter valid email!',
                   'Invalid email!',
                   'This email is already registered!',
                   'Please correct phone number!',
                   'User name already exists!',
                   'Registration failed!',
                   'Wrong math!',
                   'First',
                   'Previous',
                   'Last',
                   'Next',
                   'Leave a comment',
                   'Comment',
                   'Comments',
                   'Newer posts',
                   'Older posts',
                   'Property details sent on provided emails!',
                   'Search selection criteria saved!',
                   'Failed to save search selection criteria ! Try after some time.',
                   'Please enter your first name!',
                   'Please enter your last name!',
                   'Please correct postal code!',
                   'Please correct phone number!',
                   'Please enter email address!',
                   'Please enter valid email address!',
                   'Name',
                   'Email',
                   'Phone',
                   'Property reference',
                   'Message',
                   'Sent from',
                   'Failed to send your message! Try after some time.',
                   'Please enter at least one email address!',
                   'Please enter valide email address!',
                   'Failed to send email! Try after some time.',
                   'Comments are closed.',
                   'Newer Comments',
                   'Older Comments',
                   'Comment navigation',
                   'Comment navigation',
                   'One thought on',
                   'thoughts on',
                   'comments title',
                   'Leave a Reply',
                   'Leave a Reply to',
                   'Cancel Reply',
                   'Post Comment',
                   'Your email address will not be published',
                   'Estimation includes Tax(VAT), Notary, Lawyer, Transfer tax and Land Registry fee.',
                   'Page',
                   'of',
                   'Your profile',
                   'The passwords you entered do not match.  Your password was not updated',
                   'The Email you entered is not valid.  please try again.',
                   'This email is already used by another user.  try a different one.',
                   'My profile',
                   'Selection criteria',
                   'Nickname',
                   'House number',
                   'Street name',
                   'City/Place',
                   'State/Province',
                   'Country',
                   'Password',
                   'Repeat password',
                   'Biographical information',
                   'Login failed: You have entered an incorrect email or password, please try again.',
                   'Receive email when new post is published.',
                   'Receive email when a new property is listed.',
                   'Receive email when new property is listed matching your selection criteria.',
                   'Max price',
                   'Min price',
                   'Email this property',
                   'Get more Information on property',
                   'Update',
                   'Welcome to',
                   'Show',
                   'Registration IP',
                   'Registration language',
                   'Selection tags',
                   'Status',
                   'Requested by',
                   'Address',
                   'From',
                   'TESTIMONIALS',
                   'Property view',
                   'General Information',
                   'Location Information',
                   'Financial Information',
                   'Search Results for',
                   'Price',
                   'Go Back',
                   'Oops! That page can&rsquo;t be found',
                   'My favourites',
                   'My favourite',
                   'Mark as favorite',
                   'Remove from favorite',
                   'Ground floor',
                   'Sucessfully sent emails to',
                   'Sucessfully sent email to',
                   'Grnd',
                   'Client visibility:',
                   'Select one or more clients website.',
                   'Select post featured type.',
                   'Select post display layout.',
                   'Browser Title:',
                   'Keywords:',
                   'Description:',
                   'characters. Most search engines use a maximum of 160 chars for the description.',
                   'Featured Image',
                   'Project Name',
                   'Essential Information',
                   'System generated reference number.',
                   'Project Name',
                   'Zip:',
                   'Proprietor:',
                   '#P. Ref nbr:',
                   'Build year',
                   'Select banner for property image.',
                   'Select',
                   'Distance Score',
                   'Select one or more property',
                   'Show EPC',
                   'graph will be displayed as per selection',
                   'Agent check',
                   'energy efficiency rating(%)',
                   'Enter Number of',
                   'Add New Property Walk Score',
                   'Add  Country',
                   'Search  Country',
                   'Select category',
                   'Select view',
                   'Financial status',
                   'Build Type',
                   'Penthouse',
                   'Bank',
                   'Select features',
                   'Select exteriors',
                   'Select interiors',
                   'Select region',
                   'Select place',
                   'From sales price',
                   'To sales price',
                   'Build year',
                   'Publish date',
                   'Enter distance from',
                   'Add New Property Dimensions',
                   'Dimensions',
                   'in meters.',
                   'Essential Information',
                   'Client visibility:',
                   'System generated reference number.',
                   'Select one or more clients website.',
                   'Entery proprietor reference number.',
                   'Agent check',
                   'Select site',
                   'Province',
                   'Enter build year eg. (yyyy)',
                   'EPC energy efficiency rating (%)',
                   'EPC CO2 efficiency rating (%)',
                   'EPC energy',
                   'Layout',
                   'Select post display layout',
                   'Post settings',
                   'Offices settings',
                   'Slide settings',
                   'Adds settings',
                   'Infodays settings',
                   'Testimonials settings',
                   'Page settings',
                   'Property meta data',
                   'Property financial data',
                   'Add New Info days',
                   'Speaker',
                   'Form Titles',
                   'I want to subscribe for the info',
                   'I want more information on this property',
                   'Message Sent',
                   'my Azull',
                   'Loan Amount',
                   'Duration',
                   'Interest Rate',
                   'Monthly Repayments',
                   'Total to be re-paid',
                   'Use , for decimals',
                   'years',
                   'Loan amount is required.',
                   'Loan amount should be numeric.',
                   'Interest rate should be numeric.',
                   'Interest rate is required.',
                   'Duration should be numeric.',
                   'Duration is required.',
                   'Calculate',
                   'First Name',
                   'Last Name',
                   'Zip / Post Code',
                   'Re-enter Password',
                   'User Information',
                   'Please enter your email!',
                   'Please enter your message!',
                   'Please enter your address!',
                   'Processing',
                   'Submitted Successfully',
                   'Please enter your zip / post code!',
                   'Please enter your phone!',
                   'Speaker',
                   'URL(optional)',
                   'Last Modified Date',
                   'Successful registration, an email has been sent to',
                   'Last Modified',
                   'To set your password, visit the following address',
                   'Your username and password info',
                   'New user registration on your site',
                  'New User Registration',
                  'Notice of Password Change',
                  'This notice confirms that your email was changed on',
                  'If you did not change your email, please contact the Site Administrator at',
                  'This email has been sent to',
                  'Regards',
                  'All at',
                  'Hi',
                   'Please enter',
                   'Company',
                   'mi Azull',
                   'Please enter username and password!',
                   'No username specified',
                   'Login failed',
                   'I want more information',   
                   'Website',
                   'Weather Info',
                   'Temperature',
                   'Wind Speed',
                   'Pressure',
                   'Humidity',
                   'Temperature',
                   'Sunday',
                   'Monday',
                   'Tuesday',
                   'Wednesday',
                   'Thursday',
                   'Friday',
                   'Saturday',
                   'I agree',
                   'Welcome to',
                   'Explanation',
                   'What are cookies?',
                   'Form name',
                   'Post Date',
                   'Ip Address',
                   'Feedback List',
                   'Feedback Detail',
                   'Number Of People',
                   'IP Postal code',
                   'IP Country',
                   'Reference',
                   'Mortgage Calculator',
                   'Proprietor Address',
                   'Proprietor User Password',
                   'Proprietor User Name',
                   'Proprietor Website',
                   'Proprietor Email',
                   'Proprietor Phone',
                   'Proprietor Role',
                   'Proprietor Ref. No',
                   'Proprietor',
                   'Proprietor Url',
                   'Reference Number',
                   'Project Name',
                   'See location on map',
                   'Calculate',
                   'Click here to reset your password',
                   'Username',
                   'Hello',
                   'Lost your password?',
                   'You have requested to password reset for the following account',
                   'Property carousel',
                   'Property Map',
                   'Blocks',
                   'Video',
                   'Featured post',
                   'Provinces',
                   'Click here for pdf',
                   'This message confirms that your password has been changed on',
                   'If you have not changed your password, please contact the site administrator at',
                   'This email was sent to',
                   'This is a notification message that user have username',
                   'has been changed/reset their password on',
                   'This is a notification message that user has been changed their password for below account on',
                   'To set your password, visit the following address',
                   'Your username and password info',
                   'Password Lost/Changed',
                   'Password changed for user',
                   'Hello administrator',
                   'This notice confirms that your password was changed on',
                   'If you did not change your password, please contact the Site Administrator at',
                   'This email has been sent to',
                   'Password Reset',
                   'Someone has requested a password reset for the following account:',
                   'If this was a mistake, just ignore this email and nothing will happen.',
                   'To reset your password, visit the following address:',
                   'This is a notification that the next user set or changed his password.',
                   'With best regards',
                   'Notice of Email Change',
                   'This notice confirms that your email was changed on',
                   'If you did not change your email, please contact the Site Administrator at',
                   'Contact person',
                   'Price',
                   'Plan',
                   'Status',
                   'Phone',
                   'Proprietorship',
                   'Proprietor type',
                   'Agent Address',
                   'Agent Zip',
                   'Enter zip',
                   'Website',
                   'Enter website url',
                   'Comment',
                   'Enter proprietor price',
                   'Enter proprietor plan',
                   'Enter proprietor status',
                   'Enter proprietor contact person',
                   'Enter proprietor contact person email',
                   'Enter proprietor contact person phone',
                   'Enter proprietor comment',
                   'Enter house Number',
                   'Enter phone Number',
                   'Enter house Number',
                   'Enter City',
                   'Select country',
                   'The name is how it appears on your site.',
                   'Enter Agent email address',
                   'Enter Agent Login Username',
                   'Enter Agent Login password',
                   'GSM',
                   'Opening Hours',
                   'Enter project price list',
                   'Enter project plans',
                   'Enter project status',
                   'Enter project website URL',
                   'Enter street',
                   'GPS',
                   'Enter project GPS co-ordinates',
                   'Enter project contact person',
                   'Enter project contact email',
                   'Enter project contact phone',
                   'Enter project contact mobile phone',
                   'Enter project opening hours',
                   'Enter project comments',
                   'Projects',
                   'Project',
                   'Search Projects',
                   'Edit Project',
                   'Add New Project',
                   'Select Region',
                   'Select Place',
                   'Pricelist',
                   'Extra information',
                   'Azull photos',
                   'Title',
                   'Content',
                   'Latitude',
                   'Longitude',
                   'Number of Bathrooms',
                   'Floor',
                   'Floors',
                   'Banners',
                   'Orientations',
                   'Distance',
                   'Features',
                   'st',
                   'Location Translation',
                   'Location Translation List',
                   'Location Translation Name',
                   'Add',
                   'Edit',
                   'Visible Place Name',
                   'VAT',
                   'Enter proprietor VAT number',
                   'First name and last name are the same, not allowed!'
               );
           ///print_r($strings);die;

               foreach ($strings as $key => $string) :
                  $name = "static_string_" . $key;

                  echo '<div style="border-bottom: 1px dotted hsl(0, 0%, 70%);margin-bottom:5px;">';
                  echo '<div style="margin: 5px;     text-align: right;" class="epc_language-switcher">';
                  echo "&nbsp;|&nbsp;";

                  foreach ($languages as $lang) {

                     echo "<a href=\"javascript:" . $name . "_switch_lang('" . $lang . "')\" title='" . qtranxf_getLanguageName($lang) . "'>" . $q_config['language_name'][$lang] . "</a>&nbsp|&nbsp;";
                  }
                  echo '</div>';

                  $s = '';
                  $s .="<script type='text/javascript'>
                 //<![CDATA[
                         function " . $name . "_switch_lang(lang) {
                                 //Hide all
                                 ";
                  foreach ($languages as $lang):
                     $s .="jQuery('#" . $name . "_" . $lang . "-wrap').hide();";
                  endforeach;

                  $s .="//Show selected, recount chars
                         jQuery('#" . $name . "_'+lang+'-wrap').show();
                     }
                 //]]>
                 </script>";
                  echo $s;
    
                  foreach ($languages as $lang) {
                     $string = str_replace("\\", '', (isset($azullString[$name][$lang])) ? $azullString[$name][$lang] : $string);
                     ?>
                     <div class="azull-string-wrap" id="<?php echo $name . "_" . $lang; ?>-wrap">	                       		
                        <textarea <?php echo (($lang == 'en') ? 'readonly' : ""); ?> rows="1" style="width: 98%;margin: 5px;"  name='azullString[<?php echo $name; ?>][<?php echo $lang ?>]'><?php echo $string; ?></textarea>
                     </div>       
                     <?php
                  }
                  echo "
	                <script>
	                //<![CDATA[
	                       " . $name . "_switch_lang('" . $q_config['default_language'] . "');
	                //]]>
	                </script>
		     </div>";
               endforeach;
               ?>
               <input type="hidden" name="submit" value="<?php _e('Save translation', 'azull'); ?>" />

               <p class="submit" style="text-align: right;margin: 10px;">
                  <input type="submit" class="button-primary" value="<?php _e('Save translation', 'azull'); ?>" /></p>
            </form>
         </div>
         <?php /* ?>

         <div id="col-right" style="float: left;background: #fff;border: 1px solid #ccc;width:48%">
            <form action="" method="post" id="azull-server-string">
               <h3 style="border-bottom: 1px solid hsl(0, 0%, 80%);font-size: 14px;font-weight: normal;margin: 0;padding: 8px;" ><?php _e("Translate Server Strings", "azull"); ?></h3>
               <?php
               $azullString_s = json_decode(get_option('azull_server_String'), true);
               $languages_S = qtranxf_getSortedLanguages();

               /**
                * This has been add to save Static word and string traslation
                * todo: need further optamization
                
               // server related
               $strings_s = array(
                   'Keywords Translation Table',
                   'Translation Table',
                   'Azull adds',
                   'Testimonials',
                   'Azull offices',
                   'Media',
                   'Info days',
                   'Plugins',
                   'Websites',
                   'Extra',
                   'Translate Server Strings',
                   'Properties',
                   'Add Property',
                   'Locality',
                   'Status',
                   'Banner',
                   'Feature',
                   'Orientation',
                   'View',
                   'Exterior',
                   "Proprietor's",
                   'Walk Score',
                   'Dimensions',
                   'Add new office',
                   'Add New',
                   'Add adds',
                   'All Pages',
                   'Email',
                   'Members',
                   'Add New',
                   'Filter',
                   'All Users',
                   'Customize',
                   'Menus',
                   'Editor',
                   'you can enter range for build year and publish date. both values should be sperated by',
                   'Edit My Profile',
                   'Help',
                   'Available Tools',
                   'Permalinks',
                   'All Users',
                   'Proprietor',
                   'Search Proprietors',
                   'All Proprietors',
                   'Parent Proprietors',
                   'ParentProprietors',
                   'Edit Proprietors',
                   'Update Proprietors',
                   'Add New Proprietors',
                   'New Proprietors Name',
                   'Name',
                   'Proprietorship',
                   'Proprietor Email',
                   'Proprietor Username',
                   'Proprietor Password',
                   'Phone Number:',
                   'Agent Address:',
                   'Agent Zip:',
                   'Image',
                   'Enter website url',
                   'Enter zip',
                   'Select State/Region',
                   'Select country',
                   'Enter City',
                   'Enter street',
                   'Enter house Number',
                   'Enter phone Number',
                   'Enter Agent Login password',
                   'Enter Agent Login Username',
                   'Enter Agent email address',
                   'Agent',
                   'Owner',
                   'Builder',
                   'The name is how it appears on your site.',
                   'Interior',
                   'Search Property Interior',
                   'All Property Interior',
                   'Parent Property Interior',
                   'Edit Property Interior',
                   'Update Property Interior',
                   'Add New Property Interior',
                   'New Property Interior Name',
                   'Search Property Exterior',
                   'All Property Exterior',
                   'Edit Property Exterior',
                   'Update Property Exterior',
                   'Add New Property Exterior',
                   'New Property Exterior Name',
                   'Search Property View',
                   'Property Locality',
                   'Search Property Locality',
                   'All Property Locality',
                   'Edit Property Locality',
                   'Update Property Locality',
                   'Add New  Locality',
                   'New Locality Name',
                   'Locality',
                   'Category',
                   'Search Property Category',
                   'All Category',
                   'Parent Category',
                   'Parent Category',
                   'Edit Category',
                   'Update Category',
                   'Add New Category',
                   'New Category',
                   'Category',
                   'Add New Property',
                   'Add Property',
                   'Edit Property',
                   'New Property',
                   'View Property',
                   'Search Properties',
                   'No properties found',
                   'No properties found in Trash',
                   'Status',
                   'Search Property Status',
                   'All Property Status',
                   'Parent Property Status',
                   'Edit Property Status',
                   'Update Property Status',
                   'Add New Property Status',
                   'New Property Status Name',
                   'Search Property Banner',
                   'All Property Banner',
                   'Parent Property Banner',
                   'Edit Property Banner',
                   'Update Property Banner',
                   'Add New Property Banner',
                   'New Property Banner Name',
                   'Search Feature',
                   'All Property Feature',
                   'Parent Property Feature',
                   'Edit Property Feature',
                   'Update Property Feature',
                   'Add New Property Feature',
                   'New Feature Name',
                   'Feature',
                   'Search Property Orientation',
                   'All Property Orientation',
                   'Parent Property Orientation',
                   'Edit Property Orientation',
                   'Update Property Orientation',
                   'Add New Property Orientation',
                   'New Property Orientation Name',
                   'Orientation',
                   'Search Property View',
                   'All Property View',
                   'Parent Property View',
                   'Edit Property View',
                   'Update Property View',
                   'Add New Property View',
                   'New Property View Name',
                   'Include in search',
                   'Feature type',
                   'Will only apply to features with value',
                   'Select feature type',
                   'Check selection',
                   'Numeric value',
                   'Upload/Add image',
                   'Remove image',
                   'Property meta data',
                   'Property financial data',
                   'Property SEO meta',
                   'Keywords:',
                   'Description:',
                   'Browser Title:',
                   'Property Gallery',
                   'Note: Manage gallery for poperty',
                   'Manage gallery',
                   'Select proprietor',
                   'Entery proprietor reference number.',
                   'Enter build year eg.',
                   'Select property ',
                   'Enter Number of ',
                   'Select property ',
                   'graph will be displayed as per selection.',
                   'Show agent contact form',
                   'Show property agent',
                   'Additional Details',
                   'Field marked * will be accessiable on client website.',
                   'Agent',
                   'Select Property agent',
                   'Comission',
                   'Agent Commission',
                   '*Status',
                   'Select Financial status',
                   '*Old price',
                   'Enter old price.',
                   'Reservation amount',
                   'Enter reservation amount.',
                   'Monthly charges',
                   'Enter monthly charges.',
                   'More information',
                   'Build Type',
                   'Select Build type',
                   'Sales Price',
                   'Enter sales price',
                   'VAT',
                   'Enter value added tax in',
                   'Transmission tax',
                   'Enter transmission tax in',
                   'Stamp Duty',
                   'Enter stamp duty in',
                   'Notary costs',
                   'Enter notary costs in',
                   'Lawyer costs',
                   'Enter lawyer costs in',
                   'Utilities connection cost',
                   'Utilities connection cost',
                   'Buyer costs',
                   'Enter Buyer costs in',
                   'Total price',
                   'Total price in',
                   'Features',
                   'Exteriors',
                   'Interiors',
                   'Keywords Translation Table',
                   'for property image',
                   'Select property',
                   'Select penthouse',
                   'Applied for',
                   'Provinces',
                   'Add New Provinces',
                   'Add New office',
                   'Add New adds',
                   'Edit Info days',
                   'Search Info day',
                   'Edit adds',
                   'Search adds',
                   'Add New Testimonial',
                   'Edit Testimonial',
                   'Search Testimonial',
                   'Media Category',
                   'Edit Provinces',
                   'Edit Country',
                   'Edit Region',
                   'Add New Region',
                   'Speaker',
                   'Date',
                   'First Name',
                   'XML Feature Mapping',
                   'Map XML Feature to Azull Feature',
                   'XML Feature',
                   'The name is how it appears on your site.',
                   'Azull Features',
                   'XML Feature Name',
                   //'Agent Name',
                   'Feature Name',
                   'Modify Date',
                   'Add New XML Feature',
                   'items',
                   'URL(optional)',
                   'File Uploaded Successfully and started to upload',
                   'Please select Required fields or upload proper xml file',
                   'Import XML File',
                   'Upload XML file to insert property into the database',
                   'XML File',
                   'XML URL',
                   'Submit', 
                   'Both fields are required', 
                   'started to remove from',
                   'started to publish on', 
                   'Selected',
                   'Please select action to be performed on',
                   'Unpublish',
                   'Selected properties are published on',
                   'Selected properties are removed on', 
                   'Selected properties are unpublished on',
                   'Last Modified Date',
		   'To set your password, visit the following address',
                   'Your username and password info',
                   'New user registration on your site',
         	   'New User Registration',
         	   'Notice of Password Change',
         	   'This notice confirms that your email was changed on',
         	   'If you did not change your email, please contact the Site Administrator at',
         	   'This email has been sent to',
         	   'Regards',
         	   'All at',
         	   'Hi',
                   'Form Title',
		   'Shortcode',
                   'Forms',
                   'Form',
                   'of',
                   'Go',
                   'Apply',
                   'Delete',
                   'Bulk Actions',
                   'All',
                   'Forms Per Page',
                   'Edit',
                   'Delete this form',
                   'Textbox',
                   'Template Fields',
                   'Layout Elements',
                   'Textarea',
                   'Paswoord',
                   'hr',
                   'Text',
                   'Company',
		   'Send Emails',
		   'Print/Pdf',
		   'Publish',
                   'Unpublish',
		   'Remove',
		   'copy to site',
		   'remove from sites',
		   'language',
		   'email adress(es) to send email to',
		   'from email address',	
		   'format'
               );

               foreach ($strings_s as $key => $string) :
                  $name = "static_server_string_" . $key;
                  echo '<div style="border-bottom: 1px dotted hsl(0, 0%, 70%);margin-bottom:5px;">';
                  echo '<div style="margin: 5px; text-align: right;" class="epc_language-switcher">';
                  echo "&nbsp;|&nbsp;";
                  foreach ($languages_S as $lang) {

                     echo "<a href=\"javascript:" . $name . "_switch_lang('" . $lang . "')\" title='" . qtranxf_getLanguageName($lang) . "'>" . $q_config['language_name'][$lang] . "</a>&nbsp|&nbsp;";
                  }
                  echo '</div>';
                  $s = '';
                  $s .="<script type='text/javascript'>
                 //<![CDATA[
                         function " . $name . "_switch_lang(lang) {
                                 //Hide all
                                 ";
                  foreach ($languages_S as $lang):
                     $s .="jQuery('#" . $name . "_" . $lang . "-wrap').hide();";
                  endforeach;

                  $s .="//Show selected, recount chars
                         jQuery('#" . $name . "_'+lang+'-wrap').show();
                     }
                 //]]>
                 </script>";
                  echo $s;
                  foreach ($languages_S as $lang) {
                     ?>
                     <div class="azull-string-wrap" id="<?php echo $name . "_" . $lang; ?>-wrap">	                       		
                        <textarea <?php echo (($lang == 'en') ? 'readonly' : ""); ?> rows="1" style="width: 98%;margin: 5px;"  name='azullString_s[<?php echo $name; ?>][<?php echo $lang ?>]'><?php echo (isset($azullString_s[$name][$lang])) ? $azullString_s[$name][$lang] : $string; ?></textarea>
                     </div>       
                     <?php
                  }
                  echo "
	                <script>
	                //<![CDATA[
	                       " . $name . "_switch_lang('" . $q_config['default_language'] . "');
	                //]]>
	                </script>
		     </div>";
               endforeach;
               ?>
               <input type="hidden" name="server_submit" value="<?php _e('Save translation', 'azull'); ?>" />
               <p class="submit" style="text-align: right;margin: 10px;">
                  <input type="submit" class="button-primary" value="<?php _e('Save translation', 'azull'); ?>" /></p>
            </form>
         </div>

         <?php */
      }

      static function azull_hide_category($hook_suffix) {
         global $typenow;

         $terms = get_terms('category', 'orderby=id&hide_empty=0');

         if ($typenow == "property") {

            $style .="<style>";
            foreach ($terms as $term) {

               $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);


               if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'post') {
                  $style .="#category-" . $term->term_id . "{display:none!important;}";
                  $style .="#tag-" . $term->term_id . "{display:none!important;}";
               }
            }
            $style.="</style>";
         }



         if ($typenow == "post") {

            $style .="<style>";
            foreach ($terms as $term) {

               $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);


               if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'property') {
                  $style .="#category-" . $term->term_id . "{display:none!important;}";
                  $style .="#tag-" . $term->term_id . "{display:none!important;}";
               }
            }
            $style .="</style>";
         }

         echo $style;
      }

      static function custom_deregister_editor_expand() {
         wp_deregister_script('editor-expand');
      }

      static function MultiPostThumbnails() {
         if (class_exists('MultiPostThumbnails')) {

            new MultiPostThumbnails(array(
                'label' => 'Secondary Image',
                'id' => 'office-image',
                'post_type' => 'azulloffice'
            ));
         }
      }

//Import Data from Azull Live site
      static function azull_db_import_step_1() {
         return;
         //import and add it as new.
         //Todo :drop this fuction after making it live.
         //  require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
         // require_once(ABSPATH . "wp-admin" . '/includes/image.php');

         global $wpdb;
         ini_set('max_execution_time', 0); //300 seconds = 5 minutes		  

         $table_name = 'p35p6_nbreal_properties';
         $data_nbreal = $wpdb->get_results("SELECT * FROM " . $table_name, ARRAY_A);

         // echo count($data_nbreal);	  
//die;
         foreach ($data_nbreal as $nbreal) {

            /* $querystr = "SELECT post_id, count(post_id)
              FROM $wpdb->postmeta
              WHERE
              (meta_key = '_nreal_id' AND meta_value = '". $nbreal['nbreal_property_id']."')
              GROUP BY post_id;
              ";

              $postid=$wpdb->get_results($querystr, ARRAY_A); */

            //post-conent-start	
            $en_t = $nbreal['title'];
            $en_d = $nbreal['description'];

            $table = 'p35p6_falang_content';
            $fr_t = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=2", ARRAY_A);
            $fr_d = $wpdb->get_results("SELECT * FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=2", ARRAY_A);
            ;


            $nl_t = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='title' AND language_id=4", ARRAY_A);
            $nl_d = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=4", ARRAY_A);

            $title = "<!--:en-->" . $en_t . "<!--:-->";
            $title .="<!--:fr-->" . $fr_t[0]['value'] . "<!--:-->";
            $title .="<!--:nl-->" . $nl_t[0]['value'] . "<!--:-->";


            $content = "<!--:en-->" . $en_d . "<!--:-->";
            $content .="<!--:fr-->" . $fr_d[0]['value'] . "<!--:-->";
            $content .="<!--:nl-->" . $nl_d[0]['value'] . "<!--:-->";

            $property = array(
                'post_title' => $title,
                'post_content' => $content,
                'post_status' => 'publish',
                'post_type' => 'property',
                'post_name' => str_replace(" ", "-", $en_t),
                'post_name' => str_replace(" ", "-", $en_t)
            );

            $post_parent = wp_insert_post($property, false);

            //handle meta keyword start

            $en_kt = $nbreal['metakey'];
            $en_kd = $nbreal['metadesc'];

            $table = 'p35p6_falang_content';
            $fr_kt = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=2", ARRAY_A);
            $fr_kd = $wpdb->get_results("SELECT * FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='metadesc' AND language_id=2", ARRAY_A);
            ;

            $nl_kt = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='metakey' AND language_id=4", ARRAY_A);
            $nl_kd = $wpdb->get_results("SELECT value FROM " . $table . " Where reference_id=" . $nbreal['nbreal_property_id'] . " AND reference_table='nbreal_properties' AND reference_field='description' AND language_id=4", ARRAY_A);

            $ktitle = "<!--:en-->" . $en_kt . "<!--:-->";
            $ktitle .="<!--:fr-->" . $fr_kt[0]['value'] . "<!--:-->";
            $ktitle .="<!--:nl-->" . $nl_kt[0]['value'] . "<!--:-->";

            $kcontent = "<!--:en-->" . $en_kd . "<!--:-->";
            $kcontent .="<!--:fr-->" . $fr_kd[0]['value'] . "<!--:-->";
            $kcontent .="<!--:nl-->" . $nl_kd[0]['value'] . "<!--:-->";

            update_post_meta($post_parent, 'property_meta:title', $title);
            update_post_meta($post_parent, 'property_meta:keywords', $ktitle);
            update_post_meta($post_parent, 'property_meta:description', $kcontent);
            //handle meta keyword end
            //handle post image and gallery
            //p35p6_nbreal_files

            $gallery_table = 'p35p6_nbreal_files';

            $gallerys_nbreal = $wpdb->get_results("SELECT * FROM " . $gallery_table . " where nbreal_property_id=" . $nbreal['nbreal_property_id'] . ' ORDER BY ordering ASC', ARRAY_A);
            $uploads = wp_upload_dir();

            $i = 0;
            $gallery = array();
            foreach ($gallerys_nbreal as $gallery_nbreal) {

               $file_name = $uploads['basedir'] . '/original/' . $nbreal['nbreal_property_id'] . "/" . $gallery_nbreal['file_title'];
               $file_name_new = $uploads['path'] . "/" . $gallery_nbreal['file_title'];

               $wp_filetype = wp_check_filetype($file_name, null);

               if (!file_exists($file_name_new)) {
                  copy($file_name, $file_name_new);
               }

               $attachment = array(
                   'guid' => $uploads['url'] . "/" . $gallery_nbreal['file_title'],
                   'post_mime_type' => $wp_filetype['type'],
                   'post_title' => preg_replace('/\.[^.]+$/', '', $gallery_nbreal['file_title']),
                   'post_name' => preg_replace('/\.[^.]+$/', '', $gallery_nbreal['file_title']),
                   'post_content' => '',
                   'post_parent' => $post_parent,
                   'post_status' => 'inherit'
               );


               $attachment_id = wp_insert_attachment($attachment, $file_name_new, $post_parent);
               $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_name_new);
               wp_update_attachment_metadata($attachment_id, $attachment_data);

               if ($attachment_id && $i == 0):
                  update_post_meta($post_parent, '_thumbnail_id', $attachment_id);
               else:
                  $gallery[] = $attachment_id;
               endif;

               $i++;
            }

            if (!empty($gallery)) {
               $encode = base64_encode(json_encode($gallery));
               update_post_meta((integer) $post_parent, 'property_gallery', $encode);
            }

            update_post_meta($post_parent, '_nreal_id', (integer) $nbreal['nbreal_property_id']);
            //end handle post image
            $gallery = array();
            echo $post_parent . "<br>";
         }
      }

      static function azull_db_import_step_2() {

         require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
         global $wpdb;
         ini_set('max_execution_time', 0); //300 seconds = 5 minutes

         $table_name = 'p35p6_nbreal_properties';
         //$table_name = 'p35p6_nbreal_frelations';
         $data_nbreal = $wpdb->get_results("SELECT * FROM " . $table_name, ARRAY_A);

         foreach ($data_nbreal as $nbreal) {

            $querystr = "SELECT post_id, count(post_id) FROM $wpdb->postmeta	WHERE (meta_key = '_nreal_id' AND meta_value = '" . $nbreal['nbreal_property_id'] . "') GROUP BY post_id;";
            $postid = $wpdb->get_results($querystr, ARRAY_A);

            /* if($nbreal['n_floors']!='' )
              update_post_meta( $postid[0]['post_id'], '_feature_40',$nbreal['n_floors'] );//Floors
              if($nbreal['floor_n']!='' )
              update_post_meta( $postid[0]['post_id'], '_feature_39',$nbreal['floor_n'] );//Floor
              if($nbreal['n_bedrooms']!='' )
              update_post_meta( $postid[0]['post_id'], '_feature_37',$nbreal['n_bedrooms'] );//Bedrooms
              if($nbreal['n_bathrooms']!='' )
              update_post_meta( $postid[0]['post_id'], '_feature_36',$nbreal['n_bathrooms'] );//Bathrooms */



            //update post meta start
            //finincial data...
            //if(isset($nbreal['plus_info']) )
            //update_post_meta($postid[0]['post_id'], '_moreInformation',$nbreal['plus_info'] );	

            /*  $f_nbreal = $wpdb->get_results("SELECT * FROM p35p6_nbreal_financials WHERE nbreal_financial_id=".(int)$nbreal['nbreal_financial_id'], ARRAY_A);

              update_post_meta($postid[0]['post_id'],'_salesPrice',$f_nbreal[0]['sales_price']) ;
              update_post_meta($postid[0]['post_id'],'_totalPrice',$f_nbreal[0]['total_price']) ;
              update_post_meta($postid[0]['post_id'],'_oldPrice',$f_nbreal[0]['old_price']) ;

              update_post_meta($postid[0]['post_id'],'_commissionPer',$f_nbreal[0]['comission']) ;
              update_post_meta($postid[0]['post_id'],'_reservationAmount',$f_nbreal[0]['reservation_amount']) ;
              update_post_meta($postid[0]['post_id'],'_monthlyCharges',$f_nbreal[0]['monthly_community_fee']) ; */

            //locaton lat logn...
            /* $location_nbreal=$wpdb->get_results("SELECT * FROM p35p6_nbreal_locations WHERE nbreal_location_id=".$nbreal['nbreal_location_id'], ARRAY_A);

              update_post_meta($postid[0]['post_id'],'_lat',$location_nbreal[0]['latitude']) ;
              update_post_meta($postid[0]['post_id'],'_log',$location_nbreal[0]['longitude']) ;
              update_post_meta($postid[0]['post_id'],'_zip',$location_nbreal[0]['zipcode']) ;


              //all other post meta
              update_post_meta( $postid[0]['post_id'], '_year',$nbreal['construction_year'] );
              update_post_meta( $postid[0]['post_id'], '_propertyName',$nbreal['project_name'] );

              $nbreal_frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=".(int)$nbreal['nbreal_property_id'], ARRAY_A);


              //Todo: hand translation for these taxnomy manually....

              // dimensions has two value form nb_realpropety table, and rest in nbreal_relation table.
              update_post_meta( $postid[0]['post_id'], '_dimensions_81',$nbreal['construction_area']); //Build size
              update_post_meta( $postid[0]['post_id'], '_dimensions_110',$nbreal['total_area'] );//Plot size
              foreach ($nbreal_frelations as $nbreal_frelation){

              ////dimensions has
              if($nbreal_frelation['nbreal_feature_id']==72 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_dimensions_113',$nbreal_frelation['value'] );//Useful area

              if($nbreal_frelation['nbreal_feature_id']==26 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_dimensions_82',$nbreal_frelation['value'] );//garden

              // if($nbreal_frelation['nbreal_feature_id']=='' && $nbreal_frelation['value']!='' )
              // update_post_meta( $postid[0]['post_id'], '_dimensions_111',$nbreal_frelation['value'] );//Roof terrace

              if($nbreal_frelation['nbreal_feature_id']==43 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_dimensions_112',$nbreal_frelation['value'] );//Terrace

              //walkscores....
              if($nbreal_frelation['nbreal_feature_id']==53 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_scores_107',$nbreal_frelation['value'] );//sea

              if($nbreal_frelation['nbreal_feature_id']==54 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_scores_103',$nbreal_frelation['value'] ); //airport

              if($nbreal_frelation['nbreal_feature_id']==55 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_scores_104',$nbreal_frelation['value'] );//golf

              if($nbreal_frelation['nbreal_feature_id']==57 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_scores_106',$nbreal_frelation['value'] );//resteurent

              if($nbreal_frelation['nbreal_feature_id']==56 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_scores_108',$nbreal_frelation['value'] );//shop

              if($nbreal_frelation['nbreal_feature_id']==60 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_scores_105',$nbreal_frelation['value'] );//main road

              if($nbreal_frelation['nbreal_feature_id']==51 && $nbreal_frelation['value']!='' )
              update_post_meta( $postid[0]['post_id'], '_scores_109',$nbreal_frelation['value'] );//Solarium
              } */





            /*    $view=array(1=>60,2=>61,3=>62,4=>63,5=>64,6=>65,7=>66,8=>67,9=>68);
              if(array_key_exists($nbreal['nbreal_tview_id'], $view) )
              wp_set_object_terms( $postid[0]['post_id'], (array)$view[$nbreal['nbreal_tview_id']], 'view',false);

              $localty=array(1=>21,2=>22,3=>23);
              if(array_key_exists($nbreal['nbreal_tarea_id'], $localty) )
              wp_set_object_terms($postid[0]['post_id'], (array)$localty[$nbreal['nbreal_tarea_id']], 'locality',false);


              $banner=array(1=>32,2=>33,3=>34,4=>35);
              if(array_key_exists($nbreal['nbreal_ribbon_id'], $banner) )
              wp_set_object_terms($postid[0]['post_id'], (array)$banner[$nbreal['nbreal_ribbon_id']], 'banner',false);


              $orientation=array(1=>51,2=>52,3=>53,4=>54,5=>55,6=>58,7=>56,8=>57,9=>59);
              if(array_key_exists($nbreal['nbreal_facing_id'], $orientation) )
              wp_set_object_terms($postid[0]['post_id'], array($orientation[$nbreal['nbreal_facing_id']]), 'orientation',false);


              $categories=array(1=>10,2=>11,3=>12,4=>13);
              if(array_key_exists($nbreal['nbreal_category_id'],$categories) )
              wp_set_object_terms( $postid[0]['post_id'], (array)$categories[$nbreal['nbreal_category_id']], 'category',false);

              $status=array(1=>24,2=>25,3=>26,4=>27,5=>28,6=>29,7=>30,8=>31);

              if(array_key_exists($nbreal['nbreal_condition_id'], $status) ){
              update_post_meta($postid[0]['post_id'], '_status',$status[$nbreal['nbreal_condition_id']]);
              wp_set_object_terms($postid[0]['post_id'], (array)$status[$nbreal['nbreal_condition_id']], 'status',true);
              //bank...
              if($nbreal['nbreal_condition_id']==3)
              update_post_meta($postid[0]['post_id'],'_bank', 1);
              }

              if($nbreal['nbreal_condition_id']==1 ){
              update_post_meta($postid[0]['post_id'], '_buildType',1);

              }else{
              update_post_meta($postid[0]['post_id'], '_buildType',2);
              }


              if($nbreal['enabled']==0){
              $my_post = array( 'ID' => $postid[0]['post_id'],'post_status' => 'draft');
              wp_update_post( $my_post );} */

            //provinces has to be added and assigned form xls sheet which do not have traslation too...

            echo $postid[0]['post_id'] . "<br>";
            $nbreal_frelations = array();
         }
      }

      static function azull_db_import_step_3() {
         require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
         global $wpdb;
         ini_set('max_execution_time', 0); //300 seconds = 5 minutes  
         //$features_val=array(26,43,72,53,54,55,57,56,60,51);

         $features = array(36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50);


         $exteriors = array(69, 70, 71, 72, 73, 74, 76, 77, 79, 78, 80, 75);
         $interiors = array(83, 84, 85, 86, 87, 88, 92, 89, 90, 91, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102);

         $frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_features", ARRAY_A);


         /* foreach ($frelations as $frelation){
           //if(!in_array($frelation['nbreal_feature_id'],$features_val)){
           //echo $frelation['nbreal_feature_id']."<br>";

           //if(in_array($frelation['nbreal_feature_id'],$features))
           //wp_insert_term( $frelation['title'], 'feature');

           if(in_array($frelation['nbreal_feature_id'],$exteriors))
           wp_insert_term( $frelation['title'], 'exterior');

           if(in_array($frelation['nbreal_feature_id'], $interiors))
           wp_insert_term( $frelation['title'], 'interior');

           } */



         //fix err in step 2


         /* $regions_nbreal = $wpdb->get_results("SELECT * FROM  p35p6_nbreal_regions", ARRAY_A);		    

           foreach($regions_nbreal as $region){
           $region_terms = wp_insert_term( $region['title'], 'region');
           update_option('azull_taxonomy_meta_'.$region_terms, array('country'=>116));

           } */


         //create city/place taxnomy
         /* $city_nbreal=$wpdb->get_results("SELECT * FROM p35p6_nbreal_cities", ARRAY_A);
           foreach($city_nbreal as $place){

           //echo $place = wp_insert_term( $place['title'], 'place');
           $regions=$wpdb->get_results("SELECT * FROM  p35p6_nbreal_regions where nbreal_region_id=".$place['nbreal_region_id'], ARRAY_A);

           $term = get_term_by('name',  $regions[0]['title'], 'region');
           $term_city = get_term_by('name', $place['title'], 'place');

           echo update_option('azull_taxonomy_meta_'. $term_city->term_id, array('country'=>116,'region'=>$term->term_id));

           } */

         //create proprietor
         /* $nbreal_builders=$wpdb->get_results("SELECT * FROM p35p6_nbreal_builders", ARRAY_A);

           foreach($nbreal_builders as $builders){

           $builders_terms=wp_insert_term( $builders['title'], 'proprietor',array('description'=> $builders['plus_info'].$builders['website']));

           $meta=array('type'=>3,
           'email'=>$builders['email'],
           'phone'=>$builders['phone'],
           'mobile'=>$builders['mobile'],
           );
           if($builders_terms)
           update_option('azull_taxonomy_meta_'. $builders_terms, $meta);
           }
           return; */

         /* $regions_nbreal=$wpdb->get_results("SELECT * FROM  p35p6_nbreal_regions", ARRAY_A);				    
           foreach($regions_nbreal as $region){

           $term = get_term_by('name', $region['title'], 'region');
           update_option('azull_taxonomy_meta_'.$term->term_id, array('country'=>60));
           echo $term->term_id."--";
           } */

         //create city/place taxnomy
         /* $city_nbreal=$wpdb->get_results("SELECT * FROM p35p6_nbreal_cities", ARRAY_A);
           foreach($city_nbreal as $place){
           $regions=$wpdb->get_results("SELECT * FROM  p35p6_nbreal_regions where nbreal_region_id=".$place['nbreal_region_id'], ARRAY_A);
           $term = get_term_by('name',  $regions[0]['title'], 'region');
           $city = get_term_by('name', $place['title'], 'place');
           update_option('azull_taxonomy_meta_'.$city->term_id, array('country'=>60,'region'=>$term->term_id));
           echo  $city->term_id;
           } */



         //Second pahse
         $table_name = 'p35p6_nbreal_properties';

         $data_nbreal = $wpdb->get_results("SELECT * FROM " . $table_name, ARRAY_A);

         foreach ($data_nbreal as $nbreal) {

            $querystr = "SELECT post_id, count(post_id) FROM $wpdb->postmeta	WHERE (meta_key = '_nreal_id' AND meta_value = '" . $nbreal['nbreal_property_id'] . "') GROUP BY post_id;";
            $postid = $wpdb->get_results($querystr, ARRAY_A);

            $nbreal_frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_frelations WHERE nbreal_property_id=" . (int) $nbreal['nbreal_property_id'], ARRAY_A);
            $f = array();
            $e = array();
            $i = array();

            foreach ($nbreal_frelations as $nbreal_frelation) {

               $frelations = $wpdb->get_results("SELECT * FROM p35p6_nbreal_features where nbreal_feature_id=" . (int) $nbreal_frelation['nbreal_feature_id'], ARRAY_A);

               $fid = get_term_by('name', $frelations[0]['title'], 'feature');
               $eid = get_term_by('name', $frelations[0]['title'], 'exterior');
               $iid = get_term_by('name', $frelations[0]['title'], 'interior');

               if (in_array($nbreal_frelation['nbreal_feature_id'], $features))
                  $f[] = $fid->term_id;

               if (in_array($nbreal_frelation['nbreal_feature_id'], $exteriors))
                  $e[] = $eid->term_id;

               if (in_array($nbreal_frelation['nbreal_feature_id'], $interiors))
                  $i[] = $iid->term_id;
            }

            if (!empty($f))
               wp_set_object_terms($postid[0]['post_id'], $f, 'feature', false);

            if (!empty($e))
               wp_set_object_terms($postid[0]['post_id'], $e, 'exterior', false);

            if (!empty($i))
               wp_set_object_terms($postid[0]['post_id'], $i, 'interior', false);

            $builders = $wpdb->get_results("SELECT * FROM p35p6_nbreal_builders WHERE nbreal_builder_id=" . $nbreal['nbreal_builder_id'], ARRAY_A);

            if (isset($builders[0]['title']) && $builders[0]['title'] != '') {
               $term = get_term_by('name', $builders[0]['title'], 'proprietor');
               wp_set_object_terms($postid[0]['post_id'], array($term->term_id), 'proprietor', false);
               update_post_meta($postid[0]['post_id'], '_proprietor', $term->term_id);
            }

            $locations_nbreal = $wpdb->get_results("SELECT * FROM p35p6_nbreal_locations WHERE nbreal_location_id=" . $nbreal['nbreal_location_id'], ARRAY_A);

            $city = $wpdb->get_results("SELECT * FROM p35p6_nbreal_cities WHERE nbreal_city_id=" . $locations_nbreal[0]['nbreal_city_id'], ARRAY_A);
            if (isset($city[0]['title']) && $city[0]['title'] != '') {
               $term = get_term_by('name', $city[0]['title'], 'place');
               wp_set_object_terms($postid[0]['post_id'], array($term->term_id), 'place', false);
               update_post_meta($postid[0]['post_id'], '_place', $term->term_id);
            }

            $region = $wpdb->get_results("SELECT * FROM p35p6_nbreal_regions WHERE nbreal_region_id=" . $locations_nbreal[0]['nbreal_region_id'], ARRAY_A);

            if (isset($region[0]['title']) && $region[0]['title'] != '') {
               $term = get_term_by('name', $region[0]['title'], 'region');
               wp_set_object_terms($postid[0]['post_id'], array($term->term_id), 'region', false);
               update_post_meta($postid[0]['post_id'], '_region', $term->term_id);
            }

            wp_set_object_terms($postid[0]['post_id'], array(60), 'country', false);
            update_post_meta($postid[0]['post_id'], '_country', 60);


            // if(isset($taxonomy_meta['provinces']) && $taxonomy_meta['provinces']!=''){
            // wp_set_object_terms($postid[0]['post_id'], array((integer)$taxonomy_meta['provinces']), 'provinces',false);
            //update_post_meta($postid[0]['post_id'], '_province',  (integer)$taxonomy_meta['provinces']);
            //}
            //asign proprietor

            $nbreal_builder = $wpdb->get_results("SELECT * FROM p35p6_nbreal_builders nbreal_builder_id=" . $nbreal['nbreal_builder_id'], ARRAY_A);
            $terms = get_term_by('name', $nbreal_builde[0]['title'], 'proprietor');
            if ($terms->term_id != '') {
               wp_set_object_terms($postid[0]['post_id'], array($terms->term_id), 'proprietor', false);
               update_post_meta($postid[0]['post_id'], '_proprietor', $terms->term_id);
            }

            $term_list = wp_get_post_terms($postid[0]['post_id'], 'place', array("fields" => "ids"));
            $taxonomy_m = get_option('azull_taxonomy_meta_' . $term_list[0]);
            $t = '';
            $provinces = get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));
            foreach ($provinces as $province) {
               $taxonomy_metap = get_option('azull_taxonomy_meta_' . $province->term_id);
               if ($taxonomy_metap['region'] == $taxonomy_m['region']) {
                  $t = $province->term_id;
               }
            }

            if ($t != '') {
               wp_set_object_terms((int) $postid[0]['post_id'], array((integer) $t), 'provinces', true);
               update_post_meta((int) $postid[0]['post_id'], '_province', (integer) $t);
            }

            echo $postid[0]['post_id'] . "<br>";
         }
      }

      static function azull_db_import_step_4() {

         global $wpdb;
         ini_set('max_execution_time', 0); //300 seconds = 5 minutes

         $table_name = 'p35p6_nbreal_properties';
         $data_nbreal = $wpdb->get_results("SELECT * FROM " . $table_name, ARRAY_A);

         $table_name = 'p35p6_nbreal_properties';
         $data_nbreal = $wpdb->get_results("SELECT * FROM " . $table_name, ARRAY_A);

         foreach ($data_nbreal as $nbreal) {

            $querystr = "SELECT post_id, count(post_id) FROM $wpdb->postmeta	WHERE (meta_key = '_nreal_id' AND meta_value = '" . $nbreal['nbreal_property_id'] . "') GROUP BY post_id;";

            $postid = $wpdb->get_results($querystr, ARRAY_A);

            $builders = $wpdb->get_results("SELECT * FROM p35p6_nbreal_builders WHERE nbreal_builder_id=" . $nbreal['nbreal_builder_id'], ARRAY_A);

            $nbreal_builder = $wpdb->get_results("SELECT * FROM p35p6_nbreal_builders nbreal_builder_id=" . $nbreal['nbreal_builder_id'], ARRAY_A);
            $terms = get_term_by('name', $builders[0]['title'], 'proprietor');


            $taxonomy_meta['type'] = 3;
            if ($terms->term_id != '') {
               wp_set_object_terms($postid[0]['post_id'], array($terms->term_id), 'proprietor', false);
               update_post_meta($postid[0]['post_id'], '_proprietor', $terms->term_id);
               $taxonomy_meta['phone'] = $builders[0]['phone'];
               $taxonomy_meta['email'] = $builders[0]['email'];
               $taxonomy_meta['web'] = $builders[0]['website'];
            }
            update_option('azull_taxonomy_meta_' . $terms->term_id, $taxonomy_meta);

            echo $postid[0]['post_id'] . "--" . $terms->term_id . "--" . $builders[0]['title'] . "<br>";
         }
      }
     /* Display Drop down
      Date:- 01-june-2016
   */   
   static function callclient_dropDown() {
            global $wpdb;
            $html = '';
            $html .= '<script>
            jQuery(document).ready(function($) {
           window.asd =  jQuery(".chekbox").SumoSelect({ okCancelInMulti: false ,triggerChangeCombined: true,forceCustomRendering: true });
            });
           </script>';
            $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
            if (isset($datas) && !empty($datas)) {

             $html .='<select style="width:150px;" class="selecFeatre chekbox" name="clients[]" multiple>';
                foreach ($datas as $data){
                    $html .= "<option value='".$data->ID."'>" . qtranxf_use(qtranxf_getLanguage(),$data->post_title) . "</option>";
                }
                $html .='</select>';
                echo $html;
               
            } exit(0);
         }
	 function customAdd_button_property() {
		  if($_GET['action']=="edit" && $_GET['taxonomy']==""){
		  ?>
		     <script>
		     jQuery(function(){
			jQuery("body.post-type-property .wrap h1").append('<a href="<?php echo get_admin_url();?>tools.php?page=email&ids=<?php echo base64_encode(serialize(array($_REQUEST['post'])));?>" class="page-title-action">Send Email</a>');
			jQuery("body.post-type-property .wrap h1").append('<a href="<?php echo get_admin_url();?>tools.php?page=print&ids=<?php echo base64_encode(serialize(array($_REQUEST['post'])));?>" class="page-title-action">Print/PDF</a>');
		     });
		     </script>
		  <?php
		  }
         }
         
/* updated function for draft-status post 
   date:- 22-sep-2016
*/

function p_redirect_post_location( $location ) {
 if($_POST['post_status'] !='draft'){
   if ( 'property' == get_post_type() ) {
    
       /* Custom code for 'property' post type. */
        if ( isset( $_POST['save'] ) || isset( $_POST['publish'] ) ){
         $url=get_option('redirect_url');
         return $url;
        } 
    } 
 }else{
   return $location;
 }

return $location;
}  

function custom_button(){
        
   if($_GET['action']=="edit"){
	 /*global $wpdb; 
	 $table_name = $wpdb->prefix . "options";
	 $results = $wpdb->get_row( 
	 $wpdb->prepare("SELECT * FROM {$table_name} WHERE option_id =%d", 20027));
	 $url = $results->option_value;*/    
    $url=get_option('redirect_url');    
	 ?>
	 <script>
	 jQuery(function(){
	    jQuery("body.post-type-property .wrap h1").append('<a class="button button-primary button-large" style="float: right;" href="<?php echo $url;?>" class="page-title-action">Back</a>');
	    
	 });
	 </script>
	 <?php
    }
 }
 
 function get_proprietor_urls_value(){
    if( isset( $_POST['pId'] ) || isset( $_POST['pId'] ) )
        global $wpdb;
	$pId=$_POST['pId'];
        $table_name = $wpdb->prefix . "options";
	$key="proprietor_".$pId;
        $results = $wpdb->get_row( 
        $wpdb->prepare("SELECT option_value FROM {$table_name} WHERE option_name =%s", $key));
        echo $url = $results->option_value;
	exit(0);
      }

 
 
/*
   * Date : 04-June-2016
   * Method : function for add/create new taxonomy terms at selected client website
   */
   function xmlrpc_created_terms($term_id) {
      if(isset($term_id) && !empty($term_id) && $term_id!=0 && isset($_POST['client']) && !empty($_POST['client']) && count($_POST['client']) > 0){
         //update client id at azull.biz server
         update_option("azull_taxonomy_client_".$term_id,$_POST['client']);
         //get taxonomy meta
         $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term_id);
         foreach($_POST['client'] as $client){
            $obj = new Xmlrpc_Client($client);
            if(!$obj->test_connection())
               continue;
               $obj->save_client_taxonomy($client,$term_id);
         }

      }
   }
   /*
   * Date : 04-June-2016
   * Method : function for edit existing taxonomy terms for selected client website and also unpublish taxonomy terms for unselected client
   */
   function xmlrpc_edited_terms($term_id) {
      if(isset($term_id) && !empty($term_id) && $term_id!=0){
         $taxonomy = $_REQUEST['taxonomy'];
         $term = get_term($term_id,$taxonomy);
         if (!empty($term) && !is_wp_error($term)) {
            //get clients before update meta
            $before_clients = array();
            $before_clients = get_option('azull_taxonomy_client_' . $term_id);
            $after_clients=array();
            //update taxonomy client
            update_option("azull_taxonomy_client_".$term_id,$_POST['client']);
            //get taxonomy meta
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term_id);
            if(isset($_POST['client']) && !empty($_POST['client']) && count($_POST['client']) > 0){
               //get clients after update meta
               $after_clients = get_option('azull_taxonomy_client_' . $term_id);
               foreach($_POST['client'] as $client){
                  $obj = new Xmlrpc_Client($client);
                  if(!$obj->test_connection())
                     continue;
                     $obj->save_client_taxonomy($client,$term_id);
               }
            }
            if(isset($before_clients) && !empty($before_clients) && count($before_clients)>0){
               foreach ($before_clients as $key => $client) {
                  if(!in_array($client,$after_clients)){
                     //delete uncheck client taxonomy
                     $obj = new Xmlrpc_Client($client);
                     if(!$obj->test_connection())
                         continue;
                        $remote_term_id = $obj->has_taxonomy($taxonomy, $term->slug);
                        $obj->delete_taxonomy($taxonomy, $term->slug);
                        if ($obj->getresponse()) {
                           if(isset($remote_term_id) && $remote_term_id > 0){
                              $obj->manage_client_option('azull_taxonomy_meta_' . $remote_term_id,array('type'=>'post'), 'removeoption');
                              $obj->manage_client_option('z_taxonomy_image' . $remote_term_id, z_taxonomy_image_url($term_id), 'removeoption');
                           }
                     }
                  }
               }
            }
            if(isset($taxonomy_meta['type']) && !empty($taxonomy_meta['type'])){
               wp_safe_redirect(admin_url('edit-tags.php?action=edit&taxonomy='.$taxonomy.'&tag_ID=' . $term_id . '&post_type='.$taxonomy_meta['type']) );
               exit;
            }
         }
         
      }
     
   }
   /*
   * Date : 04-June-2016
   * Method : function for delete taxonomy terms form all available client's website
   */
   function xmlrpc_deleted_terms($term_id,$taxonomy,$deleted_term) {
      if(isset($term_id) && $term_id!=0 && isset($deleted_term) && !empty($deleted_term)){
         foreach (azull::get_sites() as $site) {
            $obj = new Xmlrpc_Client($site);
            if(!$obj->test_connection())
               continue;
            $remote_term_id = $obj->has_taxonomy($deleted_term->taxonomy, $deleted_term->slug);
            $obj->delete_taxonomy($deleted_term->taxonomy, $deleted_term->slug);
            if ($obj->getresponse()) {
               if(isset($remote_term_id) && $remote_term_id > 0){
                  //remove deleted taxonomy meta from options table at client's websites
                  $obj->manage_client_option('azull_taxonomy_meta_' . $remote_term_id,array('type'=>'post'), 'removeoption');
                  $obj->manage_client_option('z_taxonomy_image' . $remote_term_id, z_taxonomy_image_url($term_id), 'removeoption');
               }
            }
         }
         //remove deleted taxonomy meta from options table at azull.biz server
         delete_option('azull_taxonomy_meta_'.$term_id);
         delete_option('azull_taxonomy_client_'.$term_id);
         delete_option('z_taxonomy_image'.$term_id);
      }
      return;
   }
   /*
   * Date : 13-June-2016
   * Method : function for display client list at menu page
   */
   function get_client_list() {
      global $wpdb;
      $html = '';
      $html .= '<script>
      jQuery(document).ready(function($){
     window.asd =  jQuery(".chekbox").SumoSelect({ okCancelInMulti: false ,triggerChangeCombined: true,forceCustomRendering: true });
      });
     </script>';
      $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
      if (isset($datas) && !empty($datas)) {
         $taxonomy_id = $_POST['menu_id'];
         $val = get_option("azull_taxonomy_client_".$taxonomy_id);
         $html .='<select class="selecFeatre chekbox" name="clients[]" multiple>';
            foreach ($datas as $data){
              //$html .= "<option value='".$data->ID."'>" . qtranxf_use(qtranxf_getLanguage(),$data->post_title) . "</option>";
              $html .= "<option value='" . $data->ID . "' " . (( is_array($val) && in_array($data->ID, $val)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(),$data->post_title) . "</option>";
            }
         $html .='</select>';
         $html .='<style>.SumoSelect{position: absolute;width:80% !important;}</style>';
         echo $html;
      } exit(0);
   }
   /*
   * Date : 14-June-2016
   * Method : function for add/update menu at client's websites
   */
   function add_update_menu($nav_menu_selected_id) {
      //print('<pre>');print_r($_POST);die();
      if(isset($nav_menu_selected_id) && !empty($nav_menu_selected_id)){
         $taxonomy='nav_menu';
         $term = get_term($nav_menu_selected_id,$taxonomy);
         if (!empty($term) && !is_wp_error($term)) {
            //get clients before update meta
            $before_clients = array();
            $before_clients = get_option('azull_taxonomy_client_' . $nav_menu_selected_id);
            $after_clients=array();
            //update taxonomy client
            update_option("azull_taxonomy_client_".$nav_menu_selected_id,$_POST['clients']);
            //Date : 13-06-2016 for add/update/delete menu to client's website
            if(isset($_POST['clients']) && !empty($_POST['clients'])){
               //get clients after update meta
               $after_clients = get_option('azull_taxonomy_client_' . $nav_menu_selected_id);
               foreach($_POST['clients'] as $client){
                  $obj = new Xmlrpc_Client($client);
                  if(!$obj->test_connection())
                     continue;
                     $obj->save_client_manu($client,$nav_menu_selected_id);
               }
            }

            if(isset($before_clients) && !empty($before_clients) && count($before_clients)>0){
               foreach ($before_clients as $key => $client) {
                  if(!in_array($client,$after_clients)){
                     //delete uncheck client taxonomy
                     $obj = new Xmlrpc_Client($client);
                     if(!$obj->test_connection())
                         continue;
                        $obj->delete_taxonomy($taxonomy, $term->slug);
                  }
               }
            }
         }
      }
   }
   /*
   * Date : 14-June-2016
   * Method : function for update menu's location at client's websites
   */
   function update_menu_location($action) {
      if (isset($action) && ('save-menu-locations' == $action) && isset($_POST['menu-locations']) && !empty($_POST['menu-locations']) && isset($_POST['menu']) && !empty($_POST['menu']))
      {
         if(isset($_POST['menu']) && !empty($_POST['menu'])){
            $taxonomy='nav_menu';
            $term = get_term($_POST['menu'],$taxonomy);
            if (!empty($term) && !is_wp_error($term)) {
               //get menu clients
               $clients = get_option('azull_taxonomy_client_' . $_POST['menu']);
               if(isset($clients) && !empty($clients)){
                  foreach($clients as $client){
                     $obj = new Xmlrpc_Client($client);
                     if(!$obj->test_connection())
                        continue;
                        $obj->save_client_menu_location($client,$_POST['menu']);
                  }
               }
            }
         }
      }

      if (isset($action) && ($action == "delete-nav_menu-$_REQUEST[menu]") && isset($_REQUEST['menu']) && !empty($_REQUEST['menu']))
      {
         $term = get_term($_REQUEST['menu'],'nav_menu');
         foreach (azull::get_sites() as $site) {
            $obj = new Xmlrpc_Client($site);
            if(!$obj->test_connection())
               continue;
            $obj->delete_taxonomy($term->taxonomy, $term->slug);
         }
         //remove deleted taxonomy meta from options table at azull.biz server
         delete_option('azull_taxonomy_client_'.$_REQUEST['menu']);
      }
      return;
   }
   
   
   /*Date:- 18-june-2016
      *Calculator
    */
   function azull_mortgage_price_calculate() {
  
   $loanAmt = str_replace(',','.',str_replace('.','',$_POST['loanAmt']));
   //print_r($loanAmt);die;
   $rate = $_POST['rate'];
   $year = $_POST['year'];
   $error_flg=1;$err_msg='';
    if (isset($loanAmt) && !empty($loanAmt)){
      if(is_numeric($loanAmt)){
         if (isset($year) && !empty($year)){
            if(is_numeric($year) && strpos($year,'.') == false){
               if (isset($rate) && !empty($rate)){
                  if(is_numeric($rate)){
                     $n = $year*12;
                     $r = $rate/12/100;
                     $monthly_p= ($loanAmt * $r * pow((1+$r),$n))/(pow((1+$r),($n))-1); 
                     $monthly_p=round($monthly_p,2);
                     $total_pay = str_replace(',','.',number_format($monthly_p * $n));
                     //print_r(number_format($monthly_p * $n));die;
                     $monthly_pay=str_replace(',','.',number_format($monthly_p));
                     $error_flg=0;
                     $result=array('monthly_pay'=>$monthly_pay,'total_pay'=>$total_pay);
                  }else{
                     $err_msg=__('Interest rate should be numeric.', 'azull');
                  }
            }else{
               $err_msg=__('Interest rate is required.', 'azull');
            }
            }else{
               $err_msg=__('Duration should be numeric.', 'azull');
            }
         }else{
            $err_msg=__('Duration is required.', 'azull');
         }
      }else{
         $err_msg=__('Loan amount should be numeric.', 'azull');
      }
   }else{
      $err_msg=__('Loan amount is required.', 'azull');
   }
   echo json_encode(array('error' => $error_flg, 'result' => $result,'msg'=>$err_msg));
      die;
}
   
   
   
 /*function addThankuPageText(){
      $checkValue='';
      $parameters = array();
      parse_str($_POST['fdata'], $parameters);
      //$pageText=serialize($parameters['page_text']);
      $pageText=$parameters['page_text'];
      $optionId="thk_page_text_".$_POST['id'];
      $checkValue=$_POST['check'];
      if($checkValue && $checkValue!=''){
           $terms = get_option($optionId);
           //$terms = unserialize(get_option($optionId));
           echo json_encode($terms);
           exit();
      }else{
           update_option($optionId, $pageText, '', 'yes' );
           foreach (azull::get_sites() as $site) {
           // $site=50913;
            $obj = new Xmlrpc_Client($site);
            if (!$obj->test_connection())
               continue;
            $obj = new Xmlrpc_Client($site);
            $obj->add_thanks_page_text($site,$pageText,$_POST['id']);
         }
           die(true);
      }
       
} */
/*
* Date: 20-Oct-2016
* Method: function for get page list by client id
*/
function getClientPageList(){
   $client_id = $_POST['client_id'];
   $result = array();
   if(isset($client_id) && !empty($client_id)){
      $page_ids = get_all_page_ids();
      $html='<select name="page_id" id="page_id" class="SlectBox" style="width:400px" onchange="return getThkPageInfo()">';
      $html.='<option class="selectator_group_header" value="">Please select page</option>';
      if(isset($page_ids) && !empty($page_ids)){
         $html.='<option class="selectator_group_header" value="" disabled><h1>--Default Pages</h1></option>';
         $d_tmp='';
         foreach($page_ids as $page){
            $page_meta = get_post_meta($page,'_client',true);
            if(isset($page_meta) && !empty($page_meta) && is_array($page_meta) && in_array($client_id, $page_meta)){
               $d_tmp[$page] = get_the_title($page);
            }
         }
         asort($d_tmp);
         if(isset($d_tmp) && !empty($d_tmp)){
            foreach ($d_tmp as $k => $val) {
               $html.='<option value="'.$k.'"> '.$val.'</option>';
            }
         }
      }
      $all_forms = Ninja_Forms()->forms()->get_all();
      if(isset($all_forms) && !empty($all_forms)){
         $html.='<option disabled>--<b>Daynamic Pages</b></option>';
         $dyn_tmp='';
         foreach($all_forms as $form_id){
            $label = esc_html( Ninja_Forms()->form( $form_id )->get_setting( 'form_title' ) );
            $dyn_tmp[$form_id] = $label;
         }
         asort($dyn_tmp);
         if(isset($dyn_tmp) && !empty($dyn_tmp)){
            foreach ($dyn_tmp as $dyn_k => $dyn_val) {
               $html.='<option value="dyn_'.$dyn_k.'"> '.$dyn_val.'</option>';
            }
         }
      }
      $html.='<option disabled>--<b>Static Pages</b></option>';
      // All Static Form 
      $html.='<option value="infodays">Info-Days</option>';
      $html.='<option value="property_info">Property Info</option>';
      $html.='<option value="azull_reg">Registraion</option>';
      $html.='</select>';
      $img='<img src="http://azull.biz/cisin/wp-includes/images/spinner.gif" >';
      $results = array(       
         'pages' =>$html
      );
   }
   die(json_encode($results,JSON_FORCE_OBJECT));
}
/*function getClientPageList(){
   $client_id = $_POST['client_id'];
   $result = array();
   if(isset($client_id) && !empty($client_id)){
      $page_ids = get_all_page_ids();
      $html='<select name="page_id" id="page_id" class="SlectBox" style="width:400px" onchange="return getThkPageInfo()">';
          $html.='<option class="selectator_group_header" value="">Please select page</option>';
          $html.='<option class="selectator_group_header" value="" disabled><h1>--Default Pages</h1></option>';
      foreach($page_ids as $page){
         $page_meta = get_post_meta($page,'_client',true);
         if(isset($page_meta) && !empty($page_meta) && is_array($page_meta) && in_array($client_id, $page_meta)){
            $html.='<option value="'.$page.'" class="selectator_option"> '.get_the_title($page).'</option>';
         }
      }
      $all_forms = Ninja_Forms()->forms()->get_all();
      if(isset($all_forms) && !empty($all_forms)){
         $html.='<option disabled>--<b>Daynamic Pages</b></option>';
         foreach($all_forms as $form_id){
            $label = esc_html( Ninja_Forms()->form( $form_id )->get_setting( 'form_title' ) );
            $html.='<option value="dyn_'.$form_id.'" class="selectator_option"> '.$label.'</option>';
         }
      }
      $html.='<option disabled>--<b>Static Pages</b></option>';
      // All Static Form 
      $html.='<option value="azull_reg"><b>Registraion</option>';
      $html.='<option value="infodays"><b>Info-Days</option>';
      $html.='<option value="property_info">Property Info</option>';
      $html.='</select>';
      $img='<img src="http://azull.biz/cisin/wp-includes/images/spinner.gif" >';
      $results = array(       
         'pages' =>$html
      );
   }
   die(json_encode($results,JSON_FORCE_OBJECT));
}*/
/*
* Date: 12-Oct-2016
* Method: function for get thank you page information
*/   
function getThkPageInfor(){
   $page_id = $_POST['page_id'];
   $client_id = $_POST['client'];
   if(isset($page_id) && !empty($page_id) && isset($client_id) && !empty($client_id)){
      $page_txt_option = "thk_page_text_".$client_id."_".$page_id;
      $track_code_option = "thk_page_track_code_".$client_id."_".$page_id;
      $data['page_txt'] = get_option($page_txt_option);
      $data['track_code'] = get_option($track_code_option);
      $response = array('error'=>0,'data'=>$data);
   }else{
      $response = array('error'=>1);
   }
   echo json_encode($response);
   exit();
}
/*
* Date: 12-Oct-2016
* Method: function for add/update thank you page information
*/    
function saveThkPageInfor(){
   $parameters = array();
   parse_str($_POST['fdata'], $parameters);
   if(isset($parameters['client']) && !empty($parameters['client'])){
      if(isset($_POST['id']) && !empty($_POST['id'])){
         $page_text = $parameters['page_text'];
         if(strlen($page_text['en'])>68 || strlen($page_text['fr'])>68 || strlen($page_text['nl'])>68){
            /*$pageText=serialize($parameters['page_text']);*/
            $page_txt_option = "thk_page_text_".$parameters['client']."_".$_POST['id'];
            $track_code_option = "thk_page_track_code_".$parameters['client']."_".$_POST['id'];
            $page_track_code = $parameters['track_code'];
            update_option($page_txt_option, $page_text, '', 'yes' );
            update_option($track_code_option, $page_track_code, '', 'yes' );
            $obj = new Xmlrpc_Client($parameters['client']);
            if (!$obj->test_connection()){
               continue;
            }
            $data = array('thk_page_text'=>$page_text,'thk_page_track_code'=>$page_track_code);
            $obj->save_thk_page_info($parameters['client'],$data,$_POST['id']);
            $response = array('error'=>0,'msg'=>'<p>Thank you page information save successfully.</p>');
         }else{
            $response = array('error'=>1,'msg'=>'<p>Please enter thank you page text.</p>');
         }
      }else{
         $response = array('error'=>1,'msg'=>'<p>Please select page.</p>');
      }
    }else{
      $response = array('error'=>1,'msg'=>'<p>Please select client.</p>');
   }
   echo json_encode($response);
   exit();
} 


/*  function to add pages and sideblocks 
     Date:- 25-july-2016
*/


static function getpageArray($blockid =''){

    if($blockid && $blockid!=''){
      if($blockid=="main_block"){

      $array=array(
         "slider"=>"Home slider",
         "property_carousel"=>"Property carousel",
         "featured_pages"=>"Featured pages",
         "property_map"=>"Property map",
         "posts"=>"Posts",
         "featured_page"=>"featured page",
         "video_page"=>"video page",
         "azull_club"=>"Azull club"
         );
      }else{
      $array=array(
         "search_block"=>"Search box",
         "infodays_block"=>"Info days",
         "testimonial_block"=>"Testimonial",
         "featured_posts"=>"Featured posts",
         "featured_page"=>"Featured page",
         "quick_message"=>"Quick message",
         "weather_info"=>"Weather Info",
         "form_page"=>"Form Page"
         );
      }
      return $array; 
    } 
}



function get_page_side_array(){

  $array=array(
         "slider"=>"Home slider",
         "property_carousel"=>"Property carousel",
         "featured_pages"=>"Featured pages",
         "property_map"=>"Property map",
         "posts"=>"Posts",
         "featured_page"=>"featured page",
         "video_page"=>"video page",
         "azull_club"=>"Azull club",
         "search_block"=>"Search box",
         "infodays_block"=>"Info days",
         "testimonial_block"=>"Testimonial",
         "featured_posts"=>"Featured posts",
         "featured_page_side"=>"Side bar featured page",
         "quick_message"=>"Quick message",
         "weather_info"=>"Weather Info",
         "form_page"=>"Form Page"
         );
 return $array;
}



/*  function to display pages and sideblocks 
     Date:- 25-july-2016
*/

function loadPageDropDown(){

     $getArrayResult=array(); 
     $selectedDisplay='yes';
     $selectedCollapse= 0;
     $select='';
     $layout=$_POST['layout'];

/* New Code*/ 

     if(isset($layout) && $layout!='' && isset($_POST['ID']) && $_POST['ID']!=''){
        $bloack_val=$_POST['ID'];
        if($layout=='mobile'){
            $getArrayResult=azull::get_page_side_array($bloack_val);
            $addTop='<td style="color: #000;font-weight: bold;">Collapse</td>';
        }if($layout=="desktop"){
            $getArrayResult=azull::getpageArray($bloack_val);
        }
     }   


/* End New code*/
    
   if(isset($_POST['site_id']) && $_POST['site_id']!=''){
      $siteID=$_POST['site_id'];
      $general = get_post_meta($siteID,'general',true);
   }
   //echo "<pre>"; print_r($general);
   /*if($_POST['layout'] && $_POST['layout']!=''){
      $sideBlock=$general[$bloack_val."_".$_POST['layout']];
   }*/

   if($_POST['layout'] && $_POST['layout']!=''){
      if($_POST['layout']=='mobile'){
           $sideBlock=$general['mobile_block'];
      }else{
           $sideBlock=$general[$bloack_val."_".$_POST['layout']];
      }
   }
    
    //echo "<pre>";print_r($sideBlock); 
    echo "<table width='100%' style=' border:1px solid #ccc border-collapse:collapse;'>";

     if($getArrayResult && !empty($getArrayResult)){

       $pageCount=count($getArrayResult);
       echo '<tr style="background: hsl(0, 0%, 95%);">
             <td style="color: #000;font-weight: bold;">Page Name</td>
             <td style="color: #000;font-weight: bold;">Display</td>
             <td style="color: #000;font-weight: bold;">Block Order</td>'.$addTop.'</tr>';
      if($sideBlock!=''){
        foreach ($getArrayResult as $k=> $val){
          foreach ($sideBlock as $key => $value) {
           $tempArray=array_keys($value);
            if($k==$tempArray[0]){
            $selectedDisplay=$value[$k][$k.'_dis'];
            $selectedOrder=$value[$k][$k.'_order'];
            $selectedCollapse=$value[$k][$k.'_collapse'];
            
         ?>
         <tr >
         <td style="border:1px solid #ccc;"><input type="hidden" name="<?php echo $k;?>" value="<?php echo $k;?>"><?php echo $val;?></td>
         <td style="border:1px solid #ccc;">Yes <input checked="checked" type="radio" name="<?php echo $k;?>_dis" value="yes">No <input type="radio" name="<?php echo $k;?>_dis" value="no" <?php echo ($selectedDisplay=='no')?'checked="checked"':'';?>></td>   
         <td style="border:1px solid #ccc;">
         <select class="d_order" id="<?php echo $k;?>" name="<?php echo $k;?>_order"><option value="">select one</option>
         <?php
              
             if($pageCount && !empty($pageCount)){
                for ($i=1; $i <= $pageCount; $i++) { 
                   $select=($selectedOrder==$i)?"selected":''; 
                  echo "<option ".$select." value=".$i.">".$i."</options>";
                }
             }
         ?>

         </select></td>

         <?php // condition for callase on sidebar
          if($layout == "mobile"){
            ?>

            <td style="border:1px solid #ccc;">Yes <input  type="radio" name="<?php echo $k;?>_collapse" value="1" <?php echo ($selectedCollapse == 1)?'checked="checked"':'';?>>No <input <?php echo ($selectedCollapse == 0)?'checked="checked"':'';?>type="radio" name="<?php echo $k;?>_collapse" value="0"></td>   
         <?php } ?>
         </tr>
       <?php }
          // value foreach
    }
        }
      } else{
            foreach ($getArrayResult as $k=> $val){
         ?>
         <tr >
         <td style="border:1px solid #ccc;"><input type="hidden" name="<?php echo $k;?>" value="<?php echo $k;?>"><?php echo $val;?></td>
         <td style="border:1px solid #ccc;">Yes <input checked="checked" type="radio" name="<?php echo $k;?>_dis" value="yes">No <input type="radio" name="<?php echo $k;?>_dis" value="no"></td>   
         <td style="border:1px solid #ccc;">
         <select class="d_order" id="<?php echo $k;?>" name="<?php echo $k;?>_order"><option value="">select one</option>
         <?php
             if($pageCount && !empty($pageCount)){
                for ($i=1; $i <= $pageCount; $i++) { 
                  echo "<option value=".$i.">".$i."</options>";
                }
             }
         ?>

         </select></td>
         <?php // condition for callase on sidebar
         // if($checkLayout == "side_block_mobile"){
            if($layout == "mobile"){
            ?>

            <td style="border:1px solid #ccc;">Yes <input  type="radio" name="<?php echo $k;?>_collapse" value="1" <?php echo ($selectedCollapse == 1)?'checked="checked"':'';?>>No <input <?php echo ($selectedCollapse == 0)?'checked="checked"':'';?>type="radio" name="<?php echo $k;?>_collapse" value="0"></td>   
         <?php } ?>
         </tr>
       <?php  } // value foreach 

       } //else       
       
       }  
  echo "</table>";

?>
 <script>
 /*jQuery(document).ready(function() {  
jQuery("select.d_order").change(function() {
                    var pVal = this.value;
                    var pId = jQuery(this).attr('id');
                    var clary = getSelects('d_order');
                    jQuery('select.d_order').find('option').each(function() {
                                jQuery(this).prop('disabled', false);
                               for ( var i = 0, l = clary.length; i < l; i++ ) {
                                  if(parseInt(clary[ i ]) ==parseInt(jQuery(this).val())){
                                    jQuery(this).prop('disabled', true);
                                  }  
                            }
                    });

                    jQuery('select.d_order').find('option:selected').each(function() {
                               for ( var i = 0, l = clary.length; i < l; i++ ) {
                                  jQuery(this).attr('disabled', false); 
                            }
                    });


                });
                function getSelects(klass) {
                    var selected = [];
                    jQuery('select.' + klass).children('option:selected').each(function() {
                        if(this.value !='')     selected.push(this.value);
                });
                   return selected;
            }
   });*/
</script>
<?php
    exit();
}

/*
* Date: 02-sep-2016
* Method: function for get email title by email type
*/
function get_email_title(){
   $email_type = $_POST['email_type'];
   $siteid = $_POST['siteid'];
   $response = '';
   if(isset($siteid) && !empty($siteid) && isset($email_type) && !empty($email_type)){
      $general = get_post_meta($siteid,'general',true);
      $response['email_title'] = '';
      $response['email_txt'] = '';
      if(isset($general['email_title']) && !empty($general['email_title'])){
         foreach ($general['email_title'] as $key => $val) {
            if($key == $email_type){
               $response['email_title'] = $val;
            }
         }
      }
      if(isset($general['email_text']) && !empty($general['email_text'])){
         foreach ($general['email_text'] as $txt_key => $txt_val) {
            if($txt_key == $email_type){
               $response['email_txt'] = $txt_val;
            }
         }
      }
      //print_r($response);die;
      echo json_encode($response);
      exit();
   }
}
/*function get_email_title(){
   $email_type = $_POST['email_type'];
   $siteid = $_POST['siteid'];
   $email_title = '';
   if(isset($siteid) && !empty($siteid) && isset($email_type) && !empty($email_type)){
      $general = get_post_meta($siteid,'general',true);
      if(isset($general['email_title']) && !empty($general['email_title'])){
         foreach ($general['email_title'] as $key => $val) {
            if($key == $email_type){
               $email_title = $val;
            }
         }
      }
      //print_r($email_title);die;
      echo json_encode($email_title);
      exit();
   }
}*/
/*
* Date: 05-Nov-2016
* Method: function for get project list by proprietor id
*/
function getProjectList(){
   $proprietor_id = $_POST['p_id'];
   $result = array();
   if(isset($proprietor_id) && !empty($proprietor_id)){
      $html .='<select class="SlectBox" name="property_meta_essential[project]" id="property_meta_essential[project]"><option value="" selected>'. __("Select Project", "azull").'</option>';
      $terms  = get_terms('project',array('orderby' => 'name', 'hide_empty' => false));
      if(isset($terms) && !empty($terms)){
         global $wpdb;
         $p_project = get_post_meta($post->ID, '_project', true);
         foreach ($terms as $term) {
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
            if(isset($taxonomy_meta['proprietor']) && !empty($taxonomy_meta['proprietor']) && $taxonomy_meta['proprietor'] == $proprietor_id){
               $trans_name = qtranxf_use(qtranxf_getLanguage(), $term->name);
               if(isset($trans_name) && !empty($trans_name)){
                  $t_name = $trans_name;
               }else{
                  $term_data = $wpdb->get_row("SELECT * FROM wp_terms join wp_term_taxonomy on wp_terms.term_id = wp_term_taxonomy.term_id where wp_terms.term_id = '$term->term_id' AND wp_term_taxonomy.taxonomy = '$term->taxonomy'");
                  $t_name = (isset($term_data->name) && !empty($term_data->name))?$term_data->name:'';
               }
               $html .='<option value="' . $term->term_id . '" '.((isset($p_project) && !empty($p_project) && $term->term_id == $p_project)?"selected":"").'>' .$t_name. '</option>';
            }
         }
      }
      $html .='</select>';
      $html .='<style>.SumoSelect{width:96%;}</style>';
      $results = array(       
         'project' =>$html
      );
   }
   die(json_encode($results,JSON_FORCE_OBJECT));
}
/*
* Date: 21-Nov-2016
* Method: function for set/unset property as export list
*/

function setPropertyExportList(){
   $postId = $_POST['p_id'];
   $result = array();
   if (!session_id()) { session_start(); }
   if(isset($postId) && !empty($postId)){
      if(get_post_type($postId) == 'property'){
         $is_checked = $_POST['is_checked'];
         if(isset($is_checked) && $is_checked==1){
            //unset($_SESSION['properties']);
            if(isset($_SESSION['properties']) && !empty($_SESSION['properties'])){
               $properties = $_SESSION['properties'];
               if(!in_array($postId,$properties)){
                  $properties[] = $postId;   
               }
            }else{
               $properties[] = $postId;
            }
         }else{
            if(isset($_SESSION['properties']) && !empty($_SESSION['properties'])){
               $properties = $_SESSION['properties'];
               if(in_array($postId,$properties)){
                  array_splice($properties, array_search($postId, $properties), 1);   
               }
            }
         }
         $_SESSION['properties'] = $properties;
         $is_properties = (isset($_SESSION['properties']) && count($_SESSION['properties'])>0)?1:0;
         $results = array(
            'properties' => $_SESSION['properties'],
            'is_properties' => $is_properties
         );
      }
   }
   die(json_encode($results,JSON_FORCE_OBJECT));
}

/*
* Date: 22-Nov-2016
* Method: function for get session properties
*/

function getSessionProperties(){
   if (!session_id()) { session_start(); }
   $results = $_SESSION['properties'];
   die(json_encode($results,JSON_FORCE_OBJECT));
}
/*
* Date : 20-Dec-2016
* Method : function for save location translation info for each place/city to azull.biz
* Params : NULL
* Return : success or error message
*/
function save_location_translation() {
 global $wpdb;
 if(isset($_POST['place_id']) && $_POST['place_id']!=0){
   $dataArr=array();
   $error = 1;
   $languages = qtranxf_getSortedLanguages();
   if(isset($languages) && !empty($languages)){
      foreach ($languages as $key => $val) {
         if($_POST['ltn_val'][$val]){
            $error = 0;
            $t_name = $_POST['ltn_val'][$val];
         }
      }
   }
   if(isset($_POST['ltn_val']) && $error==0){
      $loc_trans_id = base64_decode($_POST['loc_trans_id']);
      if(isset($loc_trans_id) && !empty($loc_trans_id) && $loc_trans_id!=0){
         
         $update_trans_data = array(
            'term_id' => (integer) $_POST['place_id'],
            'name' => (isset($_POST['ltn_val']['nl']) && !empty($_POST['ltn_val']['nl']))?stripslashes($_POST['ltn_val']['nl']):$t_name,
            'translation_name' => serialize($_POST['ltn_val']),
            'modifyDate' => date('Y-m-d h:i:s')
         );
         $wpdb->update('wp_term_translations',$update_trans_data,array('id' => $loc_trans_id));
      }else{
         $add_trans_data = array(
            'term_id' => (integer) $_POST['place_id'],
            'name' => (isset($_POST['ltn_val']['nl']) && !empty($_POST['ltn_val']['nl']))?stripslashes($_POST['ltn_val']['nl']):$t_name,
            'translation_name' => serialize($_POST['ltn_val']),
            'createdDate' => date('Y-m-d h:i:s'),
            'modifyDate' => date('Y-m-d h:i:s'),
            'ip' => $_SERVER['REMOTE_ADDR']
         );
         $wpdb->insert('wp_term_translations',$add_trans_data); 
      }
      //print('<pre>');print_r($translation_data);die;
      $succes =__("Location translation info saved successfully..", 'azull') . "<br/>";
       $response['html'] = '<div id="message" class="notice notice-success below-h2"><p>'.$succes.'</p></div>';
       $err_state = 0;
   }else{
      $err =__("Please enter location translation name!", 'azull') . "<br/>";
      $msg = '<div id="message" class="notice notice-error below-h2"><p>'.$err.'</p></div>';
      $err_state = 1; 
    }
 }else{
   $err =__("Please select place!", 'azull') . "<br/>";
   $msg = '<div id="message" class="notice notice-error below-h2"><p>'.$err.'</p></div>';
   $err_state = 1;
 }
 $response = array('error'=>$err_state,'msg'=>$msg);
 die(json_encode($response));
}
/*
* Date : 20-Dec-2016
* Method : function for get location translation info for place/city to azull.biz
* Params : NULL
* Return : data
*/
function get_location_trans(){
   if(!empty($_POST['id'])){
      $term_trans_id = base64_decode($_POST['id']);
      global $wpdb;
      $term_trans_data = $wpdb->get_row("SELECT * FROM wp_term_translations where id = $term_trans_id",ARRAY_A);
      
      if(isset($term_trans_data) && !empty($term_trans_data) && count($term_trans_data)>0){
         $obj_subsciber = new Azull_Subscriber();
         $response['lt_id'] = $_POST['id'];
         $response['place'] = $term_trans_data['term_id'];
         $response['ltn'] = unserialize($term_trans_data['translation_name']);
         $response['place_meta'] = get_option('azull_taxonomy_meta_' . $term_trans_data['term_id']);
         $response['edit_frm_title'] = $obj_subsciber->getTranslatedString('en','nl','Edit').' '.$obj_subsciber->getTranslatedString('en','nl','Location Translation');
         //print('<pre>');print_r($response);die;
         die(json_encode($response));
      }
   }
}
/*
* Date: 20-Dec-2016
* Method: function for delete location translation record
*/
function delete_location_trans() {
   if(!empty($_POST['id'])){
      $term_trans_id = base64_decode($_POST['id']);
      if($term_trans_id != 0){
         global $wpdb;
         $wpdb->delete('wp_term_translations',array('id' => $term_trans_id));
         $response['msg'] ='<div id="message" class="notice notice-success below-h2"><p>'.__("Record successfully deleted.", 'azull').'<br/></p></div>';
         die(json_encode($response));
      }
   }
   $response['msg'] ='<div id="message" class="notice notice-error below-h2"><p>'.__("Something goes wrong, please try again later.", 'azull').'<br/></p></div>';
   die(json_encode($response));
}


function get_flag_descrption(){
   global $wpdb;
    if(isset($_POST['uri']) && $_POST['uri']!=''){
    $guid=$_POST["uri"];
    $query = "SELECT wp_posts.post_content FROM wp_posts where wp_posts.guid= '$guid'";
    $postArray= $wpdb->get_row($query);
    $imgDesc=$postArray->post_content;
    echo $imgDesc;
    }
    die();
}



//******** azull class end *******//  
}

   endif; //class if end

if (class_exists('azull')) {
   // Installation and uninstallation hooks
   register_activation_hook(__FILE__, array('azull', 'activate'));
   register_deactivation_hook(__FILE__, array('azull', 'deactivate'));

   // instantiate the plugin class
   azull::instance();
}

function fb_change_search_url_rewrite() {
	if ( is_search() && ! empty( $_GET['s'] ) ) {
		wp_redirect( home_url( "/search/" ) . urlencode( get_query_var( 's' ) ) );
		exit();
	}	
}
add_action( 'template_redirect', 'fb_change_search_url_rewrite' );

/*
* Date : 04-June-2016
* Method : function for add client list at add/edit taxonomy form
*/
function taxonomy_custom_fields() {
   $taxonomy_id = $_REQUEST['tag_ID'];
   global $post, $wpdb;
   $val = array();
   $html = "";
   $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
   if(isset($taxonomy_id) && !empty($taxonomy_id) && $taxonomy_id!=0){
      $val = get_option("azull_taxonomy_client_".$taxonomy_id);
      $html .= '<tr class="form-field form-required term-name-wrap"><th scope="row"><label>' . __("Client visibility", "azull") . '</label></th><td>';
   }else{
      $html .= '<div class="form-field"><label>' . __("Client visibility", "azull") . '</label>';
   }
   $html .= '<select style="min-height: 26px; width: 100%;" class="SlectBox" name="client[]" multiple>';
   $html .= '<option value="" disabled selected>' . __('Select site', 'azull') . '</option>';
   if(isset($datas) && !empty($datas)){
      foreach ($datas as $data) {
         if (isset($data->post_title)) {
            $sitename = explode(']', $data->post_title);
            $sitename = explode('[', $sitename[1]);
            $sitename = $sitename[0];
         }
         $postTitle = (isset($data->post_title) && !empty($data->post_title))?qtranxf_use(qtranxf_getLanguage(),$data->post_title):'';
         $html .= "<option value='" . $data->ID . "' " . (( is_array($val) && in_array($data->ID, $val)) ? 'selected' : '') . ">" . $postTitle . "</option>";
      }
   }
   $html .= "</select><br>";
   $html .= "<span class='description'>" . __('Select one or more clients website.', 'azull') . "</span>";
   if(isset($taxonomy_id) && !empty($taxonomy_id) && $taxonomy_id!=0){
      $html .='</td></tr>';
   }else{
      $html .='</div>';
   }
   $html .='<style>.SumoSelect{width:96%;}</style>';
   echo $html;
}
$taxonomy = $_REQUEST['taxonomy'];
add_filter($taxonomy."_add_form_fields", "taxonomy_custom_fields");
add_filter($taxonomy."_edit_form_fields", "taxonomy_custom_fields");
add_action( 'init', 'create_posttype_company' );

/* Code for create company post type*/ 


function create_posttype_company() {
   
if($_GET['post_type']=='company'){
?>
<style>
    .publish{
        display:none !important;
    }
    .view{
        display:none !important;
    }

</style>
<?php }

	register_post_type( 'company',
        array(

            'labels' => array(
                'name' => __( 'Company' ),
                'singular_name' => __( 'Company' ),
                'add_new' => __( 'Add New Company' ),
                'add_new_item' => __( 'Add New Company' ),
                'edit_item' => __( 'Edit Company' ),
                'new_item' => __( 'Add New Company' ),
                'view_item' => __( 'View Company' ),
                'search_items' => __( 'Search Company' ),
                'not_found' => __( 'No company found' ),
                'not_found_in_trash' => __( 'No Company found in trash' )
            ),
             'public' => true,
             'supports' => array( 'title', 'editor', ''),
             'capability_type' => 'post',
             'rewrite' => array("slug" => "company"), // Permalinks format
             'menu_position' => 80,
             'menu_icon'           => 'dashicons-calendar',
             'register_meta_box_cb' => 'add_company_metaboxes'
        )
    );

}
// Hooking up our function to theme setup
function add_company_metaboxes() {

    add_meta_box('wpt_company_color', 'Site Color', 'wpt_company_color', 'Company', 'normal', 'default');
    
    add_meta_box('wpt_company_name', 'Company Name', 'wpt_company_name', 'Company', 'normal', 'default');
    add_meta_box('wpt_company_email', 'Company Email', 'wpt_company_email', 'Company', 'normal', 'default');
    add_meta_box('wp_custom_attachment', 'Company Logo', 'wp_custom_attachment', 'Company', 'normal', 'default');
}
function wpt_company_color() {
	global $post;
	echo '<input type="hidden" name="eventmeta_noncename" id="eventmeta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	$companyclr = get_post_meta($post->ID, '_companyclr', true);
	// Echo out the field
	echo '<input type="color" name="_companyclr" value="' . $companyclr  . '" class="widefat" />';
}

function wpt_company_name() {
	global $post;
	echo '<input type="hidden" name="eventmeta_noncename1" id="eventmeta_noncename1" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	$companyname = get_post_meta($post->ID, '_companyname', true);
	// Echo out the field
	echo '<input type="text" name="_companyname" value="' . $companyname  . '" class="widefat" />';
}
function wpt_company_email() {
	global $post;
	echo '<input type="hidden" name="eventmeta_noncename2" id="eventmeta_noncename2" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	$companyemail = get_post_meta($post->ID, '_companyemail', true);
	// Echo out the field
	echo '<input type="text" name="_companyemail" value="' . $companyemail  . '" class="widefat" />';
}
function wp_custom_attachment() {
 
    wp_nonce_field(plugin_basename(__FILE__), 'wp_custom_attachment_nonce');
    $html = '<p class="description">';
        $html .= 'Upload Logo';
    $html .= '</p>';
    $html .= '<input type="file" id="wp_custom_attachment" name="wp_custom_attachment" value="" size="25" />';
    echo $html;
    $img = get_post_meta(get_the_ID(), 'wp_custom_attachment', true);
    if(isset($img) && $img!='')
     echo '<img src="'.$img['url'].'" width="70px">';
} // end wp_custom_attachment



function wpt_save_events_meta($post_id, $post) {

	if ( !wp_verify_nonce( $_POST['eventmeta_noncename'], plugin_basename(__FILE__) )) {
	return $post->ID;
	}
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;
	$events_meta['_companyclr'] = $_POST['_companyclr'];
        $events_meta['_companyname'] = $_POST['_companyname'];
	$events_meta['_companyemail'] = $_POST['_companyemail'];
	foreach ($events_meta as $key => $value) { // Cycle through the $events_meta array!
		if( $post->post_type == 'revision' ) return; // Don't store custom data twice
		$value = implode(',', (array)$value); // If $value is an array, make it a CSV (unlikely)
		if(get_post_meta($post->ID, $key, FALSE)) { // If the custom field already has a value
			update_post_meta($post->ID, $key, $value);
		} else { // If the custom field doesn't have a value
			add_post_meta($post->ID, $key, $value);
		}
		if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
	} 
}
function save_geschakelde_woning($post_id, $post) {

   if ( !wp_verify_nonce( $_POST['eventmeta_noncename'], plugin_basename(__FILE__) )) {
   return $post->ID;
   }
   if ( !current_user_can( 'edit_post', $post->ID ))
      return $post->ID;
   if (stripos($post['post_name'], ' ') !== false) {
      $post['post_name'] = str_replace(' ', '', $post['post_name']);
      $sql = "UPDATE wp_posts SET post_name='".$post['post_name']."' WHERE ID='".$post_id."'";
      global $wpdb;
      $wpdb->query($sql);
   }
}
function save_company_logo($id) {
    /* --- security verification --- */
    if(!wp_verify_nonce($_POST['wp_custom_attachment_nonce'], plugin_basename(__FILE__))) {
      return $id;
    } // end if 
    if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
      return $id;
    } // end if
       
    if('page' == $_POST['post_type']) {
      if(!current_user_can('edit_page', $id)) {
        return $id;
      } // end if
    } else {
        if(!current_user_can('edit_page', $id)) {
            return $id;
        } // end if
    } // end if
    /* - end security verification - */
     
    // Make sure the file array isn't empty
    if(!empty($_FILES['wp_custom_attachment']['name'])) {
         
        $arr_file_type = wp_check_filetype(basename($_FILES['wp_custom_attachment']['name']));
        $uploaded_type = $arr_file_type['type'];
            $upload = wp_upload_bits($_FILES['wp_custom_attachment']['name'], null, file_get_contents($_FILES['wp_custom_attachment']['tmp_name']));
     
            if(isset($upload['error']) && $upload['error'] != 0) {
                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
            } else {
                update_post_meta($id, 'wp_custom_attachment', $upload);     
            } // end if/else   
    } // end if
} // end save_custom_meta_data
function update_edit_form() {
    echo ' enctype="multipart/form-data"';
} // end update_edit_form
add_action('post_edit_form_tag', 'update_edit_form');
add_action('save_post', 'wpt_save_events_meta', 1, 2); // save the custom fields
//Tien add this to avoid geschakelde woning
add_action('save_post', 'save_geschakelde_woning', 0, 2); 
add_action('save_post', 'save_company_logo');
function my_login_redirect( $redirect_to, $request, $user ) {
	//is there a user to check?
	if ( isset( $user->roles ) && is_array( $user->roles ) ) {
		//check for admins
		if ( in_array('administrator', $user->roles ) ) {
                   return admin_url().'edit.php?post_type=property&post_status=publish&orderby=property_ref&order=desc';
			//return $redirect_to;
		}elseif ( in_array('agent', $user->roles ) ) {
		  return admin_url().'edit.php?post_type=property&post_status=publish';
		}
      elseif ( in_array('ie', $user->roles ) ) {
		  return admin_url().'edit.php?post_type=property&post_status=publish';
		}
      elseif ( in_array('info', $user->roles ) ) {
		  return admin_url().'edit.php?post_type=property&post_status=publish';
		}
      elseif ( in_array('office', $user->roles ) ) {
        return admin_url().'edit.php?post_type=property&post_status=publish';
      }
      elseif ( in_array('view_01', $user->roles ) ) {
        return admin_url().'edit.php?post_type=property&post_status=publish';
      }
      elseif ( in_array('price', $user->roles ) ) {
        return admin_url().'edit.php?post_type=property&post_status=publish';
      }
		else {
			return home_url();
		}
	} else {
		return $redirect_to;
	}
}
add_filter( 'login_redirect', 'my_login_redirect', 10, 3 );
add_action( 'init', 'getUserRole' );
add_action( 'init', 'getUserRoles' );

function remove_menus(){
   $userRole=getUserRoles();
   
switch ($userRole){
case "office":

      remove_menu_page( 'translation-page' );
      if($_GET['post_type']=="property"){
         ?>
      <style>.trash{display: none !important;}
              #toplevel_page_WP-Optimize{display: none !important;}
      <?php }
      ?>
      <style>#toplevel_page_WP-Optimize{display: none !important;}
      </style>
      <?php

   break;
/*date:- 14/12/2016 remove href on property title*/
case "view_01":
?>
      <script src="<?php echo AZULL_URL ?>js/jquery-1.11.0.min.js"></script>
         <script type="text/javascript">
            $(document).ready(function() {
               $('table.wp-list-table a.row-title').contents().unwrap();
            });
         </script>
      <?php
   break;
case "editor":
      remove_menu_page( 'translation-page' );
      ?>
      <style type="text/css">#toplevel_page_WP-Optimize{display: none;}</style>
      <?php  if($_GET['post_type']=="property"){ ?>
      <style>.trash{display: none !important;}
      <?php  } ?>    
      </style> <?php
	break;
case "author":
   break;
case "agent":
      remove_menu_page( 'azulloffice');
      remove_menu_page( 'infodays');
      remove_menu_page( 'translation-page'); 
      remove_menu_page( 'options-general');   
   break;
case "ie":?>
      <style type="text/css">
          #toplevel_page_WP-Optimize{
            display: none;
          }
       </style>
      <?php
   break;               
case "info":
      remove_menu_page( 'location' );
      if($_GET['post_type']=="property" || $_GET['post_type']=="testimonial" || $_GET['post_type']=="azulladds" || $_GET['post_type']=="azulloffice" ){
        ?>
        <style>
         .row-actions .edit {
            display: none!important;
         }
         .trash{display: none !important;}
        </style>
       <?php } 
		 ?>
		 <style>
		   .wrap .page-title-action{
			   display: none !important;
		   }
      #toplevel_page_WP-Optimize{display: none !important;}
		 </style>
            <?php 
   break;
case "price":
         if($_GET['post_type']=="property" || $_GET['post_type']=="testimonial" || $_GET['post_type']=="azulladds" || $_GET['post_type']=="azulloffice"){
            switch ($_GET['post_type']) {
               case 'property':
                  break;
               default:
                  ?>
                  <style>
                     .row-actions .edit {display: none !important;}
                  </style>
                  <script src="<?php echo AZULL_URL ?>js/jquery-1.11.0.min.js"></script>
                  <script type="text/javascript">
                     $(document).ready(function() {
                        $('table.wp-list-table a.row-title').contents().unwrap();
                     });
                  </script>
                  <?php
               break;
            }
         ?>
         <style>
            .trash{display: none !important;}
         </style>
         <?php } 
         if(get_post_type($_GET['post']) == 'property'){
         ?>
            <style>
               #postdivrich #content{background-color: #ddd !important;}
            </style>
            <script src="<?php echo AZULL_URL ?>js/jquery-1.11.0.min.js"></script> 
            <script type="text/javascript">
               $(document).ready(function() {
                  $('#content_ifr').addClass( "div_readonly");
                  $("#property_meta_meta_box").addClass( "div_readonly").css("background-color", "#ddd");
                  $("#wp-content-wrap").addClass( "div_readonly").css("background-color", "#ddd");
                  $("#property_meta_title_nl").css("background-color", "#ddd");
                  $("#property_meta_keywords_nl").css("background-color", "#ddd");
                  $("#property_meta_description_nl").css("background-color", "#ddd");
                  $('#postimagediv').addClass( "div_readonly");
                  $('#manage_gallery').attr('disabled','disabled');
                  $("#property_gallery").css("background-color", "#ddd");
               });
            </script>
         <?php } ?>
      <style>
         .wrap .page-title-action{
            display: none !important;
         }
         #toplevel_page_WP-Optimize{display: none !important;}
      </style>
            <?php 
   break;            
         }
}

function remove_admin_menu_items() {
   $userRole=getUserRoles();
   $remove_menu_items = array(__('Export'));
   switch ($userRole){
      case "view_01":
           remove_menu_page( 'WP-Optimize' ); 
           remove_menu_page( 'ninja-forms' ); 
           $remove_menu_items = array(__('Dashboard'),__('Thank'),__('Translation'),__('Posts'),__('WP'),__('Pages'),__('Media'),__('Forms'),__('Company'));
         break;
      case "office":
           $remove_menu_items = array(__('Dashboard'),__('Thank'),__('Import'),__('Pages'),__('Media'),__('Forms'),__('Websites'),__('Company'),__('Comments'),__('WP'),__('WP-Optimize'));
         break;
      case "editor":
           $remove_menu_items = array(__('Weather'),__('Dashboard'),__('Thank'),__('Import'),__('Pages'),__('Media'),__('Forms'),__('Websites'),__('Company'),__('Comments'),__('Tools'),__('WP'),__('Settings'));
         break;
      case "author":
           $remove_menu_items = array(__("Weather"),__('Dashboard'),__('Thank'),__('Import'),__('Info'),__('Pages'),__('Forms'),__('Properties'),__('Media'),__('Testimonials'),__('Tools'),__('Websites'),__('Company'),__('Comments'),__('WP'),__('Settings'));
         break;
      case "agent":
           $remove_menu_items = array(__('Dashboard'),__('Thank'),__('Azull'),__('Info'),__('WP'),__('Pages'),__('Media'),__('Forms'),__('Testimonials'),__('Tools'),__('Websites'),__('Company'),__('Comments'));
         break;
      case "info":
           $remove_menu_items = array(__('Posts')  ,__('Dashboard'),__('Thank'),__('WP'),__('Settings'),__('Location'),__('Translation'),__('Import'),__('Pages'),__('Forms'),__('Media'),__('Tools'),__('Websites'),__('Company'),__('Comments'));
         break;
      case "ie":
           $remove_menu_items = array(__('Location'),__('Dashboard'), __('Thank'),__('Posts'),__('Settings'),__('WP'),__('Translation'),__('Info'),__('Import'),__('Pages'),__('Forms'),__('Media'),__('Tools'),__('Websites'),__('Company'),__('Comments'),__('Testimonials'));
         break;
      case "price":
           $remove_menu_items = array(__('Posts')  ,__('Dashboard'),__('Thank'),__('WP'),__('Settings'),__('Location'),__('Translation'),__('Import'),__('Pages'),__('Forms'),__('Media'),__('Tools'),__('Websites'),__('Company'),__('Comments'));
         break;   

   }
	global $menu;
	end ($menu);
	while (prev($menu)){
		$item = explode(' ',$menu[key($menu)][0]);
      
		if(in_array($item[0] != NULL?$item[0]:"" , $remove_menu_items)){
		unset($menu[key($menu)]);}
	}
}
function getUserRoles(){
         $admin_role = $current_user->roles;
         $userRole='';
         $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }
	 
         return $userRole;
}


function getUserRole(){
   $userRole = getUserRoles();
   switch ($userRole){
      case "administrator":
           add_action( 'init', 'create_posttype_company');
           add_action('admin_menu', 'remove_admin_menu_items');
         break;
      case "view_01":
           add_action( 'admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');
         break;
      case "office":
           //add_action('admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');  
         break;
      case "editor":
           add_action('admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');
         break;
      case "author":
           add_action('admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');
         break;
      case "agent":
           add_action('admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');
         break;
      case "info":
           add_action( 'admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');
        break;
      case "ie":
           add_action( 'admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');
        break;
      case "price":
           add_action( 'admin_menu', 'remove_menus' );
           add_action('admin_menu', 'remove_admin_menu_items');
        break;  
    
   }
      
}
function restrict_categories($categories) {
   if(isset($categories) && !empty($categories)){  
      global $typenow;
      $new_categories=array();
      if ($typenow == "post") {
         //print('<pre>');print_r($categories);die;
               foreach ($categories as $term) {
                  $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
                  if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'post') {
                     //print('<pre>');print_r($term->name);die;
                     $new_categories[] = $term;
                     //$new_categories['name'] = $term->name;//qtranxf_use(qtranxf_getLanguage(), $term->name);
                  }
               }
            }
      if ($typenow == "property") {
               foreach ($categories as $term) {
                  $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
                  if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'property') {
                     $new_categories[] = $term;
                  }else{
                     $new_categories[] = $term;
                  }
               }
            }
      return $new_categories;
   }
}
/*
* Date : 20-08-2016
* Method : for display property banner at property preview page
*/
function property_banner($post_id=false,$flag=false){
  global $post,$q_config;
  
  if($post_id && !$flag){
      $term = wp_get_post_terms((integer)$post_id, 'banner');
      $meta    = get_option('qtranxf_term_name');
      $lang    = qtranxf_getSortedLanguages();
      return ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);
  }
  if($post_id && $flag){
      $term = wp_get_post_terms($post_id, 'banner');
      $meta    = get_option('qtranxf_term_name');
      $lang    = qtranxf_getSortedLanguages();
      echo ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);
  }
  
  return false;
  
}

add_action('init', 'checkRole' );
function checkRole(){
?>

<?php

       /*global $wp_taxonomies;
        $admin_role = $current_user->roles;
         $userRole='';
         $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         } */  
if($_GET['taxonomy'] == 'proprietor'){

?>
<script src="<?php echo AZULL_URL ?>js/jquery-1.11.0.min.js"></script> 
<script>
$(document).ready(function(){
 setTimeout(function(){ 
   $("#txnUpass").prop('type','password');
  }, 2900);
  });
</script>

<?php }

/*if($userRole =='info' OR $userRole =='view_01' OR $userRole== 'editor'){?>
   <script src="<?php echo AZULL_URL ?>js/jquery-1.11.0.min.js"></script> 
   <script>
 $(document).ready(function(){
 $("#the-list a.row-title").attr("href", "javascript:void(0)");
 $("#wpadminbar ul#wp-admin-bar-root-default>li").css("display", "none");
  });
</script>?>
<?php }*/

}

/*function bitflower_change_post_link($link, $post) {

        //replace www part with server1 using the following php function
        //preg_replace ( patter, replace, subject ) syntax
        // $link = preg_replace('/cms/', '', $link);
          $data=get_post(get_the_ID());
          ///echo "<pre>";print_r($data->post_title);
        // $link = 'http://azull.biz/cisin/archieven/property/nieuwe-villa-aan-golf-met-prive-zwembad';
         return $link;
}
add_filter('preview_post_link', 'bitflower_change_post_link', 10, 2);*/


add_action( 'wp_ajax_nopriv_azull_update_gallery', 'azull_update_gallery_callback' );
add_action( 'wp_ajax_azull_update_gallery', 'azull_update_gallery_callback' );

function azull_update_gallery_callback() {
    if( isset($_POST['azull_update_gallery']) && $_POST['azull_update_gallery'] == 'yes' ) {
        echo do_shortcode('[gallery link="none" ids="' . $_POST['gallery_ids'] . '" columns="10"]').'<div class="fadeout">Gallery updated!</div>'; 
    }
    die();
}