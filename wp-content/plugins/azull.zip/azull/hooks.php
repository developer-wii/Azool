<?php
/* all the hooks and filters that has been used in pluging file
 * @package:wordpress
 * @subpackage:azull
 */
defined('ABSPATH') or die("No script kiddies please!");
add_action( 'admin_enqueue_scripts', array($this,'_js') );
add_action( 'admin_enqueue_scripts', array($this,'_css'));
		 
add_action( 'plugins_loaded',array('Ajull_Property', 'instance'));                 

add_action( 'plugins_loaded',array('Azull_Seo_Meta', 'instance'));
add_action( 'plugins_loaded',array('Ajull_CustomPosts', 'instance'));
add_action( 'plugins_loaded',array('Media_Attachment', 'instance'));

add_action( 'wp_loaded', array('azull','restrict_wplogin'), 1 );	
add_action( 'admin_init', array('azull','custom_deregister_editor_expand') );	 

add_action('init', array('azull','MultiPostThumbnails'));
add_action( 'init',array('Class_Site', 'instance'));

add_action('edit_form_after_title', array('Azull_Meta','post_external_link'));

add_action('add_meta_boxes',  array('Azull_Meta','external_link'));

add_action('admin_notices', array('Azull_Action','azull_bulk_admin_notices'));
add_action( 'admin_init', array('Azull_Meta','add_multiple_page_thumbnails_from_plugin') );

add_action('wp', array('azull', 'generate_pdf'));                 

add_action('do_meta_boxes', array('Property_Meta','remove_post_image'));
add_filter('manage_edit-azull_site_columns', array('Class_Site','add_site_columns'));
add_filter('manage_azull_site_posts_custom_column', array('Class_Site','site_fill_columns'));
          
add_action('add_meta_boxes', array('Property_Meta', 'add_property_gallery_metabox'));
add_action('save_post', array('Property_Meta', 'save_property_metaboxes'));                 
add_action( 'save_post', array('Property_Meta','save_property') );
add_action( 'save_post', array('Azull_Meta','save_meta') );

add_action('edit_term',array('Property_Meta','save_taxonomy_meta'));
add_action('create_term',array('Property_Meta','save_taxonomy_meta'));

add_action( 'admin_enqueue_scripts', array('azull','load_admin_things' ));
add_action('after_setup_theme',  array('azull','azull_setup'));

add_action( 'agent_edit_form_fields', array('Property_Meta','term_edit') );
add_action( 'feature_add_form_fields', array('Property_Meta','features_options') );
add_action( 'feature_edit_form_fields', array('Property_Meta','features_options') );

add_action( 'category_add_form_fields', array('Property_Meta','category_options') );
add_action( 'category_edit_form_fields', array('Property_Meta','category_options') );

add_action( 'region_add_form_fields', array('Property_Meta','region_add_options') );
add_action( 'region_edit_form_fields', array('Property_Meta','region_edit_options') );

add_action( 'provinces_add_form_fields', array('Property_Meta','provinces_add_options') );
add_action( 'provinces_edit_form_fields', array('Property_Meta','provinces_edit_options') );

add_action( 'place_add_form_fields', array('Property_Meta','place_add_options') );
add_action( 'place_edit_form_fields', array('Property_Meta','place_edit_options') );

add_action( 'proprietor_add_form_fields', array('Property_Meta','proprietor_options') );
add_action( 'edit_term', array('Property_Meta','update_agents') );
add_action( 'proprietor_edit_form_fields', array('Property_Meta','proprietor_options') );
add_action( 'proprietor_edit_form_fields', array('Property_Meta','term_edit') );

add_action('admin_menu', array('azull', '_hook_meta'));
add_action('admin_menu',array('Settings', 'init')); 
add_action('admin_menu',array('Class_Site', 'site_metaboxes'));
                 

add_action('add_attachment', array('azull', 'add_attachment'));
add_action('delete_attachment', array('azull', 'delete_attachment'));
//check post unpublish event - 07-Nov-2016
//add_action('transition_post_status', array('Xmlrpc_Client', 'delete_post'),20, 3);
add_action( 'pre_get_posts', array('Azull_Search','filter_query'),100 );

add_action( 'restrict_manage_posts', array('Azull_Search','filter_display') );

add_action( 'admin_head', array('azull','bulk_action') );  
add_filter('user_contactmethods',array('Azull_Subscriber','_profile'));

add_action('admin_head', array('Azull_Subscriber','profile_admin_buffer_start'));
add_action('admin_footer', array('Azull_Subscriber','profile_admin_buffer_end'));
              
add_action('admin_head',array('Azull_Subscriber','hide_personal_options'));              
add_action('admin_menu', array('Azull_Subscriber','azull_email'));
add_action('admin_menu', array('Azull_Action','pdf_page'));              
               
add_action('admin_menu', array('Azull_Action','print_page'));
add_action('admin_menu', array('Azull_Action','import_csv_page'));
add_action('admin_menu', array('Azull_Action','export_csv_page'));
               
add_action('admin_menu', array('Azull_Action','import_xml_page'));
add_action('admin_menu', array('Azull_Action','export_xml_page'));
               
add_action('load-edit.php', array('azull','action_redirect'));              

add_action( 'wp_ajax_email_action', array('Azull_Subscriber','email_callback') );
add_action( 'wp_ajax_print_action', array('Azull_Action','ajax_print_tpl') );

add_action( 'pre_get_posts', array('Property_Meta','property_sorting'), 200);

add_action( 'posts_clauses', array('Property_Meta','mbe_sort_custom_column'), 10, 2);
// Because Johan want only english language in backend- 09-June-2016 
add_filter( 'gettext', array( 'Azull_Utility','azull_gettext_filter'), 20, 3 );     
add_action( 'wp_ajax_loadaFinincialData', array('Azull_Utility' ,'finincial_data')); 
add_action( 'wp_ajax_loadaTax', array('Azull_Utility' ,'loadaTax'));


  
add_action( 'wp_ajax_terms_region_provinces', array('Azull_Utility' ,'terms_region_provinces'));
add_action( 'wp_ajax_terms_region_place', array('Azull_Utility' ,'terms_region_place'));

add_action( 'wp_ajax_carasoleBlockUpdate', array('Azull_Utility' ,'carasoleBlockUpdate'));

add_action( 'wp_ajax_azull_region', array('Azull_Utility' ,'azull_region'));
add_action( 'wp_ajax_azull_province', array('Azull_Utility' ,'azull_province'));
add_action( 'wp_ajax_azull_place', array('Azull_Utility' ,'azull_place'));
	    

add_action( 'after_setup_theme', array('azull','restrict_frontend') );

add_action( 'authenticate', array('azull','check_username_password'), 1, 3);


add_action( 'wp_login_failed',  array('azull','front_end_login_fail') );
add_action('admin_menu',  array('azull','remove_menus'));
add_filter( 'preview_post_link',  array('azull','azull_preview_link') );
add_action('after_setup_theme', array('azull','azull_theme_setup') );

add_action( 'init',  array('azull','azull_load_textdomain') );


add_action( 'admin_enqueue_scripts', array('azull','azull_hide_category') );

add_filter("manage_edit-region_columns", array('Azull_Utility','region_columns'), 10, 3);
add_filter("manage_region_custom_column", array('Azull_Utility','manage_region_columns'), 10, 3);

add_filter("manage_edit-provinces_columns", array('Azull_Utility','provinces_columns'), 10, 3);
add_filter("manage_provinces_custom_column", array('Azull_Utility','manage_provinces_columns'), 10, 3);

add_filter("manage_edit-place_columns", array('Azull_Utility','place_columns'), 10, 3);
add_filter("manage_place_custom_column", array('Azull_Utility','manage_place_columns'), 10, 3);

add_filter("manage_edit-proprietor_columns", array('Azull_Utility','proprietor_columns'), 10, 3);
add_filter("manage_proprietor_custom_column", array('Azull_Utility','manage_proprietor_columns'), 10, 3);

add_action( 'wp_ajax_import_properties', array('Azull_Utility' ,'send_import_properties_request'));
add_action( 'wp_ajax_nopriv_import_properties', array('Azull_Utility' ,'send_import_properties_request'));

/* show dropdown with ajax */ 
add_action( 'wp_ajax_get_client_dropdown', array('azull','callclient_dropDown'));

/* Display email template for clients*/
add_action( 'wp_ajax_cmp_email_template', array('Azull_Subscriber','get_cmp_email_template') );

 /* Add Custom button on post.php for property (email/pdf)*/   
add_action('admin_head', array('azull','customAdd_button_property'));

add_action( 'post_submitbox_misc_actions', array('azull','custom_button'));
//24-3-2017 Tien commented this out to ensure the page does not redirect after property saving
//add_filter( 'redirect_post_location', array('azull','p_redirect_post_location') );
/****** for add/update/delete terms taxonomy at clients *****/
$taxonomy = $_REQUEST['taxonomy'];
add_action('create_'.$taxonomy, array('azull', 'xmlrpc_created_terms'));
add_action('edited_'.$taxonomy, array('azull', 'xmlrpc_edited_terms'));
add_action('delete_'.$taxonomy, array('azull', 'xmlrpc_deleted_terms'),10,3);
//****** for set cron job for import property data from azull.info to azull.biz ******//
add_action('wp_ajax_import_property_custom_cron', array('Azull_Utility' ,'import_property_custom_cron_request'));
add_action('wp_ajax_nopriv_import_property_custom_cron', array('Azull_Utility' ,'import_property_custom_cron_request'));
/* Date:01-06-2016 display client list to add/update menu page*/
add_action( 'wp_ajax_get_client_list', array('azull','get_client_list'));
/* Date: 01-06-2016 add/update menu*/
add_action('wp_update_nav_menu', array('azull','add_update_menu'),10,3);
add_action('check_admin_referer', array('azull','update_menu_location'),10,3);
/* Date: 18-06-2016 azull_mortgage_price_calculate */
add_action( 'wp_ajax_mortgage_price_calculate', array('azull' ,'azull_mortgage_price_calculate'));
add_action( 'wp_ajax_nopriv_mortgage_price_calculate', array('azull' ,'azull_mortgage_price_calculate'));
/* Date: 12-07-2016 add thanku page content */
//add_action( 'wp_ajax_addThankuPageText', array('azull' ,'addThankuPageText'));
/* Date: 25-07-2016 add page block dropdown */
add_action( 'wp_ajax_loadPageDropDown', array('azull' ,'loadPageDropDown'));


add_action('edit_form_after_title', array('Azull_Meta','post_slider_text'));
add_action('add_meta_boxes',  array('Azull_Meta','add_slider_text'));
//****** for save weather info for each place ******//
add_action('wp_ajax_save_weather_info', array('Azull_Utility' ,'save_weather_info_request'));
add_action('wp_ajax_nopriv_save_weather_info', array('Azull_Utility' ,'save_weather_info_request'));
add_action('wp_ajax_get_place_weather_info', array('Azull_Utility' ,'get_place_weather_info_request'));
add_action('wp_ajax_nopriv_get_place_weather_info', array('Azull_Utility' ,'get_place_weather_info_request'));

//add_filter('get_terms', 'restrict_categories');
/* Date: 11-Aug-2016 
 * Method: For get taxonomy action*/
add_action('load-edit-tags.php', array('azull','process_taxonomy_bulk_action'));


add_action( 'category_add_form_fields', array('Property_Meta','category_options_hide_post') );
add_action( 'category_edit_form_fields', array('Property_Meta','category_options_hide_post') );
/*
* Date: 02-Sep-2016
* for get email title
*/
add_action('wp_ajax_get_email_title', array('azull' ,'get_email_title'));
add_action('wp_ajax_get_email_title', array('azull' ,'get_email_title'));

add_action( 'init', 'addLocationcheckRole' );

function addLocationcheckRole(){
	$user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }
  if($userRole=='office'){
    add_action( 'admin_menu', array('azull','register_location_page_office') );
  }if($userRole=='administrator'){
  	add_action( 'admin_menu', array('azull','register_location_page') );
  }
}
/*Date: 12-Oct-2016*/
add_action( 'wp_ajax_saveThkPageInfor', array('azull' ,'saveThkPageInfor'));
add_action('wp_ajax_nopriv_saveThkPageInfor', array('azull' ,'saveThkPageInfor'));
add_action( 'wp_ajax_getClientPageList', array('azull' ,'getClientPageList'));
add_action('wp_ajax_nopriv_getClientPageList', array('azull' ,'getClientPageList'));
add_action( 'wp_ajax_getThkPageInfor', array('azull' ,'getThkPageInfor'));
add_action('wp_ajax_nopriv_getThkPageInfor', array('azull' ,'getThkPageInfor'));

add_action('project_add_form_fields', array('Property_Meta','add_project_options'));
add_action('project_edit_form_fields', array('Property_Meta','edit_project_options'));

add_action( 'wp_ajax_getProjectList', array('azull' ,'getProjectList'));
add_action('wp_ajax_nopriv_getProjectList', array('azull' ,'getProjectList'));

add_action( 'wp_ajax_setPropertyExportList', array('azull' ,'setPropertyExportList'));
add_action('wp_ajax_nopriv_setPropertyExportList', array('azull' ,'setPropertyExportList'));
add_action( 'wp_ajax_getSessionProperties', array('azull' ,'getSessionProperties'));
add_action('wp_ajax_nopriv_getSessionProperties', array('azull' ,'getSessionProperties'));
add_action('wp_ajax_export_azull_properties', array('azull' ,'export_azull_properties'));
add_action('wp_ajax_nopriv_export_azull_properties', array('azull' ,'export_azull_properties'));

/*Action to update price detail for "price user"
  Date: 02/12/2016
  Author: manoj(ab)
*/
add_action('wp_ajax_property_price', array('Azull_Utility' ,'property_price_val'));
add_action('wp_ajax_nopriv_property_price', array('Azull_Utility' ,'property_price_val'));

add_action('wp_ajax_update_property_price', array('Azull_Utility' ,'update_property_price_val'));
add_action('wp_ajax_nopriv_update_property_price', array('Azull_Utility' ,'update_property_price_val'));

/* filter to add for project textnomy*/
add_filter("manage_edit-project_columns", array('Azull_Utility','project_columns'), 10, 3);
add_filter("manage_project_custom_column", array('Azull_Utility','manage_project_columns'), 10, 3);
//****** for save location translation info for each place ******//
add_action('wp_ajax_save_location_translation', array('azull' ,'save_location_translation'));
add_action('wp_ajax_nopriv_save_location_translation', array('azull' ,'save_location_translation'));
add_action('wp_ajax_get_loc_trans_info', array('azull' ,'get_location_trans'));
add_action('wp_ajax_nopriv_get_loc_trans_info', array('azull' ,'get_location_trans'));
add_action( 'wp_ajax_delete_loc_trans', array('azull' ,'delete_location_trans'));
add_action( 'wp_ajax_nopriv_delete_loc_trans', array('azull' ,'delete_location_trans'));
//****** for delete weather info of selected place ******//
add_action( 'wp_ajax_delete_weather_info', array('Azull_Utility' ,'delete_weather_info'));
add_action( 'wp_ajax_nopriv_delete_weather_info', array('Azull_Utility' ,'delete_weather_info'));
//function for add custom permalink meta box
add_action('add_meta_boxes',  array('Azull_Meta','add_permalink_metabox'));
//function for display seo meta in SEO meta box
add_action( 'wp_ajax_get_add_seo_meta', array('Azull_Seo_Meta' ,'azull_add_get_seometa'));
add_action( 'wp_ajax_nopriv_get_add_seo_meta', array('Azull_Seo_Meta' ,'azull_add_get_seometa'));

//function for get site flag content
add_action('wp_ajax_get_flag_descrption', array('azull' ,'get_flag_descrption'));
add_action('wp_ajax_get_flag_descrption', array('azull' ,'get_flag_descrption'));