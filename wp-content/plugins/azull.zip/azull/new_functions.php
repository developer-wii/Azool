<?php
/* defination of all common function used in plugin.
 * @package:wordpress
 * @subpackage:azull
 */

defined('ABSPATH') or die("No script kiddies please!");

//move to hook
add_action('after_setup_theme', 'remove_admin_bar');
add_theme_support( 'post-thumbnails' );
function remove_admin_bar() {
  show_admin_bar(false);
   add_image_size( 'pdf-large',850,558,array( 'center', 'center' ) ); // 300 pixels wide (and unlimited height)
   add_image_size( 'pdf-small', 263, 251, array( 'center', 'center' ) ); // (cropped)
   
   add_image_size( 'print-A5-large',850,400,array( 'center', 'center' ) ); // 300 pixels wide (and unlimited height)
   //add_image_size( 'print-Asmall', 263, 251, array( 'center', 'center' ) ); // (cropped)
}

add_action('init', 'my_custom_init');
function my_custom_init() {
	add_post_type_support( 'page', 'excerpt' );	 
}

function azull_gallery($post_id,$limit,$size='full',$flag=false){    
    $html="";                 
    $i=0;    
    
    $html .= "<ul class='row'>";
        foreach (  Property_Meta::azull_gallery($post_id) as $id ) {		
           if(get_post_thumbnail_id( $post_id )!=$id && $i< $limit):
            		$html .= '<li class="col-xs-6">';
                $html .= wp_get_attachment_image( $id, 'pdf-small');
            		$html .= '</li>';
            $i++;
          endif;
        }
       $html .="</ul>";  
    
    if(!$flag && $html!='')
    return $html;
    
    if($flag && $html!='')
    echo $html;
    
    return false;
               
}
function features_icon($post_id=false,$flag=false){
  if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }

  $html ='<ul class="row">';
  
         $terms  = get_terms( 'feature', 'orderby=id&hide_empty=0' );    
         if ( !empty( $terms ) && !is_wp_error( $terms ) ){
         
	    $taxonomy_meta['type']=1;$taxonomy_meta['search']=0;
              foreach ( $terms as $term ) {
	       $taxonomy_meta = get_option('azull_taxonomy_meta_'.$term->term_id);
	            if($taxonomy_meta['type']==2 && get_post_meta($post_id,'_feature_'.$term->term_id,true)!=''){
                        $html .="<li class='col-xs-4'><img alt='".qtranxf_use(qtranxf_getLanguage(),$term->name)."' title='".qtranxf_use(qtranxf_getLanguage(),$term->name)."'  ".((!isset($val[$term->term_id]))? 'class="gray-image"':'')." src='".z_taxonomy_image_url($term->term_id)."'><span>".get_post_meta($post_id,'_feature_'.$term->term_id,true)."</span></li>";
		    }
		  $taxonomy_meta['search']=0;  
               }
         }
         
  $html .= walkScores_img($post_id);
  $html .= dimensions_img($post_id);
  $html .= locality('locality',$post_id);
  $html .= features_img('feature',$post_id);
  $html .= features_img('interior',$post_id);
  $html .= features_img('exterior',$post_id);  
  $html .='</ul>';

  if($flag)
  echo $html;
  
    return $html;

}
function locality($tax='locality',$post_id,$flag=false){
	if(!$post_id){
		global $post;
		$post_id = $post->ID;   
	}
	
	$terms = wp_get_post_terms($post_id, $tax);
	
	if ( !empty( $terms ) && !is_wp_error( $terms ) ){
			       
	   foreach ( $terms as $term ) {
		   $html .=  "<li class='col-xs-4'><img alt='".qtranxf_use(qtranxf_getLanguage(),$term->name)."' title='".qtranxf_use($lng,$term->name)."'  src='".z_taxonomy_image_url($term->term_id)."' /></li>";
	       }		   
	}           
 
  if($flag) 
	echo $html;
  
  return $html;
}
function walkScores_img($post_id=false,$flag=false){
  if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }
  $html = '';

  $terms  = get_terms( 'walkscores', 'orderby=id&hide_empty=0' );
  
  if ( !empty( $terms ) && !is_wp_error( $terms ) ){
    foreach ( $terms as $term ) {	
	$distance="";
	$val=get_post_meta($post_id,'_scores_'.$term->term_id,true);
	if(isset($val) && $val!=""){
	    $distance .="<span>";
	    $distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km' : number_format((float)$val,0,".","") .'m';
	    $distance .="</span>";	    
	    $html .=  "<li class='col-xs-4'> <img alt='".qtranxf_use(qtranxf_getLanguage(),$term->name)."' title='".qtranxf_use(qtranxf_getLanguage(),$term->name)."'  ".((!isset($val))? 'class="gray-image"':'')." src='".z_taxonomy_image_url($term->term_id)."' />".$distance."</li>";
	}
    }  
  }
  
  if($flag) 
    echo $html;  
  return $html;

}
function dimensions_img($post_id=false,$flag=false){
    if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }
  $html = '';
  $terms  = get_terms( 'dimensions', 'orderby=id&hide_empty=0' );
	    
 if ( !empty( $terms ) && !is_wp_error( $terms ) ){
                        
    foreach ( $terms as $term ) {
	$distance="";
	$val=get_post_meta($post_id,'_dimensions_'.$term->term_id,true);
	if(isset($val) && $val!=""){
	    $distance .="<span>";
	    $distance .= ((float)$val>999) ? number_format(((float)$val/1000),0,".","").'km<sup>2</sup>' : number_format((float)$val,0,".","") .'m<sup>2</sup>';					
	    $distance .="</span>";	    
	    $html .=  "<li class='col-xs-4'><img alt='".qtranxf_use(qtranxf_getLanguage(),$term->name)."' title='".qtranxf_use($lng,$term->name)."'  ".((!isset($val))? 'class="gray-image"':'')." src='".z_taxonomy_image_url($term->term_id)."' />".$distance."</li>";
	}		   
    }           
  }
  
  if($flag) 
  echo $html;
  
  return $html;
  
}
/**
 *@param:key property fetures taxonomy slug
 *@param:post_id property post id
 *@param:flag for echo or return.
 */
function features_img($key,$post_id=false,$flag=false){
  
  if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }
  $html = ''; $val=array();
  $terms  = get_terms( $key, 'orderby=id&hide_empty=0' );	
  $val = wp_get_post_terms($post_id, $key, array("fields" => "ids"));
  
   // Generate Interiors meta box HTML,
  if ( !empty( $terms ) && !is_wp_error( $terms ) ){
    foreach ( $terms as $term ) {
      if(in_array($term->term_id,$val)){
       $html .=  "<li class='col-xs-4'><img  ".(($flag) ? "width='70'":"")." alt='".qtranxf_use(qtranxf_getLanguage(),$term->name)."' title='".qtranxf_use(qtranxf_getLanguage(),$term->name)."'   src='".z_taxonomy_image_url($term->term_id)."' /></li>";
      }
    }
  }
   
  if($flag) 
  echo $html;
  
  return $html;
}

/**
 *@param:key property price 'sales price, old price, total price' is *required
 *@param:post_id property post id
 *@param:flag,to return value.
 *@note:handle currency symbole on the template.
 */
function azull_price($key='',$post_id=false,$flag=false){
 
  if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }
  
  
  switch (strtolower($key)) {
      case 'sales price':
	  $price = get_post_meta($post_id,'_salesPrice',true);  
	  break;
      case 'old price':
	  $price = get_post_meta($post_id,'_oldPrice',true); 
	  break;
      case 'total price':
             
        $country=get_post_meta($post_id,'_country',true);
	    $region=get_post_meta($post_id,'_region',true);
	    $province=get_post_meta($post_id,'_province',true);
	     
	    if(isset($country)){
	     if(get_option('country_tax_'.$country)) 	
	     $azullTax=get_option('country_tax_'.$country);
	     
	    }
	    if(isset($region)){
	       if(get_option('region_tax_'.$region))
	       $azullTax =get_option('region_tax_'.$region);   	
	    }	 
	    if( isset($province)){
	       if(get_option('region_tax_'.$province))	
		$azullTax =get_option('province_tax_'.$province);
	    }
	    
	    if($azullTax)
	    $default = json_decode($azullTax,true);
            $totalPrice = 0;
            $price = (get_post_meta($post_id,'_salesPrice',true)) ?  $price = get_post_meta($post_id,'_salesPrice',true):0;
            $buildType=get_post_meta($post_id,'_buildType',true);
            
            $vat_min = ((isset($default["vat"]["min"]) && $default["vat"]["min"] != '') ? $default["vat"]["min"] : 0);
            $vat_per = ((isset($default["vat"]["per"]) && $default["vat"]["per"] != '') ? $default["vat"]["per"] : 0);
            $vat_per = max($vat_per,(get_post_meta($post_id,'_vat',true)) ? get_post_meta($post_id,'_vat',true) :0);           
            $vat = max($vat_min,($vat_per/100) * $price);
            
            $transmissionTax_min = ((isset($default["transmissionTax"]["min"]) && $default["transmissionTax"]["min"] != '') ? $default["transmissionTax"]["min"] :0);
            $transmissionTax_per = ((isset($default["transmissionTax"]["per"]) && $default["transmissionTax"]["per"] != '') ? $default["transmissionTax"]["per"] : 0);
            $transmissionTax_per = max($transmissionTax_per,(get_post_meta($post_id,'_transmissionTax',true)) ? get_post_meta($post_id,'_transmissionTax',true) :0);
            $transmissionTax = max($transmissionTax_min,($transmissionTax_per/100) * $price);           
            
            $stampDuty_min = ((isset($default["stampDuty"]["min"]) && $default["stampDuty"]["min"] != '') ? $default["stampDuty"]["min"] : 0);
            $stampDuty_per = ((isset($default["stampDuty"]["per"]) && $default["stampDuty"]["per"] != '') ? $default["stampDuty"]["per"] : 0);
            $stampDuty_per = max($stampDuty_per,(get_post_meta($post_id,'_stampDuty',true)) ? get_post_meta($post_id,'_stampDuty',true) :0);
            $stampDuty=max($stampDuty_min,($stampDuty_per/100) * $price);
             
            $notaryCost_min = ((isset($default["notaryCost"]["min"]) && $default["notaryCost"]["min"] != '') ? $default["notaryCost"]["min"] : 0);
            $notaryCost_per = ((isset($default["notaryCost"]["per"]) && $default["notaryCost"]["per"] != '') ? $default["notaryCost"]["per"] : 0);
            $notaryCost_per = max($notaryCost_per,(get_post_meta($post_id,'_notaryCost',true)) ? get_post_meta($post_id,'_notaryCost',true) :0);
            $notaryCost=max($notaryCost_min,($notaryCost_per/100) * $price);
            
            
            $lawyerCost_min = ((isset($default["lawyerCosts"]["min"]) && $default["lawyerCosts"]["min"] != '') ? $default["lawyerCosts"]["min"] : 0);
	    	    $lawyerCost_per = ((isset($default["lawyerCosts"]["per"]) && $default["lawyerCosts"]["per"] != '') ? $default["lawyerCosts"]["per"] : 0);
	   		    $lawyerCost_per = max($lawyerCost_per,(get_post_meta($post_id,'_lawyerCost',true)) ? get_post_meta($post_id,'_lawyerCost',true) :0);
            $lawyerCost=max($lawyerCost_min,($lawyerCost_per/100) * $price);
           
            
            $utilitiesConnectionCost_min = ((isset($default["utilitiesConnectionCost"]["min"]) && $default["utilitiesConnectionCost"]["min"] != '') ? $default["utilitiesConnectionCost"]["min"] : 0);
	   	     	$utilitiesConnectionCost_per = ((isset($default["utilitiesConnectionCost"]["per"]) && $default["utilitiesConnectionCost"]["per"] != 0) ?  $default["utilitiesConnectionCost"]["per"]:0);
            $utilitiesConnectionCost = max($utilitiesConnectionCost_min,($utilitiesConnectionCost_per/100) * $price);
            $utilitiesConnectionCost = max($utilitiesConnectionCost,(get_post_meta($post_id,'_utilitiesConnectionCost',true)) ? get_post_meta($post_id,'_utilitiesConnectionCost',true) :0);
            
            
            $buyerCost_min = ((isset($default["buyerCosts"]["min"]) && $default["buyerCosts"]["min"] != '') ? $default["buyerCosts"]["min"] : 0);
            $buyerCost_per = ((isset($default["buyerCosts"]["per"]) && $default["buyerCosts"]["per"] != '') ? $default["buyerCosts"]["per"] : 0);
            $buyerCost_per = max(buyerCost_per,(get_post_meta($post_id,'_buyerCost',true)) ? get_post_meta($post_id,'_buyerCost',true) :0);
            $buyerCost=max($buyerCost_min,($buyerCost_per/100) * $price);
             
            
            if($buildType=1){                
                $totalPrice = $price + $vat + $stampDuty + $notaryCost + $lawyerCost + $utilitiesConnectionCost;                
            }else{
                $totalPrice = $price + $transmissionTax +  $notaryCost + $lawyerCost + $utilitiesConnectionCost + $buyerCost; 
            }
            
            $price = (integer)$totalPrice;
            
	  //$price = get_post_meta($post_id,'_totalPrice',true); 
	  break;
  }
  //todo: maybe need tou use simple numberformate here
  
  if($price && !$flag)
  return  $price;

  if($price && $flag)
  echo $price; 
  
  return false;
  
}

/**echo property category or return it based on flag value. property taxonomy is beeing stored as categories
 *@param:post_id*, if post id is not provide global post will be used to ge id
 *return: property category
 */
function property_category($post_id=false,$flag=false){
  global $post,$q_config,$aj_config; 
  if(!$post_id){    
    $post_id = $post->ID;   
  }
  $lang =  qtranxf_getLanguage();
  if(!qtranxf_getLanguage()){
		
	$lang=$q_config['language'];
  }
  if($post_id && !$flag){
      $term = wp_get_post_terms($post_id, 'category');
       $terms = get_term( $term[0]->term_id,'category' );       
       $meta    = get_option('qtranslate_term_name');      
      
       return ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);
  }
  if($post_id && $flag){
      $term = wp_get_post_terms($post_id, 'category');
      $terms = get_term( $term[0]->term_id,'category' );      
      $meta    = get_option('qtranslate_term_name'); 
      echo  ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);
  }
  
  return false;
}



function property_location($post_id=false,$flag=false){
  global $post,$q_config,$aj_config; 
  if(!$post_id){    
    $post_id = $post->ID;   
  }
  $lang =  qtranxf_getLanguage();
  if(!qtranxf_getLanguage()){
		
	$lang=$q_config['language'];
  }
  $meta    = get_option('qtranslate_term_name');
  $lang    = qtranxf_getLanguage();  
  
  $location="";

    $term = wp_get_post_terms($post_id, 'place');
    if($term)
        $location .= ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name).", ";
    
    //$term = wp_get_post_terms($post_id, 'provinces');
   //if($term)
        //$location .= qtranxf_use(qtranxf_getLanguage(),$term[0]->name).", ";
        
    $term = wp_get_post_terms($post_id, 'region');
    if($term)
        $location .= ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name).", ";
        
    $term = wp_get_post_terms($post_id, 'country');        
    if($term)
        $location .= ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);      
  
  
  if($post_id){

  }
  if($flag){
      echo $location;
  }
  
  return $location;
}


function remove_character_accent($String){

  $normalizeChars = array(
    '&amp;' => 'and',   '@' => 'at',    '©' => 'c', 'Ã' => 'a', 'À' => 'a',
    'Á' => 'a', 'Â' => 'a', 'Ä' => 'a', 'Å' => 'a', 'Æ' => 'ae','Ç' => 'c',
    'È' => 'e', 'É' => 'e', 'Ë' => 'e', 'Ì' => 'i', 'Í' => 'i', 'Î' => 'i',
    'Ï' => 'i', 'Ò' => 'o', 'Ó' => 'o', 'Ô' => 'o', 'Õ' => 'o', 'Ö' => 'o',
    'Ø' => 'o', 'Ù' => 'u', 'Ú' => 'u', 'Û' => 'u', 'Ü' => 'u', 'Ý' => 'y',
    'ß' => 'ss','à' => 'a', 'á' => 'a', 'â' => 'a', 'ä' => 'a', 'å' => 'a',
    'æ' => 'ae','ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e',
    'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 'ò' => 'o', 'ó' => 'o',
    'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u',
    'û' => 'u', 'ü' => 'u', 'ý' => 'y', 'þ' => 'p', 'ÿ' => 'y', 'Ā' => 'a',
    'ā' => 'a', 'Ă' => 'a', 'ă' => 'a', 'Ą' => 'a', 'ą' => 'a', 'Ć' => 'c',
    'ć' => 'c', 'Ĉ' => 'c', 'ĉ' => 'c', 'Ċ' => 'c', 'ċ' => 'c', 'Č' => 'c',
    'č' => 'c', 'Ď' => 'd', 'ď' => 'd', 'Đ' => 'd', 'đ' => 'd', 'Ē' => 'e',
    'ē' => 'e', 'Ĕ' => 'e', 'ĕ' => 'e', 'Ė' => 'e', 'ė' => 'e', 'Ę' => 'e',
    'ę' => 'e', 'Ě' => 'e', 'ě' => 'e', 'Ĝ' => 'g', 'ĝ' => 'g', 'Ğ' => 'g',
    'ğ' => 'g', 'Ġ' => 'g', 'ġ' => 'g', 'Ģ' => 'g', 'ģ' => 'g', 'Ĥ' => 'h',
    'ĥ' => 'h', 'Ħ' => 'h', 'ħ' => 'h', 'Ĩ' => 'i', 'ĩ' => 'i', 'Ī' => 'i',
    'ī' => 'i', 'Ĭ' => 'i', 'ĭ' => 'i', 'Į' => 'i', 'į' => 'i', 'İ' => 'i',
    'ı' => 'i', 'Ĳ' => 'ij','ĳ' => 'ij','Ĵ' => 'j', 'ĵ' => 'j', 'Ķ' => 'k',
    'ķ' => 'k', 'ĸ' => 'k', 'Ĺ' => 'l', 'ĺ' => 'l', 'Ļ' => 'l', 'ļ' => 'l',
    'Ľ' => 'l', 'ľ' => 'l', 'Ŀ' => 'l', 'ŀ' => 'l', 'Ł' => 'l', 'ł' => 'l',
    'Ń' => 'n', 'ń' => 'n', 'Ņ' => 'n', 'ņ' => 'n', 'Ň' => 'n', 'ň' => 'n',
    'ŉ' => 'n', 'Ŋ' => 'n', 'ŋ' => 'n', 'Ō' => 'o', 'ō' => 'o', 'Ŏ' => 'o',
    'ŏ' => 'o', 'Ő' => 'o', 'ő' => 'o', 'Œ' => 'oe','œ' => 'oe','Ŕ' => 'r',
    'ŕ' => 'r', 'Ŗ' => 'r', 'ŗ' => 'r', 'Ř' => 'r', 'ř' => 'r', 'Ś' => 's',
    'ś' => 's', 'Ŝ' => 's', 'ŝ' => 's', 'Ş' => 's', 'ş' => 's', 'Š' => 's',
    'š' => 's', 'Ţ' => 't', 'ţ' => 't', 'Ť' => 't', 'ť' => 't', 'Ŧ' => 't',
    'ŧ' => 't', 'Ũ' => 'u', 'ũ' => 'u', 'Ū' => 'u', 'ū' => 'u', 'Ŭ' => 'u',
    'ŭ' => 'u', 'Ů' => 'u', 'ů' => 'u', 'Ű' => 'u', 'ű' => 'u', 'Ų' => 'u',
    'ų' => 'u', 'Ŵ' => 'w', 'ŵ' => 'w', 'Ŷ' => 'y', 'ŷ' => 'y', 'Ÿ' => 'y',
    'Ź' => 'z', 'ź' => 'z', 'Ż' => 'z', 'ż' => 'z', 'Ž' => 'z', 'ž' => 'z',
    'ſ' => 'z', 'Ə' => 'e', 'ƒ' => 'f', 'Ơ' => 'o', 'ơ' => 'o', 'Ư' => 'u',
    'ư' => 'u', 'Ǎ' => 'a', 'ǎ' => 'a', 'Ǐ' => 'i', 'ǐ' => 'i', 'Ǒ' => 'o',
    'ǒ' => 'o', 'Ǔ' => 'u', 'ǔ' => 'u', 'Ǖ' => 'u', 'ǖ' => 'u', 'Ǘ' => 'u',
    'ǘ' => 'u', 'Ǚ' => 'u', 'ǚ' => 'u', 'Ǜ' => 'u', 'ǜ' => 'u', 'Ǻ' => 'a',
    'ǻ' => 'a', 'Ǽ' => 'ae','ǽ' => 'ae','Ǿ' => 'o', 'ǿ' => 'o', 'ə' => 'e',
    'Ё' => 'jo','Є' => 'e', 'І' => 'i', 'Ї' => 'i', 'А' => 'a', 'Б' => 'b',
    'В' => 'v', 'Г' => 'g', 'Д' => 'd', 'Е' => 'e', 'Ж' => 'zh','З' => 'z',
    'И' => 'i', 'Й' => 'j', 'К' => 'k', 'Л' => 'l', 'М' => 'm', 'Н' => 'n',
    'О' => 'o', 'П' => 'p', 'Р' => 'r', 'С' => 's', 'Т' => 't', 'У' => 'u',
    'Ф' => 'f', 'Х' => 'h', 'Ц' => 'c', 'Ч' => 'ch','Ш' => 'sh','Щ' => 'sch',
    'Ъ' => '-', 'Ы' => 'y', 'Ь' => '-', 'Э' => 'je','Ю' => 'ju','Я' => 'ja',
    'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e',
    'ж' => 'zh','з' => 'z', 'и' => 'i', 'й' => 'j', 'к' => 'k', 'л' => 'l',
    'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's',
    'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'c', 'ч' => 'ch',
    'ш' => 'sh','щ' => 'sch','ъ' => '-','ы' => 'y', 'ь' => '-', 'э' => 'je',
    'ю' => 'ju','я' => 'ja','ё' => 'jo','є' => 'e', 'і' => 'i', 'ї' => 'i',
    'Ґ' => 'g', 'ґ' => 'g', 'א' => 'a', 'ב' => 'b', 'ג' => 'g', 'ד' => 'd',
    'ה' => 'h', 'ו' => 'v', 'ז' => 'z', 'ח' => 'h', 'ט' => 't', 'י' => 'i',
    'ך' => 'k', 'כ' => 'k', 'ל' => 'l', 'ם' => 'm', 'מ' => 'm', 'ן' => 'n',
    'נ' => 'n', 'ס' => 's', 'ע' => 'e', 'ף' => 'p', 'פ' => 'p', 'ץ' => 'C',
    'צ' => 'c', 'ק' => 'q', 'ר' => 'r', 'ש' => 'w', 'ת' => 't', '™' => 'tm',
);

$nornal_str = strtr($String, $normalizeChars);
return $nornal_str;

}



/** Display or return property status fro the provided id
 *@param:flag,post id.
 */
function property_status($post_id=false,$flag=false){
  global $post,$q_config;
  $lang =  qtranxf_getLanguage();
  if(!qtranxf_getLanguage()){
		
	$lang=$q_config['language'];
  }
  if($post_id && !$flag){
      $term = wp_get_post_terms((integer)$post_id, 'status');
      $meta    = get_option('qtranslate_term_name');      
       return ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);
  }
  if($post_id && $flag){
      $term = wp_get_post_terms($post_id, 'status');
      $meta    = get_option('qtranslate_term_name');      
      echo ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);
  }
  
  return false;
  
}

/** 
 *@param:post_id property post id
 *@param:flag,to return value.
 *@return: true or false
 */
function is_penthouse($post_id=false){
  if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }  
  $penthouse = get_post_meta($post_id,'_penthouse',true);
  if($penthouse==1)
  return true;
  
  return false;  
}
/** 
 *@param:post_id property post id
 *@param:flag,to return value.
 *@return: true or false
 */
function is_bank($post_id=false){
  if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }  
  $penthouse = get_post_meta($post_id,'_bank',true);
  if($penthouse==1)
  return true;
  
  return false;  
}
/** 
 *@param:post_id property post id
 *@param:flag,to return value.
 *@return: buid type number 0 1 2 etc, check buld type finincial section.
 */
function build_type($post_id=false){
  if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }
  
  $buildtype = get_post_meta($post_id,'_buildType',true);
  if($buildtype)
  return $buildtype;
  
  return false;  
}
function build_year($post_id=false){
  
    if(!$post_id){
    global $post;
    $post_id = $post->ID;
   
  }  
  $year = get_post_meta($post_id,'_year',true);
  if($year)
  return $year;
  
  return false;
}

function azull_short_text($content, $echo = true, $length = false) {
	global $q_config;
	$lng =  qtranxf_getLanguage();
	if(!qtranxf_getLanguage()){		
	      $lng=$q_config['language'];
	}
         $title = qtranxf_use($lng,$content);

	if ( $length && is_numeric($length) && strlen($title) > $length ) {
		$title = strip_text($title,$length);
                
	}

	if ( $echo )
			echo strip_tags($title);
		else
			return strip_tags($title);
}

function strip_text($data,$size,$elipse = true){
    $data = strip_tags($data);          
    if(mb_strlen($data, 'utf-8') > $size){
        $result = mb_substr($data,0,mb_strpos($data,' ',$size,'utf-8'),'utf-8');
            if(mb_strlen($result, 'utf-8') <= 0){
            $result = mb_substr($data,0,$size,'utf-8');
            $result = mb_substr($result, 0, mb_strrpos($result, ' ','utf-8'),'utf-8');;         
        }
        if($elipse) {
            $result .= "...";
        }
    }else{
    $result = $data;
    }
    return $result; 
}

function unhide_kitchensink( $args )
{
   $args['wordpress_adv_hidden'] = false;
   return $args;
}

add_filter( 'tiny_mce_before_init', 'unhide_kitchensink' );
add_action( 'admin_init', 'disable_autosave' );
function disable_autosave() {
        wp_deregister_script( 'autosave' );
}
function addOrdinalNumberSuffix($num) {
    if (!in_array(($num % 100),array(11,12,13))){
      switch ($num % 10) {
        // Handle 1st, 2nd, 3rd
        case 1:  return $num.'st';
        case 2:  return $num.'nd';
        case 3:  return $num.'rd';
      }
    }
    return $num.'th';
  }

// Adding user roles class in the backend admin body tags
add_filter('admin_body_class', 'add_body_classes');
function add_body_classes($classes) {
  $userid = get_current_user_id();
  $user = new WP_User($userid);
  if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
      foreach ( $user->roles as $role )
        return $role;
  }       
} 

add_action( 'admin_menu', 'customize_dashboard_options');
function customize_dashboard_options() {

  global $submenu;

  $userid = get_current_user_id();
  $user = new WP_User($userid);
  if ( !empty( $user->roles ) && is_array( $user->roles ) ) {

      foreach ( $user->roles as $role ){
          unset($submenu['edit.php?post_type=property'][25]);
          if($role=='view_01'){

            remove_menu_page( 'edit.php?post_type=azulloffice');
            remove_menu_page( 'edit.php?post_type=azulladds');
            remove_menu_page( 'edit.php?post_type=testimonial');
            remove_menu_page( 'edit.php?post_type=infodays');
            remove_menu_page( 'edit.php?post_type=azull_site');
            remove_menu_page( 'edit-comments.php');
            //remove_menu_page( 'tools.php');
            remove_submenu_page('edit.php?post_type=property', 'post-new.php?post_type=property');

            add_action( 'save_post', 'send_post_admin_approval' );
            function send_post_admin_approval($post_id){
              global $post;
              if ($post->post_status=='publish'){
                  remove_action('save_post', 'send_post_admin_approval');
                  $my_post = array(
                    'ID' => $post_id,
                    'post_status'  => 'Pending'      
                  ); 
                  wp_update_post( $my_post );
                  add_action('save_post', 'send_post_admin_approval');
              }    
            }
          
          }elseif($role=='office'){

            remove_menu_page( 'edit.php?post_type=azulladds');
            remove_menu_page( 'edit.php?post_type=azull_site');
            remove_menu_page( 'edit.php?post_type=azulloffice');
            remove_menu_page( 'edit-comments.php');
            //remove_menu_page( 'tools.php');

            add_action( 'save_post', 'send_post_admin_approval' );
            function send_post_admin_approval($post_id){
              global $post;
              if ($post->post_status=='publish'){
                  remove_action('save_post', 'send_post_admin_approval');
                  $my_post = array(
                    'ID' => $post_id,
                    'post_status'  => 'Pending'      
                  ); 
                  wp_update_post( $my_post );
                  add_action('save_post', 'send_post_admin_approval');
              }    
            }

          }elseif($role=='agent'){

            //remove_submenu_page('edit.php?post_type=property', 'edit-tags.php?taxonomy=agent');

            remove_menu_page( 'edit.php?post_type=azulladds');
            remove_menu_page( 'edit.php?post_type=azull_site');
            remove_menu_page( 'edit.php?post_type=azulloffice');
            remove_menu_page( 'edit.php?post_type=infodays');
            remove_menu_page( 'edit.php');
            remove_menu_page( 'edit.php?post_type=testimonial');
            remove_menu_page( 'edit-comments.php');
            //remove_menu_page( 'tools.php');
            
            add_action( 'save_post', 'send_post_admin_approval' );
            function send_post_admin_approval($post_id){
              global $post;
              if ($post->post_status=='publish'){
                  remove_action('save_post', 'send_post_admin_approval');
                  $my_post = array(
                    'ID' => $post_id,
                    'post_status'  => 'Pending'      
                  ); 
                  wp_update_post( $my_post );
                  add_action('save_post', 'send_post_admin_approval');
              }    
            }

          }
      }
  }       
}

// Remove Agent/Properiter Submenu for Agent Role
add_action('admin_menu', 'remove_niggly_bits');
function remove_niggly_bits() {
  $userid = get_current_user_id();
  $user = new WP_User($userid);
  if ( !empty( $user->roles ) && is_array($user->roles )){
    foreach ( $user->roles as $role ){ 
        if($role=='agent'){ 
           global $submenu;
           unset($submenu['edit.php?post_type=property'][25]);
           unset($submenu['edit.php?post_type=property'][24]);
        }
    }
  }    
}


//Filter to modify property listing in agent dashboard
add_action('pre_get_posts', 'filter_property_list');
function filter_property_list($query){	
    
     global $pagenow, $typenow , $current_user; 

     // Modify property table listing For Office Dashboard
      $user_country = get_user_meta($current_user->ID, "country", true);
      $user_country = json_decode($user_country);

      $user_region = get_user_meta($current_user->ID, "region", true);
      $user_region = json_decode($user_region);

      if(isset($user_country)){
          foreach($user_country as $c){
             $c_id = get_term_by( 'name', $c, 'country');   
             $country_id = $c_id->term_id;               

             if(!current_user_can('administrator') && (in_array("office", $current_user->roles) || in_array("view_01", $current_user->roles))  && ('edit.php' == $pagenow) &&  $typenow == 'property'){
                 $query->set('meta_key', '_country');
                 $query->set('meta_value', $country_id);
             }                                           
          }
      }

      if(isset($user_region)){
        foreach($user_region as $r){
           $r_id = get_term_by( 'name', $r, 'region');
           $region_id = $r_id->term_id;

           if(!current_user_can('administrator') && (in_array("office", $current_user->roles)|| in_array("view_01", $current_user->roles)) && ('edit.php' == $pagenow) &&  $typenow == 'property'){
               $query->set('meta_key', '_region');
               $query->set('meta_value', $region_id);
           }
        }
      }

      // Modify property table listing For Agent Dashboard
      if(!current_user_can('administrator') && in_array("agent", $current_user->roles) && ('edit.php' == $pagenow) &&  $typenow == 'property'){ 
         $query->set('author', $current_user->ID); 
      } 
}


add_action('user_new_form', 'display_bio_field');
function display_bio_field() {
  $countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));    
  $regions=get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));

  $current_user = wp_get_current_user();
  $admin_role = $current_user->roles;

  $resp = '<table class="form-table">';
  $resp .= '<tbody> <tr style = "display:none;" class="form-field form-required"> <th> proprietor </th>';
  $resp .= '<td> <input id="proprietor_id" class="regular-text" type="text" value="" name="proprietor_id"></td> </tr>';

  $resp .= '<tr class="form-field"><th scope="row"> Country';
  $resp .= "</th> <td>";

  if (in_array("administrator", $admin_role)){
    $resp .= "<select multiple style='width:140px;' id='country' name='country[]'>";
  }else{
    $resp .= "<select multiple disabled style='width:140px;' id='country' name='country[]'>";
  } 
  //$resp .= "<select multiple style='width:140px;' id='country' name='country[]'>";

  $resp .= "<option value='' selected='selected'>--</option>";

    foreach ($countries as $countrie):
  	   $country_value = str_replace(" ","-", $countrie->name);	  	
  	   $resp .= "<option value='".$country_value."' >".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";     	
    endforeach;         
  $resp .="</select> </td></tr>"; 

  $resp .= '<tr id="user_regions_row" class="form-field"><th scope="row"> Regions';
  $resp .= "</th> <td>";

  if (in_array("administrator", $admin_role)){
    $resp .= "<select id='property_meta_region' multiple name='state[]'>";
  }else{
    $resp .= "<select disabled id='property_meta_region' multiple name='state[]'>";
  } 

  //$resp .= "<select id='property_meta_region' multiple name='state[]'>";

  if ( !empty( $regions ) && !is_wp_error( $regions ) ){
                                    
	$resp .= "<option selected='selected'>--</option>";
	
	foreach ($regions as $region):	
	$taxonomy_meta = get_option('azull_taxonomy_meta_'.$region->term_id);
	$region_value = str_replace(" ","-",$region->name); 
	  	if((!empty($state) && in_array($region_value, $state))){
			$resp .= "<option selected = selected value='".$region_value."'  >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";
		}else{
			$resp .= "<option value='".$region_value."'  >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";
		}
	endforeach;	
	$resp .="</select></td></tr>";
  }

  $resp .= '</tbody></table>';
  echo $resp;
}


//Modify Countries and Regions Array During User registration
add_action( 'user_register', 'modify_user_country_state_registration', 10, 1 );
function modify_user_country_state_registration( $user_id ) {
    	$country = json_encode($_POST['country']);
		$state = json_encode( $_POST['state']);
		update_user_meta($user_id, 'country', $country);
		update_user_meta($user_id, 'state', $state);
}

add_action('show_user_profile', 'custom_user_profile_fields');
add_action('edit_user_profile', 'custom_user_profile_fields');

function custom_user_profile_fields($user) {

  $all_meta_for_user = get_user_meta($user->ID); 

  $current_user = wp_get_current_user();
  $admin_role = $current_user->roles; 

  $state =  json_decode($all_meta_for_user['state'][0]);
  $country =  json_decode($all_meta_for_user['country'][0]); 

  $countries= get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));	

  $regions=get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));

  $html = '<table class="form-table">';
  $html .= '<tr><th> </th> <td>'; 
  $html .= '<input type="text" name="proprietor_id" id="proprietor_id" value="'.esc_attr( get_the_author_meta( 'proprietor_id', $user->ID ) ).'" class="regular-text" /> </td> </tr>';
  $html .= '<tr id="user_country_row" class="form-field"><th scope="row"> Country';
  $html .= "</th> <td>";

  if (in_array("administrator", $admin_role)){
    $html .= "<select multiple style='width:140px;' id='country' name='country[]'>";
  }else{
    $html .= "<select multiple disabled style='width:140px;' id='country' name='country[]'>";
  }  

  $html .= "<option value='' selected='selected'>--</option>";   

  foreach ($countries as $countrie):
  	$country_value = str_replace(" ","-", $countrie->name);	 
  	if((!empty($country) && in_array($country_value, $country))){
  		$html .= "<option selected = selected value='".$country_value."' >".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";
  	}else{
  		$html .= "<option value='".$country_value."' >".qtranxf_use(qtranxf_getLanguage(),$countrie->name)."</option>";
    }  	
  endforeach;  

  $html .="</select>";
  $html .= '</td></tr>';

  $html .= '<tr id="user_regions_row" class="form-field"><th scope="row"> Regions';
  $html .= "</th> <td>" ;

  if (in_array("administrator", $admin_role)){

    $html .= "<select id='property_meta_region' multiple name='state[]'>";
  }else{

    $html .= "<select id='property_meta_region' disabled multiple name='state[]'>";
  }

  if ( !empty( $regions ) && !is_wp_error( $regions ) ){
                                    
	$html .= "<option selected='selected'>--</option>";
	
	foreach ($regions as $region):
	
		$taxonomy_meta = get_option('azull_taxonomy_meta_'.$region->term_id);
		$region_value = str_replace(" ","-",$region->name); 

  	if((!empty($state) && in_array($region_value, $state))){
	   	$html .= "<option selected = selected value='".$region_value."'  >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";
	     }else{
		  $html .= "<option value='".$region_value."'  >".qtranxf_use(qtranxf_getLanguage(),$region->name)."</option>";
	  }

	endforeach;	
	$html .="</select>";
 }

  $html .= '</td> </tr>';
  $html .= '</table>'; 

  echo $html;
}


add_action( 'profile_update', 'my_profile_update', 10, 2 );
function my_profile_update( $user_id, $old_user_data ) {

	$country = json_encode($_POST['country']);
	$state = json_encode( $_POST['state']);
	update_user_meta($user_id, 'country', $country);
	update_user_meta($user_id, 'state', $state);       
}



function remove_higher_levels($all_roles) {
	global $pagenow;
	if($pagenow == "user-new.php"){
		$user = wp_get_current_user();
    	$next_level = 'level_' . ($user->user_level + 1);

	    foreach ( $all_roles as $name => $role ) {		
	        if (isset($role['capabilities'][$next_level])) {
	            unset($all_roles[$name]);
	        }
    			if($role['name'] === 'Property Agent'){
    				unset($all_roles[$name]);
    			}
			//if($role['name'] === 'Property Agent'){
				//unset($all_roles[$name]);
			//}
	    }
	}  
    return $all_roles;
}

add_filter('editable_roles', 'remove_higher_levels');

function assign_property_agent( $post_id, $post){

    $slug = 'property';   
    if ( $slug != $post->post_type ) {
        return;
    }

    $user = wp_get_current_user();
    $user_id = $user->ID;
    $user_meta = get_user_meta($user_id);
    $agentid = $user_meta[proprietor_id][0];
    $agentid = intval($agentid); 
    $status = wp_set_object_terms($post_id, $agentid, 'proprietor', true); 
    //$terms = get_the_terms( $post_id, 'proprietor'); 
}
add_action( 'save_post', 'assign_property_agent', 10, 2 );



