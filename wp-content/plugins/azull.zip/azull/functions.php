<?php
ob_start();
/* defination of all common function used in plugin.
 * @package:wordpress
 * @subpackage:azull
 */

defined('ABSPATH') or die("No script kiddies please!");

/***Load all the translation in the starting **/
$GLOBALS['azullString'] = json_decode(get_option('azullString'),true);    
//$GLOBALS['azullString_s'] = json_decode(get_option('azull_server_String'),true);      

//move to hook
add_action('after_setup_theme', 'remove_admin_bar');
add_theme_support('post-thumbnails');

function remove_admin_bar() {
   show_admin_bar(false);
   add_image_size('pdf-large', 850, 558, array('center', 'center')); // 300 pixels wide (and unlimited height)
   add_image_size('pdf-small', 263, 251, array('center', 'center')); // (cropped)

   add_image_size('print-A5-large', 850, 400, array('center', 'center')); // 300 pixels wide (and unlimited height)
   //add_image_size( 'print-Asmall', 263, 251, array( 'center', 'center' ) ); // (cropped)
   fly_add_image_size('web-3-2', 300, 200, array('center', 'center'));
   fly_add_image_size('web-613-324', 613, 324, array('center', 'center'));

   fly_add_image_size('print-1024-550', 1024, 550, array('center', 'center'));
   fly_add_image_size('print-512-250', 512, 250, array('center', 'center'));
   fly_add_image_size('print-335-250', 335, 250, array('center', 'center'));
}

add_action('init', 'my_custom_init');

function my_custom_init() {

   add_post_type_support('page', 'excerpt');
   $current_user = wp_get_current_user();
   $admin_role = $current_user->roles;
   $userRole='';
   $user_object = get_userdata( get_current_user_id() );
   if(isset($user_object) && $user_object!=''){
     foreach($user_object->roles as $role){
       $userRole=$role;
      } 
   }
  if($userRole == 'administrator' || $userRole == 'agent' || $userRole == 'info1'){
      add_action('admin_menu', 'books_register_ref_page');
  }
  if(isset($userRole) && $userRole != 'administrator'){
      add_action('admin_menu','wphidenag');
  }
  if($_GET['perror'] && $_GET['perror']!=''){   
   echo '<div><div id="message" class="updated notice error is-dismissible"><p>Please set property featured image.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div></div>';
  }

  if($_GET['ord_error'] && $_GET['ord_error']!=''){   
   echo '<div><div id="message" class="updated notice error is-dismissible"><p>Block order should be unique.!</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div></div>';
  }

  if($_GET['crerror'] && $_GET['crerror']!=''){   
   echo '<div><div id="message" class="updated notice error is-dismissible"><p>Property import cron is running, please add new property after completion cron.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div></div>';
  }

  if($_GET['suc'] && $_GET['suc']!=''){   
   echo '<div id="message" class="updated notice notice-success is-dismissible"><p>Property price updated.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
  }

  if($_GET['propN'] && $_GET['propN']!=''){   
   echo '<div><div id="message" class="updated notice error is-dismissible"><p>Please select proprietor.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div></div>';
  }
  if($_GET['rerror'] && $_GET['rerror']!=''){   
   echo '<div><div id="message" class="updated notice error is-dismissible"><p>Please select  region.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div></div>';
  }
  

}



/*
  function azull_gallery($post_id,$limit,$size='full',$flag=false){
  $html="";
  $i=0;

  $html .= "<ul class='row'>";
  foreach (  Property_Meta::azull_gallery($post_id) as $id ) {
  if(get_post_thumbnail_id( $post_id )!=$id && $i< $limit):
  $html .= '<li class="col-xs-6">';
  $html .= wp_get_attachment_image( $id, 'pdf-small');
  $html .= '</li>';
  $i++;
  endif;
  }
  $html .="</ul>";

  if(!$flag && $html!='')
  return $html;

  if($flag && $html!='')
  echo $html;

  return false;

  }
 */

function the_currency($echo = true) {
   $csymbols = json_decode(get_option('general', false));
   if ($echo)
      echo $csymbols->csymbols;
   else
      return $csymbols->csymbols;;
}

function azull_gallery($post_id, $limit, $size = 'full', $flag = false) {
   $html = "";
   $i = 0;

   $html .= "<ul class='row'>";

   $thumb = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'thumbnail');
   if ($thumb && $thumb != '') {
      $html .= '<li style="height:112px;" class="col-xs-4 col-sm-6">'; 
      $url = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'thumbnail');

      $url2 = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'large');
 
      $thumb_id = get_post_thumbnail_id($post_id);
      $alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
      $url[0] = str_replace('-150x150', '', $url[0]);

      $url = fly_get_attachment_image_src( get_post_thumbnail_id($post_id), 'web-3-2', array('center', 'center') );
      $url["src"] = str_replace('-cc', '-medium', $url["src"]);

      //$html .= '<img style="height:87%;width:92%;" alt="' . $alt . '" class="property-gallery" data-large="' . $url2[0] . '" src="' . $url[0] . '"/>';
      $html .= '<img style="height:87%;width:92%;" alt="' . $alt . '" class="property-gallery" data-large="' . $url2[0] . '" src="' . $url["src"] . '"/>';
      $html .= '</li>';
   } 
   $url = ''; 
   $url2 = '';
   $property_gallery = Property_Meta::azull_gallery($post_id);
   if(isset($property_gallery) && !empty($property_gallery) && count($property_gallery)>0 && is_array($property_gallery)){
   foreach ($property_gallery as $id) {
      $url = array("");
      $url2 = array("");

      if (get_post_thumbnail_id($post_id) != $id && $i < $limit - 1 && $id!=''):

         $html .= '<li style="height:112px;" class="ol-xs-4 col-sm-6">';  
         $url = wp_get_attachment_image_src($id, 'thumbnail');
         $url2 = wp_get_attachment_image_src($id, 'large'); 

         $alt = get_post_meta($id, '_wp_attachment_image_alt', true);    
       //  $url[0] = str_replace('-150x150', '', $url[0]);
         $url = fly_get_attachment_image_src( $id, 'web-3-2', array('center', 'center') );
         $url["src"] = str_replace('-cc', '-medium', $url["src"]);

         //$html .= '<img style="height:87%;width:92%;" alt="' . $alt . '" class="property-gallery" data-large="' . $url2[0] . '" src="' . $url[0] . '"/>';
         $html .= '<img style="height:87%;width:92%;" alt="' . $alt . '" class="property-gallery" data-large="' . $url2[0] . '" src="' . $url["src"] . '"/>';
         $html .= '</li>';
         $i++;
      endif; 
   }
}
   $html .="</ul>";

   if (!$flag && $html != '')
      return $html;

   if ($flag && $html != '')
      echo $html;

   return false;
}

function features_icon($post_id = false, $flag = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }

   $html = '<ul class="row">';

   $terms = get_terms('feature', 'orderby=id&hide_empty=0');
   if (!empty($terms) && !is_wp_error($terms)) {

      $taxonomy_meta['type'] = 1;
      $taxonomy_meta['search'] = 0;
      foreach ($terms as $term) {
         $taxonomy_meta = get_option('azull_taxonomy_meta_' . $term->term_id);
         if ($taxonomy_meta['type'] == 2 && get_post_meta($post_id, '_feature_' . $term->term_id, true) != '' && $taxonomy_meta!=0) {
           $fVal=get_post_meta($post_id, '_feature_' . $term->term_id, true);
           if($fVal && $fVal!=0){
             $html .="<li class='col-xs-4'><img alt='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "' title='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "'  " . ((!isset($val[$term->term_id])) ? 'class="gray-image"' : '') . " src='" . z_taxonomy_image_url($term->term_id) . "'><span>" .$fVal. "</span></li>";
           }
            
         }
         $taxonomy_meta['search'] = 0;
      }
   }

   $html .= walkScores_img($post_id);
   $html .= dimensions_img($post_id);
   $html .= locality('locality', $post_id);
   $html .= features_img('feature', $post_id);
   $html .= features_img('interior', $post_id);
   $html .= features_img('exterior', $post_id);
   $html .='</ul>';

   if ($flag)
      echo $html;

   return $html;
}

function locality($tax = 'locality', $post_id, $flag = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }

   $terms = wp_get_post_terms($post_id, $tax);

   if (!empty($terms) && !is_wp_error($terms)) {

      foreach ($terms as $term) {
         $html .= "<li class='col-xs-4'><img alt='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "' title='" . qtranxf_use($lng, $term->name) . "'  src='" . z_taxonomy_image_url($term->term_id) . "' /></li>";
      }
   }

   if ($flag)
      echo $html;

   return $html;
}

function walkScores_img($post_id = false, $flag = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }
   $html = '';

   $terms = get_terms('walkscores', 'orderby=id&hide_empty=0');
   if (!empty($terms) && !is_wp_error($terms)) {
      foreach ($terms as $term) {
         $distance = "";
         $val = get_post_meta($post_id, '_scores_' . $term->term_id, true);
         if (isset($val) && $val != "" && $val!=0) {
            $distance .="<span>";
            $distance .= ((float) $val > 999) ? number_format(((float) $val / 1000), 0, ".", "") . 'km' : number_format((float) $val, 0, ".", "") . 'm';
            $distance .="</span>";
            $html .= "<li class='col-xs-4'> <img alt='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "' title='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "'  " . ((!isset($val)) ? 'class="gray-image"' : '') . " src='" . z_taxonomy_image_url($term->term_id) . "' />" . $distance . "</li>";
         }
      }
   }

   if ($flag)
      echo $html;
   return $html;
}

function dimensions_img($post_id = false, $flag = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }
   $html = '';
   $terms = get_terms('dimensions', 'orderby=id&hide_empty=0');

   if (!empty($terms) && !is_wp_error($terms)) {

      foreach ($terms as $term) {
         $distance = "";
         $val = get_post_meta($post_id, '_dimensions_' . $term->term_id, true);
         if (isset($val) && $val != "" && $val!=0) {
            $cal =  ((float) $val > 999) ? number_format(((float) $val), 0, ".", "") : number_format((float) $val, 0, ".", "");
            if($cal==0) continue;
            $distance .="<span>";
            $distance .= ((float) $val > 999) ? number_format(((float) $val), 0, ".", "") . 'm<sup>2</sup>' : number_format((float) $val, 0, ".", "") . 'm<sup>2</sup>';
            $distance .="</span>";
            $html .= "<li class='col-xs-4'><img alt='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "' title='" . qtranxf_use($lng, $term->name) . "'  " . ((!isset($val)) ? 'class="gray-image"' : '') . " src='" . z_taxonomy_image_url($term->term_id) . "' />" . $distance . "</li>";
         }
      }
   }

   if ($flag)
      echo $html;

   return $html;
}

/**
 * @param:key property fetures taxonomy slug
 * @param:post_id property post id
 * @param:flag for echo or return.
 */
function features_img($key, $post_id = false, $flag = false) {

   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }
   $html = '';
   $val = array();
   $terms = get_terms($key, 'orderby=id&hide_empty=0');
   $val = wp_get_post_terms($post_id, $key, array("fields" => "ids"));

   // Generate Interiors meta box HTML,
   if (!empty($terms) && !is_wp_error($terms)) {
      foreach ($terms as $term) {
         if (in_array($term->term_id, $val) && z_taxonomy_image_url($term->term_id)!='') {
            $html .= "<li class='col-xs-4'><img  " . (($flag) ? "width='70'" : "") . " alt='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "' title='" . qtranxf_use(qtranxf_getLanguage(), $term->name) . "'   src='" . z_taxonomy_image_url($term->term_id) . "' /></li>";
         }
      }
   }

   if ($flag)
      echo $html;

   return $html;
}

/**
 * @param:key property price 'sales price, old price, total price' is *required
 * @param:post_id property post id
 * @param:flag,to return value.
 * @note:handle currency symbole on the template.
 */
function azull_price($key = '', $post_id = false, $flag = false) {

   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }


   switch (strtolower($key)) {
      case 'sales price':
         $price = get_post_meta($post_id, '_salesPrice', true);
         break;
      case 'old price':
         $price = get_post_meta($post_id, '_oldPrice', true);
         break;
      case 'total price': 
         
         $country = get_post_meta($post_id, '_country', true);
         $region = get_post_meta($post_id, '_region', true);
         $province = get_post_meta($post_id, '_province', true);

         if (isset($country)) {
            if (get_option('country_tax_' . $country))
               $azullTax = get_option('country_tax_' . $country);
         }
         if (isset($region)) {
            if (get_option('region_tax_' . $region))
               $azullTax = get_option('region_tax_' . $region);
         }
         if (isset($province)) {
            if (get_option('region_tax_' . $province))
               $azullTax = get_option('province_tax_' . $province);
         }

         if ($azullTax)
            $default = json_decode($azullTax, true);
         $totalPrice = 0;
         $price = (get_post_meta($post_id, '_salesPrice', true)) ? $price = get_post_meta($post_id, '_salesPrice', true) : 0;
         /*6-3-2016 Tien add to ensure total price is 0 if sales price is 0*/
         if ($price == 0) return 0;

         $buildType = get_post_meta($post_id, '_buildType', true);

         $vat_min = ((isset($default["vat"]["min"]) && $default["vat"]["min"] != '') ? $default["vat"]["min"] : 0);

         $vat_per = ((isset($default["vat"]["per"]) && $default["vat"]["per"] != '') ? $default["vat"]["per"] : 0);
         $vat_per = max($vat_per, (get_post_meta($post_id, '_vat', true)) ? get_post_meta($post_id, '_vat', true) : 0);
         $vat = max($vat_min, ($vat_per / 100) * $price);

         $transmissionTax_min = ((isset($default["transmissionTax"]["min"]) && $default["transmissionTax"]["min"] != '') ? $default["transmissionTax"]["min"] : 0);
         $transmissionTax_per = ((isset($default["transmissionTax"]["per"]) && $default["transmissionTax"]["per"] != '') ? $default["transmissionTax"]["per"] : 0);
         $transmissionTax_per = max($transmissionTax_per, (get_post_meta($post_id, '_transmissionTax', true)) ? get_post_meta($post_id, '_transmissionTax', true) : 0);
         $transmissionTax = max($transmissionTax_min, ($transmissionTax_per / 100) * $price);

         $stampDuty_min = ((isset($default["stampDuty"]["min"]) && $default["stampDuty"]["min"] != '') ? $default["stampDuty"]["min"] : 0);
         $stampDuty_per = ((isset($default["stampDuty"]["per"]) && $default["stampDuty"]["per"] != '') ? $default["stampDuty"]["per"] : 0);
         $stampDuty_per = max($stampDuty_per, (get_post_meta($post_id, '_stampDuty', true)) ? get_post_meta($post_id, '_stampDuty', true) : 0);
         $stampDuty = max($stampDuty_min, ($stampDuty_per / 100) * $price);

         $notaryCost_min = ((isset($default["notaryCost"]["min"]) && $default["notaryCost"]["min"] != '') ? $default["notaryCost"]["min"] : 0);
         $notaryCost_per = ((isset($default["notaryCost"]["per"]) && $default["notaryCost"]["per"] != '') ? $default["notaryCost"]["per"] : 0);
         $notaryCost_per = max($notaryCost_per, (get_post_meta($post_id, '_notaryCost', true)) ? get_post_meta($post_id, '_notaryCost', true) : 0);
         $notaryCost = max($notaryCost_min, ($notaryCost_per / 100) * $price);


         $lawyerCost_min = ((isset($default["lawyerCosts"]["min"]) && $default["lawyerCosts"]["min"] != '') ? $default["lawyerCosts"]["min"] : 0);
         $lawyerCost_per = ((isset($default["lawyerCosts"]["per"]) && $default["lawyerCosts"]["per"] != '') ? $default["lawyerCosts"]["per"] : 0);
         $lawyerCost_per = max($lawyerCost_per, (get_post_meta($post_id, '_lawyerCost', true)) ? get_post_meta($post_id, '_lawyerCost', true) : 0);
         $lawyerCost = max($lawyerCost_min, ($lawyerCost_per / 100) * $price);


         $utilitiesConnectionCost_min = ((isset($default["utilitiesConnectionCost"]["min"]) && $default["utilitiesConnectionCost"]["min"] != '') ? $default["utilitiesConnectionCost"]["min"] : 0);
         $utilitiesConnectionCost_per = ((isset($default["utilitiesConnectionCost"]["per"]) && $default["utilitiesConnectionCost"]["per"] != 0) ? $default["utilitiesConnectionCost"]["per"] : 0);
         $utilitiesConnectionCost = max($utilitiesConnectionCost_min, ($utilitiesConnectionCost_per / 100) * $price);
         $utilitiesConnectionCost = max($utilitiesConnectionCost, (get_post_meta($post_id, '_utilitiesConnectionCost', true)) ? get_post_meta($post_id, '_utilitiesConnectionCost', true) : 0);


         $buyerCost_min = ((isset($default["buyerCosts"]["min"]) && $default["buyerCosts"]["min"] != '') ? $default["buyerCosts"]["min"] : 0);
         $buyerCost_per = ((isset($default["buyerCosts"]["per"]) && $default["buyerCosts"]["per"] != '') ? $default["buyerCosts"]["per"] : 0);
         $buyerCost_per = max(buyerCost_per, (get_post_meta($post_id, '_buyerCost', true)) ? get_post_meta($post_id, '_buyerCost', true) : 0);
         $buyerCost = max($buyerCost_min, ($buyerCost_per / 100) * $price);


         if ($buildType = 1) {
            $totalPrice = $price + $vat + $stampDuty + $notaryCost + $lawyerCost + $utilitiesConnectionCost;
         } else {
            $totalPrice = $price + $transmissionTax + $notaryCost + $lawyerCost + $utilitiesConnectionCost + $buyerCost;
         }

         $price = (integer) $totalPrice;

         //$price = get_post_meta($post_id,'_totalPrice',true); 
         break;
   }
   //todo: maybe need tou use simple numberformate here

   if ($price && !$flag)
      return $price;

   if ($price && $flag)
      echo $price;

   return false;
}

/* * echo property category or return it based on flag value. property taxonomy is beeing stored as categories
 * @param:post_id*, if post id is not provide global post will be used to ge id
 * return: property category
 */

function property_category($post_id = false, $flag = false) {
   global $post, $q_config, $aj_config;
   if (!$post_id) {
      $post_id = $post->ID;
   }
   $lang = qtranxf_getLanguage();
   if (!qtranxf_getLanguage()) {

      $lang = $q_config['language'];
   }
   if ($post_id && !$flag) {
      $term = wp_get_post_terms($post_id, 'category');
      $terms = get_term($term[0]->term_id, 'category');
      $meta = get_option('qtranslate_term_name');
      //return "";
      
      return ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang]!='') ? $meta[$term[0]->name][$lang]:$term[0]->name);
   }


   return false;
}

function property_location($post_id = false, $flag = false) {
   global $post, $q_config, $aj_config;
   if (!$post_id) {
      $post_id = $post->ID;
   }
   $lang = qtranxf_getLanguage();
   if (!qtranxf_getLanguage()) {

      $lang = $q_config['language'];
   }
   $meta = get_option('qtranslate_term_name');
   $lang = qtranxf_getLanguage();

   $location = "";

   $term = wp_get_post_terms($post_id, 'place');
   if ($term)
      $location .= ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang] != '') ? $meta[$term[0]->name][$lang] : $term[0]->name) . ", ";

   //$term = wp_get_post_terms($post_id, 'provinces');
   //if($term)
   //$location .= qtranxf_use(qtranxf_getLanguage(),$term[0]->name).", ";

   $term = wp_get_post_terms($post_id, 'region');
   if ($term)
      $location .= ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang] != '') ? $meta[$term[0]->name][$lang] : $term[0]->name) . ", ";

   $term = wp_get_post_terms($post_id, 'country');
   if ($term)
      $location .= ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang] != '') ? $meta[$term[0]->name][$lang] : $term[0]->name);


   if ($post_id) {
      
   }
   if ($flag) {
      echo $location;
   }

   return $location;
}

function remove_character_accent($String) {

   $normalizeChars = array(
       '&amp;' => 'and', '@' => 'at', '©' => 'c', 'Ã' => 'a', 'À' => 'a',
       'Á' => 'a', 'Â' => 'a', 'Ä' => 'a', 'Å' => 'a', 'Æ' => 'ae', 'Ç' => 'c',
       'È' => 'e', 'É' => 'e', 'Ë' => 'e', 'Ì' => 'i', 'Í' => 'i', 'Î' => 'i',
       'Ï' => 'i', 'Ò' => 'o', 'Ó' => 'o', 'Ô' => 'o', 'Õ' => 'o', 'Ö' => 'o',
       'Ø' => 'o', 'Ù' => 'u', 'Ú' => 'u', 'Û' => 'u', 'Ü' => 'u', 'Ý' => 'y',
       'ß' => 'ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ä' => 'a', 'å' => 'a',
       'æ' => 'ae', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e',
       'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 'ò' => 'o', 'ó' => 'o',
       'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u',
       'û' => 'u', 'ü' => 'u', 'ý' => 'y', 'þ' => 'p', 'ÿ' => 'y', 'Ā' => 'a',
       'ā' => 'a', 'Ă' => 'a', 'ă' => 'a', 'Ą' => 'a', 'ą' => 'a', 'Ć' => 'c',
       'ć' => 'c', 'Ĉ' => 'c', 'ĉ' => 'c', 'Ċ' => 'c', 'ċ' => 'c', 'Č' => 'c',
       'č' => 'c', 'Ď' => 'd', 'ď' => 'd', 'Đ' => 'd', 'đ' => 'd', 'Ē' => 'e',
       'ē' => 'e', 'Ĕ' => 'e', 'ĕ' => 'e', 'Ė' => 'e', 'ė' => 'e', 'Ę' => 'e',
       'ę' => 'e', 'Ě' => 'e', 'ě' => 'e', 'Ĝ' => 'g', 'ĝ' => 'g', 'Ğ' => 'g',
       'ğ' => 'g', 'Ġ' => 'g', 'ġ' => 'g', 'Ģ' => 'g', 'ģ' => 'g', 'Ĥ' => 'h',
       'ĥ' => 'h', 'Ħ' => 'h', 'ħ' => 'h', 'Ĩ' => 'i', 'ĩ' => 'i', 'Ī' => 'i',
       'ī' => 'i', 'Ĭ' => 'i', 'ĭ' => 'i', 'Į' => 'i', 'į' => 'i', 'İ' => 'i',
       'ı' => 'i', 'Ĳ' => 'ij', 'ĳ' => 'ij', 'Ĵ' => 'j', 'ĵ' => 'j', 'Ķ' => 'k',
       'ķ' => 'k', 'ĸ' => 'k', 'Ĺ' => 'l', 'ĺ' => 'l', 'Ļ' => 'l', 'ļ' => 'l',
       'Ľ' => 'l', 'ľ' => 'l', 'Ŀ' => 'l', 'ŀ' => 'l', 'Ł' => 'l', 'ł' => 'l',
       'Ń' => 'n', 'ń' => 'n', 'Ņ' => 'n', 'ņ' => 'n', 'Ň' => 'n', 'ň' => 'n',
       'ŉ' => 'n', 'Ŋ' => 'n', 'ŋ' => 'n', 'Ō' => 'o', 'ō' => 'o', 'Ŏ' => 'o',
       'ŏ' => 'o', 'Ő' => 'o', 'ő' => 'o', 'Œ' => 'oe', 'œ' => 'oe', 'Ŕ' => 'r',
       'ŕ' => 'r', 'Ŗ' => 'r', 'ŗ' => 'r', 'Ř' => 'r', 'ř' => 'r', 'Ś' => 's',
       'ś' => 's', 'Ŝ' => 's', 'ŝ' => 's', 'Ş' => 's', 'ş' => 's', 'Š' => 's',
       'š' => 's', 'Ţ' => 't', 'ţ' => 't', 'Ť' => 't', 'ť' => 't', 'Ŧ' => 't',
       'ŧ' => 't', 'Ũ' => 'u', 'ũ' => 'u', 'Ū' => 'u', 'ū' => 'u', 'Ŭ' => 'u',
       'ŭ' => 'u', 'Ů' => 'u', 'ů' => 'u', 'Ű' => 'u', 'ű' => 'u', 'Ų' => 'u',
       'ų' => 'u', 'Ŵ' => 'w', 'ŵ' => 'w', 'Ŷ' => 'y', 'ŷ' => 'y', 'Ÿ' => 'y',
       'Ź' => 'z', 'ź' => 'z', 'Ż' => 'z', 'ż' => 'z', 'Ž' => 'z', 'ž' => 'z',
       'ſ' => 'z', 'Ə' => 'e', 'ƒ' => 'f', 'Ơ' => 'o', 'ơ' => 'o', 'Ư' => 'u',
       'ư' => 'u', 'Ǎ' => 'a', 'ǎ' => 'a', 'Ǐ' => 'i', 'ǐ' => 'i', 'Ǒ' => 'o',
       'ǒ' => 'o', 'Ǔ' => 'u', 'ǔ' => 'u', 'Ǖ' => 'u', 'ǖ' => 'u', 'Ǘ' => 'u',
       'ǘ' => 'u', 'Ǚ' => 'u', 'ǚ' => 'u', 'Ǜ' => 'u', 'ǜ' => 'u', 'Ǻ' => 'a',
       'ǻ' => 'a', 'Ǽ' => 'ae', 'ǽ' => 'ae', 'Ǿ' => 'o', 'ǿ' => 'o', 'ə' => 'e',
       'Ё' => 'jo', 'Є' => 'e', 'І' => 'i', 'Ї' => 'i', 'А' => 'a', 'Б' => 'b',
       'В' => 'v', 'Г' => 'g', 'Д' => 'd', 'Е' => 'e', 'Ж' => 'zh', 'З' => 'z',
       'И' => 'i', 'Й' => 'j', 'К' => 'k', 'Л' => 'l', 'М' => 'm', 'Н' => 'n',
       'О' => 'o', 'П' => 'p', 'Р' => 'r', 'С' => 's', 'Т' => 't', 'У' => 'u',
       'Ф' => 'f', 'Х' => 'h', 'Ц' => 'c', 'Ч' => 'ch', 'Ш' => 'sh', 'Щ' => 'sch',
       'Ъ' => '-', 'Ы' => 'y', 'Ь' => '-', 'Э' => 'je', 'Ю' => 'ju', 'Я' => 'ja',
       'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e',
       'ж' => 'zh', 'з' => 'z', 'и' => 'i', 'й' => 'j', 'к' => 'k', 'л' => 'l',
       'м' => 'm', 'н' => 'n', 'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's',
       'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'c', 'ч' => 'ch',
       'ш' => 'sh', 'щ' => 'sch', 'ъ' => '-', 'ы' => 'y', 'ь' => '-', 'э' => 'je',
       'ю' => 'ju', 'я' => 'ja', 'ё' => 'jo', 'є' => 'e', 'і' => 'i', 'ї' => 'i',
       'Ґ' => 'g', 'ґ' => 'g', 'א' => 'a', 'ב' => 'b', 'ג' => 'g', 'ד' => 'd',
       'ה' => 'h', 'ו' => 'v', 'ז' => 'z', 'ח' => 'h', 'ט' => 't', 'י' => 'i',
       'ך' => 'k', 'כ' => 'k', 'ל' => 'l', 'ם' => 'm', 'מ' => 'm', 'ן' => 'n',
       'נ' => 'n', 'ס' => 's', 'ע' => 'e', 'ף' => 'p', 'פ' => 'p', 'ץ' => 'C',
       'צ' => 'c', 'ק' => 'q', 'ר' => 'r', 'ש' => 'w', 'ת' => 't', '™' => 'tm',
   );

   $nornal_str = strtr($String, $normalizeChars);
   return $nornal_str;
}

/** Display or return property status fro the provided id
 * @param:flag,post id.
 */
function property_status($post_id = false, $flag = false) {
   global $post, $q_config;
   $lang = qtranxf_getLanguage();

   if (!qtranxf_getLanguage()) {
      $lang = $q_config['language'];
   }


   if ($post_id && !$flag) {

      $term = wp_get_post_terms((integer) $post_id, 'status');
      $meta = get_option('qtranslate_term_name');
      return ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang] != '') ? $meta[$term[0]->name][$lang] : $term[0]->name);
   }

   if ($post_id && $flag) {

      $term = wp_get_post_terms($post_id, 'status');
      $meta = get_option('qtranslate_term_name');
      echo ((isset($meta[$term[0]->name][$lang]) && $meta[$term[0]->name][$lang] != '') ? $meta[$term[0]->name][$lang] : $term[0]->name);
   }

   return false;
}

/**
 * @param:post_id property post id
 * @param:flag,to return value.
 * @return: true or false
 */
function is_penthouse($post_id = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }
   $penthouse = get_post_meta($post_id, '_penthouse', true);
   if ($penthouse == 1)
      return true;

   return false;
}

/**
 * @param:post_id property post id
 * @param:flag,to return value.
 * @return: true or false
 */
function is_bank($post_id = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }
   $penthouse = get_post_meta($post_id, '_bank', true);
   if ($penthouse == 1)
      return true;

   return false;
}

/**
 * @param:post_id property post id
 * @param:flag,to return value.
 * @return: buid type number 0 1 2 etc, check buld type finincial section.
 */
function build_type($post_id = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }

   $buildtype = get_post_meta($post_id, '_buildType', true);
   if ($buildtype)
      return $buildtype;

   return false;
}

function ref_number($post_id = false) {
   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }

   $buildtype = get_post_meta($post_id, '_nreal_id', true);
   if ($buildtype)
      return $buildtype;

   return false;
}

function build_year($post_id = false) {

   if (!$post_id) {
      global $post;
      $post_id = $post->ID;
   }
   $year = get_post_meta($post_id, '_year', true);
   if ($year)
      return $year;

   return false;
}

function azull_short_text($content, $echo = true, $length = false) {
   global $q_config;
   $lng = qtranxf_getLanguage();
   if (!qtranxf_getLanguage()) {
      $lng = $q_config['language'];
   }
   $title = qtranxf_use($lng, $content);

   if ($length && is_numeric($length) && strlen($title) > $length) {
      $title = strip_text($title, $length);
   }

   if ($echo)
      echo strip_tags($title);
   else
      return strip_tags($title);
}

function strip_text($data, $size, $elipse = true) {
   $data = strip_tags($data);
   if (mb_strlen($data, 'utf-8') > $size) {
      $result = mb_substr($data, 0, mb_strpos($data, ' ', $size, 'utf-8'), 'utf-8');
      if (mb_strlen($result, 'utf-8') <= 0) {
         $result = mb_substr($data, 0, $size, 'utf-8');
         $result = mb_substr($result, 0, mb_strrpos($result, ' ', 'utf-8'), 'utf-8');
         ;
      }
      if ($elipse) {
         $result .= "...";
      }
   } else {
      $result = $data;
   }
   return $result;
}

function unhide_kitchensink($args) {
   $args['wordpress_adv_hidden'] = false;
   return $args;
}

add_filter('tiny_mce_before_init', 'unhide_kitchensink');
add_action('admin_init', 'disable_autosave');

function disable_autosave() {
   wp_deregister_script('autosave');
}

function addOrdinalNumberSuffix($num) {
   if (!in_array(($num % 100), array(11, 12, 13))) {
      switch ($num % 10) {
         // Handle 1st, 2nd, 3rd
         case 1: return $num . 'st';
         case 2: return $num . 'nd';
         case 3: return $num . 'rd';
      }
   }
   return $num . 'th';
}

// Adding user roles class in the backend admin body tags
add_filter('admin_body_class', 'add_body_classes');

function add_body_classes($classes) {
   $userid = get_current_user_id();
   $user = new WP_User($userid);
   if (!empty($user->roles) && is_array($user->roles)) {
      foreach ($user->roles as $role)
         return $role;
   }
}

//add_action( 'admin_init', 'customize_dashboard_options');

add_action('admin_menu', 'customize_dashboard_options');

function customize_dashboard_options() { 
   global $submenu;

   $userid = get_current_user_id();
   $user = new WP_User($userid);

   if (!empty($user->roles) && is_array($user->roles)) {

      foreach ($user->roles as $role) {
         // Hack the property to display only publish property first || remove if we get origin of menu
        //echo '<pre>';print_r($submenu);
        //die;
         $submenu['edit.php?post_type=property'][5][2] = 'edit.php?post_type=property&post_status=publish';
         unset($submenu['edit.php?post_type=property'][26]);
         if ($role == 'view_01') {

            remove_menu_page('edit.php?post_type=testimonial');
            remove_menu_page('edit.php?post_type=infodays');
            remove_menu_page('edit.php?post_type=azulladds');
            remove_menu_page('edit.php?post_type=azull_site');
            remove_menu_page('edit.php?post_type=azulloffice');
            remove_menu_page('edit-comments.php');
            remove_menu_page('translation-page');
	          remove_submenu_page('edit.php?post_type=property','edit.php?post_type=property');
            remove_submenu_page('edit.php?post_type=property','post-new.php?post_type=property');
	          remove_menu_page('admin.php?page=WP-Optimize');
	    
         } elseif ($role == 'office' || $role == 'editor' ) {
             unset($submenu['edit.php'][15]);
             unset($submenu['edit.php'][16]);
             $submenu['edit.php?post_type=property'][5][2] = 'edit.php?post_type=property&post_status=publish';
            $p_record = $submenu['edit.php?post_type=property'];
            foreach ($p_record as $key => $value) {
               
               if($key=='10' || $key=='5' || $key=='24' || $key=='25' ){

               }else{
                    unset($submenu['edit.php?post_type=property'][$key]);
               }
            }
            remove_submenu_page ('edit-tags.php', 'edit-tags.php');
            remove_menu_page('edit.php?post_type=azulladds');
            remove_menu_page('edit.php?post_type=azull_site');
            remove_menu_page('edit.php?post_type=azulloffice');
            remove_menu_page('edit-comments.php');
            remove_menu_page('translation-page');
         } elseif ($role == 'agent') {

            remove_menu_page('edit.php?post_type=azulladds');
            remove_menu_page('edit.php?post_type=azull_site');
            remove_menu_page('edit.php?post_type=azulloffice');
            remove_menu_page('edit.php?post_type=infodays');
            remove_menu_page('edit.php');
            remove_menu_page('edit.php?post_type=testimonial');
            remove_menu_page('edit-comments.php');
            remove_menu_page('translation-page');
         }

	 elseif ($role == 'info') {

	    remove_submenu_page('edit.php?post_type=property','edit.php?post_type=property');
      remove_submenu_page('edit.php?post_type=property','post-new.php?post_type=property');
	    remove_menu_page('admin.php?page=WP-Optimize');
      remove_menu_page('edit.php?post_type=azulladds');
      remove_menu_page('edit.php?post_type=azulloffice');
         }
    elseif ($role == 'ie') {
      
      remove_menu_page('edit.php?post_type=azulladds');
      remove_menu_page('edit.php?post_type=infodays');
      remove_menu_page('edit.php?post_type=azulloffice');
      remove_menu_page('admin.php?page=WP-Optimize');
         }
    elseif ($role == 'author') {
      unset($submenu['edit.php'][15]);
      remove_menu_page('edit.php?post_type=azulladds');
      remove_menu_page('edit.php?post_type=infodays');
      remove_menu_page('edit.php?post_type=azulloffice');
      remove_menu_page('admin.php?page=WP-Optimize');
      remove_menu_page('edit-comments.php');
      remove_menu_page('translation-page');
      remove_submenu_page('edit.php?post_type=property','edit.php?post_type=property');
      remove_submenu_page('edit.php?post_type=property','post-new.php?post_type=property');
      remove_menu_page('admin.php?page=WP-Optimize');
         }  
      elseif ($role == 'price') {
            remove_submenu_page('edit.php?post_type=property','edit.php?post_type=property');
            remove_submenu_page('edit.php?post_type=property','post-new.php?post_type=property');
            remove_menu_page('admin.php?page=WP-Optimize');
            remove_menu_page('edit.php?post_type=azulladds');
            remove_menu_page('edit.php?post_type=azull_site');
            remove_menu_page('edit.php?post_type=azulloffice');
         }                  
      }
   }
}

add_action('save_post', 'send_post_admin_approval',-80);

function send_post_admin_approval($post_id) {
  global $post;
  if ($_POST['original_post_status'] == 'publish') {
    //Do nothing if that is a published thing
    return;
  }
  $userid = get_current_user_id();
  $user = new WP_User($userid);
  $current_user = wp_get_current_user();
  $admin_role = $current_user->roles;
  $userRole='';
  $user_object = get_userdata( get_current_user_id() );
  if(isset($user_object->roles) && !empty($user_object->roles)){
    foreach($user_object->roles as $role){
      $userRole=$role;
    }

    if(($userRole=='office' || $role == 'agent') && $_POST['post_status'] == 'publish'){
      $_POST['post_status'] = 'pending';
      $my_post = array(
          'ID' => $post_id,
          'post_status' => 'pending',
      );
      wp_update_post($my_post);      
      //return admin_url().'edit.php?post_type=property&post_status=pending&orderby=property_ref&order=asc';
    }else{
      //remove_action('save_post', 'send_post_admin_approval');
    }
  }
}
/*
function send_post_admin_approval($post_id) {
   global $post;
   $userid = get_current_user_id();
   $user = new WP_User($userid);

   if (!empty($user->roles) && is_array($user->roles)) {

      foreach ($user->roles as $role) {

         if ($post->post_status == 'publish' && (($role == 'agent') || ($role == 'office')) || ($role == 'info1')) {

            remove_action('save_post', 'send_post_admin_approval');

            $my_post = array(
                'ID' => $post_id,
                'post_status' => 'Pending'
            );
            wp_update_post($my_post);

            add_action('save_post', 'send_post_admin_approval');
         }
      }
   }
}*/

// Remove Agent/Properiter Submenu for Agent Role
add_action('admin_menu', 'remove_niggly_bits');

function remove_niggly_bits() {
   $userid = get_current_user_id();
   $user = new WP_User($userid);
   if (!empty($user->roles) && is_array($user->roles)) {

      global $submenu;
      foreach ($user->roles as $role) {
         if ($role == 'agent') {

             unset($submenu['edit.php?post_type=property'][25]);
             unset($submenu['edit.php?post_type=property'][24]);
         }
         elseif ($role == 'view_01') {

            unset($submenu['edit.php?post_type=property'][25]);
            unset($submenu['edit.php?post_type=property'][24]);
         }
      }
   }
}

//Filter to modify property listing in agent dashboard
add_action('pre_get_posts', 'filter_property_list');
function filter_property_list($query) {

   global $pagenow, $typenow, $current_user;

   // Modify property table listing For Office Dashboard
   $user_country = get_user_meta($current_user->ID, "country", true);
   $user_region = get_user_meta($current_user->ID, "state", true);
 
   /*if (isset($user_country) && !empty($user_country)) {
      foreach ($user_country as $c){
        if($c!=''){
         if (!current_user_can('administrator') && (in_array("office", $current_user->roles) || in_array("view_01", $current_user->roles)) && ('edit.php' == $pagenow) && $typenow == 'property') {
            $query->set('meta_key', '_country');
            $query->set('meta_value', $c);

         }
       }
      }
   }
   if (isset($user_region) && !empty($user_region)) {
      foreach ($user_region as $r) {
         if (!current_user_can('administrator') && (in_array("office", $current_user->roles) || in_array("view_01", $current_user->roles)) && ('edit.php' == $pagenow) && $typenow == 'property') {
            $query->set('meta_key', '_region');
            $query->set('meta_value', $r);
         }
      }
  }*/

   if (!current_user_can('administrator') && (in_array("office", $current_user->roles) || in_array("view_01", $current_user->roles)) && ('edit.php' == $pagenow) && $typenow == 'property' && $user_country && $user_country!=''){
    $query->set('meta_key', '_country');
    $query->set('meta_value', $user_country);
   }

   if (!current_user_can('administrator') && (in_array("office", $current_user->roles) || in_array("view_01", $current_user->roles)) && ('edit.php' == $pagenow) && $typenow == 'property' && $user_region && $user_region!=''){
      $query->set('meta_key', '_region');
      $query->set('meta_value', $user_region);
   } 

   // Modify property table listing For Agent Dashboard
   if (!current_user_can('administrator') && in_array("agent", $current_user->roles) && ('edit.php' == $pagenow) && $typenow == 'property') {
    $query->set('author', $current_user->ID);   
  }
}
function filter_property_list_old($query) {

   /*global $pagenow, $typenow, $current_user;

   // Modify property table listing For Office Dashboard
   $user_country = get_user_meta($current_user->ID, "country", true);
   $user_region = get_user_meta($current_user->ID, "region", true);
   if(isset($user_country) && !empty($user_country)){
     @$user_country = json_decode($user_country);
   }
   if(isset($user_region) && !empty($user_region)){
      @$user_region = json_decode($user_region);
   }
   
   
 

   if (isset($user_country) && !empty($user_country)) {
      foreach ($user_country as $c){
        if($c!=''){
         $c_id = get_term_by('name', $c, 'country');
         $country_id = $c_id->term_id;
    
         if (!current_user_can('administrator') && (in_array("office", $current_user->roles) || in_array("view_01", $current_user->roles)) && ('edit.php' == $pagenow) && $typenow == 'property') {
            //$query->set('meta_key', '_country');
            //$query->set('meta_value', $c);

         }
       }
      }
   }
   if (isset($user_region) && !empty($user_region)) {
      foreach ($user_region as $r) {
         $r_id = get_term_by('name', $r, 'region');
         $region_id = $r_id->term_id;

         if (!current_user_can('administrator') && (in_array("office", $current_user->roles) || in_array("view_01", $current_user->roles)) && ('edit.php' == $pagenow) && $typenow == 'property') {
            //$query->set('meta_key', '_region');
            //$query->set('meta_value', $region_id);
         }
      }
   }

   // Modify property table listing For Agent Dashboard
   //if (!current_user_can('administrator') && in_array("agent", $current_user->roles) && ('edit.php' == $pagenow) && $typenow == 'property') {
    //  $query->set('author', $current_user->ID);   
  // }*/
}

add_action('user_new_form', 'display_bio_field');

function display_bio_field() {
   $countries = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
   $regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));

   $current_user = wp_get_current_user();
   $admin_role = $current_user->roles;

   $resp = '<table class="form-table">';
   $resp .= '<tbody> <tr style = "display:none;" class="form-field form-required"> <th> proprietor </th>';
   $resp .= '<td> <input id="proprietor_id" class="regular-text" type="text" value="" name="proprietor_id"></td> </tr>';

   $resp .= '<tr class="form-field"><th scope="row"> Country';
   $resp .= "</th> <td>";

   if (in_array("administrator", $admin_role)) {
      $resp .= "<select multiple style='width:140px;' id='country' name='country[]'>";
   } else {
      $resp .= "<select multiple disabled style='width:140px;' id='country' name='country[]'>";
   }
   //$resp .= "<select multiple style='width:140px;' id='country' name='country[]'>";

   //$resp .= "<option value='' selected='selected'>--</option>";

   foreach ($countries as $countrie):
      $country_value = str_replace(" ", "-", $countrie->name);
      $resp .= "<option value='" . $countrie->term_id . "' >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
   endforeach;
   $resp .="</select> </td></tr>";

   $resp .= '<tr id="user_regions_row" class="form-field"><th scope="row"> Regions';
   $resp .= "</th> <td>";

   if (in_array("administrator", $admin_role)) {
      $resp .= "<select id='property_meta_region' multiple name='state[]'>";
   } else {
      $resp .= "<select disabled id='property_meta_region' multiple name='state[]'>";
   }
   //$resp .= "<select id='property_meta_region' multiple name='state[]'>";

   if (!empty($regions) && !is_wp_error($regions)) {

      //$resp .= "<option selected='selected'>--</option>";

      foreach ($regions as $region):

        $resp .= "<option value='" . $region->term_id . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
         //$taxonomy_meta = get_option('azull_taxonomy_meta_' . $region->term_id);
         //$region_value = str_replace(" ", "-", $region->name);
         /*if ((!empty($state) && in_array($region_value, $state))) {
            $resp .= "<option selected = selected value='" . $region_value . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
         } else {
            $resp .= "<option value='" . $region_value . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
         }*/
      endforeach;
      $resp .="</select></td></tr>";
   }

$resp .= '<tr><th>Display Xml Property</th> <td>';
$resp .= '<select id="show_xml_property" name="show_xml_property" style="width:164px">;
  <option value="">------</option><option value="yes">Yes</option><option value="no">No</option>
   </select></td> </tr>';
   
/**** Website******/ 
 $resp .= '<tr><th>Property website</th> <td>'; 
     global $wpdb;
     $datas=$wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
   if(isset($datas) && !empty($datas)):
         $resp .= '<select style="width:164px;" class="" name="website_property[]" multiple>';
   $resp .= '<option value=""  disabled selected>'.__("Select site",'azull').'</option>';
   foreach ($datas as $data){
         $resp .= "<option value=".$data->ID.">".qtranxf_use(qtranxf_getLanguage(),$data->post_title)."</option>";
    }
   $resp .= "</select>";
   endif;


$resp .= '</td> </tr>';  
   $resp .= '</tbody></table>';
   echo $resp;
}

//Modify Countries and Regions Array During User registration
add_action('user_register', 'modify_user_country_state_registration', 10, 1);

function modify_user_country_state_registration($user_id) {
   $country = json_encode($_POST['country']);
   $state = json_encode($_POST['state']);
   $displayXml=$_POST['show_xml_property'];
   update_user_meta($user_id, 'country', $_POST['country']);
   update_user_meta($user_id, 'state', $_POST['state']);
   update_user_meta($user_id, 'xml_property', $displayXml);
   update_user_meta($user_id, 'website_property', $_POST['display_website']);
}

add_action('show_user_profile', 'custom_user_profile_fields');
add_action('edit_user_profile', 'custom_user_profile_fields');

function custom_user_profile_fields($user) {

   /*$all_meta_for_user = get_user_meta($user->ID);
   $xmldisplayVal=$all_meta_for_user['xml_property'][0];
   $current_user = wp_get_current_user();
   $admin_role = $current_user->roles;

   $stateArr = json_decode($all_meta_for_user['state'][0]);
   $countryArr = json_decode($all_meta_for_user['country'][0]);
  
   $state =  (isset($stateArr) && !empty($stateArr))? $stateArr:array();
   $country =  (isset($countryArr) && !empty($countryArr))? $countryArr:array();

   $countries = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));

   $regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));

   $html = '<table class="form-table">';
   $html .= '<tr><th> </th> <td>';
   $html .= '<input type="text" name="proprietor_id" id="proprietor_id" value="' . esc_attr(get_the_author_meta('proprietor_id', $user->ID)) . '" class="regular-text" /> </td> </tr>';
   $html .= '<tr id="user_country_row" class="form-field"><th scope="row"> Country';
   $html .= "</th> <td>";

   if (in_array("administrator", $admin_role)) {
      $html .= "<select multiple style='width:140px;' id='country' name='country[]'>";
   } else {
      $html .= "<select multiple disabled style='width:140px;' id='country' name='country[]'>";
   }

   $html .= "<option value='' selected='selected'>--</option>";

   if(!empty($countries) && $countries){
   foreach ($countries as $countrie):
      $country_value = str_replace(" ", "-", $countrie->name);
      if ((!empty($country) && in_array($country_value, $country))) {
         $html .= "<option selected = selected value='" . $country_value . "' >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
      } else {
         $html .= "<option value='" . $country_value . "' >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
      }
   endforeach;
}

   $html .="</select>";
   $html .= '</td></tr>';


   $html .= '<tr id="user_regions_row" class="form-field"><th scope="row"> Regions';
   $html .= "</th> <td>";

   if (in_array("administrator", $admin_role)) {

      $html .= "<select id='property_meta_region' multiple name='state[]'>";
   } else {

      $html .= "<select id='property_meta_region' disabled multiple name='state[]'>";
   }

   if (!empty($regions) && !is_wp_error($regions)) {

      $html .= "<option selected='selected'>--</option>";

      foreach ($regions as $region):

         $taxonomy_meta = get_option('azull_taxonomy_meta_' . $region->term_id);
         $region_value = str_replace(" ", "-", $region->name);

         if ((!empty($state) && in_array($region_value, $state))) {
            $html .= "<option selected = selected value='" . $region_value . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
         } else {
            $html .= "<option value='" . $region_value . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
         }

      endforeach;
      $html .="</select>";
   }

   
   $html .= '</td> </tr>';
   */

   $all_meta_for_user = get_user_meta($user->ID);
   $current_user = wp_get_current_user();
   $xmldisplayVal=$all_meta_for_user['xml_property'][0];
   $admin_role = $current_user->roles;
   $getState = get_user_meta($user->ID, 'state', true); 
   $getCountry = get_user_meta($user->ID, 'country', true);
   $websitePropertyval = get_user_meta($user->ID, 'website_property', true); 
   
   $countries = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
   $regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));

   $html = '<table class="form-table">';
   // $html .= '<tr><th> </th> <td>';
   //$html .= '<input type="text" name="proprietor_id" id="proprietor_id" value="' . esc_attr(get_the_author_meta('proprietor_id', $user->ID)) . '" class="regular-text" /> </td> </tr>';
   $html .= '<tr id="user_country_row" class="form-field"><th scope="row"> Country';
   $html .= "</th> <td>";

   if (in_array("administrator", $admin_role)) {
      $html .= "<select multiple style='width:140px;' id='country' name='country[]'>";
      //print_r($getCountry);die;
      if(!empty($countries) && $countries){
        //$html .= "<option value='' selected='selected'>--</option>";
      foreach ($countries as $countrie):
        if(!empty($getCountry) && in_array($countrie->term_id, $getCountry)){
           $html .= "<option selected = selected value='" . $countrie->term_id . "' >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
        }
      else{
          $html .= "<option value='" . $countrie->term_id . "' >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
        }
      
        
   endforeach;
}
   $html .="</select>";
   } else {
      
      $cntC=count($getCountry);$i=1;
    if(isset($getCountry) && !empty($getCountry)) {
       foreach ($getCountry as $cnt) {
        $cntName=get_term($cnt,'country');
        if($i < $cntC){
         $coma=", ";
        }else{
          $coma='';
        }
        $html.=qtranxf_use(qtranxf_getLanguage(), $cntName->name).$coma;
        $i++;
       }
     }

   }
   
   $html .= '</td></tr>';

   $html .= '<tr id="user_regions_row" class="form-field"><th scope="row"> Regions';
   $html .= "</th> <td>";

   if (in_array("administrator", $admin_role)) {
      $html .= "<select id='property_meta_region' multiple name='state[]'>";
      if (!empty($regions) && !is_wp_error($regions)) {

    // $html .= "<option selected='selected'>--</option>";

      foreach ($regions as $region):
        
      
         if(!empty($getState) && in_array($region->term_id, $getState)){
           $html .= "<option selected = selected value='" . $region->term_id . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
         }
       
         
         else{
         $html .= "<option value='" . $region->term_id . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
       }
      endforeach;
      $html .="</select>";
   }

   } else {
      $cntC=count($getState);$j=1;
    if(isset($getState) && !empty($getState)) {  
       foreach ($getState as $st) {
        if($j < $cntC){ $coma=", ";} else{ $coma='';}
        $stateName=get_term($st,'region');
        $html.=qtranxf_use(qtranxf_getLanguage(), $stateName->name).$coma;
        $j++;
       }
     }
   }
   
   $html .= '</td> </tr>';

    $html .= '<tr><th>Display Xml Property</th> <td>';
   

     if (in_array("administrator", $admin_role)) {
$html .= '<select id="show_xml_property" name="show_xml_property" style="width:164px">;
          <option value="">------</option>';
         $select1="";$select2="";
          if($xmldisplayVal == 'yes'){
             $select1="selected = selected";
          }else{
             $select2="selected = selected";
          }

          $html .= "<option ".$select1." value='yes'  >Yes</option>";
          $html .= "<option ".$select2." value='no'  >No</option>";

          $html.='</select>';
     }else{
        $html.= $xmldisplayVal;
     }
    $html.='</td> </tr>';


  /**** Website******/ 
$html .= '<tr><th>Property website</th> <td>';
     global $wpdb;
     $datas=$wpdb->get_results( "SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY ID ASC");
  if (in_array("administrator", $admin_role)) {
   if(isset($datas) && !empty($datas)){
         $html .= '<select style="width:164px;" class="" name="website_property[]" multiple>';
   foreach ($datas as $data){
          if(!empty($websitePropertyval) && in_array($data->ID, $websitePropertyval)){
             $html .= "<option selected = selected value='" . $data->ID . "'  >" . qtranxf_use(qtranxf_getLanguage(), $data->post_title) . "</option>";
          }else{
            $html .= "<option value=".$data->ID.">".qtranxf_use(qtranxf_getLanguage(),$data->post_title)."</option>";
          } 
    }
   $html .= "</select>";
   }
}else{
  $k=1;
      $webC=count($websitePropertyval);
if(isset($websitePropertyval) && !empty($websitePropertyval)) { 
  foreach ($websitePropertyval as $id) {
     global $wpdb;
     $datas=$wpdb->get_row( "SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' and ID =$id ORDER BY ID ASC");
    // print_r($datas);
    if($k < $webC){ 
          $coma=", ";} 
        else{ $coma='';}
    $html.= qtranxf_use(qtranxf_getLanguage(),$datas->post_title).$coma;
    $k++;
  }
}
}

$html .= '</td> </tr>'; 

   $html .= '</table>';

   echo $html;
}

add_action('profile_update', 'my_profile_update', 10, 2);

function my_profile_update($user_id, $old_user_data) {

   //$country = json_encode($_POST['country']);
   //$state = json_encode($_POST['state']);
   $displayXml=$_POST['show_xml_property'];
   update_user_meta($user_id, 'country', $_POST['country']);
   update_user_meta($user_id, 'state', $_POST['state']);
   update_user_meta($user_id, 'xml_property', $displayXml);
   update_user_meta($user_id, 'website_property', $_POST['website_property']);
}

function remove_higher_levels($all_roles) {
   global $pagenow;
   if ($pagenow == "user-new.php") {
      $user = wp_get_current_user();
      $next_level = 'level_' . ($user->user_level + 1);

      foreach ($all_roles as $name => $role) {
         if (isset($role['capabilities'][$next_level])) {
            unset($all_roles[$name]);
         }
         if ($role['name'] === 'Property Agent') {
            unset($all_roles[$name]);
         }
         //if($role['name'] === 'Property Agent'){
         //unset($all_roles[$name]);
         //}
      }
   }
   return $all_roles;
}

add_filter('editable_roles', 'remove_higher_levels');

function assign_property_agent($post_id, $post) {

   $slug = 'property';
   if ($slug != $post->post_type) {
      return;
   }

   $user = wp_get_current_user();
   $user_id = $user->ID;
   $user_meta = get_user_meta($user_id);
   $agentid = $user_meta[proprietor_id][0];
   $agentid = intval($agentid);
   $status = wp_set_object_terms($post_id, $agentid, 'proprietor', true);
   //$terms = get_the_terms( $post_id, 'proprietor'); 
}

add_action('save_post', 'assign_property_agent', 10, 2);

add_action('admin_head', 'azull_favicon_admin');

function azull_favicon_admin() {
   echo '<link rel="Shortcut Icon" type="image/x-icon" href="' . get_template_directory_uri() . '/favicon.ico" />';
}

// Hide plugin updates notices in wordpress
remove_action('load-update-core.php', 'wp_update_plugins');
add_filter('pre_site_transient_update_plugins', '__return_null');

//**************************************************************//
// CODE BY : Deepak(A) 
// add menu for XML import/export

add_filter('upload_mimes', 'custom_upload_xml');

function custom_upload_xml($mimes) {
   $mimes = array_merge($mimes, array('xml' => 'application/xml'));
   return $mimes;
}

  function custom_upload_filter( $file ){
    $file['name'] = date('Ymd').time('hrs').strtolower($file['name']); 
    return $file;
  }

function wpse_141088_upload_dir($dir) {
   return array(
       'path' => $dir['basedir'] . '/tempxml',
       'url' => $dir['baseurl'] . '/tempxml',
       'subdir' => '/tempxml',
           ) + $dir;
}

function books_register_ref_page() {
  add_submenu_page( 'edit.php?post_type=xml',
        __('XML Feature Mapping', 'azull'),
        __('XML Feature Mapping', 'azull'),
        'manage_options',
        'properties',
        'addnewpage'
    );

   add_submenu_page( 'edit.php?post_type=xml',
        __( 'XML Import', 'azull' ),
         __( 'XML Import', 'azull' ),
        'manage_options',
        'xmlimport',
        'xmlimport'
    ); 

}



//add_action('admin_menu', 'books_register_ref_page');

function addnewpage() {
   //require_once( ABSPATH . 'wp-content/plugins/azull/classes/classPropertyMeta.php' ); 
   $pro_obj = new Azull_XMLmap(); // To add agent drop-down  
   $re =   $pro_obj->createMappingform();
   
}

function xmlimport() {
   //require_once( ABSPATH . 'wp-content/plugins/azull/classes/classPropertyMeta.php' ); 
   $pro_obj = new Azull_XMLmap(); // To add agent drop-down  
   $pro_obj->xmlimport();
   
}


// END deepak(A) code
/* =================Properties Import Steps Start=========== */
// Localize the script with new data
$data_array = array(
  'ajaxurl' => admin_url('admin-ajax.php')
    //'ajaxurl' => admin_url('admin-ajax.php')
);
wp_localize_script('script_handle', 'site_data', $data_array);

// Enqueued script with localized data.
wp_enqueue_script('script_handle');
/* Date : 08-June-2016
 * Method : import_azullinfo_property_custom_cron
 * Params : NULL
 * Return : set custom cron for transfer property data from azull.info to azull.biz
 */
add_action('admin_menu', 'import_azullinfo_property_custom_cron');

function import_azullinfo_property_custom_cron() {
    add_menu_page("Import Properties", "Import Properties", 1, "set_custom_cron", "set_custom_cron");
}

function set_custom_cron() {
  /*global $wpdb;
  $post_arr = array(184971,184954,184936,184926,184915,184901,184889,184857,184850,184833,184806,184780,184764,184757,184742,184721,184703,184677,184655,184648,184628,184606,184594,184569,184562,184544,184525,184516,184505,184499,184476,184454,184444,184433,184427,184417,184404,184379,184359,184335,184305,184292,184283,184260,184243,184223,184209,184181,184155,184127,184100,184083,184050,184025,184011,183974,183947,183926,183903,183865,183850,183835,183809,183787,183759,183738,183721,183688,183667,183640,183629,183622,183613,183599,183576,183552,183541,183518,183498,183479,183463,183442,183428,183416,183409,183390,183380,183347,183327,183303,183296,183258,183248,183224,183212,179481,123004,179457,179468,97461,179567,179538,179506,179497,179437,157450,155562,155577,155600,155612,155622,155636,155671,155683,155696,155705,155718,155731,155742,155755,155767,155781,155792,155805,155817,155828,155856,155910,155921,155931,155942,155954,155967,155980,156009,156043,156088,156107,156117,156130,156157,156169,156203,156226,156237,156247,156265,156274,156283,179414,156293,156302,156311,156322,156333,156345,156358,156391,156404,156416,156427,156460,156473,156930,156537,156549,156559,156570,156608,156620,156631,156642,156659,156670,156681,156694,156707,156717,156731,156744,156756,156767,156778,156790,156802,156811,156854,156877,156863,156888,156904,156917,156927,156938,156955,156967,157017,157031,157043,157052,157063,157075,157094,157107,157122,157139,179398,157151,157162,179384,157174,157212,157224,157237,179373,178880,179360,178894,178908,179349,179346,155553,157250,157320,157295,179335,179322,179309,157263,179298,179292,179281,157282,179270,157307,179257,157416,157428,157439,157462,157474,157485,157495,157513,155588,179065,179056,179051,179038,179025,179012,179001,178987,178966,178962,178947,178943,178936,178932,178928,178924,178920,178916,178912,179231,179156,179134,179080,178783,157504,178750,163367,163348,163332,163313,163304,163295,163283,163266,163239,163209,163187,163178,163172,163161,163149,163134,163122,163105,163095,163070,163060,163017,162985,162961,162943,162927,162909,162889,162876,162858,162851,162805,162789,162767,162748,162731,162717,162691,162676,162661,162621,162611,162582,162564,162531,162518,162486,162456,162437,162427,162389,162378,162360,162341,162318,162291,162263,162234,162207,162192,162156,162135,162081,162066,162024,162004,161966,161941,161927);
  
  //$post_arr = array(161911,161895,161874,161850,161839,161823,161794,161781,161751,161721,161704,161673,161661,161634,161627,161602,161587,161537,161509,161484,161477,161446,161417,161398,161365,161346,161329,161310,161289,161256,161236,161201,161181,161153,161137,161117,161104,161084,161054,161038,161013,160994,160982,160963,160944,160916,160892,160867,160854,160832,160811,160787,160763,160739,160718,160702,160684,160656,160640,160600,160577,160556,160521,160488,160459,160424,160388,160357,160324,160268,160238,160205,160177,160150,160120,160094,160074,160058,160029,160015,159973,159959,159941,159902,159881,159838,159824,159796,159771,159746,159727,159704,159683,159661,159632,159587,159569,159512,159477,159442,159393,159361,159344,159332,159314,159284,159262,159236,159210,159194,159181,159154,159135,159123,159101,159073,159047,159017,158977,158950,158915,158900,158885,158867,158843,158804,158786,158764,158751,158705,158680,158654,158639,158630,158601,158584,158572,158540,158517,158497,158475,158459,158430,158411,158384,158381,158361,158336,158310,158284);
  if(isset($post_arr) && !empty($post_arr)){
    foreach ($post_arr as $key => $val) {
      $data = array(
        'path'=>$val,
        'type'=>111,
        'status'=>0
      );
      $records = $wpdb->get_results("SELECT * FROM wp_xml_record WHERE path = $val AND type = 111", ARRAY_A);
      //print_r($records);die;
      if(empty($records)){
        $wpdb->insert('wp_xml_record',$data); 
      }
    }
  }

die('yes');*/

  //for update meta detail of properties on azull.biz only
  /*global $wpdb;
  $sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC";// 664(new import properties)//0-1337
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  //print('<pre>');print_r($property_data);die;
  if(isset($property_data) && !empty($property_data)){
    $updated_meta = array();
   foreach ($property_data as $key => $val) {
      $post_id = $val['ID'];//22135
      $post_data = get_post($post_id, ARRAY_A);
      $post_meta = get_post_meta($post_id);
      
      //print('<pre>');print_r($post_meta);

      $property_old_data = $wpdb->get_results("SELECT wp_postmeta_dev.meta_key,wp_postmeta_dev.meta_value FROM wp_posts JOIN wp_postmeta_dev ON wp_posts.ID = wp_postmeta_dev.post_id WHERE wp_postmeta_dev.post_id = " . $post_id, ARRAY_A);
      $p_old_meta = '';
      if(isset($property_old_data) && !empty($property_old_data)){
        foreach ($property_old_data as $key => $val) {
          $p_old_meta[$val['meta_key']][] = $val['meta_value'];
        }
      }
//print('<pre>');print_r($p_old_meta);
//die('yes');
      
        //update meta of manuall properties
        //print('<pre>');print_r($p_old_meta);die;
        if(isset($p_old_meta['_nreal_id'][0]) && !empty($p_old_meta['_nreal_id'][0]) && isset($post_meta['_nreal_id'][0]) && !empty($post_meta['_nreal_id'][0]) && $p_old_meta['_nreal_id'][0] == $post_meta['_nreal_id'][0]){
          $tmp['post_id'] = $post_id;

          if(isset($p_old_meta['_dimensions_81'][0]) && !empty($p_old_meta['_dimensions_81'][0]) && empty($post_meta['_dimensions_81'][0])){
            //update_post_meta($post_id,'_dimensions_81', $p_old_meta['_dimensions_81'][0]);
            $tmp['_dimensions_81'] = $p_old_meta['_dimensions_81'][0];
          }

          if(isset($p_old_meta['_dimensions_82'][0]) && !empty($p_old_meta['_dimensions_82'][0]) && empty($post_meta['_dimensions_82'][0])){
            //update_post_meta($post_id,'_dimensions_82', $p_old_meta['_dimensions_82'][0]);
            $tmp['_dimensions_82'] = $p_old_meta['_dimensions_82'][0];
          }

          if(isset($p_old_meta['_dimensions_110'][0]) && !empty($p_old_meta['_dimensions_110'][0]) && empty($post_meta['_dimensions_110'][0])){
            //update_post_meta($post_id,'_dimensions_110', $p_old_meta['_dimensions_110'][0]);
            $tmp['_dimensions_110'] = $p_old_meta['_dimensions_110'][0];
          }

          if(isset($p_old_meta['_dimensions_112'][0]) && !empty($p_old_meta['_dimensions_112'][0]) && empty($post_meta['_dimensions_112'][0])){
            //update_post_meta($post_id,'_dimensions_112', $p_old_meta['_dimensions_112'][0]);
            $tmp['_dimensions_112'] = $p_old_meta['_dimensions_112'][0];
          }

          if(isset($p_old_meta['_scores_105'][0]) && !empty($p_old_meta['_scores_105'][0]) && empty($post_meta['_scores_105'][0])){
            //update_post_meta($post_id,'_scores_105', $p_old_meta['_scores_105'][0]);
            $tmp['_scores_105'] = $p_old_meta['_scores_105'][0];
          }
          if(isset($p_old_meta['_scores_107'][0]) && !empty($p_old_meta['_scores_107'][0]) && empty($post_meta['_scores_107'][0])){
            //update_post_meta($post_id,'_scores_107', $p_old_meta['_scores_107'][0]);
            $tmp['_scores_107'] = $p_old_meta['_scores_107'][0];
          }
          if(isset($p_old_meta['_scores_103'][0]) && !empty($p_old_meta['_scores_103'][0]) && empty($post_meta['_scores_103'][0])){
            //update_post_meta($post_id,'_scores_103', $p_old_meta['_scores_103'][0]);
            $tmp['_scores_103'] = $p_old_meta['_scores_103'][0];
          }

          if(isset($p_old_meta['_scores_104'][0]) && !empty($p_old_meta['_scores_104'][0]) && empty($post_meta['_scores_104'][0])){
            //update_post_meta($post_id,'_scores_104', $p_old_meta['_scores_104'][0]);
            $tmp['_scores_104'] = $p_old_meta['_scores_104'][0];
          }
          if(isset($p_old_meta['_scores_108'][0]) && !empty($p_old_meta['_scores_108'][0]) && empty($post_meta['_scores_108'][0])){
            //update_post_meta($post_id,'_scores_108', $p_old_meta['_scores_108'][0]);
            $tmp['_scores_108'] = $p_old_meta['_scores_108'][0];
          }
          if(isset($p_old_meta['_scores_106'][0]) && !empty($p_old_meta['_scores_106'][0]) && empty($post_meta['_scores_106'][0])){
            //update_post_meta($post_id,'_scores_106', $p_old_meta['_scores_106'][0]);
            $tmp['_scores_106'] = $p_old_meta['_scores_106'][0];
          }


          if(isset($p_old_meta['_feature_36'][0]) && !empty($p_old_meta['_feature_36'][0]) && empty($post_meta['_feature_36'][0])){
            //update_post_meta($post_id,'_feature_36', $p_old_meta['_feature_36'][0]);
            $tmp['_feature_36'] = $p_old_meta['_feature_36'][0];
          }
          if(isset($p_old_meta['_feature_37'][0]) && !empty($p_old_meta['_feature_37'][0]) && empty($post_meta['_feature_37'][0])){
            //update_post_meta($post_id,'_feature_37', $p_old_meta['_feature_37'][0]);
            $tmp['_feature_37'] = $p_old_meta['_feature_37'][0];
          }
          if(isset($p_old_meta['_feature_39'][0]) && !empty($p_old_meta['_feature_39'][0]) && empty($post_meta['_feature_39'][0])){
            //update_post_meta($post_id,'_feature_39', $p_old_meta['_feature_39'][0]);
            $tmp['_feature_39'] = $p_old_meta['_feature_39'][0];
          }
          if(isset($p_old_meta['_feature_40'][0]) && !empty($p_old_meta['_feature_40'][0]) && empty($post_meta['_feature_40'][0])){
            //update_post_meta($post_id,'_feature_40', $p_old_meta['_feature_40'][0]);
            $tmp['_feature_40'] = $p_old_meta['_feature_40'][0];
          }
          $updated_meta[] = $tmp;
        }
      //}
   }
  }
  //print('<pre>');print_r($xmltmp);
  print('<pre>');print_r($updated_meta);
  die('ohhhhh');*/


  //for update meta detail of properties on azull.biz only
  /*global $wpdb;
  $sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC limit 0,1500";// 664(new import properties)
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  //print('<pre>');print_r($property_data);die;
  if(isset($property_data) && !empty($property_data)){
    $xmltmp = array();//4294
    $infotmp = array();
   foreach ($property_data as $key => $val) {
      $post_data = get_post($val['ID'], ARRAY_A);
      $post_meta = get_post_meta($val['ID']);
      if(isset($post_meta['_xmlref'][0]) && !empty($post_meta['_xmlref'][0])){

        $xmltmp[] = array('ID'=>$post_data['ID'],'ref'=>$post_meta['_nreal_id'][0]);
        //die('hi');

        $ref_no = (isset($post_meta['_nreal_id'][0]) && !empty($post_meta['_nreal_id'][0]))?$post_meta['_nreal_id'][0]:'';
        if(isset($post_meta['_place'][0]) && !empty($post_meta['_place'][0])){
          $place_term = get_term($post_meta['_place'][0],'place');
          $place = (isset($place_term->name) && !empty($place_term->name))?ucwords($place_term->name):'';
        }
        if(isset($post_meta['_region'][0]) && !empty($post_meta['_region'][0])){
          $region_term = get_term($post_meta['_region'][0],'region');
          $region = (isset($region_term->name) && !empty($region_term->name))?ucwords($region_term->name):'';
        }
        if(isset($post_meta['_country'][0]) && !empty($post_meta['_country'][0])){
          $country_term = get_term($post_meta['_country'][0],'country');
          $country = (isset($country_term->name) && !empty($country_term->name))?ucwords($country_term->name):'';
        }
        if(isset($post_data['post_category'][0]) && !empty($post_data['post_category'][0])){
          $category_term = get_term($post_data['post_category'][0],'category');
          $category = (isset($category_term->name) && !empty($category_term->name))?ucwords($category_term->name):'';
        }
        $desc_arr = array(
            'en'=>'Inmo España is the expert in sales of apartments and villas in Spain.',
            'fr'=>'Inmo España est lexpert dans la vente dappartements et de villas en Espagne.',
            'nl'=>'Inmo España is de Expert in verkoop van appartementen en villa’s in Spanje.'
        );
        $te_koop_in_arr = array(
            'en'=>'for sale',
            'fr'=>'te koop dans',
            'nl'=>'te koop in'
        );
      $languages = qtranxf_getSortedLanguages();
      $smeta_obj = new Azull_Seo_Meta();
      $title_data = '';
      $keywords_data = '';
      $description_data = '';
      foreach ($languages as $lang) {
         $t_place[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$place));
         $t_region[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$region));
         $t_country[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$country));
         $t_category[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$category));
         $t_title[$lang] = ucfirst(qtranxf_use($lang, $post_data['post_title']));


         //$title_data .= "[:$lang]".ucfirst(strtolower($t_title[$lang])).' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' Ref.'.$ref_no;
         //$keywords_data .= "[:$lang]".$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].' '.$t_region[$lang].' '.$t_country[$lang];
         //$description_data .= "[:$lang]".ucfirst(strtolower($t_title[$lang])).' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];


         $title_data .= "[:$lang]".$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' Ref.'.$ref_no;
         $keywords_data .= "[:$lang]".$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].' '.$t_region[$lang].' '.$t_country[$lang];
         $description_data .= "[:$lang]".$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];
        }
        //print('<pre>');print_r($title_data.'[:]');die;
      
      if(isset($title_data) && !empty($title_data)){
        $m_title[] = $title_data;
         //update_post_meta($val['ID'],'property_meta:title', $title_data.'[:]');
      }
      if(isset($keywords_data) && !empty($keywords_data)){
        $m_keywords[] = $keywords_data;
         //update_post_meta($val['ID'],'property_meta:keywords', $keywords_data.'[:]');
      }
      if(isset($description_data) && !empty($description_data)){
        $m_desc[] = $description_data;
         //update_post_meta($val['ID'],'property_meta:description', $description_data.'[:]');
      }
      }else{
        //$infotmp[] = array('ID'=>$post_data->ID,'ref'=>$post_meta['_nreal_id'][0]);
      }
   }
  }
  //print('<pre>');print_r($xmltmp);
  print('<pre>');print_r($m_title);
  print('<pre>');print_r($m_keywords);
  print('<pre>');print_r($m_desc);
  
  die('ohhhhh');*/


/*global $wpdb;
$sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC limit 2824,100";
//$sql = "SELECT * FROM wp_posts where post_type='property' AND ID=179481";

$property_data = $wpdb->get_results($sql, ARRAY_A);
//print('<pre>');print_r($property_data);die;
foreach ($property_data as $key => $val) {
   //for english ucwords
   //for nl,fr ucfirst
    $en_txt = qtranxf_use('en', $val['post_title']);
    $fr_txt = qtranxf_use('fr', $val['post_title']);
    $nl_txt = qtranxf_use('nl', $val['post_title']);
    
    $split_nl = explode("te koop in ", $nl_txt);
    $cnt_nl = count($split_nl);
    $split_nl[$cnt_nl-1] = ucwords(strtolower(end($split_nl)));
    //print_r($split);die;
    $nl_txt = implode("te koop in ",$split_nl);

    $split_fr = explode("te koop in ", $fr_txt);
    $cnt_fr = count($split_fr);
    $split_fr[$cnt_fr-1] = ucwords(strtolower(end($split_fr)));
    //print_r($split_fr);die;
    $fr_txt = implode("te koop in ",$split_fr);

    //print('<pre>');print_r(ucwords(strtolower(end($split))));die;
    $title = $val['post_title'];
    $old_title[] = $title;
    $update_txt = "[:en]".ucwords(strtolower($en_txt))."[:fr]".ucfirst($fr_txt)."[:nl]".ucfirst($nl_txt)."[:]";
    //$update_txt = "[:en]".ucwords(strtolower($en_txt))."[:fr]".ucfirst(strtolower($fr_txt))."[:nl]".ucfirst(strtolower($nl_txt))."[:]";
    $post_id = $val['ID'];
    $post_data = array(
        'ID'=>$val['ID'],
        'post_title' => $update_txt
      );
    $post_dataArr[] = $post_data;
    //$wpdb->update('wp_posts', array('post_title' => $update_txt), array('ID' => $post_id));
    //wp_update_post($post_data);
  }
  print('<pre>');print_r($old_title);
  print('<pre>');print_r($post_dataArr);
  die('hi');*/
echo '<style>
#dvLoading {
    background: url(images/ajax-loader.gif) no-repeat scroll center center #000;
    color: white;
    height: 140px;
    left: 43%;
    margin: -25px 0 0 -25px;
    opacity: 1;
    position: fixed;
    top: 50%;
    width: 250px;
    z-index: 1000;
}
</style>';
$html = '<div class="wrap">
<span id="msg_box"></span>
<h1>Set cron job for import properties from azull.info (Joomla Website) to azull.biz (Wordpress Website)</h1>
<p>For start import property process, please click on the below button. Once import property cron set or in process, you will be able to set another cron job for import property after finish previously defined cron process.</p>
<hr>
<form method="post" id="set_import_property_cron">
    <button type="button" onclick="set_custom_cron_call(this.value)" name="cron_set_btn" id="cron_set_btn" class="button button-primary" value="1">Import Properties</button>
</form>
<hr>
</div>';?>
<script>
function set_custom_cron_call(val){
   jQuery("#dvLoading").show();
   jQuery("#wpwrap").css({"opacity":0.3});
   jQuery.ajax({
      type: "POST",
      url: ajaxurl,
      data: {action: 'import_property_custom_cron',cron_btn:val},
   }).done(function(response) {
     response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
     jQuery('#msg_box').html(response.html);
     jQuery("#dvLoading").hide();
     jQuery("#wpwrap").css({"opacity":1});
   });
}
</script>
<?php
    echo $html;
}
/*
 * Method : import_properties_steps
 * Params : joomla Database 
 * Return : Import all properties data and insert it in wp database with  all properties details
 */
//add_action('admin_menu', 'import_properties_steps');

function import_properties_steps() {
    add_menu_page("Import Properties", "Import Properties", 1, "import_properties", "import_properties");
}

function import_properties() {
echo '<style>
#dvLoading {
    background: url(images/ajax-loader.gif) no-repeat scroll center center #000;
    color: white;
    height: 140px;
    left: 43%;
    margin: -25px 0 0 -25px;
    opacity: 1;
    position: fixed;
    top: 50%;
    width: 250px;
    z-index: 1000;
}
</style>';
$html = '<div class="wrap">
<h1>Import Properties From Joomla</h1>

<p>When you click the button below WordPress will run script for save joomla properties records to wordpress database.</p>
<p><b>Step 1:</b> In step1 we are fetching all property title and content with images</p>
<p><b>Step 2:</b> In step2 we are fetching property details like rooms information, financial information, location related information and other property features</p>
<p><b>Step 3:</b> In step3 we are fetch builder , features, interiors and exteriors information</p>
<h2>Please Select Step to import property data</h2>
<hr>
<form method="post" id="import_properties_from_joomla">
    <button type="button" onclick="import_property_data(this.value)" name="step" id="step1" class="button button-primary" value="1">Step1</button>
    <button type="button" onclick="import_property_data(this.value)" name="step" id="step2" class="button button-primary" value="2" >Step2</button>
    <button type="button" onclick="import_property_data(this.value)" name="step" id="step3" class="button button-primary" value="3" >Step3</button>
<hr>
</form>
</div>';?>
<script>
function import_property_data(val){
  jQuery("#dvLoading").show();
  jQuery("#wpwrap").css({"opacity":0.3});
  jQuery.ajax({
         type: "POST",
         url: ajaxurl,
         data: {action: 'import_properties',step:val},
         //async: false,
      }).done(function(response) {
        alert(response);
        //response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
        //data = typeof data != 'object' ? jQuery.parseJSON(data) : data;

        //if(response.error==0){
          var next_step=parseInt(val)+1;
          //alert(next_step);
          //jQuery("#step"+val).attr("disabled", true);
          //jQuery("#step"+next_step).removeAttr("disabled");
        //}
        
        jQuery("#dvLoading").hide();
        jQuery("#wpwrap").css({"opacity":1});
      });
}
</script>
<?php
    echo $html;
}

remove_role('subscriber');
remove_role('contributor');
remove_role('info1');
///remove_role('agent');
///remove_role('info');

/*
 added new role in azull.be
 date:-27-june-2016
 */
add_role('info',__( 'Info' ),
    array(
        'read'         => true,  // true allows this capability
        'edit_posts'   => true,
	'edit_others_posts'=>true,
	'edit_published_posts'=>true,
	'manage_categories'=>true,
	'manage_options'=>true
        
    )
);
add_role('ie',__( 'IE' ),
    array(
        'read'         => true,  // true allows this capability
        'edit_posts'   => true,
	'edit_others_posts'=>true,
	'edit_published_posts'=>true,
	'manage_categories'=>true,
	'manage_options'=>true
    )
);

add_role('agent',__( 'Agent' ),
    array(
        'read'         => true,  // true allows this capability
        'edit_posts'   => true,
   'edit_others_posts'=>true,
   'edit_published_posts'=>true,
   'manage_categories'=>true,
   'manage_options'=>true,
   'upload_files' => true,
        
    )
);

add_role('price',__( 'Price' ),
    array(
        'read'         => true,  // true allows this capability
        'edit_posts'   => true,
  'edit_others_posts'=>true,
  'edit_published_posts'=>true,
  'manage_categories'=>true,
  'manage_options'=>true
        
    )
);









/*
  remove_role('subscriber');
  remove_role('editor');
  remove_role('author');
  remove_role('contributor'); */
/*
 * Date : 24-02-2016
 * Method : for add custom option to define form's title for client website
 */
/* add_action('admin_menu', 'manage_form_titles');
  function manage_form_titles()
  {
  add_options_page('Form Titles', 'Form Titles', 'manage_options', 'functions','add_form_titles');
  }

  function add_form_titles()
  {
  if(isset($_POST['submit']) && $_POST['submit']!=''){
  $content='';
  $state=0;
  //print('<pre>');print_r(count($_POST['infodays_form_title']));die('done');
  if(isset($_POST['infodays_form_title']) && (!empty($_POST['infodays_form_title']['en']) || !empty($_POST['infodays_form_title']['fr']) || !empty($_POST['infodays_form_title']['nl']))){
  $infodays_frm_title= $_POST['infodays_form_title'];
  $content=serialize($infodays_frm_title);
  update_option( 'infodays_form_title', $content, '', 'yes' );
  $state=1;
  }else{
  $state=0;
  $msg='Please enter infodays form title.<br />';
  }
  if(isset($_POST['property_form_title']) && (!empty($_POST['property_form_title']['en']) || !empty($_POST['property_form_title']['fr']) || !empty($_POST['property_form_title']['nl']))){
  $property_frm_title= $_POST['property_form_title'];
  $content=serialize($property_frm_title);
  update_option( 'property_form_title', $content, '', 'yes' );
  $state=1;
  }else{
  $state=0;
  $msg .='Please enter property form title.';
  }
  if($state==1){
  $msg='Settings saved.';
  }
  }
  ?>
  <div class="wrap">
  <div class="meta-box-sortables ui-sortable">
  <div id="" class="postbox" style="padding: 8px;">
  <div class="handlediv" title="Click to toggle"><br></div><h3 class="hndle ui-sortable-handle"><span><?php _e('Form Titles','azull') ?></span></h3>

  <?php
  $languages = qtranxf_getSortedLanguages();  // for get all languages
  echo '<div style="margin: 5px;text-align: left;" class="epc_language-switcher">';
  echo "&nbsp;";
  foreach ($languages as $lang) {
  echo "<a href=\"javascript:frm_title_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
  }
  echo "</div>";
  ?>
  <form method="post" action="#" novalidate="novalidate" enctype="multipart/form-data">
  <?php if(isset($msg) && !empty($msg)){ ?>
  <div class="updated settings-error notice is-dismissible">
  <p><strong><?php echo $msg; ?></strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
  <?php } ?>
  <table class="form-table">
  <tr>
  <th scope="row"><label for="infodays_form_title"><?php _e('Infodays form title','azull') ?></label></th>
  <td>
  <?php $info_data=unserialize(get_option('infodays_form_title'));
  foreach ($languages as $lang):
  ?>
  <div class="frm_title_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
  <input name="infodays_form_title[<?php echo $lang ?>]" type="text" id="infodays_form_title" value="<?php echo (isset($info_data[$lang]))?$info_data[$lang]:''; ?>" class="regular-text" />
  </div>
  <?php endforeach; ?>
  </td>
  </tr>
  <tr>
  <th scope="row"><label for="property_form_title"><?php _e('Property form title','azull') ?></label></th>
  <td>
  <?php $property_data=unserialize(get_option('property_form_title'));
  foreach ($languages as $lang):
  ?>
  <div class="frm_title_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
  <input name="property_form_title[<?php echo $lang ?>]" type="text" id="property_form_title" value="<?php echo (isset($property_data[$lang]))?$property_data[$lang]:''; ?>" class="regular-text" />
  </div>
  <?php endforeach; ?>
  </td>
  </tr>
  </table>
  <script type="text/javascript">
  var default_lang = 'nl';
  frm_title_switch_lang(default_lang);
  function frm_title_switch_lang(lang) {
  <?php
  foreach ($languages as $lang): echo "jQuery('.frm_title_language_{$lang}').hide();";
  endforeach;
  ?>
  jQuery('.frm_title_language_' + lang).show();
  jQuery(".epc_language-switcher a").css("font-weight", "normal");
  jQuery('#active_lang_' + lang).css("font-weight", "bold");
  }
  </script>
  <?php submit_button(); ?>
  </form>
  </div>
  </div>
  </div>
  <?php
  } */

function ninja_forms_submission_call() {
   Class_Site::ninja_forms_submission();
}

function ninja_forms_save_settings() {
   Class_Site::ninja_forms_submission();
}

function add_transient_option($form_id) {
   require_once WP_CONTENT_DIR . '/plugins/ninja-forms/deprecated/ninja-forms.php';
   // Create a new form object for this form.
   $return = Ninja_Forms()->form($form_id);
   set_transient('nf_form_' . $form_id, $return, DAY_IN_SECONDS);
}

/*
 * Date : 31-03-2016
 * Method : Function for delete form from client website
 */

function ninja_forms_delete_call() {
   Class_Site::ninja_forms_delete();
}

function test_remote() {
   global $wpdb;
  
   //ini_set('display_errors', '1');
   //die('123');
   //$mydb = new wpdb('username','password','database','localhost');
   $mydb = new wpdb('azull_realestate', 'azull2012realestate', 'azull_realestate', 'azull.info:3306');
   echo "<pre>";
   print_r($mydb);
   echo "select reference_table from p35p6_falang_content where id=21864";
   $rows = $mydb->get_results("select reference_table from p35p6_falang_content where id=21864");
   print_r($rows);
   exit;
}

/**
 * Language Select Code for non-Widget users, addpted to use it as per azull theme.
 * @Note: check qtranxf_generateLanguageSelectCode(), call azull_LanguageSelectCode() insted of tranxf_generateLanguageSelectCode() in azull theme.
 * @Author:CISIN
 */
function azull_LanguageSelectCode($args = array(), $id = '') {
   global $q_config;
   if (is_string($args))
      $type = $args;
   elseif (is_bool($args) && $args)
      $type = 'image';
   elseif (is_array($args)) {
      if (!empty($args['type']))
         $type = $args['type'];
      if (empty($id) && !empty($args['id']))
         $id = $args['id'];
   }
   $type = 'both';
   if (empty($id))
      $id = 'qtranslate';
   $id .= '-chooser';
   if (is_404())
      $url = get_option('home');
   else
      $url = '';
   $flag_location = qtranxf_flag_location();
   echo '<ul class="language-chooser language-chooser-' . $type . ' qtranxs_language_chooser" id="' . $id . '">';
   switch ($type) {
      case 'both': {
            foreach (qtranxf_getSortedLanguages() as $language) {
               $alt = $q_config['language_name'][$language] . ' (' . $language . ')';
               echo '<li';
               if ($language == $q_config['language'])
                  echo ' class="active"';
                $url2 = qtranxf_convertURL($url, $language, false, true);
               if (strpos($url2, 'preview=true') !== false) {
                 echo '><a style="backgrond" href="' . str_replace('/property', '', qtranxf_convertURL($url, $language, false, true)) . '"';
               } else {
                 echo '><a style="backgrond" href="' . qtranxf_convertURL($url, $language, false, true) . '"';
               }
               echo ' class="qtranxs_flag_' . $language . ' qtranxs_flag_and_text" title="' . $alt . '">';
               //echo '<img src="'.$flag_location.$q_config['flag'][$language].'"></img>';
               echo '<span>' . $q_config['language_name'][$language] . '</span></a></li>';
            }
         } break;
   }
   echo '</ul><div class="qtranxs_widget_end"></div>';
}


/* code for display last update date in custom post
* Date:- 11-may-2016
*/
add_action( 'load-edit.php', function() {
    $post_type   = 'testimonial';
    $col_name    = 'modified_author';
    $screen = get_current_screen();

    if ( ! isset ( $screen->id ) )
        return;

    if ( "edit-$post_type" !== $screen->id )
        return;

    add_filter(
        "manage_{$post_type}_posts_columns",
        function( $posts_columns ) use ( $col_name ) {
            $posts_columns[ $col_name ] = __('Last Modified Date','azull');

            return $posts_columns;
        }
    );
    add_action(
        "manage_{$post_type}_posts_custom_column",
        function( $column_name, $post_id ) use ( $col_name ) {

            if ( $col_name !== $column_name )
                return;
            $post_update = get_post( $post_id ); 
            $update_date = $post_update->post_modified;
            print esc_html( $update_date );
        },
        10, 2
    );
});

function set_xml_columns($columns) {
    unset($columns['language']);
    return $columns;
}
add_filter('manage_xml_posts_columns' , 'set_xml_columns');

/* add Aciton to add propriter url deepak(A)*/
add_action( 'wp_ajax_get_proprietor_url', array('azull','get_proprietor_urls_value') );




/* Add menu for add thanku page content deepak(A)*/ 
//add_action('admin_menu', 'thk_menu_pages');
/*function thk_menu_pages(){
 add_menu_page('Thank you page text', 'Thank you page text', 'manage_options', 'thank-you-page-text', 'thk_page_output','dashicons-welcome-add-page');
}*/

/* function for display form for add thanku page content
   Date:- 15/july/2016
*/
/*function thk_page_output(){
?>
    <div class="wrap">
      <div id="msg" style="height:38px; display: none;" class="updated notice notice-success is-dismissible below-h2"><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
    <div class="meta-box-sortables ui-sortable">
    <div id="" class="postbox" style="padding: 8px;">
    <div class="handlediv" title="Click to toggle"><br></div><h3 class="hndle ui-sortable-handle"><span><?php _e('Add thank you page text','azull') ?></span></h3>

        <?php
          $languages = qtranxf_getSortedLanguages();  // for get all languages 
            echo '<div style="margin: 5px;text-align: left;" class="epc_language-switcher">';
            echo "&nbsp;";
            foreach ($languages as $lang) {
                echo "<a href=\"javascript:frm_title_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
            }
            echo "</div>";
         ?>
        <form method="post" action="#" novalidate="novalidate" enctype="multipart/form-data" name="thanku_form" id="thanku_form">
        <?php if(isset($msg) && !empty($msg)){ ?>
        <div class="updated settings-error notice is-dismissible"> 
<p><strong><?php echo $msg; ?></strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
<?php } 

                // All Dynamic Form created by ninja forms
       $all_forms = Ninja_Forms()->forms()->get_all();
       $html ='<form id="thanks_page" name="thanks_page">';
        $html.='<table class="form-table">';
       $html.='<tr><td><b>Pages</b></td><td>';
       $html.='<select name="page_id" id="page_id" class="SlectBox" style="width:300px" onchange="return chaeckPageText()">';
       $html.='<option class="selectator_group_header" value="">Please select page</option>';
       $html.='<option class="selectator_group_header" value="" disabled><h1>--Default Pages</h1></option>';
       
       // All Default Form 
       $page_ids=get_all_page_ids();
        foreach($page_ids as $page){
          $html.='<option value="'.$page.'" class="selectator_option"> '.get_the_title($page).'</option>';
        }
        $html.='<option disabled>--<b>Daynamic Pages</b></option>';
        foreach($all_forms as $form_id){
             $label = esc_html( Ninja_Forms()->form( $form_id )->get_setting( 'form_title' ) );
             $html.='<option value="dyn_'.$form_id.'" class="selectator_option"> '.$label.'</option>';
        }

       $html.='<option disabled>--<b>Static Pages</b></option>';
       // All Static Form 
       $html.='<option value="azull_reg"><b>Registraion</option>';
       $html.='<option value="infodays"><b>Info-Days</option>';
       $html.='<option value="property_info">Property Info</option>';
       $img='<img src="http://azull.biz/cisin/wp-includes/images/spinner.gif" >';
       echo $html.='</select></td></tr>';
              ?>  <tr>
                   <td><b><?php _e('Text','azull') ?></b></td>
                <td>
                <?php foreach ($languages as $lang):?>
                <div class="thanku_text_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
                <textarea class="textareaEditor_thk_txt" rows="10" name="page_text[<?php echo $lang ?>]" id="page_text_<?php echo $lang ?>" style="width:100%;background: hsl(0, 0%, 95%);"></textarea>
                
                 </div>
                <?php endforeach; ?>
                </td>
                </tr> 
                <?php 
       $html1.='<tr><td></td><td><input type="button" value="Save" onClick="addThankuPageText()" class="button button-primary button-large">&nbsp;<span id="load" style="display:none">'.$img.'</span></td></tr></table> </form>';
       
        echo $html1;
       ?>
            <script type="text/javascript">
                var default_lang = 'nl';
                frm_title_switch_lang(default_lang);
                function frm_title_switch_lang(lang) {
            <?php
            foreach ($languages as $lang): echo "jQuery('.thanku_text_language_{$lang}').hide();";
            endforeach;
            ?>
                    jQuery('.thanku_text_language_' + lang).show();
                    jQuery(".epc_language-switcher a").css("font-weight", "normal");
                    jQuery('#active_lang_' + lang).css("font-weight", "bold");
                }
            </script>
    </div>
    </div>
    </div>
    <script src="<?php echo WP_PLUGIN_URL ?>/azull/js/tinymce/tinymce.min.js"></script>
    <script>
      jQuery(document).ready(function($) {
     tinymce.init({
    selector: "textarea.textareaEditor_thk_txt",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });

   setTimeout(function(){ jQuery("div.mce-btn > button > i").addClass("mce-ico"); }, 3000);

     
   });
</script>
<?php } */

/* Date : 12-Oct-2016
 * Method : thk_pages_menu
 * Params : NULL
 * Return : define thank you page info for each page on different websites
 */

add_action('admin_menu', 'thk_pages_menu');
function thk_pages_menu(){
 add_menu_page('Thank You Page Info', 'Thank You Page Info', 'manage_options', 'thank-you-page-info', 'thk_page_info','dashicons-welcome-add-page');
}

/* Date : 12-Oct-2016
 * Method : thk_page_info
 * Params : NULL
 * Return : function for display form for add thanku page content
 */
function thk_page_info(){
?>
    <div class="wrap">
      <div id="msg" style="height:38px; display: none;" class="updated notice notice-success is-dismissible below-h2"><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
    <div class="meta-box-sortables ui-sortable">
    <div id="" class="postbox" style="padding: 8px;">
    <div class="handlediv" title="Click to toggle"><br></div><h3 class="hndle ui-sortable-handle"><span><?php _e('Add thank you page text','azull') ?></span></h3>
        <?php
          $languages = qtranxf_getSortedLanguages();  // for get all languages 
            echo '<div style="margin: 5px;text-align: left;" class="epc_language-switcher">';
            echo "&nbsp;";
            foreach ($languages as $lang) {
                echo "<a href=\"javascript:frm_title_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
            }
            echo "</div>";
         ?>
        <form method="post" action="#" novalidate="novalidate" enctype="multipart/form-data" name="thanku_form" id="thanku_form">
        <?php if(isset($msg) && !empty($msg)){ ?>
        <div class="updated settings-error notice is-dismissible"> 
        <p><strong><?php echo $msg; ?></strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
        <?php } ?>
        <form id="thanks_page" name="thanks_page">
<table class="form-table">
        <tr>
                <td><b><?php _e('Client visibility','azull') ?></b></td>
      <td>
      <?php
      global $wpdb;
      $val = array();
      $val = get_post_meta($post->ID, "_client", true);
      $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' order by post_title ASC");
      ?>
      <select style="min-height: 26px; width: 400px" class="SlectBox" name="client" id="client" onchange="return getClientPages()">
      <option value="" disabled selected><?php echo __('Select site', 'azull'); ?></option>
      <?php
      foreach ($datas as $data) {
         echo "<option value='" . $data->ID . "'>" . qtranxf_use(qtranxf_getLanguage(), $data->post_title) . "</option>";
      }
      ?>
      </select><br>
     </td></tr> 
<?php
      // All Dynamic Form created by ninja forms
       $html='<tr><td><b>Pages</b></td><td><span id="page_box">';
       $html.='<select name="page_id" id="page_id" class="SlectBox" style="width:460px" onchange="return getThkPageInfo()">';
       $html.='<option class="selectator_group_header" value="">Please select page</option>';
       /*$html.='<option class="selectator_group_header" value="" disabled><h1>--Default Pages</h1></option>';
       // All Default Form 
       $page_ids=get_all_page_ids();
        foreach($page_ids as $page){
          $html.='<option value="'.$page.'" class="selectator_option"> '.get_the_title($page).'</option>';
        }
        $all_forms = Ninja_Forms()->forms()->get_all();
        $html.='<option disabled>--<b>Daynamic Pages</b></option>';
        foreach($all_forms as $form_id){
             $label = esc_html( Ninja_Forms()->form( $form_id )->get_setting( 'form_title' ) );
             $html.='<option value="dyn_'.$form_id.'" class="selectator_option"> '.$label.'</option>';
        }

       $html.='<option disabled>--<b>Static Pages</b></option>';
       // All Static Form 
       $html.='<option value="azull_reg"><b>Registraion</option>';
       $html.='<option value="infodays"><b>Info-Days</option>';
       $html.='<option value="property_info">Property Info</option>';*/
       $img='<img src="http://azull.biz/cisin/wp-includes/images/spinner.gif" >';
       echo $html.='</select></span></td></tr>';
              ?>
              
              <tr>
                   <td><b><?php _e('Thank You Page Text','azull') ?></b></td>
                <td>
                <?php foreach ($languages as $lang):?>
                <div class="thanku_text_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
                <textarea class="textareaEditor_thk_txt" rows="10" name="page_text[<?php echo $lang ?>]" id="page_text_<?php echo $lang ?>" style="width:100%;background: hsl(0, 0%, 95%);"></textarea>
                
                 </div>
                <?php endforeach; ?>
                </td>
                </tr>
                <tr>
                   <td><b><?php _e('Tracking Code','azull') ?></b></td>
                <td>
                <?php foreach ($languages as $lang):?>
                <div class="track_code_language_<?php echo $lang ?>"  <?php echo (($lang != 'en') ? 'style="display:none"' : ''); ?>>
                <textarea rows="10" name="track_code[<?php echo $lang ?>]" id="track_code_<?php echo $lang ?>" style="width:100%;"></textarea>
                
                 </div>
                <?php endforeach; ?>
                </td>
                </tr>
                <?php 
       $html1.='<tr><td></td><td><input type="button" value="Save" onClick="saveThkPageInfo()" class="button button-primary button-large">&nbsp;<span id="load" style="display:none">'.$img.'</span></td></tr></table> </form>';
       
        echo $html1;
       ?>
            <script type="text/javascript">
                var default_lang = 'nl';
                frm_title_switch_lang(default_lang);
                function frm_title_switch_lang(lang) {
            <?php
            foreach ($languages as $lang): echo "jQuery('.thanku_text_language_{$lang}').hide();";
            echo "jQuery('.track_code_language_{$lang}').hide();";
            endforeach;
            ?>
                    jQuery('.thanku_text_language_' + lang).show();
                    jQuery('.track_code_language_' + lang).show();
                    jQuery(".epc_language-switcher a").css("font-weight", "normal");
                    jQuery('#active_lang_' + lang).css("font-weight", "bold");
                }
            </script>
    </div>
    </div>
    </div>
    <script src="<?php echo WP_PLUGIN_URL ?>/azull/js/tinymce/tinymce.min.js"></script>
    <script>
      jQuery(document).ready(function($) {
     tinymce.init({
    selector: "textarea.textareaEditor_thk_txt",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });
     /*tinymce.init({
    selector: "textarea.textareaEditor_track_code",   
    menubar : false,
    plugins: [
                "advlist autolink autosave link image lists charmap print preview hr anchor pagebreak spellchecker",
                "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
                "table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker textpattern"
        ],

        toolbar1: "bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | styleselect formatselect fontselect fontsizeselect",
        toolbar2: "cut copy paste | bullist numlist | outdent indent blockquote | undo redo | link unlink anchor image | insertdatetime | forecolor backcolor",
        toolbar3: "table | hr removeformat | subscript superscript | charmap emoticons | print fullscreen | ltr rtl | spellchecker | visualchars visualblocks nonbreaking template pagebreak restoredraft",
        menubar: false,
        toolbar_items_size: 'small',

        style_formats: [
                {title: 'Bold text', inline: 'b'},
                {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
                {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
                {title: 'Example 1', inline: 'span', classes: 'example1'},
                {title: 'Example 2', inline: 'span', classes: 'example2'},
                {title: 'Table styles'},
                {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],
    });*/
   setTimeout(function(){ jQuery("div.mce-btn > button > i").addClass("mce-ico"); }, 3000);
   });
</script>
<?php }



/* Date : 04-June-2016
 * Method : weather_info
 * Params : NULL
 * Return : define weather info for each place
 */
//add_action('admin_menu', 'weather_info');

function weather_info1() {
    add_menu_page("Weather Info", "Weather Info", 1, "weatherinfo", "weatherinfo");
}

function weatherinfo1() {

 
 /*Code for update Image name and title*/
/*get all xml Ids */




//$allPostId =array(200024,200054);

/* run for all xml post id*/
foreach ($allPostId as $post_id) {
  //echo $post_id."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];

  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

  $refid=get_post_meta($post_id,'_nreal_id');
  
  $imageTitle =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName));
 
  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];
    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    //echo '<pre>';print_r($ids);
    //die;////////

  /* run for all post attachment id*/ 
  $i=0; 
  foreach ($ids as $atchid) {
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
          ///$oldnamefile=$path."wp-content/uploads/2017/01/".$prvName;
          $oldnamefile=$filepath.'/'.$prvName;
          $newfile = $filepath.'/'.$name.'.'.$ext;
         
              // check attachmentImage title and post name
              if($pData->post_name!='' && $imageTitle != $pData->post_name){
                 $table_name='wp_posts';

                  /*update post meta*/       
                  $wpdb->query($wpdb->prepare("UPDATE $table_name SET guid= '$updatedGuid', post_title='$name', post_name='$name' WHERE ID=$atchid"));
                
              /* get wp_attached_file data */
                  $atchData=get_post_meta($atchid,'_wp_attached_file');
                  $file = get_attached_file($atchid);
                  $path = pathinfo($file);
                  $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];

                  /*rename attact guid */
                  if(file_exists($oldnamefile)) {
                    rename($oldnamefile, $newfile);
                  }

                  /*rename attact fileName */
                  if(file_exists($file)){
                    //rename($file, $newwp_attached_file); 
                    //update_attached_file( $atchid, $newwp_attached_file );
                  }
                  
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;
               $updatedAttachData=serialize($atchData1);
              
              /*Update attechment data*/ 
 
                $thumbnail= $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                $large= $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
          
                
                /*if(file_exists($thumbnail)) {
                  echo 'yes<br>';
                }else{
                  echo 'exist--'.$thumbnail.'<br>';
                }*/

                //$rn1=rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                //$rn2=rename($medium, $filepath."/".$name.'-300x169.jpg');
                //$rn3=rename($large, $filepath."/".$name.'-1024x576.jpg');
                //rename($large, $filepath."/".$name.'-1024x576.jpg');
                
                $atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                $atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                $atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                
                //echo  "<br>".$rn1."<br>".$rn2."<br>".$rn3."<br>";

                if($rn1 == 1 && $rn2==1 && $rn3==1){
                  //echo 'fileUpdated<br>';
                  //$table_name1='wp_postmeta';
                  //$wpdb->query( "DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'" );
                  //$wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");
                }else{
                   //echo 'notupdated';
                   //$notRenameproper[]= $atchid;
                }
              } else { //end check attachmentImage title and updation
                   //$notupdate[]=$atchid;
              }

    $i++;
  }//end for attachment id
 }// end for post id    


//echo 'notRenameproper<pre>';
//print_r($notRenameproper);
//echo '------<br>notupdate attachment<br>';
//echo '<pre>';
print_r($notupdate);

die('-------------done');




  /*End Update Images*/
  global $wpdb;
  /*$places = get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));
    //create excel file
    $file = fopen('/home/azullbiz/public_html/cisin/wp-content/azull-location-list.xls', 'w+');
    fputcsv($file, array('', 'Place/Location', 'Region', 'Country'));
            $sno=1;
  foreach ($places as $key => $val) {
    $place_meta = get_option('azull_taxonomy_meta_' . $val->term_id);
    if(isset($place_meta['country']) && $place_meta['country']!=0){
      $country_term = get_term_by('id', $place_meta['country'], 'country');
    }
    if(isset($place_meta['region']) && $place_meta['region']!=0){
      $region_term = get_term_by('id', $place_meta['region'], 'region');
    }
   $row = array($sno,$val->name,$region_term->name,$country_term->name);
        fputcsv($file, $row);
        $sno++;
  }
  fclose($file);
  print('<pre>');print_r($places);die;*/
  /*$sql = "SELECT * FROM wp_posts where post_type='attachment' AND post_name like '4129%' AND post_parent = 0 ORDER BY id ASC";
  $attachment_data = $wpdb->get_results($sql, ARRAY_A);
  //print('<pre>');print_r($attachment_data);die;
  if(isset($attachment_data) && !empty($attachment_data)){
    $i = 1;
    foreach ($attachment_data as $key => $val) {
      $data = array(
        'path'=>$val['ID'],
        'type'=>111,
        'status'=>0
      );

      $records = $wpdb->get_results("SELECT * FROM wp_xml_record WHERE path = $val AND type = 111", ARRAY_A);
      //print_r($records);die;
      if(empty($records)){
        $uploads = wp_upload_dir();
        $attachment_path = get_post_meta($val['ID'], '_wp_attached_file');
        $file_path = $uploads['basedir'].'/'.$attachment_path[0];
        //unlink($file_path);
        //$wpdb->insert('wp_xml_record',$data); 
      }
    }
  }
  //print('<pre>');print_r($removed_tmp);
  print('<pre>');print_r($attachment_data);die;*/
  /**** code for check and remove property images using property ref no that are not in used on azull.biz server *****/
/*$sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC";
$property_data = $wpdb->get_results($sql, ARRAY_A);
//http://azull.biz/cisin/wp-content/uploads/2016/05/
//$property_data = array(26943);
if(isset($property_data) && !empty($property_data)){
  foreach ($property_data as $key => $val) {
    $post_id = $val['ID'];
    //$post_id = $val;
    //print('<pre>');print_r($post_id);die;
    $post_meta = get_post_meta($post_id);
    $nreal_id = $post_meta['_nreal_id'][0];
    //echo $val.' ==> '.$nreal_id.'<br>';
    //print('<pre>');print_r($post_meta['_nreal_id'][0]);die;
    $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
       $ids = array();
    $f_img = get_post_thumbnail_id($post_id);
    $ids[] = $f_img;
    //echo 'attacted ====>>>>';
    //print('<pre>');print_r($ids);
    if(isset($ids) && !empty($ids) && isset($nreal_id) && !empty($nreal_id) && $nreal_id!=0){
      $sql = "SELECT * FROM wp_posts where post_type='attachment' AND post_name like '$nreal_id%' AND post_parent = 0 ORDER BY id ASC";
      $attachment_data = $wpdb->get_results($sql);
      //print('<pre>');print_r($attachment_data);die;
      if(isset($attachment_data) && !empty($attachment_data)){
        $i = 1;
        foreach ($attachment_data as $key => $val) {
          if(!in_array($val->ID, $ids) && $val->post_type=='attachment'){
            echo $post_id.' un-used =====>>>>> '.$i.' ==> '.$val->ID.'<br>';
            //if($i<=20){
              $data = array(
                'path'=>$val->ID,
                'type'=>111,
                'status'=>0
              );
              $records = $wpdb->get_results("SELECT * FROM wp_xml_record WHERE path = $val->ID AND type = 111", ARRAY_A);
              //print_r($records);die;
              //if(empty($records)){
                $uploads = wp_upload_dir();
                //print('<pre>');print_r($uploads);die;
                $attachment_path = get_post_meta($val->ID, '_wp_attached_file');
                $file_path = $attachment_path[0];//baseurl
                //print_r($file_path);
                $f_path = str_replace('.jpg','-300x225.jpg',$file_path);
                //$f_base_path = str_replace('/home/azullbiz/public_html/', 'http://azull.biz/', $file_path);
                //print_r($f_base_path);die('s');
                //if(file_exists($f_base_path)){
                  //print_r($f_base_path);die('s');
                  //unlink($file_path);
                  //unlink($f_path);
                //}else{
                  $file_l_path = str_replace('.jpg','-300x225.jpg',$uploads['basedir'].'/'.$attachment_path[0]);
                  $f_l_path = $uploads['basedir'].'/'.$attachment_path[0];
                  //if(file_exists($file_path)){
                    //print_r($file_path);die('l');
                    //unlink($file_l_path);
                    //unlink($f_l_path);
                  //}
                //}
                
                //$wpdb->insert('wp_xml_record',$data); 
                
              //}
            //}
            $i++;
          }
          
        }
        //die('1');
      }
    }
  }//end post_arr foreach
}//end post_arr if
die('hio');*/

/********/
   /**************/
   //for remove given words from property Dutch title
  /*global $wpdb;
  $sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC"; 
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  $p_data = array_column($property_data, 'post_title');
  $tmp='';//192
  print('<pre>');print_r($p_data);
  //spectaculair, spectaculaire, geweldig, geweldige, adembenemend, adembenemende, magnifiek, magnifieke, ongelooflijk, ongelooflijke, verbazingwekkend, verbazingwekkende, fantastisch, fantastische.
  $findArr = array('Spectaculaire','spectaculaire','Spectaculair','spectaculair','Geweldige','geweldige', 'Geweldig', 'geweldig', 'Adembenemende', 'adembenemende', 'Adembenemend', 'adembenemend', 'Magnifieke', 'magnifieke', 'Magnifiek', 'magnifiek', 'Ongelooflijke', 'ongelooflijke', 'Ongelooflijk', 'ongelooflijk', 'Verbazingwekkende','verbazingwekkende', 'Verbazingwekkend', 'verbazingwekkend', 'Fantastische', 'fantastische', 'Fantastisch', 'fantastisch');
  /*$replaceArr = array('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');*/
  /*$replaceArr = array('Deepak_S', 'deepak_s', 'Deepak_Sr', 'deepak_s', 'Deepak_G', 'deepak_g', 'Deepak_G', 'deepak_g', 'Deepak_A', 'deepak_a', 'Deepak_A', 'deepak_a', 'Deepak_M', 'deepak_m', 'Deepak_M', 'deepak_m', 'Deepak_O', 'deepak_o', 'Deepak_O', 'deepak_o', 'Deepak_V', 'deepak_v', 'Deepak_V', 'deepak_v', 'Deepak_F', 'deepak_f', 'Deepak_F', 'Deepak_f');
  //foreach ($p_data as $key => $val) {
   foreach ($property_data as $key => $val) {
    $dutch_txt = qtranxf_use('nl', $val['post_title']);
    $tmp[] = $dutch_txt;
    $new_nl_str = ucfirst(ltrim(str_replace('  ',' ',str_replace($findArr,$replaceArr,$dutch_txt))));
    //print_r($new_nl_str);die;
    $relaced_txt[] = $new_nl_str;
    $title = $val['post_title'];
    $nl_str = explode("[:nl]",$title);
    $update_txt = str_replace($nl_str[1],$new_nl_str.'[:]',$title);
    //$updated_txt[] = $update_txt;
    $post_data = array(
        'ID'=>$val['ID'],
        'post_title' => $update_txt
      );
    $post_dataArr[] = $post_data;
    //if($dutch_txt != $new_nl_str){
      $updated_txt[] = $update_txt;
      //wp_update_post($post_data);
    //}
    
  }
  //print('<pre>');print_r($tmp);
  //print('<pre>');print_r($relaced_txt);
  print('<pre>');print_r($updated_txt);
  //print('<pre>');print_r($post_dataArr);
  
  die('ji');*/
/**************/
//for update meta detail of properties on azull.biz only
/*global $wpdb;
  $sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC limit 1700,500"; 
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  print('<pre>');print_r($property_data);die;
  if(isset($property_data) && !empty($property_data)){
   foreach ($property_data as $key => $val) {
      $post_data = get_post($val['ID'], ARRAY_A);
      $post_meta = get_post_meta($val['ID']);

       $ref_no = (isset($post_meta['_nreal_id'][0]) && !empty($post_meta['_nreal_id'][0]))?$post_meta['_nreal_id'][0]:'';
       if(isset($post_meta['_place'][0]) && !empty($post_meta['_place'][0])){
          $place_term = get_term($post_meta['_place'][0],'place');
          $place = (isset($place_term->name) && !empty($place_term->name))?ucwords($place_term->name):'';
      }
      if(isset($post_meta['_region'][0]) && !empty($post_meta['_region'][0])){
          $region_term = get_term($post_meta['_region'][0],'region');
          $region = (isset($region_term->name) && !empty($region_term->name))?ucwords($region_term->name):'';
      }
      if(isset($post_meta['_country'][0]) && !empty($post_meta['_country'][0])){
          $country_term = get_term($post_meta['_country'][0],'country');
          $country = (isset($country_term->name) && !empty($country_term->name))?ucwords($country_term->name):'';
      }
      if(isset($post_data['post_category'][0]) && !empty($post_data['post_category'][0])){
          $category_term = get_term($post_data['post_category'][0],'category');
          $category = (isset($category_term->name) && !empty($category_term->name))?ucwords($category_term->name):'';
      }
      $desc_arr = array(
         'en'=>'Azull leader in sales of apartments and villas in Spain.',
         'fr'=>'Leader Azull des ventes d appartements et de villas en Espagne.',
         'nl'=>'Azull marktleider in verkoop van appartementen en villa’s in Spanje.'
       );
       $te_koop_in_arr = array(
         'en'=>'for sale',
         'fr'=>'te koop dans',
         'nl'=>'te koop in'
       );
      $languages = qtranxf_getSortedLanguages();
      $smeta_obj = new Azull_Seo_Meta();
      $title_data = '';
      $keywords_data = '';
      $description_data = '';
      foreach ($languages as $lang) {
         $t_place[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$place));
         $t_region[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$region));
         $t_country[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$country));
         $t_category[$lang] = ucwords($smeta_obj->getTranslatedTerm($lang,$category));
         $t_title[$lang] = ucfirst(qtranxf_use($lang, $post_data['post_title']));

         $title_data .= "[:$lang]".$t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].', '.$t_country[$lang].' Ref.'.$ref_no;
         $keywords_data .= "[:$lang]".$t_category[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].' '.$t_region[$lang].' '.$t_country[$lang];
         $description_data .= "[:$lang]".$t_title[$lang].' '.$te_koop_in_arr[$lang].' '.$t_place[$lang].', '.$t_region[$lang].'. '.$desc_arr[$lang];
        }
        //print('<pre>');print_r($title_data.'[:]');die;
      
      if(isset($title_data) && !empty($title_data)){
         update_post_meta($val['ID'],'property_meta:title', $title_data.'[:]');
      }
      if(isset($keywords_data) && !empty($keywords_data)){
         update_post_meta($val['ID'],'property_meta:keywords', $keywords_data.'[:]');
      }
      if(isset($description_data) && !empty($description_data)){
         update_post_meta($val['ID'],'property_meta:description', $description_data.'[:]');
      }
   }
  }
  die('ohhhhh');*/
/***************/
echo '<style>
#dvLoading {
    background: url(images/ajax-loader.gif) no-repeat scroll center center #000;
    color: white;
    height: 140px;
    left: 43%;
    margin: -25px 0 0 -25px;
    opacity: 1;
    position: fixed;
    top: 50%;
    width: 250px;
    z-index: 1000;
}
</style>';
 $default_lang = "nl";
            $languages = qtranxf_getSortedLanguages();
            echo '<div class="wrap">
<span id="msg_box"></span><div class="postbox" style="margin: 15px 0 10px;padding: 10px;"><h3 class="hndle ui-sortable-handle" style="margin-top:5px;"><span>Weather Info</span></h3><div style="margin: 5px;text-align: right;" class="epc_language-switcher inside">';
            echo "&nbsp;|&nbsp;";
            foreach ($languages as $lang) {
                echo "<a href=\"javascript:weatherinfo_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
            }
            echo '</div><form method="post" id="weather-info">';
            echo location_fields($languages);
            ?>
            <script type="text/javascript">//<![CDATA[
                var default_lang = '<?php echo $default_lang; ?>';
                weatherinfo_switch_lang(default_lang);
                function weatherinfo_switch_lang(lang) {
                    //Hide all
            <?php foreach ($languages as $lang): echo "jQuery('#weatherinfo_language_{$lang}').hide();";
            endforeach;
            ?>
                    jQuery('#weatherinfo_language_' + lang).show();
                    jQuery(".epc_language-switcher a").css("font-weight", "normal");
                    jQuery('#active_lang_' + lang).css("font-weight", "bold");
                }
                //]]>
            </script>
            <?php
$html = '<button type="button" onclick="save_weather_info(this.value)" class="button button-primary" value="1">Save</button></form></div></div></div>';?>
<script>
jQuery(document).ready(function() {
   jQuery("#property_meta_place").click(function(){
      jQuery("#dvLoading").show();
      jQuery("#wpwrap").css({"opacity":0.3});
      jQuery.ajax({
         type: "POST",
         url: ajaxurl,
         data: {action: 'get_place_weather_info',place_id:this.value},
      }).done(function(response) {
         response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
         if(response.vpn){
            jQuery.each(response.vpn, function( key, value ) {
               jQuery('#visible_place_name_'+key).val(value)
            });
         }else{
            jQuery('.visible_place_name').val('')
         }
         if(response.clients){
            jQuery('select[name="client[]"] option').each(function(key,val){
               if(jQuery.inArray( val.value, response.clients) != -1){
                  jQuery('select[name="client[]"]')[0].sumo.selectItem(key);
               }else{
                  jQuery('select[name="client[]"]')[0].sumo.unSelectItem(key);
               }
            });
         }else{
            jQuery('select[name="client[]"] option').each(function(key,val){
                  jQuery('select[name="client[]"]')[0].sumo.unSelectItem(key);
            });
         }
         //jQuery('#msg_box').html(response.html);
         jQuery("#dvLoading").hide();
         jQuery("#wpwrap").css({"opacity":1});
      });
   });
  
});

function save_weather_info(val){
   jQuery("#dvLoading").show();
   jQuery("#wpwrap").css({"opacity":0.3});
   var vpn = {};
   var place = jQuery("#property_meta_place").val();
   jQuery('input[name^="visible_place_name"]').each(function(i, v) {
      var lang = jQuery(this).data('lang');
      vpn[lang] = jQuery('#visible_place_name_'+lang).val();
      //vpn.push(jQuery(this).val());
   });

   jQuery.ajax({
      type: "POST",
      url: ajaxurl,
      data: {action: 'save_weather_info',place_id:place,vpn_val:vpn,clients:jQuery('select[name="client[]"]').val()},
   }).done(function(response) {
     response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
     jQuery('#msg_box').html(response.html);
     jQuery("#dvLoading").hide();
     jQuery("#wpwrap").css({"opacity":1});
     //location.reload();
   });
}
</script>
<?php
    echo $html;
}

/* Date : 22-Nov-2016
 * Method : function for export properties
 */
add_action('admin_menu', 'export_properties_info');
function export_properties_info() {
    add_menu_page("Export Properties", "Export Properties", 1, "export-properties", "export_properties");
}
function export_properties() {
  echo '<style>
  #dvLoading {
      background: url(images/ajax-loader.gif) no-repeat scroll center center #000;
      color: white;
      height: 140px;
      left: 43%;
      margin: -25px 0 0 -25px;
      opacity: 1;
      position: fixed;
      top: 50%;
      width: 250px;
      z-index: 1000;
  }
  </style>';
  if (!session_id()) { session_start(); }
  $back_url = get_option('redirect_url');
  $properties = $_SESSION['properties'];
  $html = '<div class="wrap"><span id="msg_box"></span><div class="postbox" style="margin: 15px 0 10px;padding: 10px;"><h3 class="hndle ui-sortable-handle" style="margin-top:5px;margin-bottom:8px;"><span>Selected Properties</span></h3><div style="margin-left: 5px;margin-bottom:5px;float:left;"><a type="button" href="'.$back_url.'" class="button button-primary">'.__('Back', 'azull').'</a></div>';
  if(isset($properties) && !empty($properties) && count($properties)>0){
    $html .= '<div id="export_btn_box" style="margin-left: 5px;margin-bottom:5px; float:right;"><a type="button" href="'.admin_url(). "edit.php?post_type=property&_wpnonce=754165365d&azullaction=export&action=azull-export".'" class="button button-primary" id="export_btn">'.__('Export', 'azull').'</a></div><form method="post">';
  }
  $html .= '<table class="wp-list-table widefat fixed striped posts">
    <thead>
      <tr>
        <td id="cb" class="manage-column column-cb check-column">
        </td>
        <th scope="col" id="property_ref" class="manage-column column-property_ref"><a href="javascript:void(0);"><span>#Ref</span><span class="sorting-indicator"></span></a>
        </th>
        <th scope="col" id="title" class="manage-column column-title column-primary"><a href="javascript:void(0);"><span>Title</span><span class="sorting-indicator"></span></a>
        </th>
        <th scope="col" id="property_cat" class="manage-column column-property_cat"><a href="javascript:void(0);"><span>Category</span><span class="sorting-indicator"></span></a>
        </th>
        <th scope="col" id="proprietor_ref" class="manage-column column-proprietor_ref"><a href="javascript:void(0);"><span>Proprietor</span><span class="sorting-indicator"></span></a>
        </th>
        <th scope="col" id="country" class="manage-column column-country"><a href="javascript:void(0);"><span>Country</span><span class="sorting-indicator"></span></a>
        </th>
        <th scope="col" id="region" class="manage-column column-region"><a href="javascript:void(0);"><span>Region</span><span class="sorting-indicator"></span></a>
        </th>
        <th scope="col" id="place" class="manage-column column-place"><a href="javascript:void(0);"><span>Place</span><span class="sorting-indicator"></span></a>
        </th>
      </tr>
    </thead>
    <tbody id="the-list">';
    if(isset($properties) && !empty($properties) && count($properties)>0){
      foreach ($properties as $key => $property_id) {
        $data = get_post($property_id, ARRAY_A);
        //print('<pre>');print_r($data);die;
        $id = (isset($data['ID']) && !empty($data['ID']))?$data['ID']:'';
        $title = (isset($data['post_title']) && !empty($data['post_title']))?qtranxf_use('nl', $data['post_title']):'';
        $category = $place = $region = $country = $proprietor = '';
        if(isset($data['post_category'][0]) && !empty($data['post_category'][0])){
          $category_term = get_term($data['post_category'][0],'category');
          $category = (isset($category_term->name) && !empty($category_term->name))?ucwords(qtranxf_use('nl', $category_term->name)):'';
        }
        $property_meta = get_post_meta($property_id);
        if(isset($property_meta) && !empty($property_meta)){
          $ref = (isset($property_meta['_nreal_id'][0]) && !empty($property_meta['_nreal_id'][0]))?$property_meta['_nreal_id'][0]:'';
          if(isset($property_meta['_place'][0]) && !empty($property_meta['_place'][0])){
            $place_term = get_term($property_meta['_place'][0],'place');
            $place = (isset($place_term->name) && !empty($place_term->name))?ucwords(qtranxf_use('nl', $place_term->name)):'';
          }
          if(isset($property_meta['_region'][0]) && !empty($property_meta['_region'][0])){
            $region_term = get_term($property_meta['_region'][0],'region');
            $region = (isset($region_term->name) && !empty($region_term->name))?ucwords(qtranxf_use('nl', $region_term->name)):'';
          }
          if(isset($property_meta['_country'][0]) && !empty($property_meta['_country'][0])){
            $country_term = get_term($property_meta['_country'][0],'country');
            $country = (isset($country_term->name) && !empty($country_term->name))?ucwords(qtranxf_use('nl', $country_term->name)):'';
          }
          if(isset($property_meta['_proprietor'][0]) && !empty($property_meta['_proprietor'][0])){
            $proprietor_term = get_term($property_meta['_proprietor'][0],'proprietor');
            $proprietor = (isset($proprietor_term->name) && !empty($proprietor_term->name))?ucwords(qtranxf_use('nl', $proprietor_term->name)):'';
          }
        }

        $html .= '<tr id="post-'.$id.'" class="iedit author-self level-0 post-'.$id.' type-property status-publish has-post-thumbnail hentry category-apartment proprietor-activa country-spain region-tenerife place-adeje">
          <th scope="row" class="check-column">
            <input id="cb-select-'.$id.'" type="checkbox" name="post[]" value="'.$id.'">
            <div class="locked-indicator"></div>
          </th>
          <td class="property_ref column-property_ref" data-colname="#Ref">'.$ref.'</td>
          <td class="title column-title has-row-actions column-primary page-title" data-colname="Title"><a href="javascript:void(0);"><strong>'.$title.'</strong></a>
          </td>
          <td class="property_cat column-property_cat" data-colname="Category">'.$category.'</td>
          <td class="proprietor_ref column-proprietor_ref" data-colname="Proprietor">'.$proprietor.'</td>
          <td class="country column-country" data-colname="Country">'.$country.'</td>
          <td class="region column-region" data-colname="Region">'.$region.'</td>
          <td class="place column-place" data-colname="Place">'.$place.'</td>
        </tr>';
      
      }
    }else{
      $html .= '<tr><td colspan="8" align="center"><strong>No record found!</strong></td></tr>';
    }
    
    $html .= '</tbody>
    <tfoot>
      <tr>
      <td id="cb" class="manage-column column-cb check-column">
      </td>
      <th scope="col" id="property_ref" class="manage-column column-property_ref"><a href="javascript:void(0);"><span>#Ref</span><span class="sorting-indicator"></span></a>
      </th>
      <th scope="col" id="title" class="manage-column column-title column-primary"><a href="javascript:void(0);"><span>Title</span><span class="sorting-indicator"></span></a>
      </th>
      <th scope="col" id="property_cat" class="manage-column column-property_cat"><a href="javascript:void(0);"><span>Category</span><span class="sorting-indicator"></span></a>
      </th>
      <th scope="col" id="proprietor_ref" class="manage-column column-proprietor_ref"><a href="javascript:void(0);"><span>Proprietor</span><span class="sorting-indicator"></span></a>
      </th>
      <th scope="col" id="country" class="manage-column column-country"><a href="javascript:void(0);"><span>Country</span><span class="sorting-indicator"></span></a>
      </th>
      <th scope="col" id="region" class="manage-column column-region"><a href="javascript:void(0);"><span>Region</span><span class="sorting-indicator"></span></a>
      </th>
      <th scope="col" id="place" class="manage-column column-place"><a href="javascript:void(0);"><span>Place</span><span class="sorting-indicator"></span></a>
      </th>
    </tr>
    </tfoot>
  </table>'; 
    echo $html;
}


function location_fields($languages) {
      global $post, $wpdb;
      $html = '';
      $countries = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
      $regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
      $provinces = get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));
      $places = get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));
      //$vpn = '';
     
      $html .= "<table class='property_meta_location'>";
      $html .= "<tr>";
      $html .="<th width='20%'><label for='property_meta_country'>" . __('Country', 'azull') . "</label></th>";
      $html .= "<td width='80%'>";
      if (!empty($countries) && !is_wp_error($countries)) {
         $html .="<select id='property_meta_country' name='country' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         if(empty($assigned_terms)) $assigned_terms = array('116');
         foreach ($countries as $countrie):
            $html .= "<option value='" . $countrie->term_id . "' " . (($countrie->term_id == 116) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
         endforeach;
         $html .="</select>";
      }else {
         $html .="<select id='property_meta_country' name='country' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .= "</td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .="<th><label for='property_meta_region'>" . __('Region', 'azull') . "</label> </th>";
      $html .= "<td>";
      if (!empty($regions) && !is_wp_error($regions)) {
        $assigned_terms = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
         $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
         $cntry= (isset($cntryId[0]))?$cntryId[0]:116 ;
         $html .="<select id='property_meta_region' name='region' class='weather_info_frm'>";
         $html .= "<option>--</option>";
       
         foreach ($regions as $region):
               $taxonomy_meta = get_option('azull_taxonomy_meta_' . $region->term_id);
            //$html .= "<option value='" . $region->term_id . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";

            if(isset($taxonomy_meta['country']) && isset($cntryId) && $taxonomy_meta['country']==$cntry){ 
                         $html .= "<option value='" . $region->term_id . "'  " . ((!empty($assigned_terms) && in_array($region->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
                    }

         endforeach;

         $html .="</select>";
      } else {
         $html .="<select id='property_meta_region' name='region' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }

      $html .= "</td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .="<th><label for='property_meta_province'>" . __('Province', 'azull') . "</label> </th>";
      $html .= "<td>";
      $html .="<select id='property_meta_province' name='province' class='weather_info_frm'>";
      $html .= "<option >--</option>";
      if (!empty($provinces)) {

         $assigned_terms = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
         $reginId = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
         $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
         $cntry= (isset($cntryId[0]))?$cntryId[0]:'' ;
         $region= (isset($reginId[0]))?$reginId[0]:'' ;
          foreach ($provinces as $province):
            $taxonomy_meta = get_option('azull_taxonomy_meta_' . $province->term_id);
         if(isset($taxonomy_meta['country']) && $taxonomy_meta['country']==$cntry){
       if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$region){ 
         $html .= "<option value='" . $province->term_id . "' " . ((!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
          }
    }
          
         endforeach;
         /*$html .="<select id='property_meta_province' name='province' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         
         foreach ($provinces as $province):
            $html .= "<option value='" . $province->term_id . "'>" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
         endforeach;*/


         $html .="</select>";
      } else {
         $html .="<select id='property_meta_province' name='province' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .= "</td>";
      $html .= "</tr>";

      $html .= "<tr>";
      $html .="<th><label for='property_meta_place'>" . __('Place', 'azull') . "</label> </th>";
      $html .= "<td>";
      if (!empty($places) && !is_wp_error($places)) {
         $html .="<select id='property_meta_place' name='place' class='weather_info_frm'>";
          $html .= "<option >--</option>";
         
         $assigned_terms = wp_get_post_terms($post->ID, 'place', array("fields" => "ids"));
         
         $reginId = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
         $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
         $provience = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
         
         $cntry= (isset($cntryId[0]))?$cntryId[0]:'' ;
         $region= (isset($reginId[0]))?$reginId[0]:'' ;
         $provien = (isset($provience[0]))?$provience[0]:'' ;

 
         foreach ($places as $place):
            //$html .= "<option value='" . $place->term_id . "'>" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
        
$taxonomy_meta = get_option('azull_taxonomy_meta_' . $place->term_id);
           if(isset($taxonomy_meta['country']) && $taxonomy_meta['country']==$cntry){
  if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$region){      
    if(isset($taxonomy_meta['provinces'])  &&  $taxonomy_meta['provinces']==$provien){ 
              $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
            }else{   
              $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
            }
          }       
      }  
         endforeach;
         $html .="</select>";
      } else {
         $html .="<select id='property_meta_place' name='place' class='weather_info_frm'>";
         $html .= "<option value='' selected='selected'>--</option>";
         $html .="</select>";
      }
      $html .= "</td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .="<th><label for='visible_place_name'>" . __('Client visibility', 'azull') . "</label> </th>";
      $html .= "<td>";
      
      $val = array();
      $val = get_post_meta($post->ID, "_client", true);
      $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft'");
      $html .= '<select style="min-height: 26px; width: 460px" class="SlectBox" name="client[]" multiple>';
      $html .= '<option value="" disabled selected>' . __('Select site', 'azull') . '</option>';
      foreach ($datas as $data) {
         if (isset($data->post_title)) {
            $sitename = explode(']', $data->post_title);
            $sitename = explode('[', $sitename[1]);
            $sitename = $sitename[0];
         }
         $html .= "<option value='" . $data->ID . "' " . (( is_array($val) && in_array($data->ID, $val)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $data->post_title) . "</option>";
      }
      $html .= "</select><br>";
      $html .= "<span class='description'>" . __('Select one or more clients website.', 'azull') . "</span>";
      $html .= "</td>";
      $html .= "</tr>";
      $html .= "<tr>";
      $html .="<th><label for='visible_place_name'>" . __('Visible Place Name', 'azull') . "</label> </th>";
      $html .= "<td>";
      foreach($languages as $lang){
            $vpn_val = (isset($weatherinfo[$lang]['visible_place_name'])) ? $weatherinfo[$lang]['visible_place_name'] : '';
            $html .="<div id='weatherinfo_language_".$lang."'  ".(($lang != 'en') ? 'style="display:none"' : '')."><p><input type='text' name='visible_place_name[".$lang."]' id='visible_place_name_".$lang."' value='".$vpn_val."' placeholder='Visible Place Name' class='weather_info_frm visible_place_name' data-lang='".$lang."'/></p></div>";
        }
      $html .= "</td>";
      
      $html .= "</tr>";
      
      $html .= "</table>";
      return $html;
   }



add_action('category_edit_form_fields','category_edit_form_fields');
add_action('category_edit_form', 'category_edit_form');
add_action('category_add_form_fields','category_edit_form_fields');
add_action('category_add_form','category_edit_form');


/* 
 function to hide category drop-down
 Date:- 12-Aug-2016
*/
function category_edit_form() {
?>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#edittag').attr( "enctype", "multipart/form-data" ).attr( "encoding", "multipart/form-data" );
        });
</script>
<?php 
}

/* 
 function to get all clildren category
 Date:- 12-Aug-2016
*/
function sort_terms_hierarchicaly(Array &$cats, Array &$into, $parentId = 0)
{
    foreach ($cats as $i => $cat) {

       $taxonomy_meta = get_option('azull_taxonomy_meta_' .$cat->term_id);
       if (isset($taxonomy_meta['type']) && $taxonomy_meta['type'] == 'post') {
        if ($cat->parent == $parentId) {
            $into[$cat->term_id] = $cat;
            unset($cats[$i]);
        }
     }
    }
    foreach ($into as $topCat) {
        $topCat->children = array();
        sort_terms_hierarchicaly($cats, $topCat->children, $topCat->term_id);
    }
}
/* 
 function to display all  category
  Date:- 12-Aug-2016
*/

function category_edit_form_fields() {
 if($_GET['post_type']!='property'){  
   $get_id=$_GET['tag_ID'];
   $pat_id=get_term_by('id', $get_id, 'category');
   $tagID=$pat_id->parent;
   $select="selected='selected'";

  ?>

<div class="form-field term-parent-wrap">
    <tr class="form-field">
            <th valign="top" scope="row">
                <label for="catpic"><?php _e('Parent', ''); ?></label>
            </th>
            <td>
             <select name="parent" id="parent" class="SlectBox">
               <option value="-1">None</option>
  <?php

    //$categories = get_terms('my_taxonomy_name', array('hide_empty' => false));
$categories = get_terms('category', 'orderby=id&hide_empty=0');
$categoryHierarchy = array();
sort_terms_hierarchicaly($categories, $categoryHierarchy);
if($categoryHierarchy){
   foreach ($categoryHierarchy as $value) {

      ?>
      <option <?php if($get_id == $value->term_id || $tagID == $value->term_id){ echo $select; } ?> value="<?php echo $value->term_id;?>"> <?php echo str_replace("(Nederlands)"," ",qtranxf_use(qtranxf_getLanguage(), $value->name)) ?></option>
 <?php   

    if(!empty($value->children)){
      foreach ($value->children as $value1) { ?>
        <option  <?php if($tagID == $value1->term_id){ echo $select; } ?> value="<?php echo $value1->term_id?>"> &nbsp;-<?php echo str_replace("(Nederlands)"," ",qtranxf_use(qtranxf_getLanguage(), $value1->name)) ?></option>

<?php 
       
     if(!empty($value1->children)){
       foreach ($value1->children as  $value2) {?>
          <option  <?php if($tagID == $value2->term_id){ echo $select; } ?> value="<?php echo $value2->term_id?>"> &nbsp;&nbsp;-&nbsp;-<?php echo str_replace("(Nederlands)"," ",qtranxf_use(qtranxf_getLanguage(), $value2->name)) ?></option>
           
 <?php

        if(!empty($value2->children)){

          foreach ($value2->children as $value3) { ?>
          <option  <?php if($tagID == $value3->term_id){ echo $select; } ?> value="<?php echo $value3->term_id?>"> &nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-<?php echo str_replace("(Nederlands)"," ",qtranxf_use(qtranxf_getLanguage(), $value3->name)) ?></option>
        

<?php 
         if(!empty($value3->children)){
           foreach ($value3->children as $value4) { ?>
            <option  <?php if($tagID == $value4->term_id){ echo $select; } ?> value="<?php echo $value4->term_id?>"> &nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-&nbsp;-<?php echo str_replace("(Nederlands)"," ",qtranxf_use(qtranxf_getLanguage(), $value4->name)) ?></option>
   <?php        

        if(!empty($value4->children)){
         foreach ($value4->children as  $value5) { ?>
           <option  <?php if($tagID == $value5->term_id){ echo $select; } ?> value="<?php echo $value5->term_id?>"> &nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;-&nbsp;-&nbsp;-&nbsp;-<?php echo str_replace("(Nederlands)"," ",qtranxf_use(qtranxf_getLanguage(), $value5->name)) ?></option>

         <?php } //end $value5

         }
            } // $value4
          }   
         } // $value3
        }
      }// end $value2
     }
   }// end $value1 
}

}// end $value
}
  ?>
               </select>
             </td>
       </tr> 
       <p>Categories, unlike tags, can have a hierarchy. You might have a Jazz category, and under that have children categories for Bebop and Big Band. Totally optional.</p>
       </div>       
<?php }// check post type
}  // end function 
//to remove wordpress version updation notification
  function wphidenag() {
    remove_action( 'admin_notices', 'update_nag', 3 );
  }



/*  Function to update where clause getting publish post 
    Date:- 13-09-2016
    Note: whenever will create new custom post then custom post type should be add there 
*/
add_action('pre_get_posts','wpse50761_alter_query');
function wpse50761_alter_query($query){
    if( $query->is_main_query() ){
          $array = array('property','azulloffice','testimonial','infodays','xml','azull_site','company','page','post','azulladds');
         if(!in_array($query->query['post_type'], $array) && $query->query['post_status'] !='trash'){
           $query->set( 'post_type', array( 'post', 'page','property') );
         }
         if(($query->query['post_type']!='azull_site') AND ($query->query['post_type']!='post') AND ($query->query['post_type']!='page') AND ($query->query['post_status'] !='pending') && ($query->query['post_status'] !='draft') && ($query->query['post_status'] !='trash') && $query->query['post_type']!='property'){
           add_filter( 'posts_where' , 'MyFilterFunction_1' ); 
         } 
    }  
}
function MyFilterFunction_1($where) {
    global $wpdb;
    $where .= " AND ({$wpdb->posts}.post_status = 'publish')"; 
    return $where;
}

add_action('init', 'checkTeamRole' );
function checkTeamRole(){
global $wp_taxonomies;
        $admin_role = $current_user->roles;
         $userRole='';
         $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }

/* this filter work for "admin" user*/
if($userRole == 'administrator'){
  add_filter( 'post_row_actions', 'rd_duplicate_post_link', 10, 2 );
}

/* this filter work for "price" user, Date: 02/12/2016, manoj(ab)*/
//$post_type = get_post_type($_GET['post']);
//echo $post_type;die;$post_type == "property" && 
if($userRole == 'price'){

   add_filter('tiny_mce_before_init', 'dynamic_editor_styles', 10);
  //add_filter( 'post_row_actions', 'rd_price_edit_post_link', 10, 2 );
}

if($userRole =='info' OR $userRole =='view_01' OR $userRole== 'editor'){
add_filter( 'comments_open', '__return_true' );
 ?> 
<style>
  #wpadminbar ul#wp-admin-bar-root-default>li{
    display: none;
}

</style>
<?php }
  
}
/*
* Date: 27-Sep-2016
* Method: function for add custom column(s) in post overview list
*/
function post_columns_head($defaults,$post_type) {
   if($post_type == 'post'){
      $defaults['websites'] = __('Websites', 'azull');
   }
   return $defaults;
}
/*
* Date: 27-Sep-2016
* Method: function for get and display custom column(s) value in post overview list
*/
function post_columns_content($column_name, $post_ID) {
   $post_type = get_post_type($post_ID);
   if ($column_name == 'websites' && $post_type!='property') {
      global$wpdb;
      $val = array();
      $val = get_post_meta($post_ID, "_client", true);
      $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft'");
      if(isset($datas) && !empty($datas)){
         foreach ($datas as $data) {
            if (is_array($val) && in_array($data->ID, $val))
               echo qtranxf_use(qtranxf_getLanguage(),$data->post_title). " ";
         }
      }
   }
}
add_filter('manage_posts_columns', 'post_columns_head', 10, 2);
add_action('manage_posts_custom_column', 'post_columns_content', 10, 2);
/*
* Date: 27-Sep-2016
* Method: function for add custom column(s) in page overview list
*/
function page_columns_head($defaults) {
    $defaults['websites'] = __('Websites', 'azull');
    return $defaults;
}
/*
* Date: 27-Sep-2016
* Method: function for get and display custom column(s) value in page overview list
*/
function page_columns_content($column_name, $post_ID) {
   if ($column_name == 'websites') {
      global$wpdb;
      $val = array();
      $val = get_post_meta($post_ID, "_client", true);
      $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft'");
      if(isset($datas) && !empty($datas)){
         foreach ($datas as $data) {
            if (is_array($val) && in_array($data->ID, $val))
               echo qtranxf_use(qtranxf_getLanguage(),$data->post_title). " ";
         }
      }
   }
}
add_filter('manage_pages_columns', 'page_columns_head');
add_action('manage_pages_custom_column', 'page_columns_content', 10, 2);

function get_custom_category_parents( $id, $link = false, $separator = '/', $nicename = false, $visited = array() ) {
  $chain = '';
  $parent = get_term( $id, 'category' );
  if ( is_wp_error( $parent ) )
    return $parent;

  if ( $nicename )
    $name = $parent->slug;
  else
    $name = $parent->name;

  if ( $parent->parent && ( $parent->parent != $parent->term_id ) && !in_array( $parent->parent, $visited ) ) {
    $visited[] = $parent->parent;
    $chain .= get_custom_category_parents( $parent->parent, $link, $separator, $nicename, $visited );
  }
  if ( $link ){
    if(isset($chain) && !empty($chain)){
    $chain .= $name.$separator;
    //$chain .= '<a href="' . esc_url( get_category_link( $parent->term_id ) ) . '">'.$name.'</a>' . $separator;
    }else{
      if(isset($visited) && !empty($visited)){
        $separator = '<br>'.$separator;
      }
      $chain .= $name.$separator;
      // / $chain .= '<a href="' . esc_url( get_category_link( $parent->term_id ) ) . '">'.$name.'</a>' . $separator;
    }
  }else{
    $chain .= $name.$separator;
  }
  return $chain;
}



add_action('phpmailer_init', 'wp_intercept_account_email');
function wp_intercept_account_email($phpmailer){
//print('<pre>');print_r($phpmailer);die('yes');
global $user_id, $wpdb;
    $obj = new Azull_Subscriber(); 
    $language = json_decode(get_option("language"));
    $cur_lang = (isset($language->d) && !empty($language->d))?strtolower($language->d):'nl';
    $sigval='emailsignature_'.$cur_lang;
    $emailsignature = stripslashes(htmlspecialchars_decode(get_option($sigval)));
    $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES); 

    /* Mail subject*/
    $userRegitersub  = '[Azull.biz] Your username and password info';
    $userRegitersub1 = 'Azull.biz: '.$obj->getTranslatedString('en','nl','Your username and password info');

    $adminRegitersub  = '[Azull.biz] New User Registration';
    $adminRegitersub1 = 'Azull.biz: '.$obj->getTranslatedString('en','nl','New User Registration');

    $adminPasswordChange  = '[Azull.biz] Password Lost/Changed';
    $adminPasswordChange1 = 'Azull.biz: '.$obj->getTranslatedString('en','nl','Password Lost/Changed');

    $userpasswordChange   = '[Azull.biz] Notice of Password Change';
    $userpasswordChange1 = 'Azull.biz: '.$obj->getTranslatedString('en','nl','Notice of Password Change');
    
    $useremailChange   = '[Azull.biz] Notice of Email Change';
    $useremailChange1 = 'Azull.biz: '.$obj->getTranslatedString('en','nl','Notice of Email Change');

    $forgotpassChange   = '[Azull.biz] Password Reset';
    $forgotpassChange1 = 'Azull.biz: '.$obj->getTranslatedString('en','nl','Password Reset');
   
    /*$userID = $wpdb->get_results('SELECT ID FROM  wp_users order by ID desc limit 1', ARRAY_A);

    $lastid=$userID[0]['ID'];
    $lastid=$user_id*/
    $user = get_userdata($user_id);
    $userName=(isset($user->display_name) && $user->display_name!='')?$user->display_name:$user->user_login;


 $sabjectPrev=qtranxf_use(qtranxf_getLanguage(), $phpmailer->Subject);   
if($sabjectPrev == $userRegitersub){ 
  
    // Generate something random for a password reset key.
    $key = wp_generate_password( 20, false );
    /** This action is documented in wp-login.php */
    do_action( 'retrieve_password_key', $user->user_login, $key );
    // Now insert the key, hashed, into the DB.
    if ( empty( $wp_hasher ) ) {
      require_once ABSPATH . WPINC . '/class-phpass.php';
      $wp_hasher = new PasswordHash( 8, true );
    }
    $hashed = time() . ':' . $wp_hasher->HashPassword( $key );
    $wpdb->update( $wpdb->users, array( 'user_activation_key' => $hashed ), array( 'user_login' => $user->user_login ) ); 
    $url=network_site_url()."/wp-login.php?action=rp&key=".$key."&login=".rawurlencode($user->user_login);
    $rdurl='<a href="'.$url.'">'.$url.'</a>';
    $message .= $obj->getTranslatedString('en','nl','Hello').' '.$userName.', <br/><br/>';
    $message .= $obj->getTranslatedString('en','nl','Username').': <br/>'.$user->user_login.'<br/><br/>';
    $message .= $obj->getTranslatedString('en','nl','To set your password, visit the following address');
    $message .= '<br/>'.$rdurl;
    $message .= $emailsignature;
    $html = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

    $html .='<html xmlns="http://www.w3.org/1999/xhtml">';
    $html .='<head>';
    $html .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
    $html .='<title>' . $subject . '</title>';
    $html .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
    $html .='</head>';
    $html .='<body style="margin: 0; padding: 0;font-size:12px;">';
    $html .= $message;
    $html .='</body>';
    $html .='</html>';
    add_filter('wp_mail_content_type', array('Azull_Utility', 'set_html_content_type'));

     
   // Change mail content by mail subject                   
       $sabjectPrev=qtranxf_use(qtranxf_getLanguage(), $phpmailer->Subject);
       //$phpmailer->FromName = $blogname;
       //$phpmailer->From = $site_email;
      $phpmailer->Subject = $userRegitersub1;
      $phpmailer->Body = $html;
      $phpmailer->IsHTML(true);
    }


    /* admin mail */   
$sabjectPrev2=qtranxf_use(qtranxf_getLanguage(), $phpmailer->Subject);
  if($sabjectPrev2 == $adminRegitersub){

      $message1  = $obj->getTranslatedString('en','nl','Hello administrator').', <br/><br/>';
      $message1 .= $obj->getTranslatedString('en','nl','New user registration on your site').' Azull.biz <br/><br/>';
      $message1 .= $obj->getTranslatedString('en','nl','Username').': <br/>'.$user->user_login.'<br/><br/>';
      $message1 .= $obj->getTranslatedString('en','nl','Email').': <br/>'.$user->user_email.'<br/><br/>';
      $message1 .=$emailsignature;
      $html1 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

    $html1 .='<html xmlns="http://www.w3.org/1999/xhtml">';
    $html1 .='<head>';
    $html1 .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
    $html1 .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
    $html1 .='</head>';
    $html1 .='<body style="margin: 0; padding: 0;font-size:12px;">';
    $html1 .= $message1;
    $html1 .='</body>';
    $html1 .='</html>';
    add_filter('wp_mail_content_type', array('Azull_Utility', 'set_html_content_type'));

      $phpmailer->Subject = $adminRegitersub1;
      $phpmailer->Body = $html1;
      $phpmailer->IsHTML(true);
  }

/* admin mail password change by user */ 

$sabjectPrev3=qtranxf_use(qtranxf_getLanguage(), $phpmailer->Subject);
if($sabjectPrev3 == $adminPasswordChange){

      $message2  = $obj->getTranslatedString('en','nl','Hello administrator').', <br/><br/>';
      $message2 .= $obj->getTranslatedString('en','nl','Password changed for user').' :<br/>';
      $message2 .= $user->user_login.'<br/>';
      $message2 .= $emailsignature;
      $html1 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

    $html2 .='<html xmlns="http://www.w3.org/1999/xhtml">';
    $html2 .='<head>';
    $html2 .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
    $html2 .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
    $html2 .='</head>';
    $html2 .='<body style="margin: 0; padding: 0;font-size:12px;">';
    $html2 .= $message2;
    $html2 .='</body>';
    $html2 .='</html>';
    add_filter('wp_mail_content_type', array('Azull_Utility', 'set_html_content_type'));

      $phpmailer->Subject = $adminPasswordChange1;
      $phpmailer->Body = $html2;
      $phpmailer->IsHTML(true);
  }

  /*user password change*/
$sabjectPrev4=qtranxf_use(qtranxf_getLanguage(), $phpmailer->Subject); 
if($sabjectPrev4 == $userpasswordChange){

      $message  = $obj->getTranslatedString('en','nl','Hi')." ".$userName.', <br/><br/>';
      $message .= $obj->getTranslatedString('en','nl','This notice confirms that your password was changed on').' Azull.biz <br/><br/>';

      $message .= $obj->getTranslatedString('en','nl','If you did not change your password, please contact the Site Administrator at').'<br/>';
      $message .= get_option('admin_email').'<br/><br/>';
      $message .= $obj->getTranslatedString('en','nl','This email has been sent to').' '.$user->user_email;
     
      $message .= $emailsignature;
      $html1 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

    $html .='<html xmlns="http://www.w3.org/1999/xhtml">';
    $html .='<head>';
    $html .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
    $html .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
    $html .='</head>';
    $html .='<body style="margin: 0; padding: 0;font-size:12px;">';
    $html .= $message;
    $html .='</body>';
    $html .='</html>';
    add_filter('wp_mail_content_type', array('Azull_Utility', 'set_html_content_type'));
      $phpmailer->Subject = $userpasswordChange1;
      $phpmailer->Body = $html;
      $phpmailer->IsHTML(true);
  }

$sabjectPrev6=qtranxf_use(qtranxf_getLanguage(), $phpmailer->Subject); 
if($sabjectPrev6 == $useremailChange){

      $message  = $obj->getTranslatedString('en','nl','Hi')." ".$userName.', <br/><br/>';
      $message .= $obj->getTranslatedString('en','nl','This notice confirms that your email was changed on').' Azull.biz <br/><br/>';

      $message .= $obj->getTranslatedString('en','nl','If you did not change your email, please contact the Site Administrator at').'<br/>';
      $message .= get_option('admin_email').'<br/><br/>';
      $message .= $obj->getTranslatedString('en','nl','This email has been sent to').' '.get_option('admin_email');
     
      $message .= $emailsignature;
      $html1 = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

    $html .='<html xmlns="http://www.w3.org/1999/xhtml">';
    $html .='<head>';
    $html .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
    $html .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
    $html .='</head>';
    $html .='<body style="margin: 0; padding: 0;font-size:12px;">';
    $html .= $message;
    $html .='</body>';
    $html .='</html>';
    add_filter('wp_mail_content_type', array('Azull_Utility', 'set_html_content_type'));
      $phpmailer->Subject = $useremailChange1;
      $phpmailer->Body = $html;
      $phpmailer->IsHTML(true);
  }

  $sabjectPrev5=qtranxf_use(qtranxf_getLanguage(), $phpmailer->Subject); 
  if($sabjectPrev5 == $forgotpassChange){
      $phpmailer->Subject = $forgotpassChange1;
      $phpmailer->IsHTML(true);
  }
  /*if($phpmailer->Subject=='Blog posts added/updated on azull.biz'){
    $phpmailer->IsHTML(true);
  }*/
  if($phpmailer->Subject=='Blog post unpublished on azull.biz'){
    $phpmailer->IsHTML(true);
  }
}

/*add_action( 'save_post', 'email_post_author', 10, 3);
function email_post_author( $post_id, $post, $update ) {
  if(isset($post_id) && !empty($post_id) && isset($post) && !empty($post)){
    if($post->post_status!='auto-draft' && $post->post_type=='post'){
      $email = 'manoj.p@cisinlabs.com';
      $subject = 'Blog posts added/updated on azull.biz';
      $message = 'A post was added/updated/published/unpublished below is the post detail<br>';
      $message .= 'Post Id => '.$post->ID.'<br>';
      $message .= 'Post Date => '.$post->post_date.'<br>';
      $message .= 'Post Title => '.$post->post_title.'<br>';
      $message .= 'Post Content => '.$post->post_content.'<br>';
      $message .= 'Post Name => '.$post->post_name.'<br>';
      $ip = $_SERVER['REMOTE_ADDR'];
      $user = wp_get_current_user();
      $message .= 'User Ip => '.$ip.'<br>';
      $message .= 'User ID => '.$user->ID.'<br>';
      $message .= 'User Email => '.$user->user_email.'<br>';
      $message .= 'User Role => '.$user->roles[0].'<br>';
      if(isset($user) && !empty($user)){
        $user_meta = get_user_meta($user->ID);
        $f_name = (isset($user_meta['first_name'][0]))?$user_meta['first_name'][0]:'';
        $l_name = (isset($user_meta['last_name'][0]))?$user_meta['last_name'][0]:'';
        $message .= 'User First Name => '.$f_name.'<br>';
        $message .= 'User Last Name => '.$l_name.'<br>';
      }
      $html = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
      $html .='<html xmlns="http://www.w3.org/1999/xhtml">';
      $html .='<head>';
      $html .='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
      $html .='<title>' . $subject . '</title>';
      $html .='<meta name="viewport" content="width=device-width, initial-scale=1.0"/>';
      $html .='</head>';
      $html .='<body style="margin: 0; padding: 0;font-size:12px;">';
      $html .= $message;
      $html .='</body>';
      $html .='</html>';
      wp_mail($email, $subject, $html);
    }
  }
}*/
/*
* Date: 07-Nov-2016
* Method: function for add new custom status like Rejected
*/
function custom_post_status(){
  register_post_status( 'rejected', array(
    'label'                     => _x( 'Rejected', 'post' ),
    'public'                    => true,
    'exclude_from_search'       => false,
    'show_in_admin_all_list'    => true,
    'show_in_admin_status_list' => true,
    'label_count'               => _n_noop( 'Rejected <span class="count">(%s)</span>', 'Rejected <span class="count">(%s)</span>' ),
  ) );
}
add_action('init','custom_post_status');


/*
 * Add duplicate record
 * Date:- 16/nov/2016
 * Function creates post duplicate as a draft and redirects then to the edit post screen
 */

function rd_duplicate_post_as_draft(){
  global $wpdb;
  if (! ( isset( $_GET['post']) || isset( $_POST['post'])  || ( isset($_REQUEST['action']) && 'rd_duplicate_post_as_draft' == $_REQUEST['action'] ) ) ) {
    wp_die('No post to duplicate has been supplied!');
  }
    /*
   * get the original post id
   */
  $post_id = (isset($_GET['post']) ? absint( $_GET['post'] ) : absint( $_POST['post'] ) );
  /*
   * and all the original post data then
   */
  $post = get_post( $post_id );
 
  /*
   * if you don't want current user to be the new post author,
   * then change next couple of lines to this: $new_post_author = $post->post_author;
   */
  $current_user = wp_get_current_user();
  $new_post_author = $current_user->ID;
 
  /*
   * if post data exists, create the post duplicate
   */
  if (isset( $post ) && $post != null) {
 
    /*
     * new post data array
     */
    $args = array(
      'comment_status' => $post->comment_status,
      'ping_status'    => $post->ping_status,
      'post_author'    => $new_post_author,
      'post_content'   => $post->post_content,
      'post_excerpt'   => $post->post_excerpt,
      'post_name'      => $post->post_name,
      'post_parent'    => $post->post_parent,
      'post_password'  => $post->post_password,
      'post_status'    => 'draft',
      'post_title'     => $post->post_title,
      'post_type'      => $post->post_type,
      'to_ping'        => $post->to_ping,
      'menu_order'     => $post->menu_order
    );
 
    /*
     * insert the post by wp_insert_post() function
     */
    $new_post_id = wp_insert_post( $args );
 
    /*
     * get all current post terms ad set them to the new post draft
     */
    $taxonomies = get_object_taxonomies($post->post_type); // returns array of taxonomy names for post type, ex array("category", "post_tag");
    foreach ($taxonomies as $taxonomy) {
      $post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
      wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
    }
 
    /*
     * duplicate all post meta just in two SQL queries
     */
    $post_meta_infos = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->postmeta WHERE post_id=$post_id");
    if (count($post_meta_infos)!=0) {
      $sql_query = "INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) ";
      foreach ($post_meta_infos as $meta_info) {
        $meta_key = $meta_info->meta_key;
        $meta_value = addslashes($meta_info->meta_value);
        
        if($meta_info->meta_key!= '_xmlref'){
           $sql_query_sel[]= "SELECT $new_post_id, '$meta_key', '$meta_value'"; 
        }
        //$sql_query_sel[]= "SELECT $new_post_id, '$meta_key', '$meta_value'";
      }
      $sql_query.= implode(" UNION ALL ", $sql_query_sel);
      $wpdb->query($sql_query);
    }
 
    /*
     * finally, redirect to the edit post screen for the new draft
     */
    wp_redirect( admin_url( 'post.php?action=edit&post=' . $new_post_id ) );
    exit;
  } else {
    wp_die('Post creation failed, could not find original post: ' . $post_id);
  }
}

add_action( 'admin_action_rd_duplicate_post_as_draft', 'rd_duplicate_post_as_draft' );
 

function rd_price_edit_post_link($actions, $post){
global $wp_taxonomies;
        $admin_role = $current_user->roles;
         $userRole='';
         $user_object = get_userdata( get_current_user_id() );
         if(isset($user_object) && $user_object!=''){
           foreach($user_object->roles as $role){
             $userRole=$role;
            } 
         }

?>
<script type="text/javascript">

/* Function to get property price detail.
   Date: 02/12/20016, manoj(ab).
*/
function getPropertyPriceDetail(postId){
    jQuery.ajax({
      type: "POST",
      url: ajaxurl,
      data: {
          action: 'property_price',p_id:postId},
   }).done(function(response) {
      jQuery(".popup").html(response);
   });

}
</script>
<div id="price" class="overlay">
  <div class="popup">
    
  </div>
</div>
<?php
   if ($post->post_type =="property" && $userRole=='price'){
    if (current_user_can('edit_posts')) {
      $actions['duplicate'] = '<span><a id="myanchor" href="#price" onClick="return getPropertyPriceDetail('.$post->ID.')">Edit</a></span>';
    }
  }
  return $actions;
}

/*
 * Add the duplicate link to action list for post_row_actions
 */
function rd_duplicate_post_link( $actions, $post ) {
  
  if ($post->post_type =="infodays" || $post->post_type =="property" ){
  //if ($post->post_type =="infodays"){
    if (current_user_can('edit_posts')) {
      $actions['duplicate'] = '<a href="admin.php?action=rd_duplicate_post_as_draft&amp;post=' . $post->ID . '" title="Duplicate this item" rel="permalink">Copy</a>';
    }
  }
  return $actions;
}
//add_filter( 'post_row_actions', 'rd_duplicate_post_link', 10, 2 );
//add_filter( "views_edit-post" , 'wpse_30331_custom_view_count', 10, 1);
add_action('trash_post','remove_client_post',1,2);
add_action('trash_infodays','remove_client_post',1,2);
add_action('trash_property','remove_client_post',1,2);
add_action('trash_azulloffice','remove_client_post',1,2);
add_action('trash_testimonial','remove_client_post',1,2);
add_action('trash_azulladds','remove_client_post',1,2);
add_action('trash_page','remove_client_post',1,2);

function remove_client_post($post_id,$post){
  //if(!did_action('trash_post')){
    if(isset($post_id) && !empty($post_id) && isset($post->post_type) && !empty($post->post_type)){
      $clients = get_post_meta($post_id, "_client", true);
      if(isset($clients) && !empty($clients) && count($clients)>0){
      foreach ($clients as $key => $client) {
          $obj = new Xmlrpc_Client($client);
          if(!$obj->test_connection())
              continue;
              $obj->delete_post_single($post_id);
        }
      }
      /*switch ($post->post_type) {
        case 'infodays':
          
        break;        
      }*/
    }
  //}
}

/* add code for display map 
   Date:- 23/nov/2016
*/
add_shortcode('azullmap','azullmap');
function azullmap() {
        $markers = array();
        $infocontent = array();
        $html = false;
        $args = array(
            'post_type' => 'post',
            'showposts' => -1,
            'meta_query' => array(
                array(
                    'key' => '_featured',
                 //   'value' => array('10'),
                    'compare' => 'IN'
                )
            )
        );
        $offices = get_posts($args);
        global $post;
            $latitude = get_post_meta($post->ID,"_lat",true);
            $longitude = get_post_meta($post->ID,"_lng",true);
            $html .= '<style>iframe{width:100% !important; height:400px !important;}</style><iframe frameborder="0" src="https://www.google.com/maps/embed/v1/place?q='.$latitude.','.$longitude.'&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU&zoom=14"></iframe>';
          
        return $html;
    }


/*function to add validation on edit project taxonomy_meta form
  date: 08/12/2016,Manoj(ab)
*/
add_action( 'edited_project', 'save_extra_fields_project_callback', 10, 2);

function save_extra_fields_project_callback(){
  $allPost=$_POST;
  if((isset($allPost)) && (isset($allPost['taxonomy_meta']['proprietor']) && $allPost['taxonomy_meta']['proprietor']=='')){
    $tagId=$_GET['tag_ID'];
    $variable_to_send = '1';
    $url = get_admin_url() . 'edit-tags.php?action=edit&taxonomy=project&tag_ID='.$allPost['tag_ID'].'&post_type=property';   
    wp_redirect( $url.'&propN='.$variable_to_send );
    exit();
  }
}

add_action( 'admin_head-edit.php', 'admin_head_post_listing');
/*
* Date: 12-Dec-2016
* Method: Function for update post's clients
*/
function admin_head_post_listing() {
  global $post_type;
  if(isset($post_type) && !empty($post_type) && $post_type == 'post'){
    global $wpdb;
    $querystr = "SELECT p.ID FROM $wpdb->posts p JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID) WHERE p.post_type = 'post' AND pm1.meta_key LIKE '_ext_%' GROUP BY p.ID";
      $records = $wpdb->get_results($querystr, ARRAY_A);
      $azull_clients = $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft'", ARRAY_A);
      //print('<pre>');print_r($records);die('ye1s');
      if(isset($records) && !empty($records) && count($records)>0 && is_array($records) && isset($azull_clients) && !empty($azull_clients) && count($azull_clients)>0 && is_array($azull_clients)){
        $i = 0;
        foreach ($records as $key => $val) {
          $tmp = [];
          $p_clients = get_post_meta($val['ID'], '_client', true);
          $p_clients = (isset($p_clients) && !empty($p_clients))?$p_clients:array();
          foreach ($azull_clients as $ac_key => $ac_val) {
            $remote_post_id = get_post_meta($val['ID'], '_ext_'.$ac_val['ID'], true);
            if(isset($remote_post_id) && $remote_post_id!=0){
              if(!in_array($ac_val['ID'], $p_clients)){
                $tmp[] = $ac_val['ID'];
              }
            }
          }
          if(isset($tmp) && !empty($tmp) && count($tmp)>0){
            update_post_meta($val['ID'],'_client', $tmp);
          }
        }
      }
  }
}


/* function use for change editor backround color for price user*/
function dynamic_editor_styles($settings){
}
/* 
 * Date : 19-Dec-2016
 * Method : Function for manage location translation
 */
add_action('admin_menu', 'location_translation');

function location_translation() {
    //add_menu_page("Location Translation", "Location Translation", 1, "location-translation", "locationtranslation");
    add_submenu_page( 'edit.php?post_type=xml', "Location Translation", "Location Translation", 1, "location-translation", "locationtranslation");
}

function locationtranslation() {
  $orderby ="";
  $order = (isset($_GET['order']) && $_GET['order'] =='asc') ? 'desc' : 'asc';
  if(isset($_GET['orderby'])){
    $orderby = "order by ".$_GET['orderby']." ".$_GET['order'] ;
  }else{
    $orderby = "order by name asc";
    $order = 'desc';
  }
  $where_c = "";
  if(isset($_GET['searchkey']) && $_GET['searchkey'] !=''){
     $where_c = "where wtt.name like '%".$_GET['searchkey']."%'";
  } 
  $big = 999999999; // need an unlikely integer
  $paged = ( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
  $str = 0; 
  $end = 10;
  if($paged>1){
      $str = ($end*$paged)-$end;
  }
  global $wpdb;
  $sql1 = "SELECT wtt.id,wtt.term_id,wtt.name,wtt.translation_name FROM wp_term_translations as wtt left join wp_terms as wt on wt.term_id = wtt.term_id left join wp_term_taxonomy as wtr on wtr.term_id = wt.term_id $where_c $orderby limit $str,$end "; 
  $sql2 = "SELECT * FROM wp_term_translations as wtt left join wp_terms as wt on wt.term_id = wtt.term_id left join wp_term_taxonomy as wtr on wtr.term_id = wt.term_id"; 
  $filtered_location_trans = $wpdb->get_results($sql1,ARRAY_A);
  $all_location_trans = $wpdb->get_results($sql2);
  $smeta_obj = new Azull_Seo_Meta();
  $obj_subsciber = new Azull_Subscriber();
  $languages = qtranxf_getSortedLanguages();
  ?>
  <div class="wrap">
    <h2><?php echo $obj_subsciber->getTranslatedString('en','nl','Location Translation List'); ?></h2>
    <ul class="qtranxs-lang-switch-wrap"><li lang="en" class="qtranxs-lang-switch" id="qtranxs_lang_en" onclick="loctranslist_switch_lang('en');"><img src="<?php echo plugins_url(); ?>/qtranslate-x/flags/gb.png"><span>English</span></li><li lang="fr" class="qtranxs-lang-switch" id="qtranxs_lang_fr" onclick="loctranslist_switch_lang('fr');"><img src="<?php echo plugins_url(); ?>/qtranslate-x/flags/fr.png"><span>Français</span></li><li lang="nl" class="qtranxs-lang-switch" id="qtranxs_lang_nl" onclick="loctranslist_switch_lang('nl');"><img src="<?php echo plugins_url(); ?>/qtranslate-x/flags/nl.png"><span>Nederlands</span></li></ul>
    <form id="posts-filter" method="get" action="<?php echo get_admin_url(); ?>admin.php">
      <div class="tablenav top" style="margin:-18px 0 4px;">
        <p class="search-box">
          <input type="hidden" id="post-search-input" name="page" value="location-translation">
          <label class="screen-reader-text" for="post-search-input">Zoeken:</label>
          <input type="search" id="post-search-input" name="searchkey" value="<?php echo $_GET['searchkey']; ?>">
          <input type="submit" id="search-submit" class="button" value="Zoeken">
        </p>
      </div>
    </form>
  <?php
  echo '<style>table.wp-list-table tr:nth-child(even) {background-color: #f2f2f2}</style>';
  $html='<div class="nosubsub">
  <div id="ajax-response"></div>
  <div id="col-container">
  <div id="">
  <div class="">
  <table class="wp-list-table widefat fixed striped tags table" width="100%" >
    <thead>';
      foreach($languages as $lang){
        $html .='<tr class="loctranslist_lang_'.$lang.'" '.(($lang != 'nl') ? 'style="display:none"' : '').'>
          <th width="40%" class="manage-column column-name column-primary sortable '.$order.'"><a href="'.get_admin_url() . 'admin.php?page=location-translation&amp;orderby=name&amp;order='.$order.'">
    <span>'.$obj_subsciber->getTranslatedString('en',$lang,'Location Translation').'  </span><span class="sorting-indicator"></span></a></th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Place').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Region').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Country').'</th>
        </tr>';
      }
    $html .= '</thead><tbody id="the-list" data-wp-lists="list:tag">';
    if (!empty($filtered_location_trans)) {
      foreach ($filtered_location_trans as $key => $val) {
        $translation_name = unserialize($val['translation_name']);
        //print('<pre>');print_r($translation_name);die;
        $place_meta = get_option('azull_taxonomy_meta_' . $val['term_id']);
          if(isset($place_meta['country']) && $place_meta['country']!=0){
            $country_term = get_term_by('id', $place_meta['country'], 'country');
          }
          if(isset($place_meta['region']) && $place_meta['region']!=0){
            $region_term = get_term_by('id', $place_meta['region'], 'region');
          }
          $place_term = get_term_by('id', $val['term_id'], 'place');
          foreach($languages as $lang){//\" \"
            $html .= '<tr class="loctranslist_lang_'.$lang.'" '.(($lang != 'nl') ? 'style="display:none"' : '').'><td class="name column-name has-row-actions column-primary" data-colname="Name"><strong><a class="row-title" href="javascript:void();" onclick="return editloctrans(\''.base64_encode($val['id']).'\')" title="Edit">'.stripslashes($translation_name[$lang]).'</a></strong><br>
              <div class="row-actions">'; 
               $html .= '<span class="edit"><a href="javascript:void();" onclick="return editloctrans(\''.base64_encode($val['id']).'\')">Edit</a></span>&nbsp;|&nbsp;<span class="delete"><a href="javascript:void();" onclick="return deleteloctrans(\''.base64_encode($val['id']).'\')">'.__('Delete', 'azull').'</a></span></td>
              <td>'.$smeta_obj->getTranslatedTerm($lang,$place_term->name).'</td>
              <td>'.$smeta_obj->getTranslatedTerm($lang,$region_term->name).'</td>
              <td>'.$smeta_obj->getTranslatedTerm($lang,$country_term->name).'</td>
              </tr>';
          }
      }
    }else{
      $html .= '<tr><td colspan="5" align="center">'.$obj_subsciber->getTranslatedString('en','nl','Nothing Found').'</td></tr>';
    }
    $totalpages = ceil(count($all_location_trans)/$end);
    $html .= '</tbody>
    <tfoot>';
      foreach($languages as $lang){
        $html .='<tr class="loctranslist_lang_'.$lang.'" '.(($lang != 'nl') ? 'style="display:none"' : '').'>
          <th width="40%" class="manage-column column-name column-primary sortable '.$order.'"><a href="'.get_admin_url() . 'admin.php?page=location-translation&amp;orderby=name&amp;order='.$order.'">
    <span>'.$obj_subsciber->getTranslatedString('en',$lang,'Location Translation').'  </span><span class="sorting-indicator"></span></a></th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Place').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Region').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Country').'</th>
        </tr>';
      }
    $html .='</tfoot>
  </table>
    <div class="tablenav bottom">
      <div class="tablenav-pages one-page"><span class="displaying-num">'.count($all_location_trans).' '.__("items",'azull').'</span>
  '.paginate_links( array(
    'base' => str_replace('#038;','',str_replace( $big, '%#%', esc_url( get_pagenum_link($big)))),
    'format' => '?paged=%#%',
    'current' => max( 1, $paged),
    'mid-size' => 1,
    'prev_next' => True,
      'prev_text' => __( '«' ),
      'next_text' => __( '»' ),
    'total' => $totalpages
  ) ).'
  </div>
  </div>
  </div>
  </div>';
  echo $html;
   ?>
    </div>
    <script>
      function editloctrans(val){

        jQuery("#dvLoading").show();
        jQuery("#wpwrap").css({"opacity":0.3});
        if(val){
        jQuery.ajax({
           type: "POST",
           url: ajaxurl,
           data: {action: 'get_loc_trans_info',id:val},
        }).done(function(response) {
           response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
           if(response.ltn){
              jQuery.each(response.ltn, function( key, value ) {
                var value1 = value.replace("\\'", "'");
                 jQuery('#loc_trans_name_'+key).val(value1);
              });
           }
           if(response.place_meta){
              if(response.place_meta['country']){
                jQuery("#property_meta_country").val(response.place_meta['country']);   
              }
              if(response.place_meta['region']){
                jQuery("#property_meta_region").val(response.place_meta['region']);
                jQuery( "#property_meta_region" ).trigger( "change" ); 
              }
              setTimeout(function() {
                jQuery("#property_meta_place").val(response.place);
              }, 800);
              jQuery("#loc_trans_frm_head").html(response['edit_frm_title']);
           }
           jQuery("#loc_trans_id").val(response['lt_id']);
           jQuery("#dvLoading").hide();
           jQuery("#wpwrap").css({"opacity":1});
        });
      }
      }
      function deleteloctrans(val){
        if (confirm('Are you sure, you want to delete this record?')) {
          var data = {
            'action': 'delete_loc_trans',
            'id' : val
          }; 
          jQuery.post(ajaxurl, data, function(response) {
            response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
            if(response.msg){
              //jQuery('#msg_box').html(response.msg);
              location.reload();
            }
          });
        }
        return false;
      }
      var default_lang = 'nl';
      loctranslist_switch_lang(default_lang);
      function loctranslist_switch_lang(lang) {
      <?php foreach ($languages as $lang): echo "jQuery('.loctranslist_lang_{$lang}').hide();";
      endforeach;
      ?>
        jQuery('.loctranslist_lang_' + lang).show();
        jQuery('.qtranxs-lang-switch').removeClass("active");
        jQuery('#qtranxs_lang_' + lang).addClass('active');
      }
    </script>
    <?php
    echo '<style>
    #dvLoading {
        background: url(images/ajax-loader.gif) no-repeat scroll center center #000;
        color: white;
        height: 140px;
        left: 43%;
        margin: -25px 0 0 -25px;
        opacity: 1;
        position: fixed;
        top: 50%;
        width: 250px;
        z-index: 1000;
    }
    </style>';
    $default_lang = "nl";
    $languages = qtranxf_getSortedLanguages();
    echo '<div class="">
    <span id="msg_box"></span><div class="postbox" style="margin: 15px 0 10px;padding: 10px;"><h3 class="hndle ui-sortable-handle" style="margin-top:5px;"><span id="loc_trans_frm_head">'.$obj_subsciber->getTranslatedString('en','nl','Add').' '.$obj_subsciber->getTranslatedString('en','nl','Location Translation').'</span></h3><div style="margin: 5px;text-align: right;" class="epc_language-switcher inside">';
    echo "&nbsp;|&nbsp;";
    foreach ($languages as $lang) {
        echo "<a href=\"javascript:loctrans_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
    }
    echo '</div><form method="post" id="location-translation-info">';
    echo location_filter($languages);
    

    $html1 ="<table class='property_meta_location'>";
    $html1 .="<tr><th width='20%'><label for='loc_trans_name'>" .$obj_subsciber->getTranslatedString('en','nl','Location Translation Name'). "</label> </th>";
    $html1 .= "<td width='80%'><input type='hidden' name='loc_trans_id' id='loc_trans_id' value=''/>";
    foreach($languages as $lang){
      $html1 .="<div id='loctrans_language_".$lang."'  ".(($lang != 'nl') ? 'style="display:none"' : '')."><p><input type='text' name='loc_trans_name[".$lang."]' id='loc_trans_name_".$lang."' value='' placeholder='Location Translation Name' class='w50per' data-lang='".$lang."'/></p></div>";
    }
    $html1 .= "</td></tr></table>";
?>

    <script type="text/javascript">//<![CDATA[
        var default_lang = 'nl';
        loctrans_switch_lang(default_lang);
        function loctrans_switch_lang(lang) {
    <?php foreach ($languages as $lang): echo "jQuery('#loctrans_language_{$lang}').hide();";
    endforeach;
    ?>
            jQuery('#loctrans_language_' + lang).show();
            jQuery(".epc_language-switcher a").css("font-weight", "normal");
            jQuery('#active_lang_' + lang).css("font-weight", "bold");
        }
        //]]>
    </script>
    <?php
$html1 .= '<button type="button" onclick="save_loc_translation(this.value)" class="button button-primary" value="1">Save</button></form></div></div></div>';?>
<script>
function save_loc_translation(val){
  jQuery("#dvLoading").show();
  jQuery("#wpwrap").css({"opacity":0.3});
  var ltn = {};
  var loc_trans_id = jQuery("#loc_trans_id").val();
  var place = jQuery("#property_meta_place").val();
  jQuery('input[name^="loc_trans_name"]').each(function(i, v) {
    var lang = jQuery(this).data('lang');
    ltn[lang] = jQuery('#loc_trans_name_'+lang).val();
  });
  jQuery.ajax({
    type: "POST",
    url: ajaxurl,
    data: {action: 'save_location_translation',place_id:place,ltn_val:ltn,loc_trans_id:loc_trans_id},
  }).done(function(response) {
    response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
    jQuery('#msg_box').html(response.msg);
    jQuery("#dvLoading").hide();
    jQuery("#wpwrap").css({"opacity":1});
    if(response.error == 0){
      location.reload();
    }
  });
}
</script>
<?php
    echo $html1;
}
/*
* Date: 20-Dec-2016
* Method: functon for display loction filter 
*/
function location_filter($languages) {
  global $post, $wpdb;
  $obj_subsciber = new Azull_Subscriber();
  $html = '';
  $countries = get_terms('country', array('orderby' => 'slug', 'hide_empty' => false));
  $regions = get_terms('region', array('orderby' => 'slug', 'hide_empty' => false));
  //$provinces = get_terms('provinces', array('orderby' => 'slug', 'hide_empty' => false));
  $places = get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));
     
  $html .= "<table class='property_meta_location'>";
  $html .= "<tr>";
  $html .="<th width='20%'><label for='property_meta_country'>" . $obj_subsciber->getTranslatedString('en','nl','Country') . "</label></th>";
  $html .= "<td width='80%'>";
  if (!empty($countries) && !is_wp_error($countries)) {
     $html .="<select id='property_meta_country' name='country' class='w50per'>";
     $html .= "<option value='' selected='selected'>--</option>";
     if(empty($assigned_terms)) $assigned_terms = array('116');
     foreach ($countries as $countrie):
        $html .= "<option value='" . $countrie->term_id . "' " . (($countrie->term_id == 116) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $countrie->name) . "</option>";
     endforeach;
     $html .="</select>";
  }else {
     $html .="<select id='property_meta_country' name='country' class='w50per'>";
     $html .= "<option value='' selected='selected'>--</option>";
     $html .="</select>";
  }
  $html .= "</td>";
  $html .= "</tr>";
  $html .= "<tr>";
  $html .="<th><label for='property_meta_region'>" . $obj_subsciber->getTranslatedString('en','nl','Region') . "</label> </th>";
  $html .= "<td>";
  if (!empty($regions) && !is_wp_error($regions)) {
    $assigned_terms = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
    $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
    $cntry= (isset($cntryId[0]))?$cntryId[0]:116 ;
    $html .="<select id='property_meta_region' name='region' class='w50per'>";
    $html .= "<option>--</option>";
    foreach ($regions as $region):
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $region->term_id);
      if(isset($taxonomy_meta['country']) && isset($cntryId) && $taxonomy_meta['country']==$cntry){ 
        $html .= "<option value='" . $region->term_id . "'  >" . qtranxf_use(qtranxf_getLanguage(), $region->name) . "</option>";
      }
    endforeach;
    $html .="</select>";
  } else {
    $html .="<select id='property_meta_region' name='region' class='w50per'>";
    $html .= "<option value='' selected='selected'>--</option>";
    $html .="</select>";
  }

  $html .= "</td>";
  $html .= "</tr>";
  /*$html .= "<tr>";
  $html .="<th><label for='property_meta_province'>" . $obj_subsciber->getTranslatedString('en','nl','Province') . "</label> </th>";
  $html .= "<td>";
  $html .="<select id='property_meta_province' name='province' class='w50per'>";
  $html .= "<option >--</option>";
  if (!empty($provinces)) {
     $assigned_terms = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
     $reginId = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
     $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
     $cntry= (isset($cntryId[0]))?$cntryId[0]:'' ;
     $region= (isset($reginId[0]))?$reginId[0]:'' ;
      foreach ($provinces as $province):
        $taxonomy_meta = get_option('azull_taxonomy_meta_' . $province->term_id);
        if(isset($taxonomy_meta['country']) && $taxonomy_meta['country']==$cntry){
          if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$region){ 
            $html .= "<option value='" . $province->term_id . "' " . ((!empty($assigned_terms) && in_array($province->term_id, $assigned_terms)) ? 'selected' : '') . ">" . qtranxf_use(qtranxf_getLanguage(), $province->name) . "</option>";
          }
        }
      endforeach;
      $html .="</select>";
  } else {
    $html .="<select id='property_meta_province' name='province' class='w50per'>";
    $html .= "<option value='' selected='selected'>--</option>";
    $html .="</select>";
  }
  $html .= "</td>";
  $html .= "</tr>";*/
  $html .= "<tr>";
  $html .="<th><label for='property_meta_place'>" . $obj_subsciber->getTranslatedString('en','nl','Place') . "</label> </th>";
  $html .= "<td>";
  if (!empty($places) && !is_wp_error($places)) {
    $html .="<select id='property_meta_place' name='place' class='w50per'>";
    $html .= "<option >--</option>";
    $assigned_terms = wp_get_post_terms($post->ID, 'place', array("fields" => "ids"));
    $reginId = wp_get_post_terms($post->ID, 'region', array("fields" => "ids"));
    $cntryId  = wp_get_post_terms($post->ID, 'country', array("fields" => "ids"));
    //$provience = wp_get_post_terms($post->ID, 'provinces', array("fields" => "ids"));
    $cntry= (isset($cntryId[0]))?$cntryId[0]:'' ;
    $region= (isset($reginId[0]))?$reginId[0]:'' ;
    //$provien = (isset($provience[0]))?$provience[0]:'' ;
    foreach ($places as $place):
      $taxonomy_meta = get_option('azull_taxonomy_meta_' . $place->term_id);
      if(isset($taxonomy_meta['country']) && $taxonomy_meta['country']==$cntry){
        if(isset($taxonomy_meta['region']) && $taxonomy_meta['region']==$region){      
          /*if(isset($taxonomy_meta['provinces'])  &&  $taxonomy_meta['provinces']==$provien){ 
            $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
          }else{ */  
            $html .= "<option value='" . $place->term_id . "' " . ((!empty($assigned_terms) && in_array((int)$place->term_id, $assigned_terms)) ? 'selected' : '') . " >" . qtranxf_use(qtranxf_getLanguage(), $place->name) . "</option>";
          //}
        }       
      }  
    endforeach;
    $html .="</select>";
  } else {
    $html .="<select id='property_meta_place' name='place' class='w50per'>";
    $html .= "<option value='' selected='selected'>--</option>";
    $html .="</select>";
  }
  $html .= "</td>";
  $html .= "</tr>";
  $html .= "</table>";
  return $html;   
}
/* 
 * Date : 22-Dec-2016
 * Method : Function for manage location translation
 */
function get_termName($termId) {
    global $wpdb;
    $terms = $wpdb->get_results('SELECT name FROM wp_terms WHERE term_id =' . $termId, ARRAY_A);
    if (isset($terms[0]['name']))
        return $terms[0]['name'];
    return false;
}
function test_n_run_script(){
  global $wpdb;
  die('out');
  //find properties which have agent.proprioter name in description text on azull.biz
  //$sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC";
  /*$sql = "SELECT p.ID,p.post_title,p.post_content,pm1.meta_value AS _import_id,pm2.meta_value as _proprietor FROM $wpdb->posts p JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_import_id') JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_proprietor') WHERE p.post_type = 'property' AND pm1.meta_key ='_import_id' AND pm2.meta_value != ''";
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  $tmp = array();
   $file = fopen('/home/azullbiz/public_html/cisin/wp-content/properties-have-agent-name-in-text.xls', 'w+');
    fputcsv($file, array('', 'Ref', 'Title', 'Proprietor/Agent', 'Proprietor Ref','Published Websites','Description'));
            $sno=1;
  foreach ($property_data as $key => $val) {
    $proprietor = $val['_proprietor'];
    //$proprietor_term = get_term($proprietor,'proprietor');
    $proprietor_term = $wpdb->get_row("SELECT * FROM wp_terms where term_id=" . $proprietor, ARRAY_A);
    $agent_txt_found_in_desc = 0;
    //print('<pre>');print_r($proprietor_term['name']);die();
    $languages = qtranxf_getSortedLanguages();
    if(isset($languages) && !empty($languages)){
      foreach ($languages as $key => $lang_val) {
        $desc = qtranxf_use($lang_val, $val['post_content']);
        if(stripos(strtolower($desc),strtolower($proprietor_term['name'])) !== false)
        {
          $agent_txt_found_in_desc = 1;
        }
      }
    }
    //print('<pre>');print_r($proprietor_term['name']);die();
    if($agent_txt_found_in_desc==1)
    {
      $val['_proprietor_name'] = $proprietor_term['name'];
      $val['_clients'] = get_post_meta($val['ID'], "_client", true);
      $val['ref'] = get_post_meta($val['ID'], "_nreal_id", true);
      $val['_proprietorRef'] = get_post_meta($val['ID'], "_proprietorRef", true);
      $tmp[] = $val;
      $val['_proprietorRef'] = (isset($val['_proprietorRef']) && !empty($val['_proprietorRef']))?$val['_proprietorRef']:'NA';
      if(isset($_clients) && !empty($_clients) && is_array($_clients)){
        foreach ($_clients as $clientId) { 
          //$wpdb->insert('wp_xml_record',array('path' => (integer) $val['ID'],'agentId' => (integer)$clientId,'status'=>0,'type'=>4)); 
        }
      }
      //$wpdb->update('wp_posts',array('post_status'=>'rejected'),array('ID' => $val['ID']));
      //print('<pre>');print_r($tmp);die('chk');
      $desc_txt = (!empty(qtranxf_use('en', $val['post_content'])))?qtranxf_use('en', $val['post_content']):'NA';
      $row = array($sno,$val['ref'],qtranxf_use('nl', $val['post_title']),$val['_proprietor_name'],$val['_proprietorRef'],'inmo-espana.com',$desc_txt);
      //print('<pre>');print_r($row);die('chk');
      fputcsv($file, $row);
      $sno++;
    }
  }
  fclose($file);
  print('<pre>');print_r($tmp);die('chk');*/


  /*$property_data = array('277619');
  $tmp = array();
  foreach ($property_data as $key => $val) {
    $post_data = get_post($val, ARRAY_A);
    //$post_meta_data = get_post_meta($val);
    //print('<pre>');print_r($post_meta_data);die();
    $ref = get_post_meta($val, '_nreal_id', true);
    $countryId = get_post_meta($val, '_country', true);
    $regionId = get_post_meta($val, '_region', true);
    $placeId = get_post_meta($val, '_place', true);
    $country = (isset($countryId) && $countryId!=0)?get_termName($countryId):'';
    $region = (isset($regionId) && $regionId!=0)?get_termName($regionId):'';
    $place = (isset($placeId) && $placeId!=0)?get_termName($placeId):'';
    $cat = (isset($post_data['post_category'][0]) && $post_data['post_category'][0]!=0)?get_termName($post_data['post_category'][0]):'';
//print('<pre>');print_r($cat);die();
    

    $name = $ref . '-' . ucwords(str_replace(" ", "-", ucwords($cat))) . '-te-koop-' . str_replace(" ", "-", ucwords($place)) . '-' . str_replace(" ", "-", ucwords($region)) . '-' . str_replace(" ", "-", ucwords($country)) . '-';// . $i;
    $file = get_attached_file(277623);
    print('<pre>');print_r($file);
    $final = dirname($file).$newname;
    //rename($file,dirname($file).$newname)
        //update_attached_file(277623, $final );
print('<pre>');print_r($final);die();
    $fullsize_path = get_attached_file(277623); // Full path
    print('<pre>');print_r($fullsize_path);
    $attach_data = wp_generate_attachment_metadata(277623, $fullsize_path);
    print('<pre>');print_r($attach_data);die();

    $attachment_sql = "SELECT * FROM wp_posts where post_type='attachment' AND post_parent = ".$val." ORDER BY id ASC";
    $attachment_data = $wpdb->get_results($attachment_sql);
    foreach ($attachment_data as $akey => $aval) {
      $fullsize_path = get_attached_file($aval->ID); // Full path
    print('<pre>');print_r($fullsize_path);die();
      echo $aval->ID;
      $attachment_path = get_post_meta($aval->ID, '_wp_attachment_metadata');
      print('<pre>');print_r($attachment_path);die();
    }
    print('<pre>');print_r($attachment_data);die();
  }
  die('out');*/
  /*$sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC limit 0,100";
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  print('<pre>');print_r($property_data);die();*/
  /*$sql = "SELECT p.ID,p.post_content,pm1.meta_value AS _import_id,pm2.meta_value as _proprietor FROM $wpdb->posts p JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_import_id') JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_proprietor') WHERE p.post_type = 'property' AND pm1.meta_key ='_import_id' AND pm2.meta_value != ''";
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  //print('<pre>');print_r($property_data);//die();
  $tmp = array();
  foreach ($property_data as $key => $val) {
    //print('<pre>');print_r($val);
    $attachment_sql = "SELECT * FROM wp_posts where post_type='attachment' AND post_parent = ".$val['ID']." AND post_name like '%-Penthouse-%' ORDER BY id ASC";
      $attachment_data = $wpdb->get_results($attachment_sql);
      if(isset($attachment_data) && !empty($attachment_data)){
        $tmp[] = $attachment_data;
      }
      
      
  }
  print('<pre>');print_r($tmp);//die();
  die('out');*/
  //find properties which have agent.proprioter name in description text on azull.biz
  //$sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC";
  /*$sql = "SELECT p.ID,p.post_content,pm1.meta_value AS _import_id,pm2.meta_value as _proprietor FROM $wpdb->posts p JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_import_id') JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_proprietor') WHERE p.post_type = 'property' AND pm1.meta_key ='_import_id' AND pm2.meta_value != ''";
  $property_data = $wpdb->get_results($sql, ARRAY_A);
  $tmp = array();
  foreach ($property_data as $key => $val) {
    $proprietor = $val['_proprietor'];
    //$proprietor_term = get_term($proprietor,'proprietor');
    $proprietor_term = $wpdb->get_row("SELECT * FROM wp_terms where term_id=" . $proprietor, ARRAY_A);
    $agent_txt_found_in_desc = 0;
    //print('<pre>');print_r($proprietor_term['name']);die();
    $languages = qtranxf_getSortedLanguages();
    if(isset($languages) && !empty($languages)){
      foreach ($languages as $key => $lang_val) {
        $desc = qtranxf_use($lang_val, $val['post_content']);
        if(stripos(strtolower($desc),strtolower($proprietor_term['name'])) !== false)
        {
          $agent_txt_found_in_desc = 1;
        }
      }
    }
    //print('<pre>');print_r($proprietor_term['name']);die();
    if($agent_txt_found_in_desc==1)
    {
      $val['_proprietor_name'] = $proprietor_term['name'];
      $val['_clients'] = get_post_meta($val['ID'], "_client", true);
      $tmp[] = $val;
    }
  }
  print('<pre>');print_r($tmp);die('chk');*/
 
}
function test_n_run_script2(){
  //die('not allowed');
  //global $wpdb;
  //find properties which have agent.proprioter name in description text on azull.biz
  //$sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC";
 // $sql = "SELECT p.ID,p.post_name,pm1.meta_value AS _import_id,pm2.meta_value as _nreal_id FROM $wpdb->posts p JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_import_id') JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_nreal_id') WHERE p.post_type = 'property' AND pm1.meta_key ='_import_id' AND pm2.meta_value != ''";
  //$property_data = $wpdb->get_results($sql, ARRAY_A);
  $tmp = array();
   //print('<pre>');print_r($property_data);die();

  //foreach ($property_data as $key => $val) {
    $val=get_post(335435,ARRAY_A);
    //echo $val['post_name'];
    $ref = get_post_meta($val['ID'], "_nreal_id", true);
    $post_name_arr = explode('-',$val['post_name']);
    //print('<pre>');print_r($ref);
    //print('<pre>');print_r($post_name_arr);die();
    $post_name_ref = $post_name_arr[0];
    if($ref != $post_name_ref){
      global $wpdb;
      $post_name_arr[0] = $ref;
      $post_name_new = implode('-',$post_name_arr);//  explode('-',$val['post_name']);
      $tmp[] = array('ref'=>$ref,'post_name'=>$val['post_name'],'post_name_new'=>$post_name_new);
      $wpdb->update('wp_posts', array('post_name' => $post_name_new), array('ID' => $val['ID']));
      //print('<pre>');print_r($tmp);die('chk');
      //die('chk');
    }
  //}
  
  print('<pre>');print_r($tmp);die('chk');
}
function test_n_run_script3(){
  //die('not allowed');
  global $wpdb;
  //find properties which have agent.proprioter name in description text on azull.biz
  //$sql = "SELECT * FROM wp_posts where post_type='page' ORDER BY id DESC";// AND post_status='publish'
 //$sql = "SELECT p.ID,p.post_name,pm1.meta_value AS _import_id,pm2.meta_value as _nreal_id FROM $wpdb->posts p JOIN $wpdb->postmeta pm1 ON (pm1.post_id = p.ID  AND pm1.meta_key = '_import_id') JOIN $wpdb->postmeta pm2 ON (pm2.post_id = p.ID  AND pm2.meta_key = '_nreal_id') WHERE p.post_type = 'property' AND pm1.meta_key ='_import_id' AND pm2.meta_value != ''";

  
   //echo '<pre>';print_r($getresult);
   //die;
  //$post_data = $wpdb->get_results($sql, ARRAY_A);
  $tmp = array();
  //print('<pre>');print_r($post_data);die();
  //$i = 1;
 // foreach ($post_data as $val) {

    $val=get_post(335435,ARRAY_A);
    print('<pre>');print_r($val);die();//['post_title']
    $tmp=array();
    $existing_post_title = $val['post_title'];
    //print('<pre>');print_r($existing_post_title);die('existing_post_title');
    $fr_pos = strpos($existing_post_title,"[:fr]");
    $en_txt = str_replace('[:en]','',substr($existing_post_title, 0, $fr_pos));
    
    $fr_str = substr($existing_post_title,$fr_pos);
    $nl_pos = strpos($fr_str,"[:nl]");
    $fr_txt = str_replace('[:fr]','',substr($fr_str, 0, $nl_pos));
    //print('<pre>');print_r($fr_txt);die('fr_txt');
    $nl_str = explode("[:nl]",$existing_post_title);
    $nl_txt_arr = str_replace('[:]','',explode("[:nl]",$nl_str[1]));
    
    $post_date = date('Y/m/d',strtotime($val['post_date']));
    $site_url = get_site_url();//.'/'.$post_date;
    if(isset($en_txt) && !empty($en_txt)){
      $en_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($en_txt));
      if(isset($en_slug) && !empty($en_slug)){
        $en_slug = $site_url.'/'.rtrim($en_slug,"-");
        update_post_meta($val['ID'],'_custom_permalink_en', $en_slug);
      }
    }
    if(isset($fr_txt) && !empty($fr_txt)){
      $fr_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($fr_txt));
      if(isset($fr_slug) && !empty($fr_slug)){
        $fr_slug = $site_url.'/'.rtrim($fr_slug,"-");
        update_post_meta($val['ID'],'_custom_permalink_fr', $fr_slug);
      }
    }
    if(isset($nl_txt_arr[0]) && !empty($nl_txt_arr[0])){
      $nl_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($nl_txt_arr[0]));
      if(isset($nl_slug) && !empty($nl_slug)){
        $nl_slug = $site_url.'/'.rtrim($nl_slug,"-");
        update_post_meta($val['ID'],'_custom_permalink_nl',$nl_slug);
      }
    }

    //if($i==3){
      print('<pre>');print_r($en_slug);//die();
      print('<pre>');print_r($fr_slug);
      print('<pre>');print_r($nl_slug);//die();
    //}
    //$i++;
  ///}
}

function updateimagetitle(){
  
 $allPostId=array(335435);

/* run for all xml post id*/
//foreach ($allPostId as $key => $pId) {
 foreach ($allPostId as $post_id) { 
 //if($key==32){
  //$post_id= $pId['ID'];
 //echo $post_id."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);
  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }
 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

   // echo '<pre>';print_r($ids);
    //die;
    //die;////////
  /* run for all post attachment id*/ 
      $i=0; 
         if(isset($ids) && !empty($ids)){ 
           foreach ($ids as $atchid) {
            echo $atchid.'<br>';
            $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;
               global $wpdb; 
                $table_name='wp_postmeta';
                /*update post meta*/  
                //echo "UPDATE $table_name SET meta_value='$name' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'"."<br>";     
                $wpdb->query("UPDATE $table_name SET meta_value='$name' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");
                $i++;
          }
      }
 }//end post
 die('helll');
}


function weatehrInfoRun(){
//echo 'hehhe';
//die;
  global $wpdb; 
 $query = "SELECT wp_posts.ID FROM wp_posts
  JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id where wp_postmeta.meta_key='_nreal_id_man' and wp_postmeta.meta_value !='' and wp_postmeta.meta_value !=0 ORDER BY ID DESC LIMIT 300,50";

//echo $query."<br>";
$allPostId = $wpdb->get_results($query, ARRAY_A);

echo '<pre>';
print_r($allPostId);
//echo count($allPostId);
//die;
//die;
//$allPostId=array(264115);
/* run for all xml post id*/
foreach ($allPostId  as $key => $pId) {
///foreach ($allPostId as $post_id) { 
$post_id= $pId['ID'];
 $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];
  echo '<br>'.$post_id."---nbrl---".$nbId."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

$postName =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",strtolower($countryName));
  

  global $wpdb; 
  $table_name='wp_posts';
  /*/update post name*/       
  $wpdb->query("UPDATE $table_name SET  post_name='$postName' WHERE ID=$post_id");


  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    //echo '<pre>';print_r($ids);
    //die;////////
  /* run for all post attachment id*/ 
  $i=0; 
  $temp=false;
 if(isset($ids) && !empty($ids)){ 
  
  foreach ($ids as $atchid) {
      $addedFilesNames=array('');
      foreach ($ids as $atID) {
       $addedFilesNames[] = get_attached_file($atID);
      }
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;
        $postname =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
  
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
            /*oldFileName*/
              //$oldnamefile=$filepath.'/'.$prvName;
              //$newfile = $filepath.'/'.$name.'.'.$ext;
              //$atchData=get_post_meta($atchid,'_wp_attached_file');

  $file = get_attached_file($atchid);
  $newfileName=$pathName['dirname']."/".$name.'.'.$pathName['extension'];
  // echo  $newfileName."<br>";
   //echo '<pre>';
   //print_r($addedFilesNames)."<br>";
  if(!in_array($newfileName, $addedFilesNames)){
      $path = pathinfo($file);       
      if($path['basename']!='' && $path['basename'] != $name.'.'.$ext){
        $updatedPostID[]=$post_id.'-'.$nbId;
            //echo 'in--  ';    
                global $wpdb; 
                $table_name='wp_posts';
                /*/update post meta*/       
                $wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$postname' WHERE ID=$atchid");

                /* get wp_attached_file data */
                $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];
                
                /*rename attact fileName */
                  if(file_exists($file)){
                   rename($file, $newwp_attached_file); 
                   update_attached_file( $atchid, $newwp_attached_file );
                  }
                  
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
               //echo '<pre>';
               //print_r($atchData1);
               
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;

              /*Update attechment data*/ 
 
                $thumbnail= $atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $atchData1[0]['sizes']['medium']['file'];
                $large= $atchData1[0]['sizes']['large']['file'];
                
                $pdfLarge= $atchData1[0]['sizes']['pdf-large']['file'];
                $pdfSmall= $atchData1[0]['sizes']['pdf-small']['file'];
                $printA5Large= $atchData1[0]['sizes']['print-A5-large']['file'];
                

        if($pdfLarge!='' || $pdfSmall!='' || $printA5Large!=''){
                 ///echo $atchid.'pdfin<br>';
                  
                if($pdfLarge!=''){

                    $pdfLarge = $filepath.'/'.$atchData1[0]['sizes']['pdf-large']['file'];
                    if(file_exists($pdfLarge)){
                      $atchData1[0]['sizes']['pdf-large']['file']= $name.'-.jpg';
                      rename($pdfLarge, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($pdfSmall!=''){

                  $pdfSmall = $filepath.'/'.$atchData1[0]['sizes']['pdf-small']['file'];
                    if(file_exists($pdfSmall)){
                      $atchData1[0]['sizes']['pdf-small']['file']= $name.'-.jpg';
                      rename($pdfSmall, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($printA5Large!=''){

                     $printA5Large = $filepath.'/'.$atchData1[0]['sizes']['print-A5-large']['file'];
                    if(file_exists($printA5Large)){
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['print-A5-large']['file']= $name.'-.jpg';
                      
                    }  
                }


                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                      rename($thumbnail, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-small.jpg';
                      
                    }  
                }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                      rename($medium, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['medium']['file']= $name.'-medium.jpg';
                      
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-.jpg';
                      
                    }  
                }    
             }else{
                    
                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                      rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                    }  
                  }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                       rename($medium, $filepath."/".$name.'-300x169.jpg');
                       $atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                      rename($large, $filepath."/".$name.'-1024x576.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                    }  
                }
                
             }         
                      
             $updatedAttachData=serialize($atchData1);
             //$atchData1=unserialize($updatedAttachData);
             //echo '<pre>';
             //print_r($atchData1);
           
          $table_name1='wp_postmeta';
            global $wpdb;
            $wpdb->query("DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'");
             
            $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");

            $wpdb->query("UPDATE $table_name1 SET meta_value='$name' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");  
        }
        else{ //end check attachmentImage title and updation
              $notupdate[]=$post_id.'-'.$nbId;
        }
      }else{
        global $wpdb;
        $table_name1='wp_postmeta';
        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $altName=$pathName['filename'];
        $wpdb->query("UPDATE $table_name1 SET meta_value='$altName' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");
        $notupdate[]=$post_id.'-'.$nbId;
      }
    $i++;
    //die('atch');
  }//end for attachment id
}//check atchId

}// end for post id    


$updatedPostID=array_unique($updatedPostID); 
print_r($updatedPostID);
//die('helll');

if(!empty($updatedPostID)){
 $updatedPostID=array_unique($updatedPostID); 
 $myfile1 = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id1.txt", "w") or die("Unable to open file!");
foreach ($updatedPostID as $ids) {
   $txt=$ids.'--';
  fwrite($myfile1, $txt);
}
fclose($myfile1);
}

if(!empty($notupdate)){
 $notupdate=array_unique($notupdate); 
  $myfile = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id.txt", "w") or die("Unable to open file!");
//$txt = "John Doe\n";
foreach ($notupdate as $ids) {
   $txt=$ids.'--';
  fwrite($myfile, $txt);
}
fclose($myfile);

}

die('-- ');
}

function wprunfile(){
  //echo 'hhh';die();
  global $wpdb; 
  $query = "SELECT wp_posts.ID FROM wp_posts
  JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id where wp_postmeta.meta_key='_nreal_id_man' and wp_postmeta.meta_value !='' and wp_postmeta.meta_value !=0 ORDER BY ID DESC LIMIT 19,1";

//echo $query."<br>";
//$allPostId = $wpdb->get_results($query, ARRAY_A);

//echo '<pre>';
//print_r($allPostId);
//echo count($allPostId);
//die;
//die;
//$allPostId=array(291716);
$allPostId=array(264115);
/* run for all xml post id*/
//foreach ($allPostId  as $key => $pId) {
 foreach ($allPostId as $post_id) { 
 //if($key==32){
 //$post_id= $pId['ID'];
 $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];
  echo '<br>'.$post_id."---nbrl---".$nbId."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

 // $imageTitle =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName));
  
  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    echo '<pre>';print_r($ids);
    //die;////////
  /* run for all post attachment id*/ 
  $i=0; 
  $temp=false;
 if(isset($ids) && !empty($ids)){ 
  
  foreach ($ids as $atchid) {
      
      $addedFilesNames=array('');
      foreach ($ids as $atID) {
       $addedFilesNames[] = get_attached_file($atID);
      }
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;
        $postname =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
  
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
            /*oldFileName*/
              //$oldnamefile=$filepath.'/'.$prvName;
              //$newfile = $filepath.'/'.$name.'.'.$ext;
              //$atchData=get_post_meta($atchid,'_wp_attached_file');

  $file = get_attached_file($atchid);
  $newfileName=$pathName['dirname']."/".$name.'.'.$pathName['extension'];
     echo  $newfileName."<br>";
   //echo '<pre>';
  // print_r($addedFilesNames)."<br>";
  //if(!in_array($newfileName, $addedFilesNames)){
      echo "in----".$atchid."<br>";
      $path = pathinfo($file);  
      //echo "File====".$file."<br>";
      echo $path['basename'].'----ne--<br>';
      echo $name.'.'.$pathName['extension']."<br><br>";
         
      //if($path['basename']!='' && $path['basename'] != $name.'.'.$ext){

        $updatedPostID[]=$post_id.'-'.$nbId;
            //echo 'in--  ';    
                global $wpdb; 
                $table_name='wp_posts';
                /*/update post meta*/       
                //$wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$postname' WHERE ID=$atchid");

                /* get wp_attached_file data */
                $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];
                
                /*rename attact fileName */
                  if(file_exists($file)){
                   //rename($file, $newwp_attached_file); 
                   //update_attached_file( $atchid, $newwp_attached_file );
                  }
                  
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
              echo '<pre>';
              print_r($atchData1);
              echo 'newID====<br>';
               
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;

              /*Update attechment data*/ 
 
                $thumbnail= $atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $atchData1[0]['sizes']['medium']['file'];
                $large= $atchData1[0]['sizes']['large']['file'];
                
                $pdfLarge= $atchData1[0]['sizes']['pdf-large']['file'];
                $pdfSmall= $atchData1[0]['sizes']['pdf-small']['file'];
                $printA5Large= $atchData1[0]['sizes']['print-A5-large']['file'];
                

        if($pdfLarge!='' || $pdfSmall!='' || $printA5Large!=''){
                 ///echo $atchid.'pdfin<br>';
                  
                if($pdfLarge!=''){

                    $pdfLarge = $filepath.'/'.$atchData1[0]['sizes']['pdf-large']['file'];
                    if(file_exists($pdfLarge)){
                      //$atchData1[0]['sizes']['pdf-large']['file']= $name.'-.jpg';
                      //rename($pdfLarge, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($pdfSmall!=''){

                  $pdfSmall = $filepath.'/'.$atchData1[0]['sizes']['pdf-small']['file'];
                    if(file_exists($pdfSmall)){
                      //$atchData1[0]['sizes']['pdf-small']['file']= $name.'-.jpg';
                      //rename($pdfSmall, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($printA5Large!=''){

                     $printA5Large = $filepath.'/'.$atchData1[0]['sizes']['print-A5-large']['file'];
                    if(file_exists($printA5Large)){
                      //rename($printA5Large, $filepath."/".$name.'-.jpg');
                      //$atchData1[0]['sizes']['print-A5-large']['file']= $name.'-.jpg';
                      
                    }  
                }


                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                     // rename($thumbnail, $filepath."/".$name.'-.jpg');
                     // $atchData1[0]['sizes']['thumbnail']['file']= $name.'-small.jpg';
                      
                    }  
                }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                      //rename($medium, $filepath."/".$name.'-.jpg');
                      //$atchData1[0]['sizes']['medium']['file']= $name.'-medium.jpg';
                      
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                      //rename($printA5Large, $filepath."/".$name.'-.jpg');
                      //$atchData1[0]['sizes']['large']['file']= $name.'-.jpg';
                      
                    }  
                }    
             }else{
                    
                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                      //rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                      //$atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                    }  
                  }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                       //rename($medium, $filepath."/".$name.'-300x169.jpg');
                       //$atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                      //rename($large, $filepath."/".$name.'-1024x576.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                    }  
                }
                
             }         
                      
             $updatedAttachData=serialize($atchData1);
             //$atchData1=unserialize($updatedAttachData);
             //echo '<pre>';
             //print_r($atchData1);
           
          /*$table_name1='wp_postmeta';
            global $wpdb;
            $wpdb->query("DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'");
             
            $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");

            $wpdb->query("UPDATE $table_name1 SET meta_value='$name' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");  */
        //}
        //else{ //end check attachmentImage title and updation
              //$notupdate[]=$post_id.'-'.$nbId;
       // }
      /*}else{
        global $wpdb;
        $table_name1='wp_postmeta';
        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $altName=$pathName['filename'];
        $wpdb->query("UPDATE $table_name1 SET meta_value='$altName' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");
        $notupdate[]=$post_id.'-'.$nbId;
      }*/
    $i++;
    //die('atch');
  }//end for attachment id
}//check atchId

}// end for post id    


$updatedPostID=array_unique($updatedPostID); 
print_r($updatedPostID);
//die('helll');

if(!empty($updatedPostID)){
 $updatedPostID=array_unique($updatedPostID); 
 $myfile1 = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id1.txt", "w") or die("Unable to open file!");
foreach ($updatedPostID as $ids) {
   $txt=$ids.'--';
  fwrite($myfile1, $txt);
}
fclose($myfile1);
}

if(!empty($notupdate)){
 $notupdate=array_unique($notupdate); 
  $myfile = fopen("/home/azullbiz/public_html/cisin/wp-content/uploads/id.txt", "w") or die("Unable to open file!");
//$txt = "John Doe\n";
foreach ($notupdate as $ids) {
   $txt=$ids.'--';
  fwrite($myfile, $txt);
}
fclose($myfile);

}

die('-- ');
}

function update_post_attached_imagename(){

   //die('not allowed');

  global $wpdb; 
$query = "SELECT wp_posts.ID FROM wp_posts
  JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id where wp_postmeta.meta_key='_xmlref' and wp_postmeta.meta_value!='' ORDER BY ID DESC LIMIT 40,50";

//$allPostId = $wpdb->get_results($query, ARRAY_A);

$allPostId=array(335435);
//$allPostId=array(,151856,97802,97740,97733,96844,96733,96355,96241);
//$allPostId=array(293504);

/* run for all xml post id*/
//foreach ($allPostId as $key => $pId) {
 foreach ($allPostId as $post_id) { 
 //if($key==32){
  //$post_id= $pId['ID'];
 //echo $post_id."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

 // $imageTitle =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName));
  
  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    echo '<pre>';print_r($ids);
    die;
    

    //die;////////
  /* run for all post attachment id*/ 
  $i=0; 
  $temp=false;
 if(isset($ids) && !empty($ids)){ 
  foreach ($ids as $atchid) {
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
         
      $file = get_attached_file($atchid);
      $path = pathinfo($file);  
      echo $path['basename'].'--';
      echo 'new...'.$name.'.'.$ext."<br><br>";
     if($path['basename']!='' && $path['basename'] != $name.'.'.$ext){
                
                 global $wpdb; 
                $table_name='wp_posts';
                /*update post meta*/       
              $wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$name' WHERE ID=$atchid");

                /* get wp_attached_file data */
                $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];
                
                /*rename attact fileName */
                  if(file_exists($file)){
                    rename($file, $newwp_attached_file); 
                    update_attached_file( $atchid, $newwp_attached_file );
                  }
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
              //echo 'attech ile------<pre>';
              //print_r($atchData1);
               
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;

              /*Update attechment data*/ 
 
                $thumbnail= $atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $atchData1[0]['sizes']['medium']['file'];
                $large= $atchData1[0]['sizes']['large']['file'];
                
                $pdfLarge= $atchData1[0]['sizes']['pdf-large']['file'];
                $pdfSmall= $atchData1[0]['sizes']['pdf-small']['file'];
                $printA5Large= $atchData1[0]['sizes']['print-A5-large']['file'];
               // echo $pdfLarge."<br>";
               // echo $pdfSmall."<br>";

        if($pdfLarge!='' && $pdfSmall!='' && $printA5Large!=''){
                 //echo $atchid.'pdfin<br>';
                  
                  $pdfLarge = $filepath.'/'.$atchData1[0]['sizes']['pdf-large']['file'];
                  $pdfSmall = $filepath.'/'.$atchData1[0]['sizes']['pdf-small']['file'];
                  $printA5Large = $filepath.'/'.$atchData1[0]['sizes']['print-A5-large']['file'];
                  $thumbnail= $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                  $medium= $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                  $large= $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                
            if(file_exists($pdfLarge) && file_exists($pdfSmall) && file_exists($printA5Large) && file_exists($thumbnail) && file_exists($medium) && file_exists($large)){
                   
                    echo 'exists<br>';  
                      rename($pdfLarge, $filepath."/".$name.'-.jpg');
                      rename($pdfSmall, $filepath."/".$name.'-.jpg');
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      rename($thumbnail, $filepath."/".$name.'-small.jpg');
                      rename($medium, $filepath."/".$name.'-medium.jpg');
                      rename($large, $filepath."/".$name.'-.jpg');
                      
                      $atchData1[0]['sizes']['pdf-large']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['pdf-small']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['print-A5-large']['file']= $name.'-.jpg';
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-small.jpg';
                      $atchData1[0]['sizes']['medium']['file']= $name.'-medium.jpg';
                      $atchData1[0]['sizes']['large']['file']= $name.'-.jpg';
                      $updatedAttachData=serialize($atchData1);
                  
                  //echo 'newAttecgmetData================================<br>';    
                  //print_r(unserialize($updatedAttachData));

                  /*global $wpdb;
                  $table_name1='wp_postmeta';   
                  $wpdb->query( "DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'" );

                  $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");*/
                  
           }
        }else{
                if($thumbnail!='' && $medium!='' && $large!=''){
                //echo $atchid.'out-----<br>';
                  $thumbnail= $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                  $medium= $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                  $large= $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
  
                  if(file_exists($thumbnail)){
                      rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                       $atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                  }else if(file_exists($thumbnail)){
                       rename($medium, $filepath."/".$name.'-300x169.jpg');
                       $atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                  }else if(file_exists($large)){
                      rename($large, $filepath."/".$name.'-1024x576.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                  }
                  
                  $updatedAttachData=serialize($atchData1);
                  $table_name1='wp_postmeta';
                  global $wpdb;
                  $wpdb->query( "DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'");
                  $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");
                 } 
          }
        } else{ //end check attachmentImage title and updation
                  $notupdate[]=$post_id.'-'.$nbId;
          }
    $i++;
    //die('atch');
  }//end for attachment id
}//check atchId
}// end for post id    

  
}
function test_property_custom_permalink() {
  //print('<pre>');print_r($postId);//die('hi');
    global $wpdb;
    $sql = "SELECT * FROM wp_posts where post_type='property' ORDER BY id ASC limit 3000, 500";
    $property_data = $wpdb->get_results($sql, ARRAY_A);
    print('<pre>');print_r($property_data);die('hi');
    if(isset($property_data) && !empty($property_data) && count($property_data)>0){
        $option_lang = get_option('qtranslate_term_name');
        $languages = qtranxf_getSortedLanguages();
        foreach ($property_data as $key => $val) {
          $postId = $val['ID'];
          echo $postId.'<br>';
          $category = wp_get_post_terms($postId,'category');
          $post_meta = get_post_meta($postId);
          $ref = $post_meta['_nreal_id'][0];
          $cntry_term = Azull_Meta::get_termname_custom($post_meta['_country'][0]);
          $region_term =Azull_Meta::get_termname_custom($post_meta['_region'][0]);
          $place_term = Azull_Meta::get_termname_custom($post_meta['_place'][0]);
          $site_url = get_site_url();
          $slug_txt_arr = array(
              'en'=>'for-sale',
              'fr'=>'a-vendre',
              'nl'=>'te-koop'
          );
          foreach ($languages as $key => $lang) {
            $post_category = (isset($option_lang[$category[0]->name][$lang]))?$option_lang[$category[0]->name][$lang]:$category[0]->name;
            $post_country = (isset($option_lang[$cntry_term][$lang]))?$option_lang[$cntry_term][$lang]:$cntry_term;
            $post_region = (isset($option_lang[$region_term][$lang]))?$option_lang[$region_term][$lang]:$region_term;
            $post_place = (isset($option_lang[$place_term][$lang]))?$option_lang[$place_term][$lang]:$place_term;

            $p_post_name = $ref.'-'.$post_category.'-'.$slug_txt_arr[strtolower($lang)].'-'.$post_place.'-'.$post_region.'-'.$post_country;
            $p_post_name = str_replace(' ', '-', strtolower($p_post_name));
            $slug = str_replace('--', '-',str_replace(',', '', str_replace('.', '', $p_post_name)));
            $slug = str_replace('--', '-',$slug);
            $slug = str_replace('-–-', '-',$slug);//-–-
            echo 'lang => '.$lang.' => '.$slug.'<br>';
            update_post_meta($postId, '_custom_permalink_'.$lang, $site_url.'/'.rtrim($slug,"-"));

          }
          //die($postId);
        }
die('chk');

        
      //print('<pre>');print_r($_POST['custom_permalink']);die('hi');
    }
}
add_action('admin_menu', 'weather_info');

function weather_info() {
    add_menu_page("Weather Info", "Weather Info", 1, "weatherinfo", "weatherinfo");
}

/*function weather_info() {
    add_menu_page("Weather Info", "Weather Info", 1, "weather_infoRun", "weather_infoRun");
}*/

function updateimageName(){
  global $wpdb; 
 

//$wpdb->query( "DELETE FROM wp_posts WHERE post_title = 'Auto Draft' ORDER BY ID DESC LIMIT 400" );
//$wpdb->query( "DELETE FROM wp_postmeta WHERE meta_value = 9888 and meta_key='_nreal_id'");
//die('done');

$query = "SELECT wp_posts.post_content FROM wp_posts
  JOIN wp_postmeta ON wp_posts.ID = wp_postmeta.post_id where wp_postmeta.meta_key='_xmlref' and wp_postmeta.meta_value!='' and wp_posts.post_type ='property' ORDER BY ID ASC limit 5";

$allPostId= $wpdb->get_results($query, ARRAY_A);
//echo '<pre>';
//print_r($allPostId);
//$postData=qtranxf_split($allPostId['post_content']);
//print_r($postData);
//die;

foreach ($allPostId as $key => $pId) {

 $postcontent= $pId['post_content'];
 $dta=qtranxf_split($postcontent);
 echo '<pre>';
 print_r($dta)."-----------<br>";
 //echo $postcontent
 //$atchData1 = get_post_meta($post_id, '_client');
 //echo '<pre>';
 //print_r($atchData1);


 
/*
 if(in_array(50913, $atchData1[0]) && in_array(335455, $atchData1[0]) && in_array(50913, $atchData1[0])){
    //print_r($atchData1[0]);
    echo $post_id.'----be'."<br>";
    update_post_meta($post_id, '_main_site', 50913);
 }

 else if(in_array(50913, $atchData1[0]) && in_array(335455, $atchData1[0])){
    //print_r($atchData1[0]);
    echo $post_id.'----be'."<br>";
    update_post_meta($post_id, '_main_site', 50913);
 }
 else if(in_array(50913, $atchData1[0]) && in_array(50933, $atchData1[0])){
    //print_r($atchData1[0]);
    echo $post_id.'----be'."<br>";
    update_post_meta($post_id, '_main_site', 50913);
 }
 else if(in_array(335455  , $atchData1[0])){
    //print_r($atchData1[0]);
    echo $post_id.'----fr'."<br>";
    update_post_meta($post_id, '_main_site', 335455);
 }
 else if(in_array(50913  , $atchData1[0])){
    //print_r($atchData1[0]);
    echo $post_id.'----be'."<br>";
    update_post_meta($post_id, '_main_site', 50913);
 }
 else if(in_array(50933, $atchData1[0])){
  //print_r($atchData1[0]);
  echo $post_id.'----inmo'."<br>";
  update_post_meta($post_id, '_main_site', 50933);

 }*/
 
 //echo '<pre>';
 //print_r($atchData1);

}

}

function weatherinfo() {
      
    //updateimageName();die('helll');
    ///wprunfile();die('run');
    //weatehrInfoRun();die('Done==');

  //test_property_custom_permalink();die('have fun!');
  //updateimagetitle();die('helll');;
  //update_post_attached_imagename();die('done---');
  //test_n_run_script2();die('have fun!');
  //test_n_run_script3();die('have fun!');
    
  /*$places = get_terms('place', array('orderby' => 'slug', 'hide_empty' => false));
    //create excel file
    $file = fopen('/home/azullbiz/public_html/cisin/wp-content/azull-location-list.xls', 'w+');
    fputcsv($file, array('', 'Place/Location', 'Region', 'Country'));
            $sno=1;
  foreach ($places as $key => $val) {
    $place_meta = get_option('azull_taxonomy_meta_' . $val->term_id);
    if(isset($place_meta['country']) && $place_meta['country']!=0){
      $country_term = get_term_by('id', $place_meta['country'], 'country');
    }
    if(isset($place_meta['region']) && $place_meta['region']!=0){
      $region_term = get_term_by('id', $place_meta['region'], 'region');
    }
   $row = array($sno,qtranxf_use(qtranxf_getLanguage(), $val->name),qtranxf_use(qtranxf_getLanguage(), $region_term->name),qtranxf_use(qtranxf_getLanguage(), $country_term->name));
        fputcsv($file, $row);
        $sno++;
  }
  fclose($file);
  print('<pre>');print_r($places);die;*/


  
  $big = 999999999; // need an unlikely integer
  $paged = ( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1;
  $str = 0; 
  $end = 10;
  if($paged>1){
      $str = ($end*$paged)-$end;
  }
  $weather_info_data = get_option('weather_info');
  $searchkey = (isset($_GET['searchkey']) && $_GET['searchkey'] !='')?$_GET['searchkey']:'';
  $tmp = array();
  if(!empty($searchkey)){
    foreach ($weather_info_data as $key => $val) {
      if(stripos(strtolower($val['name']),strtolower($searchkey)) !== false)
      {
        $tmp[$key] = $val;
      }
    }
    $weather_info_data = $tmp;
  }
//print('<pre>');print_r($weather_info_data);die;
  $order = (isset($_GET['order']) && $_GET['order'] =='asc') ? 'desc' : 'asc';
  sortBy('name',$weather_info_data,$order);
  //print('<pre>');print_r($weather_info_data);die;
  $smeta_obj = new Azull_Seo_Meta();
  $obj_subsciber = new Azull_Subscriber();
  $languages = qtranxf_getSortedLanguages();
  ?>
  <div class="wrap">
    <h2><?php echo $obj_subsciber->getTranslatedString('en','nl','Weather Info'); ?> List</h2>
    <ul class="qtranxs-lang-switch-wrap"><li lang="en" class="qtranxs-lang-switch" id="qtranxs_lang_en" onclick="weatherinfolist_switch_lang('en');"><img src="<?php echo plugins_url(); ?>/qtranslate-x/flags/gb.png"><span>English</span></li><li lang="fr" class="qtranxs-lang-switch" id="qtranxs_lang_fr" onclick="weatherinfolist_switch_lang('fr');"><img src="<?php echo plugins_url(); ?>/qtranslate-x/flags/fr.png"><span>Français</span></li><li lang="nl" class="qtranxs-lang-switch" id="qtranxs_lang_nl" onclick="weatherinfolist_switch_lang('nl');"><img src="<?php echo plugins_url(); ?>/qtranslate-x/flags/nl.png"><span>Nederlands</span></li></ul>
    <form id="posts-filter" method="get" action="<?php echo get_admin_url(); ?>admin.php">
      <div class="tablenav top" style="margin:-18px 0 4px;">
        <p class="search-box">
          <input type="hidden" id="post-search-input" name="page" value="weatherinfo">
          <label class="screen-reader-text" for="post-search-input">Zoeken:</label>
          <input type="search" id="post-search-input" name="searchkey" value="<?php echo $_GET['searchkey']; ?>">
          <input type="submit" id="search-submit" class="button" value="Zoeken">
        </p>
      </div>
    </form>
  <?php
  echo '<style>table.wp-list-table tr:nth-child(even) {background-color: #f2f2f2}</style>';
  $html='<div class="nosubsub">
  <div id="ajax-response"></div>
  <div id="col-container">
  <div id="">
  <div class="">
  <table class="wp-list-table widefat fixed striped tags table" width="100%" >
    <thead>';
      foreach($languages as $lang){
        $html .='<tr class="weatherinfolist_lang_'.$lang.'" '.(($lang != 'nl') ? 'style="display:none"' : '').'>
          <th width="40%" class="manage-column column-name column-primary sortable '.$order.'"><a href="'.get_admin_url() . 'admin.php?page=weatherinfo&amp;order='.$order.'">
    <span>'.$obj_subsciber->getTranslatedString('en',$lang,'Visible Place Name').'  </span><span class="sorting-indicator"></span></a></th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Place').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Region').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Country').'</th>
        </tr>';
      }
    $html .= '</thead><tbody id="the-list" data-wp-lists="list:tag">';
    if (!empty($weather_info_data)) {
      $totalRcrd = 0;
      $i=0;
      foreach ($weather_info_data as $place => $val) {
        if($totalRcrd >= $str && $end > $i){
          $place_meta = get_option('azull_taxonomy_meta_' . $val['place']);
          if(isset($place_meta) && !empty($place_meta) && count($place_meta)>0){
            if(isset($place_meta['country']) && $place_meta['country']!=0){
              $country_term = get_term_by('id', $place_meta['country'], 'country');
            }
            if(isset($place_meta['region']) && $place_meta['region']!=0){
              $region_term = get_term_by('id', $place_meta['region'], 'region');
            }
          }
          $place_term = get_term_by('id', $val['place'], 'place');
          foreach($languages as $lang){
            $html .= '<tr class="weatherinfolist_lang_'.$lang.'" '.(($lang != 'nl') ? 'style="display:none"' : '').'><td class="name column-name has-row-actions column-primary" data-colname="Name"><strong><a class="row-title" href="javascript:void();" onclick="return editweatherinfo(\''.base64_encode($val['place']).'\')" title="Edit">'.$val['vpn'][$lang].'</a></strong><br>
              <div class="row-actions">'; 
               $html .= '<span class="edit"><a href="javascript:void();" onclick="return editweatherinfo(\''.base64_encode($val['place']).'\')">Edit</a></span>&nbsp;|&nbsp;<span class="delete"><a href="javascript:void();" onclick="return deleteweatherinfo(\''.base64_encode($val['place']).'\')">'.__('Delete', 'azull').'</a></span></td>
              <td>'.$smeta_obj->getTranslatedTerm($lang,$place_term->name).'</td>
              <td>'.$smeta_obj->getTranslatedTerm($lang,$region_term->name).'</td>
              <td>'.$smeta_obj->getTranslatedTerm($lang,$country_term->name).'</td>
              </tr>';
          }
          $i++;
        }
        $totalRcrd++;
      }
    }else{
      $html .= '<tr><td colspan="5" align="center">'.$obj_subsciber->getTranslatedString('en','nl','Nothing Found').'</td></tr>';
    }
    $totalpages = ceil($totalRcrd/$end);
    $html .= '</tbody>
    <tfoot>';
      foreach($languages as $lang){
        $html .='<tr class="weatherinfolist_lang_'.$lang.'" '.(($lang != 'nl') ? 'style="display:none"' : '').'>
          <th width="40%" class="manage-column column-name column-primary sortable '.$order.'"><a href="'.get_admin_url() . 'admin.php?page=weatherinfo&amp;order='.$order.'">
    <span>'.$obj_subsciber->getTranslatedString('en',$lang,'Visible Place Name').'  </span><span class="sorting-indicator"></span></a></th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Place').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Region').'</th>
          <th width="20%">'.$obj_subsciber->getTranslatedString('en',$lang,'Country').'</th>
        </tr>';
      }
      $totalRcrd = (isset($totalRcrd))?$totalRcrd:0;
    $html .='</tfoot>
  </table>
    <div class="tablenav bottom">
      <div class="tablenav-pages one-page"><span class="displaying-num">'.$totalRcrd.' '.__("items",'azull').'</span>
  '.paginate_links( array(
    'base' => str_replace('#038;','',str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) )),
    'format' => '?paged=%#%',
    'current' => max( 1, $paged),
    'mid-size' => 1,
    'prev_next' => True,
      'prev_text' => __( '«' ),
      'next_text' => __( '»' ),
    'total' => $totalpages
  ) ).'
  </div>
  </div>
  </div>
  </div>';
  echo $html;
   ?>
    </div>
    <script>
      function editweatherinfo(val){
        jQuery("#dvLoading").show();
        jQuery("#wpwrap").css({"opacity":0.3});
        if(val){
        jQuery.ajax({
           type: "POST",
           url: ajaxurl,
           data: {action: 'get_place_weather_info',place_id:val},
        }).done(function(response) {
          response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
          if(response.vpn){
            jQuery.each(response.vpn, function( key, value ) {
               jQuery('#visible_place_name_'+key).val(value)
            });
          }
          if(response.clients){
            jQuery('select[name="client[]"] option').each(function(key,val){
               if(jQuery.inArray( val.value, response.clients) != -1){
                  jQuery('select[name="client[]"]')[0].sumo.selectItem(key);
               }else{
                  jQuery('select[name="client[]"]')[0].sumo.unSelectItem(key);
               }
            });
          }else{
            jQuery('select[name="client[]"] option').each(function(key,val){
                  jQuery('select[name="client[]"]')[0].sumo.unSelectItem(key);
            });
          }
          if(response.place_meta){
            if(response.place_meta['country']){
              jQuery("#property_meta_country").val(response.place_meta['country']);   
            }
            if(response.place_meta['region']){
              jQuery("#property_meta_region").val(response.place_meta['region']);
              jQuery( "#property_meta_region" ).trigger( "change" ); 
            }
            setTimeout(function() {
              jQuery("#property_meta_place").val(response.place);
            }, 800);
            jQuery("#loc_trans_frm_head").html(response['edit_frm_title']);
          }
          jQuery("#dvLoading").hide();
          jQuery("#wpwrap").css({"opacity":1});
        });
      }
    }
    function deleteweatherinfo(val){
      if (confirm('Are you sure, you want to delete this record?')) {
        var data = {
          'action': 'delete_weather_info',
          'place_id' : val
        }; 
        jQuery.post(ajaxurl, data, function(response) {
          response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
          if(response.error==1){
            jQuery('#msg_box').html(response.msg);
          }else{
            location.reload();
          }
        });
      }
      return false;
    }
    var default_lang = 'nl';
    weatherinfolist_switch_lang(default_lang);
    function weatherinfolist_switch_lang(lang) {
    <?php foreach ($languages as $lang): echo "jQuery('.weatherinfolist_lang_{$lang}').hide();";
    endforeach;
    ?>
      jQuery('.weatherinfolist_lang_' + lang).show();
      jQuery('.qtranxs-lang-switch').removeClass("active");
      jQuery('#qtranxs_lang_' + lang).addClass('active');
    }
  </script>
    <?php
    echo '<style>
    #dvLoading {
        background: url(images/ajax-loader.gif) no-repeat scroll center center #000;
        color: white;
        height: 140px;
        left: 43%;
        margin: -25px 0 0 -25px;
        opacity: 1;
        position: fixed;
        top: 50%;
        width: 250px;
        z-index: 1000;
    }
    </style>';
    $default_lang = "nl";
    $languages = qtranxf_getSortedLanguages();
    echo '<div class="">
    <span id="msg_box"></span><div class="postbox" style="margin: 15px 0 10px;padding: 10px;"><h3 class="hndle ui-sortable-handle" style="margin-top:5px;"><span id="loc_trans_frm_head">'.$obj_subsciber->getTranslatedString('en','nl','Add').' '.$obj_subsciber->getTranslatedString('en','nl','Weather Info').'</span></h3><div style="margin: 5px;text-align: right;" class="epc_language-switcher inside">';
    echo "&nbsp;|&nbsp;";
    foreach ($languages as $lang) {
        echo "<a href=\"javascript:weatherinfo_switch_lang('$lang')\" id=\"active_lang_$lang\"  title=\"" . qtranxf_getLanguageName($lang) . "\">" . qtranxf_getLanguageName($lang) . "</a>&nbsp|&nbsp;";
    }
    echo '</div><form method="post" id="weather-info">';
    echo location_filter($languages);
    
    
    $html1 ="<table class='property_meta_location'>";
    $html1 .= "<tr>";
    $html1 .="<th><label for=''>" . $obj_subsciber->getTranslatedString('en','nl','Client visibility') . "</label> </th>";
    $html1 .= "<td>";
    global $wpdb;
    $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft'");
    $html1 .= '<select style="min-height: 26px; width: 460px" class="SlectBox" name="client[]" multiple>';
    $html1 .= '<option value="" disabled selected>' . __('Select site', 'azull') . '</option>';
    foreach ($datas as $data) {
       if (isset($data->post_title)) {
          $sitename = explode(']', $data->post_title);
          $sitename = explode('[', $sitename[1]);
          $sitename = $sitename[0];
       }
       $html1 .= "<option value='" . $data->ID . "'>" . qtranxf_use(qtranxf_getLanguage(), $data->post_title) . "</option>";
    }
    $html1 .= "</select><br>";
    $html1 .= "<span class='description'>" . __('Select one or more clients website.', 'azull') . "</span>";
    $html1 .= "</td>";
    $html1 .= "</tr>";
    $html1 .="<tr><th width='20%'><label for='visible_place_name'>" .$obj_subsciber->getTranslatedString('en','nl','Visible Place Name'). "</label> </th>";
    $html1 .= "<td width='80%'>";
    foreach($languages as $lang){
      $html1 .="<span id='weatherinfo_language_".$lang."'  ".(($lang != 'nl') ? 'style="display:none"' : '')."><input type='text' name='visible_place_name[".$lang."]' id='visible_place_name_".$lang."' value='' placeholder='Visible Place Name' class='w50per' data-lang='".$lang."'/></span>";
    }
    $html1 .= "</td></tr></table>";
?>

    <script type="text/javascript">//<![CDATA[
        var default_lang = 'nl';
        weatherinfo_switch_lang(default_lang);
        function weatherinfo_switch_lang(lang) {
    <?php foreach ($languages as $lang): echo "jQuery('#weatherinfo_language_{$lang}').hide();";
    endforeach;
    ?>
            jQuery('#weatherinfo_language_' + lang).show();
            jQuery(".epc_language-switcher a").css("font-weight", "normal");
            jQuery('#active_lang_' + lang).css("font-weight", "bold");
        }
        //]]>
    </script>
    <?php
$html1 .= '<button type="button" onclick="save_weather_info(this.value)" class="button button-primary" value="1">Save</button></form></div></div></div>';?>
<script>
function save_weather_info(val){
   jQuery("#dvLoading").show();
   jQuery("#wpwrap").css({"opacity":0.3});
   var vpn = {};
   var place = jQuery("#property_meta_place").val();
   jQuery('input[name^="visible_place_name"]').each(function(i, v) {
      var lang = jQuery(this).data('lang');
      vpn[lang] = jQuery('#visible_place_name_'+lang).val();
   });
   jQuery.ajax({
      type: "POST",
      url: ajaxurl,
      data: {action: 'save_weather_info',place_id:place,vpn_val:vpn,clients:jQuery('select[name="client[]"]').val()},
   }).done(function(response) {
     response = typeof response != 'object' ? jQuery.parseJSON(response) : response;
     jQuery('#msg_box').html(response.msg);
     jQuery("#dvLoading").hide();
     jQuery("#wpwrap").css({"opacity":1});
     if(response.error == 0){
        location.reload();
     }
   });
}
</script>
<?php
    echo $html1;
}
/*
* Date: 22-Dec-2016
* Method: Function for sort associative array
*/
function sortBy($field, &$array, $direction = 'asc')
{
  usort($array, create_function('$a, $b', '
    $a = $a["' . $field . '"];
    $b = $b["' . $field . '"];
    if ($a == $b)
    {
      return 0;
    }
    return ($a ' . ($direction == 'desc' ? '>' : '<') .' $b) ? -1 : 1;
  '));
  return true;
}
/*
* Date: 23-Dec-2016
* Method: Function for get list of azull sites to select as main website
*/
function get_main_sites_list() {
  global $post, $wpdb;
  $val = array();
  $val = get_post_meta($post->ID, "_main_site", true);
  $datas = $wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_type = 'azull_site' and post_status ='draft' ORDER BY post_title ASC");
  $html .= "<th valign='top' scope='row'><label>" . __('Main Website:', 'azull') . "</label></th>";
  $html .= "<td>";
  $html .= '<select style="min-height: 26px; width: 180px" class="SlectBox" name="main_website">';
  $html .= '<option value="" selected>' . __('Select site', 'azull') . '</option>';
  foreach ($datas as $data) {
     if (isset($data->post_title)) {
        $sitename = explode(']', $data->post_title);
        $sitename = explode('[', $sitename[1]);
        $sitename = $sitename[0];
     }
    $selected = (isset($val) && $val == $data->ID)?'selected':'';
    $html .= "<option value='" . $data->ID . "' " .$selected. ">" . qtranxf_use(qtranxf_getLanguage(), $data->post_title) . "</option>";
  }
  $html .= "</select><br>";
  $html .= "<span class='description'>" . __('Select main website.', 'azull') . "</span>";
  $html .= "</td>";
  $html .='</tr>';
  return $html;
}


function post_published_notification( $ID, $post ) {
  global $wpdb;
  $postData=get_post($ID,ARRAY_A);
  $title=$postData['post_name'];
  $wpdb->query("update wp_posts set post_name='".$title."' where ID=".$ID);  
}
add_action( 'publish_post', 'post_published_notification', 10, 2 );
function post_saved_notification( $ID, $post ) {
  global $wpdb;
  $postData=get_post($ID,OBJECT);
    if($postData->post_title!='Auto Draft') { 
     if(empty(get_post_meta($postData->ID,'countkey',true))){  
      update_post_meta($postData->ID,'countkey',1);
      $existing_post_title=$postData->post_title;
      $nl_exist = strpos($existing_post_title,"[:nl]");
        if($nl_exist !== false){
          $nl_txt = qtranxf_use('nl', $postData->post_title);
          $nl_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($nl_txt));
            if(isset($nl_slug) && !empty($nl_slug)){
              $cust_title_nl = rtrim($nl_slug,"-");
            }
        }
      $en_exist = strpos($existing_post_title,"[:en]");
        if($en_exist !== false){
          $en_txt = qtranxf_use('en', $postData->post_title);
          $en_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($en_txt));
          if(isset($en_slug) && !empty($en_slug)){
             $cust_title_en  = rtrim($en_slug,"-");
          }
      }
      $fr_exist = strpos($existing_post_title,"[:fr]");
        if($fr_exist !== false){
          $fr_txt = qtranxf_use('fr', $postData->post_title);
          $fr_slug = preg_replace('/[^A-Za-z0-9-]+/', '-', strtolower($fr_txt));
          if(isset($fr_slug) && !empty($fr_slug)){
            $cust_title_fr  = rtrim($fr_slug,"-");
          }
        }
        if($cust_title_nl !=''){
          $title =$cust_title_nl;
        }else if($cust_title_fr !=''){
          $title =$cust_title_fr;
        }else{
          $title =$cust_title_en;
        }
      $wpdb->query("update wp_posts set post_name='".$title."' where ID=".$ID);
    }
    else{
       $title=$postData->post_name;
       $wpdb->query("update wp_posts set post_name='".$title."' where ID=".$ID);
    } 
 }
}
add_action( 'save_post', 'post_saved_notification', 10, 2 );

function auto_featured_image() {
   global $post;
   // echo '<pre>';
   // print_r($post);
    //die('tes');

    if (!has_post_thumbnail($post->ID)) {
        $attached_image = get_children( "post_parent=$post->ID&amp;post_type=attachment&amp;post_mime_type=image&amp;numberposts=1" );
         
      if ($attached_image) {
              foreach ($attached_image as $attachment_id => $attachment) {
                   set_post_thumbnail($post->ID, $attachment_id);
              }
         }
    }
}
// Use it temporary to generate all featured images
add_action('the_post', 'auto_featured_image');

/*funciton to get genrate title and content*/
function getTitleContent($post_id,$lang){
   
  $te_koop_in_arr = array(
  'en'=>'for sale in',
  'fr'=>'à vendre à',
  'nl'=>'te koop in'
  );
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);
  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($countryName && $countryName==$key) $countryName = $value[$lang];
    if($regionName && $key==$regionName) $regionName = $value[$lang];
    if($cat_name==$key) $cat_name = $value[$lang];
    if($place==$key) $place = $value[$lang];
  }
  $titleCnt =  ucwords($cat_name).' '.$te_koop_in_arr[$lang].' '.ucwords($place).', '.ucwords($regionName).', '.ucwords($countryName);
  if($titleCnt){
    return $titleCnt;
  }else{
    return false;
  }
  
}

/*Rename Image name
  Date:- 16/02/2017
*/
function updatePropertyGalerryImage($post_id){
  $nbrlid=get_post_meta($post_id,'_nreal_id');
    $nbId=$nbrlid[0];
  //echo '<br>'.$post_id."---nbrl---".$nbId."============================<br>";
  $path='/var/www/html/azulllive/';
  $cat=get_the_category($post_id);
  $cat_name=$cat[0]->cat_name;
  $countryName = $regionName = $country= $region='';
  $country=get_post_meta($post_id,'_country');  
  $region=get_post_meta($post_id,'_region');
  $place=get_post_meta($post_id,'_place');
  $country=$country[0];
  $place=$place[0];
  $region=$region[0];
  $countryName = get_termName($country);
  $place = get_termName($place);
  $regionName = get_termName($region);

  $all_terms = get_option('qtranslate_term_name');
  foreach ($all_terms as $key => $value) {
    if($country && $country==$key) $countryName = $value['nl'];
    if($region && $region==$key) $regionName = $value['nl'];
    if($cat_name==$key) $cat_name = $value['nl'];
    if($place==$key) $place = $value['nl'];
  }

 //echo $cat_name;
  //echo $cat_name.'00000000'.$place."----<br>";
  /*refId*/
  $refid=get_post_meta($post_id,'_nreal_id');

$postName =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",strtolower($countryName));
  

  global $wpdb; 
  $table_name='wp_posts';
  /*/update post name*/       
  $wpdb->query("UPDATE $table_name SET  post_name='$postName' WHERE ID=$post_id");


  $values = get_post_custom($post_id);
    if (isset($values['property_gallery']))
       $ids = json_decode(base64_decode($values['property_gallery'][0]));
    else
    $ids = array();
    $f_img = get_post_thumbnail_id($post_id);

    if (!empty($ids) && !in_array($f_img, $ids)) {
       $ids[] = $f_img;
    }
    

    $prvmainFileA='';
    $uploadPrath=wp_upload_dir();
    $basedir=$uploadPrath['basedir'];
    $subdir=$uploadPrath['subdir'];

    //echo '<pre>';print_r($ids);
    //die;////////
  /* run for all post attachment id*/ 
  $i=0; 
  $temp=false;
 if(isset($ids) && !empty($ids)){ 
  
  foreach ($ids as $atchid) {
      $addedFilesNames=array('');
      foreach ($ids as $atID) {
       $addedFilesNames[] = get_attached_file($atID);
      }
    //echo '<br>postId-----'.$post_id.'<br> attchID-----'.$atchid."--cnt--------".$i."<br><br><br>";

        $name =  $refid[0].'-'.ucwords($cat_name).'-te-koop-'.str_replace(" ","-",ucwords($place)).'-'.str_replace(" ","-",ucwords($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;
        $postname =  $refid[0].'-'.strtolower($cat_name).'-te-koop-'.str_replace(" ","-",strtolower($place)).'-'.str_replace(" ","-",strtolower($regionName)).'-'.str_replace(" ","-",ucwords($countryName)).'-'.$i;

        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
  
        $arrayPath= explode('uploads', $pathName['dirname']);
        $pathsubDir= $arrayPath[1];
        $filepath = $basedir.$pathsubDir;

          /* get post data */   
          $pData=get_post($atchid);
          $guid=$pData->guid;
          $newguid=explode('/', $guid);
          $newguid1=array_reverse($newguid);
          $prvName=$newguid1[0];
          $extname = explode('.',$newguid1[0]);
          $ext = end($extname);
          $newguid1[0]=$name.'.'.$ext;
          $newguid2=array_reverse($newguid1);
          $updatedGuid=implode('/',$newguid2);
              
            /*oldFileName*/
              //$oldnamefile=$filepath.'/'.$prvName;
              //$newfile = $filepath.'/'.$name.'.'.$ext;
              //$atchData=get_post_meta($atchid,'_wp_attached_file');

  $file = get_attached_file($atchid);
  $newfileName=$pathName['dirname']."/".$name.'.'.$pathName['extension'];
  // echo  $newfileName."<br>";
   //echo '<pre>';
   //print_r($addedFilesNames)."<br>";
  if(!in_array($newfileName, $addedFilesNames)){
      $path = pathinfo($file);       
      if($path['basename']!='' && $path['basename'] != $name.'.'.$ext){
        $updatedPostID[]=$post_id.'-'.$nbId;
            //echo 'in--  ';    
                global $wpdb; 
                $table_name='wp_posts';
                /*/update post meta*/    
                //echo "UPDATE $table_name SET post_title='$name', post_name='$postname' WHERE ID=$atchid";
                //echo "<br>";   
                $wpdb->query("UPDATE $table_name SET post_title='$name', post_name='$postname' WHERE ID=$atchid");

                /* get wp_attached_file data */
                $newwp_attached_file = $path['dirname']."/".$name.".".$path['extension'];
                
                /*rename attact fileName */
                  if(file_exists($file)){
                   rename($file, $newwp_attached_file); 
                   update_attached_file( $atchid, $newwp_attached_file );
                  }
                  
              /*===end wp_attached_file */
 
               $atchData1 = get_post_meta($atchid, '_wp_attachment_metadata');
               //echo '<pre>';
               //print_r($atchData1);
               
               $mainFile=$atchData1[0]['file'];
               $mainFileA=explode('/', $mainFile);
               $mainFileA=array_reverse($mainFileA);
               $prvmainFileA=$mainFileA[0];
               $extname1 = explode('.',$mainFileA[0]);
               $ext1 = end($extname1);
               $mainFileA[0]= $name.'.'.$ext1;
               $mainFileA2=array_reverse($mainFileA);
               $updatedmainFileA=implode('/',$mainFileA2);
               $atchData1[0]['file']=$updatedmainFileA;

              /*Update attechment data*/ 
 
                $thumbnail= $atchData1[0]['sizes']['thumbnail']['file'];
                $medium= $atchData1[0]['sizes']['medium']['file'];
                $large= $atchData1[0]['sizes']['large']['file'];
                
                $pdfLarge= $atchData1[0]['sizes']['pdf-large']['file'];
                $pdfSmall= $atchData1[0]['sizes']['pdf-small']['file'];
                $printA5Large= $atchData1[0]['sizes']['print-A5-large']['file'];
                

        if($pdfLarge!='' || $pdfSmall!='' || $printA5Large!=''){
                 ///echo $atchid.'pdfin<br>';
                  
                if($pdfLarge!=''){

                    $pdfLarge = $filepath.'/'.$atchData1[0]['sizes']['pdf-large']['file'];
                    if(file_exists($pdfLarge)){
                      $atchData1[0]['sizes']['pdf-large']['file']= $name.'-.jpg';
                      rename($pdfLarge, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($pdfSmall!=''){

                  $pdfSmall = $filepath.'/'.$atchData1[0]['sizes']['pdf-small']['file'];
                    if(file_exists($pdfSmall)){
                      $atchData1[0]['sizes']['pdf-small']['file']= $name.'-.jpg';
                      rename($pdfSmall, $filepath."/".$name.'-.jpg');
                    }  
                }

                if($printA5Large!=''){

                     $printA5Large = $filepath.'/'.$atchData1[0]['sizes']['print-A5-large']['file'];
                    if(file_exists($printA5Large)){
                      rename($printA5Large, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['print-A5-large']['file']= $name.'-.jpg';
                      
                    }  
                }


                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                     rename($thumbnail, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-small.jpg';
                      
                    }  
                }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                      rename($medium, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['medium']['file']= $name.'-medium.jpg';
                      
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                     rename($printA5Large, $filepath."/".$name.'-.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-.jpg';
                      
                    }  
                }    
             }else{
                    
                if($thumbnail!=''){
                    
                    $thumbnail = $filepath.'/'.$atchData1[0]['sizes']['thumbnail']['file'];
                    if(file_exists($thumbnail)){
                      rename($thumbnail, $filepath."/".$name.'-150x150.jpg');
                      $atchData1[0]['sizes']['thumbnail']['file']= $name.'-150x150.jpg';
                    }  
                  }

                if($medium!=''){

                   $medium = $filepath.'/'.$atchData1[0]['sizes']['medium']['file'];
                    if(file_exists($medium)){
                      rename($medium, $filepath."/".$name.'-300x169.jpg');
                       $atchData1[0]['sizes']['medium']['file']= $name.'-300x169.jpg';
                    }  
                }

                if($large!=''){
                    $large = $filepath.'/'.$atchData1[0]['sizes']['large']['file'];
                    if(file_exists($large)){
                      rename($large, $filepath."/".$name.'-1024x576.jpg');
                      $atchData1[0]['sizes']['large']['file']= $name.'-1024x576.jpg';
                    }  
                }
                
             }         
                      
             $updatedAttachData=serialize($atchData1);
             $atchData1=unserialize($updatedAttachData);
             //echo '<pre>';
            //print_r($atchData1);
           
          $table_name1='wp_postmeta';
            global $wpdb;
            $wpdb->query("DELETE FROM $table_name1 WHERE post_id = $atchid AND meta_key ='_wp_attachment_metadata'");
             
            $wpdb->query("INSERT INTO $table_name1 (post_id,meta_key,meta_value) VALUES ('$atchid', '_wp_attachment_metadata', '$updatedAttachData')");

            $wpdb->query("UPDATE $table_name1 SET meta_value='$name' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");  
        }else{
              global $wpdb;
              $table_name='wp_posts';
              $table_name1='wp_postmeta';
              $fileDirectory = get_attached_file($atchid);
              $pathName = pathinfo($fileDirectory);
              $altName=$pathName['filename'];
              $wpdb->query("UPDATE $table_name1 SET meta_value='$altName' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");
              $wpdb->query("UPDATE $table_name SET post_title='$altName' WHERE ID=$atchid");
        }
        
      }else{
        //echo "id:-".$atchid;
        global $wpdb;
        $table_name='wp_posts';
        $table_name1='wp_postmeta';
        $fileDirectory = get_attached_file($atchid);
        $pathName = pathinfo($fileDirectory);
        $altName=$pathName['filename'];
        /*echo "UPDATE $table_name1 SET meta_value='$altName' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'"."<br>-----";
        echo "UPDATE $table_name SET post_title='$altName' WHERE ID=$atchid"."<br>-----";;*/
        $wpdb->query("UPDATE $table_name1 SET meta_value='$altName' WHERE post_id=$atchid AND meta_key='_wp_attachment_image_alt'");
        $wpdb->query("UPDATE $table_name SET post_title='$altName' WHERE ID=$atchid");
      }
    $i++;
    //die('atch');
  }//end for attachment id
}//check atchId

}

function azull_show_blank_translation($content) {
  return "";
}
add_filter('i18n_content_translation_not_available', 'azull_show_blank_translation');

/*add_filter( 'posts_clauses', 'qtrans_fix_clauses', 999, 2 );
function qtrans_fix_clauses($clauses,$query){
  //if(is_admin()){
    global $q_config;
    $lang = $q_config['language'];    
    if($query->query_vars['orderby'] == 'title'){
      $clauses['orderby'] = "SUBSTR(post_title, IF(LOCATE('<!--:".$lang."-->',post_title),LOCATE('<!--:".$lang."-->',post_title)+10, LOCATE('[:".$lang."]',post_title)+5),
  IF(LOCATE('<!--:".$lang."-->',post_title),LOCATE('<!--:-->',post_title,LOCATE('<!--:".$lang."-->',post_title)+10) - (LOCATE('<!--:".$lang."-->',post_title)+10),
  LOCATE('[:',post_title,LOCATE('[:".$lang."]',post_title)+5) - (LOCATE('[:".$lang."]',post_title)+5))) ".$query->query_vars['order'];
    }
  //}
  return $clauses;
}*/

is_admin() && add_action( 'pre_get_posts', 'permalink_orderby', '9' );    

function permalink_orderby( $query ) 
{   
    // Nothing to do:  
    if( ! $query->is_main_query() || 'property' == $query->get( 'post_type' )  )
        return;

    $post_type = $query->get( 'post_type' );
    $orderby = $query->get( 'orderby');  
    if ($post_type != 'post')  {
      if ($orderby == "" || $orderby == 'menu_order title') {
        $query->set( 'orderby',  'post_name' );
        $query->set( 'order',  'asc' );
      }      
    }    
}

add_shortcode('azullcode','azullcode');
function azullcode($atts, $content) {
  return $content;
}

add_shortcode('azullyoutube','azullyoutube');
function azullyoutube($atts, $content) {
  return site_url('video.php?v='.$content);
}